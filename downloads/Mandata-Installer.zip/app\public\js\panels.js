// Shared panels: the task card, the task drawer, the follow-up draft editor and the email viewer.
import { api, GET, esc, $, $$, modal, toast, busy, confirmBox, promptBox, icon, avatar, dirChip, dueBadge, statusChip, priChip, dir, CLOSE,
  tipAttr, tipHead, tipLine, tipActs, tipPill, peopleTip, fullDate, dateLabel, when, ago, enc, splitList, pref, setPref, LOCALE, META, labelOf, plural, errorBox } from './ui.js';
import { S, emit, on, isMe } from './store.js';
import { mailHtml } from './mailtext.js';
import { threadFlow, deadlineBar, radar, scoreLine, heat, LEVEL } from './viz.js';

const who = (name, email) => isMe(email) ? 'Me' : name || email || 'Unknown';
const personLink = (name, email, cls = '') => email && !isMe(email)
  ? `<a class="plink ${cls}" data-person="${esc(email)}" data-tip-name="${esc(name || email)}">${avatar(name, email, 'sm', false)}<span>${esc(name || email)}</span></a>`
  : `<span class="plink ${cls}" data-tip-name="${esc(who(name, email))}" data-tip-email="${esc(email || '')}">${avatar(isMe(email) ? 'Me' : name, email, 'sm', false)}<span>${esc(who(name, email))}</span></span>`;

// ---------- card ----------
/** You told whoever asked that you have the task: shown while it is open. */
const acked = t => t.acknowledged_at && t.status === 'open';
const ackMark = t => acked(t) ? `<span class="statemark" style="--c:#2f8f7f" title="Acknowledged on ${esc(fullDate(t.acknowledged_at))}" aria-label="Acknowledged"><i>${icon('check', 9)}</i>ACK</span>` : '';
/** Forwarded: you passed it on to someone, by email or without. The task a forward made is theirs, not a forward: it
 * says where it came from in its drawer. */
export const forwarded = t => t.forwarded > 0;
const fwdMark = t => !forwarded(t) ? '' : `<span class="statemark" style="--c:#3b5bdb" title="You forwarded it on${t.forwarded > 1 ? ` ${t.forwarded} times` : ''}" aria-label="Forwarded"><i>${icon('forward', 9)}</i>FWD</span>`;
/** Followed up: how many follow-up emails you sent about it, as FOL with the count. */
export const followed = t => t.followups > 0;
const folMark = t => !followed(t) ? '' : `<span class="statemark fol" style="--c:#d9480f" title="You sent ${t.followups} follow-up email${t.followups > 1 ? 's' : ''}" aria-label="Followed up ${t.followups} time${t.followups > 1 ? 's' : ''}"><i>${icon('send', 9)}</i>FOL<b class="num">${t.followups}</b></span>`;
/** Who does it: the primary owner, and +N when others were also asked (the secondary). Asked of a group nobody named
 *  ("Dear colleagues" to a list): + alone, and its tip says others were asked too. */
const GROUP_TIP = tipHead('Also asked', 'people') + tipLine('Others: written to a group (all, colleagues or a list), no names given.');
const ownerLink = t => {
  const n = t.secondary?.length || 0, l = personLink(t.owner_name, t.owner_email);
  if (n) return `<span class="owners">${l}<span class="more-n" ${tipAttr(peopleTip('Also asked', t.secondary))}>+${n}</span></span>`;
  return t.to_group ? `<span class="owners">${l}<span class="more-n" ${tipAttr(GROUP_TIP)} aria-label="And others">+</span></span>` : l;
};
const ackChip = t => acked(t) ? `<span class="chip" title="You acknowledged it on ${esc(fullDate(t.acknowledged_at))}" style="--c:#2f8f7f">${icon('check', 10)}Acknowledged</span>` : '';
/** A button that pins the task, or unpins it; Pinned under What you did lists them. It stays in sight while the task is pinned. */
export const pinBtn = t => `<button class="tc-pin${t.pinned_at ? ' on' : ''}" data-pin="${t.id}" title="${t.pinned_at ? 'Unpin' : 'Pin'}" aria-label="${t.pinned_at ? 'Unpin' : 'Pin'}" aria-pressed="${!!t.pinned_at}">${icon('pin', 13)}</button>`;
const PRI_TIP = tipHead('High priority', 'flag') + tipActs(tipPill('See all high priority', 'data-go="#/tasks/?pri=high"', 'tasks'));
const NEW_TIP = tipHead('New') + tipLine('Found in your email and not opened yet.') + tipActs(tipPill('See all new tasks', 'data-go="#/tasks/?due=new"', 'tasks'));
const threadTip = t => tipHead('Email thread', 'thread') + tipLine(`<b>${esc(t.subject)}</b>`)
  + (t.opened_at ? tipLine(`Received ${esc(fullDate(t.opened_at))}`) : '')
  + tipActs(tipPill('Open the thread', `data-thread="${esc(t.conversation_id)}"`, 'thread'));
/** A card's news line: the latest event and when it came. A deadline event adds nothing to the due badge on the top row, so it shows none. */
function newsLine(ev) {
  if (!ev || ev.kind === 'deadline') return '';
  const k = EV[ev.kind] || EV.update;
  return `<div class="tc-news" style="--k:${k[1]}" title="${esc(ev.text + ' · ' + fullDate(ev.at))}">${icon(k[0], 11)}<span>${esc(ev.text)}</span><em>${esc(ago(ev.at))}</em></div>`;
}
/** The buttons of a task, in a pane that floats over it on hover: quick closes it as not a task, archived or done (a task between
 *  others, which is not yours to close, only as not a task or archived); pin pins it. Empty when there is nothing to show. */
export function taskActs(t, { quick = false, pin = false } = {}) {
  const q = quick && t.status === 'open';
  if (!q && !pin) return '';
  return `<div class="tc-float">${q ? `<button class="tc-done tc-notask" data-done="${t.id}" data-reason="notask" title="Not a task: the AI misread the email" aria-label="Close as not a task">${icon('ban', 13)}</button><button class="tc-done tc-arch" data-done="${t.id}" data-reason="archived" title="Archive: seen, nothing for you to do" aria-label="Archive">${icon('archive', 13)}</button>${t.direction === 'others' ? '' : `<button class="tc-done" data-done="${t.id}" title="Close as done" aria-label="Close as done">${icon('check', 13)}</button>`}` : ''}${pin ? pinBtn(t) : ''}</div>`;
}
/** A small pin after the title or in the top row, so a pinned task shows it without hovering. */
export const pinMark = t => t.pinned_at ? `<span class="pinmark" title="Pinned" aria-label="Pinned">${icon('pin', 11)}</span>` : '';
/** news: show the task's latest event (needs t.last); quick and pin: the buttons of taskActs. */
export function taskCard(t, { compact = false, news = false, quick = false, pin = false } = {}) {
  const d = dir(t.direction), ev = news && t.last && t.last.kind !== 'opened' ? t.last : null;
  return `<article class="tcard ${t.status !== 'open' ? 'closed' : ''} ${t.overdue ? 'late' : ''} ${!t.seen && t.status === 'open' ? 'unseen' : ''} ${t.pinned_at ? 'pinned' : ''}" data-task="${t.id}" style="--c:${d.color};--s:${d.soft};--i:${d.ink}">
    ${taskActs(t, { quick, pin })}
    <div class="tc-top">${dirChip(t.direction)}${t.priority === 'high' ? `<span class="pri" data-go="#/tasks/?pri=high" ${tipAttr(PRI_TIP)}>${icon('flag', 11)}</span>` : ''}${!t.seen && t.status === 'open' ? `<span class="newdot" data-go="#/tasks/?due=new" ${tipAttr(NEW_TIP)}>New</span>` : ''}${ackMark(t)}${fwdMark(t)}${folMark(t)}${pinMark(t)}<span class="sp"></span>${dueBadge(t)}</div>
    <h4>${esc(t.title)}</h4>
    ${compact ? '' : `<p>${esc(t.progress || t.detail)}</p>`}
    ${newsLine(ev)}
    ${scoreLine(t.radar) || '<div class="tc-scores none" aria-hidden="true"></div>'}
    <div class="tc-foot">${personLink(t.requester_name, t.requester_email)}<span class="arr">${icon('arrow', 12)}</span>${ownerLink(t)}</div>
    ${compact ? '' : `<div class="tc-thread" data-thread="${esc(t.conversation_id)}" ${tipAttr(threadTip(t))}>${icon('thread', 11)}<span>${esc(t.subject)}</span>${t.opened_at ? `<time>${esc(dateLabel(t.opened_at))}</time>` : ''}</div>`}
  </article>`;
}
// Clicks on cards, people, threads, emails and badges are handled once for the whole app (app.js).

// ---------- conversation ----------
/** The emails of a thread, newest first unless you chose oldest first, each folding open and shut. All shut at first;
 *  the ones marked (opened: the email that asked for the task; closed: the one that ended it) carry a tag. */
const newestFirst = () => pref('convoOrder', 'newest') !== 'oldest';
/** The newest / oldest first switch, as two icons. */
const orderToggle = () => `<span class="seg sm icons convo-order">${[['newest', 'Newest first'], ['oldest', 'Oldest first']].map(([k, l]) =>
  `<button data-order="${k}" class="${(k === 'newest') === newestFirst() ? 'on' : ''}" title="${l}" aria-label="${l}">${icon(k, 13)}</button>`).join('')}</span>`;
export function conversation(messages, { opened = '', closed = '', toggle = true, tasks = [] } = {}) {
  const pname = (name, email) => email && !isMe(email) ? `<a data-person="${esc(email)}" style="color:inherit">${esc(name || email)}</a>` : esc(isMe(email) ? 'Me' : name || email);
  const nf = newestFirst();
  const order = toggle ? `<div class="convo-bar">${orderToggle()}</div>` : '';
  const list = [...messages];
  if (nf) list.reverse();
  return `${order}<div class="convo">${list.map(m => {
    const tag = m.id === opened ? '<span class="msgtag tag-ask">Asked here</span>' : m.id === closed ? '<span class="msgtag tag-end">Closed here</span>' : '';
    // The tasks read from this email: hovering the pill lights their cards above, a click brings them into view.
    const from = tasks.filter(t => t.opened_email_id === m.id);
    const pill = from.length ? `<span class="msgtag tag-task" data-hl-tasks="${from.map(t => t.id).join(',')}" title="${esc(from.map(t => t.title).join(' · '))}">${icon('tasks', 10)}${from.length} task${from.length > 1 ? 's' : ''}</span>` : '';
    return `<details class="msg ${m.mine ? 'mine' : ''}"><summary><span class="msg-av" ${m.mine ? '' : `data-person="${esc(m.from_email)}"`}>${avatar(m.from_name, m.from_email, 'sm')}</span>
      <div class="msg-h"><div class="msg-l1"><b>${m.mine ? 'Me' : pname(m.from_name, m.from_email)}</b>${tag}${pill}<span class="sp"></span><time class="muted small" title="${esc(fullDate(m.received_at))}">${esc(when(m.received_at))}</time>
      <button class="mini" data-msg="${esc(m.id)}" title="Open in a window">${icon('out', 12)}</button></div>
      <div class="msg-to muted small">to ${(m.to || []).map(r => pname(r.name, r.email)).join(', ')}</div></div></summary>${mailHtml(m.body)}</details>`; }).join('')}</div>`;
}
// A task pill on an email: its cards light up while the pointer is on it; a click scrolls to them instead of opening the email.
const litCards = (pill, on) => {
  for (const id of pill.dataset.hlTasks.split(',')) $$(`.tcard[data-task="${id}"]`, document).forEach(c => c.classList.toggle('hl', on));
};
document.addEventListener('mouseover', e => { const p = e.target.closest?.('[data-hl-tasks]'); if (p && !p.contains(e.relatedTarget)) litCards(p, true); });
document.addEventListener('mouseout', e => { const p = e.target.closest?.('[data-hl-tasks]'); if (p && !p.contains(e.relatedTarget)) litCards(p, false); });
document.addEventListener('click', e => {
  const p = e.target.closest('[data-hl-tasks]'); if (!p) return;
  e.preventDefault(); e.stopPropagation();
  $(`.tcard[data-task="${p.dataset.hlTasks.split(',')[0]}"]`, document)?.scrollIntoView({ behavior: 'smooth', block: 'center' });
}, true);

// Newest or oldest first: remembered, and every email list on screen turns round at once, keeping what is open.
document.addEventListener('click', e => {
  const b = e.target.closest('.convo-order [data-order]');
  if (!b) return;
  const nf = b.dataset.order === 'newest';
  if (nf === newestFirst()) return;
  setPref('convoOrder', b.dataset.order);
  $$('.convo-order').forEach(s => $$('[data-order]', s).forEach(x => x.classList.toggle('on', (x.dataset.order === 'newest') === nf)));
  $$('.convo').forEach(c => [...c.children].reverse().forEach(x => c.appendChild(x)));
});

// ---------- deadline stepper ----------
// In the task pane, − and + beside the due badge move an open task's deadline a day at a time (Shift: a week). While stepping, the badge
// shows the new date; it is saved once the clicks stop. Pending dates live here, so a list that repaints keeps them.
const stepping = new Map();   // task id -> { from, to, timer }
const isoAdd = (d, n) => { const x = new Date(d + 'T00:00:00Z'); x.setUTCDate(x.getUTCDate() + n); return x.toISOString().slice(0, 10); };
const todayIso = () => { const n = new Date(); return new Date(n.getTime() - n.getTimezoneOffset() * 6e4).toISOString().slice(0, 10); };
const dayLabel = d => new Date(d + 'T12:00:00').toLocaleDateString(LOCALE, { weekday: 'short', day: 'numeric', month: 'short' });
function pendingBadge(p) {
  const n = Math.round((Date.parse(p.to) - Date.parse(p.from)) / 864e5);
  return `<span class="due pending" title="Saving in a moment: ${esc(dayLabel(p.to))}">${icon('clock', 11)}${esc(dayLabel(p.to))}<i>${n > 0 ? '+' : ''}${n} day${Math.abs(n) === 1 ? '' : 's'}</i></span>`;
}
/** The due badge, with − and + to move the deadline when the task is open and has one. */
function dueStep(t, cls = '') {
  if (t.status !== 'open' || !t.deadline) return dueBadge(t);
  const p = stepping.get(t.id);
  return `<span class="dstep ${cls}${p ? ' on' : ''}" data-step-task="${t.id}" data-deadline="${esc(t.deadline)}">`
    + `<button class="dstep-b" data-step="-1" title="One day earlier (Shift: a week)" aria-label="Deadline one day earlier">${icon('minus', 11)}</button>`
    + `<span class="dstep-v">${p ? pendingBadge(p) : dueBadge(t)}</span>`
    + `<button class="dstep-b" data-step="1" title="One day later (Shift: a week)" aria-label="Deadline one day later">${icon('plus', 11)}</button></span>`;
}
document.addEventListener('click', e => {
  const b = e.target.closest('.dstep-b');
  if (!b) return;
  e.preventDefault(); e.stopPropagation();
  const box = b.closest('.dstep'), id = Number(box.dataset.stepTask);
  const p = stepping.get(id) || { from: box.dataset.deadline, to: box.dataset.deadline };
  const step = Number(b.dataset.step) * (e.shiftKey ? 7 : 1), today = todayIso();
  let to = isoAdd(p.to, step);
  // Never into the past: + on a late task starts from today; − stops at today.
  if (step > 0 && to < today) to = today;
  if (step < 0 && to < today) { to = p.to < today ? p.to : today; }
  if (to === p.to) { box.classList.remove('nudge'); void box.offsetWidth; box.classList.add('nudge'); return; }
  clearTimeout(p.timer);
  p.to = to;
  if (p.to === p.from) { stepping.delete(id); paintStep(id); return; }   // back where it started: nothing to save
  p.timer = setTimeout(() => saveStep(id), 1300);
  stepping.set(id, p); paintStep(id);
}, true);
function paintStep(id) {
  const p = stepping.get(id);
  $$(`.dstep[data-step-task="${id}"]`).forEach(box => {
    box.classList.toggle('on', !!p);
    if (p) box.querySelector('.dstep-v').innerHTML = pendingBadge(p);
  });
  // Back to its saved deadline: the task is read once, for every box that shows it (unless stepping began again meanwhile).
  if (!p) GET('/api/tasks/' + id).then(t => !stepping.has(id) && $$(`.dstep[data-step-task="${id}"]`).forEach(box => { box.outerHTML = dueStep(t, box.classList.contains('big') ? 'big' : ''); })).catch(() => {});
}
async function saveStep(id) {
  const p = stepping.get(id);
  if (!p) return;
  stepping.delete(id);
  try {
    await api('PATCH', '/api/tasks/' + id, { deadline: p.to });
    toast(`Deadline moved to ${dayLabel(p.to)}`);
    if (drawerId === id) openTask(id);
    else paintStep(id);
  } catch (e) { toast(e.message, true); paintStep(id); }
}

/** Where the deadline comes from: the words in the email, or you. With neither there is none. */
function deadlineSource(t) {
  if (!t.deadline) return '';
  return `<div class="dl-src firm">${icon(t.deadline_source === 'user' ? 'edit' : 'mail', 13)}<div><b>${t.deadline_source === 'user' ? 'Deadline set by you' : 'Deadline from the email'}</b>${t.deadline_source === 'user' ? 'You set this date.' : t.deadline_note ? `In the email: “${esc(t.deadline_note)}”` : 'Written in the thread.'}</div></div>`;
}

// ---------- drawer ----------
let drawerId = null;
export const currentTask = () => drawerId;
export function closeTask() {
  drawerId = null;
  secRo?.disconnect(); secRo = null;
  $('#drawer').classList.remove('on');
  $$('.tcard.sel').forEach(x => x.classList.remove('sel'));
}
// The pane's tabs; the one last chosen stays chosen for the next task.
const TABS = [['overview', 'Overview', 'tasks'], ['thread', 'Thread', 'thread'], ['timeline', 'Timeline', 'pulse'], ['follow', 'Follow-up', 'mail'], ['radar', 'Radar', 'target']];
let tab = TABS.some(([k]) => k === pref('drTab', '')) ? pref('drTab', '') : 'overview';
function showTab(el, k) {
  tab = k; setPref('drTab', k);
  $$('.dr-tabs [data-tab]', el).forEach(b => { b.classList.toggle('on', b.dataset.tab === k); b.setAttribute('aria-selected', b.dataset.tab === k); });
  $$('.dr-pane', el).forEach(p => { p.hidden = p.dataset.pane !== k; });
}

/** The radar tab: the chart, then each score with the reasons that made it. */
function radarPane(t) {
  if (!t.radar) return '';
  return `<div class="rd-wrap">${radar(t.radar)}</div>
    <ul class="rd-list">${t.radar.map(a => `<li style="--k:${heat(a.v)}"><div class="rd-row"><span class="rd-num">${a.v}</span><b>${esc(a.label)}</b><span class="rd-pips set" title="${a.v} of 5. Click to set your own score; click the last lit bar again for 0">${[1, 2, 3, 4, 5].map(i => `<i class="${i <= a.v ? 'on' : ''}" data-rk="${a.k}" data-rv="${i === a.v ? 0 : i}" role="button" aria-label="Set ${esc(a.label)} to ${i === a.v ? 0 : i}"></i>`).join('')}</span><em>${a.v}/5 · ${LEVEL[a.v]}${a.set ? ` · <a data-rk="${a.k}" data-rv="" title="Give this score back to the rules (${a.rule}/5)">reset</a>` : ''}</em></div>
      <p>${a.why.map(esc).join(' · ')}</p></li>`).join('')}</ul>
    <p class="muted small">Scored by fixed rules from the deadline, the emails of the thread, Outlook's flags and who asked. No AI is used, so the scores are instant and always explained. Not right? Click the bars to set a score yourself: it is kept until you reset it.</p>`;
}

const EV = { opened: ['mail', '#3b5bdb'], update: ['pulse', '#1098ad'], deadline: ['clock', '#c8822f'], closed: ['check', '#2f8a4f'], cancelled: ['x', '#a0522d'], parked: ['pause', '#b08900'],
  reopened: ['undo', '#c8822f'], dismissed: ['ban', '#a0522d'], reviewed: ['spark', '#1864ab'], drafted: ['draft', '#3b5bdb'], followup: ['send', '#2f8f7f'], people: ['people', '#1098ad'], forwarded: ['forward', '#3b5bdb'], acknowledged: ['check', '#2f8f7f'], unacknowledged: ['undo', '#c8822f'],
  deleted: ['trash', '#c92a2a'], restored: ['undo', '#2f9e44'] };

// Kept current while open: a change from the server (mail read, a revision round) redraws the pane where it was scrolled,
// unless you are typing or choosing in it. One listener for the app's life, whichever task is open.
const editing = el => (el.contains(document.activeElement) && document.activeElement.matches('input,textarea,select,[contenteditable]'))
  || $$('input,textarea', el).some(i => i.value !== i.defaultValue) || $$('.cmenu', el).some(m => !m.hidden);
let watching = false;
function watchTasks() {
  if (watching) return;
  watching = true;
  on('tasks', () => {
    const el = $('#drawer'), id = drawerId;
    if (!id || !el.classList.contains('on') || editing(el)) return;
    const y = $('.dr-body', el)?.scrollTop || 0;
    openTask(id).then(() => { const b = drawerId === id && $('.dr-body', el); if (b) b.scrollTop = y; });
  });
}

// Only the newest opening is drawn: an older read of the same task landing late would bring back the task as it was.
let opening = 0;
export async function openTask(id) {
  drawerId = id;
  watchTasks();
  const el = $('#drawer'), k = ++opening;
  el.classList.add('on');
  $$('.tcard').forEach(x => { const on = Number(x.dataset.task) === id; x.classList.toggle('sel', on); if (on) x.classList.remove('unseen'); });
  let t;
  try { t = await GET('/api/tasks/' + id); } catch (e) { if (drawerId === id && k === opening) el.innerHTML = errorBox(e); return; }
  if (drawerId !== id || k !== opening) return;
  if (!t.seen) api('POST', `/api/tasks/${id}/seen`).then(() => emit('seen', id)).catch(() => {});
  const d = dir(t.direction);
  const binned = !!t.deleted_at, open = t.status === 'open' && !binned, others = t.direction === 'others';   // between others: not yours to close
  el.style.setProperty('--c', d.color); el.style.setProperty('--s', d.soft); el.style.setProperty('--i', d.ink);
  el.innerHTML = `
  <header class="dr-head">
    <div class="dr-chips">${dirChip(t.direction)}${statusChip(t)}${priChip(t.priority)}${ackChip(t)}
      ${t.thread ? `<span class="chip" data-thread="${esc(t.conversation_id)}" title="Open the thread" style="--c:#1098ad">${icon('mail', 10)}${t.thread.messages?.length || ''} email${t.thread.messages?.length === 1 ? '' : 's'}</span>` : ''}
      ${t.drafts.length ? `<span class="chip" data-tab="follow" title="Follow-ups and forwards drafted for this task" style="--c:#3b5bdb">${icon('draft', 10)}${t.drafts.length} draft${t.drafts.length > 1 ? 's' : ''}</span>` : ''}
      <span class="chip" data-tab="timeline" title="Go to the timeline" style="--c:#0b7285">${icon('pulse', 10)}${plural(t.events.length, 'event')}</span></div>
    <button class="iconbtn" id="drClose" title="Close (Esc)">${icon('x')}</button>
  </header>
  <div class="dr-body">
    <h2 class="dr-title">${esc(t.title)} <button class="mini" id="edTitle" title="Correct the title">${icon('edit', 12)}</button></h2>
    <p class="dr-detail">${esc(t.detail)}</p>
    <nav class="dr-tabs" role="tablist">${TABS.map(([k, l, ic]) => `<button role="tab" data-tab="${k}" class="${k === tab ? 'on' : ''}" aria-selected="${k === tab}">${icon(ic, 13)}${l}${
      k === 'follow' && t.drafts.length ? `<span class="num">${t.drafts.length}</span>` : k === 'timeline' ? `<span class="num">${t.events.length}</span>` : ''}</button>`).join('')}</nav>
    <div class="dr-pane" data-pane="overview">
    ${binned ? `<div class="stand binned"><b>${icon('trash', 12)} In the recycle bin</b>Deleted ${esc(fullDate(t.deleted_at))}. Removed for good on ${esc(fullDate(t.purge_at))}, unless you restore it or a new email about it brings it back.</div>` : ''}
    ${t.thread?.summary ? `<div class="stand">${'<b>' + icon('spark', 12) + ' What this thread is about</b>'}${esc(t.thread.summary)}</div>` : ''}
    <div class="dr-flow">${personLink(t.requester_name, t.requester_email, 'big')}<div class="dr-asks"><span>asked</span>${icon('arrow', 16)}</div>${personLink(t.owner_name, t.owner_email, 'big')}
      <button class="mini" id="edPeople" title="Correct who asked whom">${icon('edit', 12)}</button>${t.direction === 'to_me' && !isMe(t.requester_email) && !binned
        ? `<button class="mini" id="edShared" data-v="1" title="Not yours alone: asked of you among others, and someone else (or nobody) answers for it">${icon('layers', 12)}</button>` : ''}</div>
    ${t.secondary?.length ? `<div class="dr-secondary one"><span class="lbl" title="Also asked to do this task; ${esc(who(t.owner_name, t.owner_email))} is the primary owner">Secondary</span>${t.secondary.map(p => personLink(p.name, p.email, 'sec')).join('')}<button class="sec-more" type="button" hidden aria-expanded="false"></button></div>` : ''}
    ${t.direction === 'among' ? `<div class="stand among"><b>${icon('layers', 12)} Among others</b>You were asked as one of many: the email asks a group, or someone else ahead of you answers for it.${binned ? '' : ` <a id="edShared" data-v="0">It is mine to answer for</a>`}</div>` : ''}
    ${forwardLinks(t)}
    <div class="dr-due">${dueStep(t, 'big')}<button class="btn sm ghost" id="edDue">${icon('clock', 12)} ${t.deadline ? 'Change deadline' : 'Set a deadline'}</button></div>
    ${deadlineSource(t)}
    ${deadlineBar(t)}
    ${t.progress ? `<div class="stand"><b>Where it stands</b>${esc(t.progress)}</div>` : ''}
    ${t.close_note ? `<div class="stand done"><b>${t.status === 'parked' ? 'Parked by you' : t.closed_by === 'user' ? `${CLOSE[t.close_reason] ? 'Closed as ' + esc(CLOSE[t.close_reason].label.toLowerCase()) : 'Closed'} by you` : 'Closed by email'}</b>${esc(t.close_note)}</div>` : ''}
    </div>

    <div class="dr-pane" data-pane="radar">${radarPane(t)}</div>

    <div class="dr-pane" data-pane="follow">
    <section class="ai-box">
      <h3>${icon('spark', 15)} Ask the AI to follow up</h3>
      <div class="presets">${['Gentle reminder', 'Ask for a date', 'Offer help', 'Send an update', 'Ask for an extension', 'Escalate politely']
        .map(p => `<button class="pchip" data-p="${esc(p)}">${esc(p)}</button>`).join('')}</div>
      <textarea id="fuInstr" rows="2" placeholder="Anything to add? For example: mention the board meeting on Thursday"></textarea>
      <div class="btnrow"><button class="btn primary" id="fuGo" data-busy="Drafting">${icon('mail', 14)} Draft follow-up email</button>
        <span class="muted small">You review it before anything is sent.</span></div>
      ${t.status === 'open' ? `<div class="fw-hint">${icon('forward', 13)}<span>Someone else should do it? <a id="fwLink">Forward it</a>: it becomes a task you asked of them, by email or without.</span></div>` : ''}
      ${t.drafts.length ? `<div class="dr-drafts" id="drDrafts">${t.drafts.map(x => `<button class="draftline" data-draft="${x.id}">${icon(x.mode === 'forward' ? 'forward' : 'draft', 13)}<span>${esc(x.subject)}</span><em>${esc(draftState(x))} · ${esc(when(x.updated_at))}</em></button>`).join('')}</div>` : ''}
    </section>
    </div>

    <div class="dr-pane" data-pane="thread">
    ${t.thread ? `<section class="dr-sec"><h3>${icon('thread', 15)} Task flow</h3>
      <div class="tflow-wrap">${threadFlow(t.thread, { focus: t.id, width: el.clientWidth - 44 })}</div></section>
    <section class="dr-sec"><h3>${icon('mail', 15)} ${plural(t.thread.messages.length, 'email')}
        <span class="dr-xc">${orderToggle()}<span class="seg sm icons"><button data-xc="1" title="Expand all emails">${icon('expand', 13)}</button><button data-xc="0" title="Collapse all emails">${icon('collapse', 13)}</button></span>
        <button class="iconbtn sm" data-thread="${esc(t.conversation_id)}" title="Open in Threads">${icon('out', 13)}</button></span></h3>
      ${conversation(t.thread.messages, { opened: t.opened_email_id, closed: t.closed_email_id, toggle: false })}</section>` : '<div class="empty sm">The thread is not available.</div>'}
    </div>

    <div class="dr-pane" data-pane="timeline">
    <section class="dr-sec" id="drTimeline"><h3>${icon('pulse', 15)} Timeline</h3>
      <ol class="tl">${t.events.map(ev => { const [ic, c] = EV[ev.kind] || ['pulse', '#0b7285'];
        return `<li style="--c:${c}"><span class="tl-ic">${icon(ic, 12)}</span><div><p>${esc(ev.text)}</p><small>${esc(fullDate(ev.at))}${ev.email_id ? ` · <a data-msg="${esc(ev.email_id)}">Read the email</a>` : ''}${ev.kind === 'drafted' || ev.kind === 'followup' ? ' · <a data-go="#/drafts">All follow-ups</a>' : ''}</small></div></li>`; }).join('')}</ol></section>
    </div>
  </div>
  <footer class="dr-foot">
    ${binned ? `<button class="btn primary" id="doRestore">${icon('undo', 14)} Restore</button><span class="sp"></span>
      <button class="btn danger" id="doPurge">${icon('x', 14)} Delete for good</button>` : `
    ${open && others ? `<button class="btn good" id="doArchive" title="${esc(CLOSE.archived.hint)}">${icon('archive', 14)} Archive</button>
      <span class="dr-info" title="Only a task you asked for, or one asked of you, is yours to close">${icon('people', 14)} Between others: for information only. It closes when their emails show it done</span>`
      : open ? `<div class="splitbtn"><button class="btn good" id="doClose">${icon('check', 14)} Close as done</button><button class="btn good caret" id="doCloseAs" title="Close another way: archived, delegated, cancelled…" aria-haspopup="menu">${icon('down', 14)}</button>
      <div class="cmenu" id="closeMenu" role="menu" hidden>${Object.entries(CLOSE).filter(([k, r]) => k !== 'parked' && !r.auto).map(([k, r]) => `<button role="menuitem" data-reason="${k}" style="--c:${r.color}">${icon(r.icon, 14)}<span><b>Close as ${esc(r.label.toLowerCase())}</b><em>${esc(r.hint)}</em></span></button>`).join('')}</div></div>`
      : `<button class="btn" id="doReopen">${icon(t.status === 'parked' ? 'play' : 'undo', 14)} ${t.status === 'parked' ? 'Resume' : 'Reopen'}</button>`}
    ${open && !others ? `<button class="btn soft" id="doPark" title="${esc(CLOSE.parked.hint)}">${icon('pause', 14)} Park</button>` : ''}
    ${open ? `<button class="btn soft" id="doForward" title="Hand this task to someone else: forward it without any email (their task at once), or by an email the AI drafts for you to review and send">${icon('forward', 14)} Forward</button>` : ''}
    ${t.can_ack ? `<button class="btn soft" id="doAck" title="Mark that you have this task, and if you like draft an acknowledgement to ${esc(t.requester_name || t.requester_email)}">${icon('check', 14)} Acknowledge</button>` : ''}
    <span class="sp"></span>
    <div class="moremenu"><button class="btn ghost" id="doMore" title="More actions: read the source email, correct the AI" aria-haspopup="menu">${icon('more', 14)} More</button>
      <div class="cmenu right" id="moreMenu" role="menu" hidden>
        <button role="menuitem" data-msg="${esc(t.opened_email_id)}" style="--c:#3b5bdb">${icon('mail', 14)}<span><b>Read the source email</b><em>The email that asked for this task</em></span></button>
        ${open && t.acknowledged_at ? `<button role="menuitem" id="doUnack" style="--c:#c8822f">${icon('undo', 14)}<span><b>Unacknowledge</b><em>Take back the acknowledgement; the task stays open</em></span></button>` : ''}
        ${t.status !== 'dismissed' ? `<button role="menuitem" id="doReprocess" style="--c:#1864ab">${icon('spark', 14)}<span><b>Reprocess</b><em>The AI got something wrong: read the email again</em></span></button>
        <button role="menuitem" id="doDismiss" style="--c:#a0522d">${icon('ban', 14)}<span><b>Not a task</b><em>The AI misread the email: remove it from every list</em></span></button>` : ''}
        <button role="menuitem" id="doDelete" style="--c:#c92a2a">${icon('trash', 14)}<span><b>Delete</b><em>To the recycle bin: restore it from there, or it goes for good after ${esc(String(S.config?.tasks?.binDays ?? 30))} days (Del)</em></span></button>
      </div></div>`}
  </footer>`;
  $('#drClose', el).onclick = closeTask;
  showTab(el, tab);
  fitSecondary($('.dr-secondary', el));
  $$('[data-xc]', el).forEach(b => b.onclick = () => $$('.dr-pane[data-pane="thread"] details.msg', el).forEach(d => { d.open = b.dataset.xc === '1'; }));
  $$('[data-tab]', el).forEach(b => b.onclick = e => { e.stopPropagation(); showTab(el, b.dataset.tab); });
  $$('.pchip', el).forEach(b => b.onclick = () => { const ta = $('#fuInstr', el); ta.value = (ta.value ? ta.value + '. ' : '') + b.dataset.p; ta.focus(); });
  $('#fuGo', el).onclick = e => busy(e.currentTarget, async () => {
    const dr = await api('POST', `/api/tasks/${id}/followup`, { instruction: $('#fuInstr', el).value.trim() });
    openDraft(dr.id); if (drawerId === id) openTask(id);
  });
  // The pane is drawn again only while it still shows this task: closed or moved on meanwhile, it stays so.
  const patch = async (body, msg) => { try { await api('PATCH', '/api/tasks/' + id, body); if (msg) toast(`${msg}. Ctrl+Z to undo`); if (drawerId === id) openTask(id); } catch (e) { toast(e.message, true); } };
  $('#edDue', el).onclick = async () => { const v = await promptBox(t.deadline ? 'Change deadline' : 'Set a deadline', 'Deadline', { type: 'date', value: t.deadline || '' }); if (v) patch({ deadline: v }, 'Deadline set'); };
  $('#edTitle', el).onclick = async () => { const v = await promptBox('Correct the title', 'Title', { value: t.title }); if (v?.trim()) patch({ title: v.trim() }); };
  $('#edPeople', el).onclick = () => editPeople(t, patch);
  const sh = $('#edShared', el);
  if (sh) sh.onclick = () => patch({ shared: sh.dataset.v === '1' }, sh.dataset.v === '1' ? 'Moved to Among others' : 'Assigned to you');
  $('.dr-pane[data-pane="radar"]', el).onclick = e => { const b = e.target.closest('[data-rk]'); if (b) patch({ radar: { [b.dataset.rk]: b.dataset.rv === '' ? null : +b.dataset.rv } }, b.dataset.rv === '' ? 'Score given back to the rules' : 'Score set'); };
  const closeAs = async reason => {
    const r = CLOSE[reason];
    const park = reason === 'parked';
    const note = await promptBox(park ? 'Park this task' : `Close as ${r.label.toLowerCase()}`, park ? 'Why park it, or until when? (optional)' : reason === 'delegated' ? 'Who did you hand it to? (optional)' : reason === 'duplicate' ? 'Which task is the same work? (optional)'
      : reason === 'cancelled' ? 'Why is it no longer needed, or what replaced it? (optional)'
      : reason === 'outofscope' ? 'Who is handling it? (optional)' : reason === 'notask' ? 'What did the AI get wrong? (optional)' : 'A short note (optional)', { type: 'textarea', okLabel: park ? 'Park task' : 'Close task' });
    if (note !== null) patch(reason === 'notask' ? { action: 'dismiss', note } : { action: 'close', reason, note }, park ? 'Parked' : `Closed as ${r.label.toLowerCase()}`);
  };
  // The two pop-up menus of the footer (other ways to close, more actions): a click outside or on a choice shuts them.
  const dropMenu = (btn, menu) => {
    if (!btn || !menu) return () => {};
    const hide = e => { if (!e || !menu.parentElement.contains(e.target)) { menu.hidden = true; document.removeEventListener('click', hide); } };
    btn.addEventListener('click', () => { menu.hidden = !menu.hidden; if (!menu.hidden) setTimeout(() => document.addEventListener('click', hide)); });
    menu.addEventListener('click', e => { if (e.target.closest('[role=menuitem]')) hide(); });
    return hide;
  };
  const menu = $('#closeMenu', el), hideMenu = dropMenu($('#doCloseAs', el), menu);
  dropMenu($('#doMore', el), $('#moreMenu', el));
  $('#doClose', el)?.addEventListener('click', () => closeAs('done'));
  menu?.addEventListener('click', e => { const b = e.target.closest('[data-reason]'); if (b) { hideMenu(); closeAs(b.dataset.reason); } });
  $('#doReopen', el)?.addEventListener('click', () => patch({ action: 'reopen' }, t.status === 'parked' ? 'Resumed' : 'Reopened'));
  $('#doPark', el)?.addEventListener('click', () => closeAs('parked'));
  $('#doArchive', el)?.addEventListener('click', () => closeAs('archived'));
  $('#doAck', el)?.addEventListener('click', () => acknowledge(t));
  $('#doUnack', el)?.addEventListener('click', () => unacknowledge(t));
  $('#doForward', el)?.addEventListener('click', () => forwardTask(t));
  $('#fwLink', el)?.addEventListener('click', () => forwardTask(t));
  $('#doReprocess', el)?.addEventListener('click', () => reprocess(t));
  $('#doDelete', el)?.addEventListener('click', () => deleteTask(t));
  $('#doRestore', el)?.addEventListener('click', async () => { try { await api('POST', '/api/bin/restore', { ids: [id] }); toast('Restored from the recycle bin'); if (drawerId === id) openTask(id); } catch (e) { toast(e.message, true); } });
  $('#doPurge', el)?.addEventListener('click', async () => {
    if (!await confirmBox('Delete for good', `<b>${esc(t.title)}</b> is removed for good. <b class="red">This cannot be undone.</b>`, 'Delete for good')) return;
    try { await api('POST', '/api/bin/purge', { ids: [id] }); toast('Removed for good'); closeTask(); } catch (e) { toast(e.message, true); }
  });
  $('#doDismiss', el)?.addEventListener('click', async () => { if (await confirmBox('Not a task', 'Mark this as not a task? It leaves your lists and the AI will not raise it again.', 'Not a task')) patch({ action: 'dismiss' }, 'Removed'); });
}
/** Send a task to the recycle bin and close its pane. */
async function deleteTask(t) {
  try {
    await api('POST', '/api/tasks/delete', { ids: [t.id] });
    toast(`Moved to the recycle bin: ${t.title}. Ctrl+Z to undo`);
    if (drawerId === t.id) closeTask();
  } catch (e) { toast(e.message, true); }
}
// Del with a task's pane open sends it to the recycle bin (not while typing, nor with a dialog open).
document.addEventListener('keydown', e => {
  if (e.key !== 'Delete' || !drawerId || e.ctrlKey || e.metaKey || e.altKey || e.shiftKey || document.querySelector('.overlay')) return;
  if (e.target.closest?.('input,textarea,select,[contenteditable]')) return;
  if ($('#doDelete')) { e.preventDefault(); $('#doDelete').click(); }
});

/** The secondary people on one line: as many as fit, then "+N more", which unfolds the whole list (and folds it back).
 *  Measured again whenever the row changes width: the pane resizes, or its tab is shown. */
let secRo = null;   // the open pane's: the next pane, or closing it, lets it go
function fitSecondary(box) {
  secRo?.disconnect(); secRo = null;
  if (!box) return;
  const more = $('.sec-more', box), ppl = $$('.plink.sec', box);
  const fit = () => {
    if (!box?.isConnected || !box.clientWidth) return;
    ppl.forEach(p => { p.hidden = false; });
    more.hidden = true;
    if (box.classList.contains('all') || box.scrollWidth <= box.clientWidth) { more.hidden = !box.classList.contains('all'); more.textContent = 'Show less'; return; }
    more.hidden = false;
    // Hide from the end until the rest, and the button, fit; at least one name always shows.
    let n = ppl.length;
    do { ppl[--n].hidden = true; more.textContent = `+${ppl.length - n} more`; } while (n > 1 && box.scrollWidth > box.clientWidth);
    more.title = 'Also: ' + ppl.slice(n).map(p => p.textContent.trim()).join(', ');
  };
  more.onclick = e => { e.stopPropagation(); const all = box.classList.toggle('all'); more.setAttribute('aria-expanded', String(all)); fit(); };
  secRo = new ResizeObserver(fit);
  secRo.observe(box);
  fit();
}
// Escape in a field you are typing in leaves the field first: what you typed is not lost with the drawer.
document.addEventListener('keydown', e => {
  if (e.key !== 'Escape' || !drawerId || document.querySelector('.overlay')) return;
  if (e.target.closest?.('input, textarea, select, [contenteditable]')) { e.target.blur(); return; }
  closeTask();
});

/** Acknowledge a task someone else asked of you: it is marked acknowledged, and the AI drafts the reply to them only when you tick it. */
function acknowledge(t) {
  const name = esc(t.requester_name || t.requester_email), copies = t.ack_cc || [];
  const m = modal({ title: 'Acknowledge this task', size: 'small', body: `
    <p class="muted small">You confirm you have this task and will take it on. It stays open; Ctrl+Z takes it back.</p>
    <label class="tog"><input type="checkbox" id="akReply" checked><span>Draft an acknowledgement to ${name}</span></label>
    ${copies.length ? `<label class="tog" title="${esc(copies.map(r => r.email).join(', '))}"><input type="checkbox" id="akCc"><span>Copy those in copy on the task email: ${esc(copies.map(r => r.name || r.email).join(', '))}</span></label>` : ''}
    <label class="f">Anything to add to the email? (optional)</label>
    <textarea id="akNote" rows="2" placeholder="For example: I will share a first draft on Thursday"></textarea>`,
    footer: `<div class="btnrow"><button class="btn primary" id="akGo" data-busy="Acknowledging">${icon('check', 14)} Acknowledge</button>
      <span class="muted small" id="akHint">You review the email before anything is sent.</span></div>` });
  const box = $('#akReply', m.el), note = $('#akNote', m.el);
  const cc = $('#akCc', m.el);
  box.onchange = () => { note.disabled = !box.checked; if (cc) cc.disabled = !box.checked; $('#akHint', m.el).hidden = !box.checked; };
  $('#akGo', m.el).onclick = e => busy(e.currentTarget, async () => {
    const r = await api('POST', `/api/tasks/${t.id}/acknowledge`, { reply: box.checked, ccAll: !!cc?.checked, note: note.value.trim() });
    m.close(true);
    if (r.id) { openDraft(r.id); toast('Acknowledged: review the email before sending. Ctrl+Z to undo'); }
    else toast('Acknowledged. Ctrl+Z to undo');
    if (drawerId === t.id) openTask(t.id);
  });
}

/** Take an acknowledgement back; an acknowledgement email not yet sent can be discarded with it. A sent one cannot be recalled. */
function unacknowledge(t) {
  const unsent = t.drafts.filter(d => d.meta?.ack && ['draft', 'outlook'].includes(d.status));
  const sent = t.drafts.some(d => d.meta?.ack && ['sent', 'sending'].includes(d.status));
  const m = modal({ title: 'Unacknowledge this task', size: 'small', body: `
    <p class="muted small">The task is no longer marked as acknowledged. It stays open; Ctrl+Z puts the acknowledgement back.</p>
    ${unsent.length ? '<label class="tog"><input type="checkbox" id="uaDiscard" checked><span>Also discard the acknowledgement email not yet sent</span></label>' : ''}
    ${sent ? `<p class="muted small">${icon('alert', 12)} The acknowledgement email to ${esc(t.requester_name || t.requester_email)} was already sent and cannot be recalled.</p>` : ''}`,
    footer: `<div class="btnrow"><button class="btn primary" id="uaGo" data-busy="Saving">${icon('undo', 14)} Unacknowledge</button></div>` });
  $('#uaGo', m.el).onclick = e => busy(e.currentTarget, async () => {
    const r = await api('POST', `/api/tasks/${t.id}/unacknowledge`, { discard: !!$('#uaDiscard', m.el)?.checked });
    m.close(true);
    toast(`Acknowledgement taken back${r.discarded ? ' and the unsent email discarded' : ''}. Ctrl+Z to undo`);
    if (drawerId === t.id) openTask(t.id);
  });
}

// What the AI can be told it got wrong, as the server names it (REVIEW in threads.js), first letter up.
const WRONG = () => Object.entries(META.review || {}).map(([k, label]) => [k, String(label).replace(/^./, c => c.toUpperCase())]);

/** The AI read this task wrong: say what, and it reads the original email and its thread again, carefully. */
function reprocess(t) {
  const m = modal({ title: 'Reprocess this task', size: 'small', body: `
    <p class="muted small">The AI reads the original email and its thread again, told that its first reading was wrong and where. What you tick takes the new reading.</p>
    <label class="f">What is wrong?</label>
    <div class="rp-grid">${WRONG().map(([k, l]) => `<label class="tog"><input type="checkbox" value="${esc(k)}"><span>${esc(l)}</span></label>`).join('')}</div>
    <label class="f">What is right, or why it is wrong (optional, helps the AI)</label>
    <textarea id="rpNote" rows="3" placeholder="For example: it was asked of a colleague, not me. The deadline is the Friday after the email."></textarea>`,
    footer: `<div class="btnrow"><button class="btn primary" id="rpGo" data-busy="Reading again">${icon('spark', 14)} Reprocess with corrections</button>
      <button class="btn ghost" id="rpPlain" title="A task was missed: the thread is read again carefully, and tried again while nothing new is found">${icon('undo', 14)} Just read the emails again</button></div>` });
  $('#rpPlain', m.el).onclick = e => busy(e.currentTarget, async () => {
    await api('POST', '/api/reprocess', { ids: [t.id] });
    m.close(true);
    toast('Queued: the AI reads the emails of this task again carefully, looking for a missed task');
  });
  $('#rpGo', m.el).onclick = e => {
    const issues = $$('.rp-grid input:checked', m.el).map(x => x.value), note = $('#rpNote', m.el).value.trim();
    if (!issues.length && !note) return toast('Tick what is wrong, or say it in a few words', true);
    busy(e.currentTarget, async () => {
      const r = await api('POST', `/api/tasks/${t.id}/reprocess`, { issues, note });
      m.close(true);
      toast(!r.review.found ? 'The AI did not find this task again: mark it as not a task if so' : r.review.changes.length ? `Corrected: ${r.review.changes.join('; ')}` : 'The AI kept its reading: correct it by hand if it is still wrong');
      if (drawerId === t.id) openTask(t.id);
    });
  };
}

/** People are picked from the People list, never typed: the email always comes with the person chosen. */
async function editPeople(t, patch) {
  let list;
  try { list = await GET('/api/people'); } catch (e) { return toast(e.message, true); }
  const ppl = new Map();
  const add = (email, name) => { email = String(email || '').toLowerCase(); if (email && !ppl.has(email)) ppl.set(email, name || email); };
  for (const e of S.config?.me?.emails || []) add(e, `Me (${S.config.me.name || e})`);
  for (const p of list) add(p.email, p.name);
  // The task's current people stay choosable even when hidden from People.
  add(t.requester_email, t.requester_name); add(t.owner_email, t.owner_name);
  for (const p of t.secondary || []) add(p.email, p.name);
  const sorted = [...ppl].sort((a, b) => isMe(b[0]) - isMe(a[0]) || a[1].localeCompare(b[1]));
  // Unknown stays unknown: without this choice the first person (you) would be picked silently for an empty side.
  const opts = (sel, unknown = false) => (unknown ? `<option value="" ${sel ? '' : 'selected'}>Unknown</option>` : '') + sorted.map(([e, n]) => `<option value="${esc(e)}" ${e === sel ? 'selected' : ''}>${esc(n)}${n === e ? '' : ` · ${esc(e)}`}</option>`).join('');
  let sec = (t.secondary || []).map(p => String(p.email || '').toLowerCase()).filter(Boolean);
  const m = modal({ title: 'Who asked whom', size: 'small', body: `
    <label class="f">Asked by</label><select id="rq" style="width:100%">${opts((t.requester_email || '').toLowerCase(), true)}</select>
    <div class="muted small" id="rqE" style="margin-top:4px"></div>
    <label class="f">To be done by</label><select id="ow" style="width:100%">${opts((t.owner_email || '').toLowerCase(), true)}</select>
    <div class="muted small" id="owE" style="margin-top:4px"></div>
    <label class="f">Secondary: also asked to do it</label><div id="seL" style="display:flex;flex-wrap:wrap;gap:5px;margin-bottom:6px"></div>
    <select id="seA" style="width:100%"><option value="">Add a person…</option>${opts('')}</select>`,
    footer: `<div class="btnrow"><button class="btn primary ok">Save</button></div>` });
  const showEmail = (s, out) => { $(out, m.el).textContent = s.value; };
  const drawSec = () => {
    const owner = $('#ow', m.el).value;
    sec = sec.filter(e => e !== owner);
    $('#seL', m.el).innerHTML = sec.length ? sec.map(e => `<span class="chip">${esc(ppl.get(e) || e)} <a data-rm="${esc(e)}" title="Remove" style="cursor:pointer">✕</a></span>`).join('') : '<span class="muted small">Nobody</span>';
    $$('[data-rm]', m.el).forEach(a => a.onclick = () => { sec = sec.filter(e => e !== a.dataset.rm); drawSec(); });
  };
  $('#rq', m.el).onchange = e => showEmail(e.target, '#rqE');
  $('#ow', m.el).onchange = e => { showEmail(e.target, '#owE'); drawSec(); };
  $('#seA', m.el).onchange = e => { const v = e.target.value; e.target.value = ''; if (v && !sec.includes(v) && sec.length < 6) sec.push(v); drawSec(); };
  showEmail($('#rq', m.el), '#rqE'); showEmail($('#ow', m.el), '#owE'); drawSec();
  $('.ok', m.el).onclick = () => {
    const rq = $('#rq', m.el).value, ow = $('#ow', m.el).value, nm = e => !e ? '' : isMe(e) ? (S.config?.me?.name || ppl.get(e)) : ppl.get(e);
    m.close(true);
    patch({ requester_email: rq, requester_name: nm(rq), owner_email: ow, owner_name: nm(ow), secondary: sec }, 'Saved');
  };
}

// ---------- forwarding ----------
/** Where a task was forwarded from, and the tasks you made by forwarding it on: each opens its task. */
function forwardLinks(t) {
  const row = (k, lbl) => `<div class="fw-row" data-task="${k.id}" title="Open task #${k.id}: ${esc(k.title)}">${icon('forward', 12)}<span class="lbl">${lbl}</span>`
    + `${personLink(k.owner_name, k.owner_email)}${k.secondary?.length ? `<em title="${esc(k.secondary.map(p => p.name || p.email).join(', '))}">+${k.secondary.length}</em>` : ''}`
    + `<span class="sp"></span>${statusChip(k)}<em>#${k.id}</em></div>`;
  const from = t.parent ? row(t.parent, 'Forwarded from the task of') : '';
  const to = (t.forwards || []).map(k => row(k, 'Forwarded to')).join('');
  return from || to ? `<div class="fw-links">${from}${to}</div>` : '';
}

/** Forward a task to someone else: who, what to tell them, by when. Without email, it is their task at once; by email, the AI drafts the email, you review it and send it. */
async function forwardTask(t) {
  let list;
  try { list = await GET('/api/people'); } catch (e) { return toast(e.message, true); }
  const ppl = new Map();
  for (const p of list) if (p.email && !isMe(p.email)) ppl.set(p.email.toLowerCase(), p.name || p.email);
  const sorted = [...ppl].sort((a, b) => a[1].localeCompare(b[1]));
  const opts = first => `<option value="">${first}</option>` + sorted.map(([e, n]) => `<option value="${esc(e)}">${esc(n)}${n === e ? '' : ` · ${esc(e)}`}</option>`).join('');
  const mineTask = t.direction === 'to_me';
  const msgs = t.thread?.messages || [], latest = msgs.at(-1);
  const askedBy = t.requester_email && !isMe(t.requester_email) ? t.requester_name || t.requester_email : '';
  const keep = !t.deadline ? 'no deadline' : dateLabel(t.deadline);
  let sec = [];
  const m = modal({ title: 'Forward this task', size: 'small', body: `
    <p class="muted small" style="margin-top:0">${icon('forward', 12)} <b>${esc(t.title)}</b></p>
    <div class="seg sm" id="fwMode"><button data-v="assign" class="on" title="Make it their task now, without sending any email">Without email</button><button data-v="forward" title="The AI drafts an email that forwards the thread; their task is made once you send it">By email</button></div>
    <label class="f">To be done by</label><select id="fwTo" style="width:100%">${opts('Choose a person…')}<option value="*">Someone else: type the address</option></select>
    <input type="email" id="fwOther" placeholder="name@un.org" style="width:100%;margin-top:6px" hidden>
    <label class="f">Also asked (secondary)</label><div id="fwSec" class="fw-sec"></div>
    <select id="fwAlso" style="width:100%">${opts('Add a person…')}</select>
    <label class="f">Deadline for them</label><input type="date" id="fwDue" value="${esc(t.deadline || '')}" style="width:100%">
    <div class="muted small" style="margin-top:4px">Left empty, it keeps the task's: ${esc(keep)}.</div>
    ${latest && latest.id !== t.opened_email_id ? `<div data-fw="forward" hidden><label class="f">Email to forward</label><div class="seg sm" id="fwSrc"><button data-v="opened" class="on" title="The email where this task was asked">The email that asked</button><button data-v="latest" title="${esc(latest.from_name)}, ${esc(when(latest.received_at))}: it usually quotes the whole conversation">The latest email</button></div></div>` : ''}
    <label class="f" data-fw="assign">Note (optional, kept on their task)</label>
    <label class="f" data-fw="forward" hidden>What to tell them (optional, the AI writes it into the email)</label>
    <textarea id="fwNote" rows="3" placeholder="For example: you lead on this; I am away from Monday."></textarea>
    ${askedBy ? `<label class="tog" data-fw="forward" hidden><input type="checkbox" id="fwCc"><span>Copy ${esc(askedBy)}, who asked for it</span></label>` : ''}
    ${t.direction === 'others' ? '' : `<label class="tog"><input type="checkbox" id="fwClose" ${mineTask && t.status === 'open' ? 'checked' : ''}><span>Close ${mineTask ? 'my' : 'this'} task as delegated<span data-fw="forward" hidden> once it is sent</span></span></label>`}
    <p class="muted small" data-fw="assign">No email is sent: it becomes a task you asked of them at once, in Tasks, in this thread and on their profile. Tell them yourself.</p>
    <p class="muted small" data-fw="forward" hidden>Nothing is sent until you press Send. Once it is sent, it is a task you asked of them: in Tasks, in this thread and on their profile.</p>`,
    footer: `<div class="btnrow"><button class="btn primary" id="fwGo" data-busy="Forwarding">${icon('forward', 14)} Forward</button></div>` });
  const mode = () => $('#fwMode .on', m.el).dataset.v;
  $('#fwMode', m.el).onclick = e => {
    const b = e.target.closest('button');
    if (!b) return;
    $$('#fwMode button', m.el).forEach(x => x.classList.toggle('on', x === b));
    $$('[data-fw]', m.el).forEach(x => x.hidden = x.dataset.fw !== b.dataset.v);
    const go = $('#fwGo', m.el), fwd = b.dataset.v === 'forward';
    go.dataset.busy = fwd ? 'Drafting' : 'Forwarding';
    go.innerHTML = fwd ? `${icon('spark', 14)} Draft the forward` : `${icon('forward', 14)} Forward`;
  };
  const to = () => { const v = $('#fwTo', m.el).value; return v === '*' ? $('#fwOther', m.el).value.trim().toLowerCase() : v; };
  const drawSec = () => {
    sec = sec.filter(e => e !== to());
    $('#fwSec', m.el).innerHTML = sec.length ? sec.map(e => `<span class="chip">${esc(ppl.get(e) || e)} <a data-rm="${esc(e)}" title="Remove" style="cursor:pointer">✕</a></span>`).join('') : '<span class="muted small">Nobody</span>';
    $$('[data-rm]', m.el).forEach(a => a.onclick = () => { sec = sec.filter(e => e !== a.dataset.rm); drawSec(); });
  };
  $('#fwTo', m.el).onchange = e => { const o = $('#fwOther', m.el); o.hidden = e.target.value !== '*'; if (!o.hidden) o.focus(); drawSec(); };
  $('#fwAlso', m.el).onchange = e => { const v = e.target.value; e.target.value = ''; if (v && v !== to() && !sec.includes(v) && sec.length < 6) sec.push(v); drawSec(); };
  const src = $('#fwSrc', m.el);
  if (src) src.onclick = e => { const b = e.target.closest('button'); if (b) $$('button', src).forEach(x => x.classList.toggle('on', x === b)); };
  drawSec();
  $('#fwGo', m.el).onclick = e => {
    const who = to();
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(who)) return toast(who ? 'That is not an email address' : 'Choose who should do it', true);
    if (isMe(who)) return toast('Forward it to someone else', true);
    busy(e.currentTarget, async () => {
      if (mode() === 'assign') {
        const r = await api('POST', `/api/tasks/${t.id}/assign`, { people: [who, ...sec.filter(x => x !== who)], note: $('#fwNote', m.el).value.trim(),
          deadline: $('#fwDue', m.el).value, close: !!$('#fwClose', m.el)?.checked });
        m.close(true);
        toast(`Forwarded to ${ppl.get(who) || who} (no email): now task #${r.id}`);
        if (drawerId === t.id) openTask(t.id);
        return;
      }
      const dr = await api('POST', `/api/tasks/${t.id}/forward`, { people: [who, ...sec.filter(x => x !== who)], note: $('#fwNote', m.el).value.trim(),
        deadline: $('#fwDue', m.el).value, close: !!$('#fwClose', m.el)?.checked, cc: $('#fwCc', m.el)?.checked ? [t.requester_email] : [],
        source: $('#fwSrc .on', m.el)?.dataset.v || 'opened' });
      m.close(true);
      openDraft(dr.id);
      if (drawerId === t.id) openTask(t.id);
    });
  };
}

// ---------- draft editor ----------
export const draftState = d => labelOf('draft_statuses', d.status);

export async function openDraft(id) {
  let d;
  try { d = await GET('/api/drafts/' + id); } catch (e) { return toast(e.message, true); }
  const locked = ['sent', 'sending', 'discarded'].includes(d.status), fwd = d.mode === 'forward', ack = !!d.meta?.ack;
  const named = d.to.map(e => d.meta?.names?.[e] || e).join(', ').replace(/, ([^,]*)$/, ' and $1');
  const what = fwd ? `It forwards ${d.meta?.source === 'latest' ? 'the latest email of the thread' : 'the email that asked for this task'}, with its attachments. `
    + (d.made_task_id ? `It is <a data-task="${d.made_task_id}">task #${d.made_task_id}</a>, which you asked of ${esc(named)}.`
      : `Once it is sent, it becomes a task you asked of ${esc(named)}${d.meta?.close ? ', and yours is closed as delegated' : ''}.`)
    : `It replies in the task's own thread, so the answer is tracked automatically.`;
  const m = modal({ title: fwd ? (locked ? 'Forwarded email' : 'Review the forward') : ack ? (locked ? 'Acknowledgement' : 'Review the acknowledgement') : locked ? 'Follow-up email' : 'Review the follow-up', size: 'wide', body: `
    ${d.task_title ? `<div class="muted small" style="margin-bottom:6px"><a data-task="${d.task_id}" title="Open the task">${icon('tasks', 12)} ${esc(d.task_title)}</a> · <a data-go="#/drafts">All follow-ups</a></div>` : ''}
    <div class="dgrid"><label>To</label><input type="text" id="dTo" value="${esc(d.to.join('; '))}" ${locked ? 'disabled' : ''}>
    <label>Cc</label><input type="text" id="dCc" value="${esc(d.cc.join('; '))}" ${locked ? 'disabled' : ''}>
    <label>Subject</label><input type="text" id="dSub" value="${esc(d.subject)}" ${locked ? 'disabled' : ''}></div>
    <textarea id="dBody" rows="14" ${locked ? 'disabled' : ''}>${esc(d.body)}</textarea>
    ${locked ? '' : `<div class="rewrite"><input type="text" id="dInstr" placeholder="Ask the AI to change it: shorter, warmer, mention the deadline..."><button class="btn soft" id="dRe" data-busy="Rewriting">${icon('spark', 14)} Rewrite</button></div>`}
    <p class="muted small">${esc(draftState(d))}. ${what}${d.meta?.reviewed ? ` ${icon('spark', 11)} The AI read it once more against the task and the emails before you saw it${d.meta.reviewChanged ? ', and corrected it' : ''}.` : ''}</p>`,
    footer: locked ? '' : `<div class="btnrow"><button class="btn primary" id="dSend" data-busy="Sending">${icon('send', 14)} Send</button>
      <button class="btn" id="dOl" data-busy="Saving">${icon('inbox', 14)} Save to Outlook drafts</button>
      <button class="btn" id="dOpen" data-busy="Opening">${icon('out', 14)} Open in Outlook</button>
      <button class="btn danger push" id="dDel">${icon('trash', 14)} Discard</button></div>` });
  if (locked) return;
  const save = () => api('PATCH', '/api/drafts/' + id, { to: splitList($('#dTo', m.el).value), cc: splitList($('#dCc', m.el).value), subject: $('#dSub', m.el).value, body: $('#dBody', m.el).value });
  $('#dRe', m.el)?.addEventListener('click', e => busy(e.currentTarget, async () => { await save(); const n = await api('POST', `/api/drafts/${id}/rewrite`, { instruction: $('#dInstr', m.el).value }); m.close(true); openDraft(n.id); }));
  $('#dOl', m.el).onclick = e => busy(e.currentTarget, async () => { await save(); await api('POST', `/api/drafts/${id}/outlook`); toast('Saved to your Outlook Drafts'); });
  $('#dOpen', m.el).onclick = e => busy(e.currentTarget, async () => { await save(); await api('POST', `/api/drafts/${id}/open`); });
  $('#dDel', m.el).onclick = async () => { if (!await confirmBox('Discard', 'Discard this draft?', 'Discard')) return; try { await api('DELETE', '/api/drafts/' + id); } catch (e) { return toast(e.message, true); } m.close(true); toast('Discarded'); if (drawerId) openTask(drawerId); };
  $('#dSend', m.el).onclick = async e => {
    const to = splitList($('#dTo', m.el).value);
    if (!await confirmBox('Send this email?', `It goes to <b>${esc(to.join(', '))}</b>${splitList($('#dCc', m.el).value).length ? ' with copies' : ''} through your Outlook, now.`, 'Send')) return;
    busy(e.target.closest('button'), async () => { await save(); await api('POST', `/api/drafts/${id}/send`, { confirm: true }); m.close(true); toast(fwd ? `Sent. It is now a task you asked of ${to.join(', ')}` : 'Sent'); if (drawerId) openTask(drawerId); });
  };
}

// ---------- email viewer ----------
export async function openEmail(emailId) {
  let msg;
  try { msg = await GET('/api/emails/' + enc(emailId)); } catch (e) { return toast(e.message, true); }
  const list = r => r.map(x => x.email && !isMe(x.email) ? `<a data-person="${esc(x.email)}">${esc(x.name || x.email)}</a>` : esc(x.name || x.email)).join(', ');
  const from = msg.from_email && !isMe(msg.from_email) ? `data-person="${esc(msg.from_email)}"` : '';
  const m = modal({ title: msg.subject, size: 'wide', body: `<div class="mailhead"><span ${from}>${avatar(msg.from_name, msg.from_email)}</span><div><b><a ${from} style="color:inherit">${esc(msg.from_name)}</a></b> <span class="muted">&lt;${esc(msg.from_email)}&gt;</span>
      <div class="muted small">To ${list(msg.to)}${msg.cc.length ? ` · Cc ${list(msg.cc)}` : ''}</div><div class="muted small">${esc(fullDate(msg.received_at))}${msg.attachments.length ? ` · ${icon('mail', 11)} ${esc(msg.attachments.join(', '))}` : ''}</div></div></div>
    ${mailHtml(msg.body)}`,
    footer: `<div class="btnrow"><button class="btn" id="eOl">${icon('out', 14)} Open in Outlook</button>${msg.conversation_id ? `<button class="btn ghost" data-thread="${esc(msg.conversation_id)}">${icon('thread', 14)} Whole thread</button>` : ''}</div>` });
  $('#eOl', m.el).onclick = () => api('POST', `/api/emails/${enc(emailId)}/open`).catch(e => toast(e.message, true));
}
