@echo off
rem Removes Mandata for this Windows user. Asks before deleting your data or the local AI.
rem It hands over to a copy of itself in %TEMP% first, so the app's folder (where a copy of this file is kept for
rem Settings > Apps) can be deleted while it runs.
title Uninstall Mandata
set "RUN=%TEMP%\Mandata-uninstall"
if defined MANDATA_UNINSTALL_COPY goto run
set "SRC=%~dp0scripts"
if not exist "%SRC%\uninstall.ps1" set "SRC=%~dp0."
if exist "%RUN%" rd /s /q "%RUN%"
mkdir "%RUN%"
copy /y "%SRC%\*.ps1" "%RUN%" >nul
copy /y "%~f0" "%RUN%\uninstall.bat" >nul
set "MANDATA_UNINSTALL_COPY=1"
"%RUN%\uninstall.bat" %*

:run
cd /d "%RUN%"
powershell -NoProfile -ExecutionPolicy Bypass -File "%RUN%\uninstall.ps1" %*
echo.
pause
