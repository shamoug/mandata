// Drawings, all plain SVG: the thread flow (tasks branching off the emails that opened them and merging back where an
// email closed them), the flow of who tasks whom, weekly bars, a donut, and the deadline bar.
import { esc, dir, colorOf, initials, dateLabel, STATUS, firstName, LOCALE, monthLabel } from './ui.js';

const trunc = (s, n) => { s = String(s || ''); return s.length > n ? s.slice(0, n - 1) + '…' : s; };

/**
 * The thread as a subway map. The top line is the conversation, one stop per email. Each task branches off at the
 * email that opened it and runs on its own lane; it merges back at the email that closed it, or runs on to "now"
 * (dashed past its deadline) while still open.
 */
export function threadFlow(thread, { focus = null, width = 0 } = {}) {
  const msgs = thread.messages || [], tasks = thread.tasks || [];
  if (!msgs.length) return '';
  // The drawing fills the width it is given: stops spread out on a short thread and squeeze together on a long one;
  // a very long thread is then scaled down, never scrolled.
  const left = 34, top = 44, lane = 54, endZone = 96, n = Math.max(1, msgs.length);
  const W = Math.max(width > 0 ? width : 0, left + n * 30 + endZone, 360);
  const col = Math.max(30, Math.min(150, (W - left - endZone) / n));
  const nowX = W - 52, laneTop = top + 26, H = laneTop + Math.max(1, tasks.length) * lane + 6;
  const idx = new Map(msgs.map((m, i) => [m.id, i]));
  const xAt = i => left + i * col + col / 2;
  const nearest = iso => { let k = 0; msgs.forEach((m, i) => { if (m.received_at <= iso) k = i; }); return k; };
  let svg = `<svg class="tflow" width="100%" style="max-width:${W}px" viewBox="0 0 ${W} ${H}">`;
  // Lane bands, so each task reads as its own row; the task in focus is tinted.
  tasks.forEach((t, k) => {
    const y = laneTop + k * lane;
    if (focus === t.id) svg += `<rect x="0" y="${y}" width="${W}" height="${lane}" fill="${dir(t.direction).color}" opacity=".07"/>`;
    else if (k % 2) svg += `<rect x="0" y="${y}" width="${W}" height="${lane}" class="tf-band"/>`;
  });
  // Days: a label and a faint guide down through the lanes; a day too close to the last one shown is left out.
  let lastDay = '', lastX = -1e9;
  msgs.forEach((m, i) => {
    const d = String(m.received_at || '').slice(0, 10);
    if (d !== lastDay && xAt(i) - lastX >= 60) {
      svg += `<text x="${xAt(i)}" y="14" class="tf-day" text-anchor="middle">${esc(dateLabel(d))}</text>`;
      if (i) svg += `<line x1="${xAt(i) - col / 2}" y1="20" x2="${xAt(i) - col / 2}" y2="${H - 4}" class="tf-grid"/>`;
      lastX = xAt(i);
    }
    lastDay = d;
  });
  // Now: a dashed line through every lane, with its label on top.
  svg += `<line x1="${nowX}" y1="22" x2="${nowX}" y2="${H - 4}" class="tf-nowline"/>`;
  svg += `<g transform="translate(${nowX},14)"><rect x="-17" y="-9" width="34" height="16" rx="8" class="tf-nowpill"/><text text-anchor="middle" y="3" class="tf-now">Now</text></g>`;
  svg += `<line x1="${xAt(0)}" y1="${top}" x2="${nowX}" y2="${top}" class="tf-main"/>`;
  // Lanes. Their end marks (done, cancelled, the arrow at now) are kept apart and drawn after every lane, so no later
  // lane's line runs over them.
  let marks = '';
  tasks.forEach((t, k) => {
    const y = laneTop + k * lane + lane / 2 - 4, d = dir(t.direction);
    const o = idx.has(t.opened_email_id) ? idx.get(t.opened_email_id) : nearest(t.opened_at || msgs[0].received_at);
    const closed = !['open', 'parked'].includes(t.status);
    const c = closed && t.closed_email_id && idx.has(t.closed_email_id) ? idx.get(t.closed_email_id) : closed && t.closed_at ? nearest(t.closed_at) : null;
    const x0 = xAt(o), x1 = c != null ? Math.max(xAt(c), x0 + 44) : nowX;
    const grey = ['cancelled', 'dismissed', 'parked'].includes(t.status), color = grey ? '#74c0fc' : d.color;
    const dim = focus && focus !== t.id ? ' dim' : '', r = Math.min(16, (y - top) / 2);
    let state, stateC;
    svg += `<g class="tf-lane${dim}" data-task="${t.id}"><title>${esc(t.title)}\n${esc(t.requester_name)} → ${esc(t.owner_name)}\n${esc(STATUS[t.status]?.label || t.status)}${t.deadline ? ', deadline ' + esc(t.deadline) : ''}</title>`;
    // Branch off the email that opened it: down, then along the lane.
    svg += `<path d="M${x0} ${top} V ${y - r} Q ${x0} ${y}, ${x0 + r} ${y}" stroke="${color}" class="tf-br"/>`;
    if (c != null) {
      // Closed: along the lane and back up into the email that closed it, with a badge at the corner.
      svg += `<path d="M${x0 + r} ${y} H ${x1 - r} Q ${x1} ${y}, ${x1} ${y - r} V ${top}" stroke="${color}" class="tf-br${grey ? ' gone' : ''}"/>`;
      marks += `<g class="tf-mark" data-task="${t.id}" transform="translate(${x1},${y})"><circle r="9" fill="${t.status === 'done' ? STATUS.done.color : '#74c0fc'}" class="tf-end"/>` +
        (t.status === 'done' ? `<path d="M-3.5 0 l2.5 2.5 l4.5 -4.5" stroke="#fff" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round"/>` : `<path d="M-3 -3 l6 6 M3 -3 l-6 6" stroke="#fff" stroke-width="1.8" stroke-linecap="round"/>`) + `</g>`;
      state = t.status === 'done' ? `Done${t.closed_at ? ' ' + dateLabel(t.closed_at) : ''}` : STATUS[t.status]?.label || t.status;
      stateC = t.status === 'done' ? STATUS.done.color : '#0b7285';
    } else {
      // Open: solid up to the deadline (when it falls inside the drawing), dashed red after it, an arrow at now.
      let xd = nowX;
      if (t.deadline) {
        const dl = t.deadline + 'T23:59:59Z';
        const after = msgs.findIndex(m => m.received_at > dl);
        if (after >= 0) xd = Math.max(x0 + r + 20, xAt(after) - col / 2);
        else if (t.days_left < 0) xd = Math.max(x0 + r + 20, nowX - 34);
      }
      svg += `<path d="M${x0 + r} ${y} H ${xd}" stroke="${color}" class="tf-br"/>`;
      if (xd < nowX) svg += `<path d="M${xd} ${y} H ${nowX - 6}" stroke="#e03131" class="tf-br late"/>`;
      const fc = t.overdue ? '#e03131' : color;
      if (t.deadline) svg += `<g transform="translate(${xd},${y})"><path d="M0 -12 V 7" stroke="${fc}" stroke-width="2" stroke-linecap="round"/><path d="M0 -12 h9 l-3 3.5 l3 3.5 h-9z" fill="${fc}"/></g>`;
      marks += `<path data-task="${t.id}" class="tf-mark" d="M${nowX + 2} ${y} l-10 -6.5 v13z" fill="${fc}" stroke="#fff" stroke-width="1.5" stroke-linejoin="round"/>`;
      const dl = t.days_left;
      [state, stateC] = dl == null ? ['Open', color] : dl < 0 ? [`${-dl} day${dl < -1 ? 's' : ''} late`, '#e03131'] : dl === 0 ? ['Due today', '#c8822f'] : dl === 1 ? ['Due tomorrow', '#c8822f'] : [`${dl} days left`, color];
      if (t.status === 'parked') [state, stateC] = ['Parked', STATUS.parked.color];
    }
    // The label sits just above the lane and may run on past its end: a white halo keeps it readable over lines. A task
    // that starts late in the thread slides its title left so it still fits before now.
    const title = trunc(t.title, Math.floor((nowX - 30) / 6.6)), lx = Math.max(10, Math.min(x0 + r + 8, nowX - 16 - title.length * 6.6));
    svg += `<text x="${lx}" y="${y - 8}" class="tf-lbl" fill="${d.ink}">${esc(title)}</text>`;
    const who = `${firstName(t.requester_name) || '?'} → ${firstName(t.owner_name) || '?'}`;
    const sx = Math.max(10, Math.min(x0 + r + 8, W - 10 - (who.length + state.length + 2) * 6));
    svg += `<text x="${sx}" y="${y + 17}" class="tf-sub">${esc(who)}` +
      `<tspan dx="8" class="tf-state" fill="${stateC}">${esc(state)}</tspan></text></g>`;
  });
  svg += marks;
  // Stops, drawn last so they sit on top of the branches; a white ring lifts them off the line.
  msgs.forEach((m, i) => {
    const c = colorOf(m.from_email || m.from_name);
    svg += `<g class="tf-stop" data-msg="${esc(m.id)}" transform="translate(${xAt(i)},${top})"><title>${esc(m.from_name)}\n${new Date(m.received_at).toLocaleString(LOCALE)}</title>` +
      `<circle r="15" fill="#fff" class="tf-halo"/><circle r="12" fill="${m.mine ? '#fff' : c}" stroke="${c}" stroke-width="${m.mine ? 2.5 : 0}"/>` +
      `<text text-anchor="middle" dominant-baseline="central" fill="${m.mine ? c : '#fff'}">${esc(initials(m.from_name))}</text></g>`;
  });
  svg += '</svg>';
  const key = (sym, txt) => `<span>${sym}${txt}</span>`;
  return svg + `<div class="tf-key">` +
    key(`<svg width="14" height="14"><circle cx="7" cy="7" r="6" fill="#0b7285"/></svg>`, 'Email from someone') +
    key(`<svg width="14" height="14"><circle cx="7" cy="7" r="5.5" fill="#fff" stroke="#0b7285" stroke-width="2"/></svg>`, 'Email you sent') +
    key(`<svg width="14" height="14"><circle cx="7" cy="7" r="6" fill="${STATUS.done.color}"/><path d="M4.5 7 l2 2 l3.5 -3.5" stroke="#fff" stroke-width="1.6" fill="none"/></svg>`, 'Done') +
    key(`<svg width="12" height="14"><path d="M2 1 V13" stroke="#0b7285" stroke-width="2"/><path d="M2 1 h8 l-3 3 l3 3 h-8z" fill="#0b7285"/></svg>`, 'Deadline') +
    key(`<svg width="22" height="14"><path d="M1 7 H21" stroke="#e03131" stroke-width="3" stroke-dasharray="4 3"/></svg>`, 'Overdue') + `</div>`;
}

/** Who tasks whom: people who ask on the left, people who do on the right, bands as wide as the number of tasks. */
export function whoFlow(tasks, { meLabel = 'Me', max = 7, height = 300, width = 560, status = 'open', labelW = 150, chars = 22 } = {}) {
  if (!tasks.length) return '<div class="empty sm">No tasks to show yet.</div>';
  const key = (e, n) => e || n || '?';
  const label = new Map();
  const tally = (side, list) => {
    const m = new Map();
    for (const t of list) {
      const k = key(t[side + '_email'], t[side + '_name']);
      label.set(k, t[side + '_name'] || k);
      m.set(k, (m.get(k) || 0) + 1);
    }
    const top = [...m].sort((a, b) => b[1] - a[1]);
    return new Set(top.slice(0, max).map(x => x[0]));
  };
  const L = tally('requester', tasks), R = tally('owner', tasks);
  const links = new Map();
  for (const t of tasks) {
    let a = key(t.requester_email, t.requester_name), b = key(t.owner_email, t.owner_name);
    if (!L.has(a)) a = '__other'; if (!R.has(b)) b = '__other';
    const k = a + '>' + b, x = links.get(k) || { a, b, n: 0, dirs: {}, ids: [] };
    x.n++; x.dirs[t.direction] = (x.dirs[t.direction] || 0) + 1; x.ids.push(t.id);
    links.set(k, x);
  }
  label.set('__other', 'Everyone else');
  const nodes = side => {
    const sums = new Map();
    for (const l of links.values()) { const k = side === 'L' ? l.a : l.b; sums.set(k, (sums.get(k) || 0) + l.n); }
    return [...sums].sort((a, b) => (a[0] === '__other') - (b[0] === '__other') || b[1] - a[1]);
  };
  const ln = nodes('L'), rn = nodes('R');
  const total = tasks.length, gap = 8, pad = 14;
  const unit = (height - pad * 2 - gap * (Math.max(ln.length, rn.length) - 1)) / total;
  const place = list => { let y = pad; const m = new Map(); for (const [k, n] of list) { m.set(k, { y, h: Math.max(3, n * unit), off: 0, n }); y += Math.max(3, n * unit) + gap; } return m; };
  const lp = place(ln), rp = place(rn);
  const nw = 10, lx = labelW, rx = width - labelW;
  let svg = `<svg class="who" viewBox="0 0 ${width} ${height}" width="100%" preserveAspectRatio="xMidYMid meet">`;
  const sorted = [...links.values()].sort((a, b) => (rp.get(a.b).y - rp.get(b.b).y) || (lp.get(a.a).y - lp.get(b.a).y));
  for (const l of sorted) {
    const A = lp.get(l.a), B = rp.get(l.b), h = Math.max(2, l.n * unit);
    const y0 = A.y + A.off + h / 2, y1 = B.y + B.off + h / 2;
    A.off += h; B.off += h;
    const main = Object.entries(l.dirs).sort((a, b) => b[1] - a[1])[0][0];
    const mx = (lx + nw + rx) / 2;
    const go = l.n === 1 ? `data-task="${l.ids[0]}"` : `data-go="${esc(filterHash({ from: l.a, to: l.b, status }))}"`;
    svg += `<path d="M${lx + nw} ${y0} C ${mx} ${y0}, ${mx} ${y1}, ${rx} ${y1}" stroke="${dir(main).color}" stroke-width="${h}" class="who-link" ${go}><title>${esc(label.get(l.a))} → ${esc(label.get(l.b))}: ${l.n} task${l.n > 1 ? 's' : ''}\nClick to ${l.n === 1 ? 'open it' : 'see them'}</title></path>`;
  }
  const name = k => k === '__other' ? 'Everyone else' : String(label.get(k)).toLowerCase() === meLabel.toLowerCase() ? meLabel : label.get(k);
  for (const [k, p] of lp) svg += `<rect x="${lx}" y="${p.y}" width="${nw}" height="${p.h}" rx="3" class="who-bar" data-go="${esc(filterHash({ from: k, status }))}" fill="${k === '__other' ? '#d6dbe4' : colorOf(k)}"><title>Tasks asked by ${esc(name(k))}</title></rect>` +
    `<text x="${lx - 8}" y="${p.y + p.h / 2 + 4}" text-anchor="end" class="who-t" ${k !== '__other' ? `data-person="${esc(k)}"` : ''}>${esc(trunc(name(k), chars))} <tspan class="who-n">${p.n}</tspan></text>`;
  for (const [k, p] of rp) svg += `<rect x="${rx}" y="${p.y}" width="${nw}" height="${p.h}" rx="3" class="who-bar" data-go="${esc(filterHash({ to: k, status }))}" fill="${k === '__other' ? '#d6dbe4' : colorOf(k)}"><title>Tasks done by ${esc(name(k))}</title></rect>` +
    `<text x="${rx + nw + 8}" y="${p.y + p.h / 2 + 4}" class="who-t" ${k !== '__other' ? `data-person="${esc(k)}"` : ''}><tspan class="who-n">${p.n}</tspan> ${esc(trunc(name(k), chars))}</text>`;
  svg += `<text x="${lx + nw / 2}" y="${height - 1}" text-anchor="middle" class="who-h">ASKED BY</text><text x="${rx + nw / 2}" y="${height - 1}" text-anchor="middle" class="who-h">DONE BY</text>`;
  return svg + '</svg>';
}

/** The task list filtered to who asked and who does it ("Everyone else" is not a filter). */
function filterHash({ from, to, status }) {
  const p = new URLSearchParams();
  if (from && from !== '__other') p.set('from', from);
  if (to && to !== '__other') p.set('to', to);
  p.set('status', status);
  return '#/tasks/?' + p;
}

/** A donut of open tasks by kind, with the total in the middle. */
export function donut(parts, { size = 132, label = 'open' } = {}) {
  const total = parts.reduce((s, p) => s + p.n, 0);
  const r = size / 2 - 10, c = 2 * Math.PI * r;
  let off = 0, svg = `<svg width="${size}" height="${size}" viewBox="0 0 ${size} ${size}" class="donut"><circle cx="${size / 2}" cy="${size / 2}" r="${r}" stroke="#f1f3f5" stroke-width="16" fill="none"/>`;
  for (const p of parts) {
    if (!p.n) continue;
    const len = c * p.n / total;
    svg += `<circle cx="${size / 2}" cy="${size / 2}" r="${r}" stroke="${p.color}" stroke-width="16" fill="none" stroke-dasharray="${len - 2} ${c - len + 2}" stroke-dashoffset="${-off}" transform="rotate(-90 ${size / 2} ${size / 2})"><title>${esc(p.label)}: ${p.n}</title></circle>`;
    off += len;
  }
  return svg + `<text x="50%" y="48%" text-anchor="middle" class="dn-n">${total}</text><text x="50%" y="63%" text-anchor="middle" class="dn-l">${esc(label)}</text></svg>`;
}

/** From the day it was asked to its deadline, with today marked. */
export function deadlineBar(t) {
  if (!t.deadline || !t.opened_at) return '';
  const a = Date.parse(t.opened_at.slice(0, 10) + 'T00:00:00'), b = Date.parse(t.deadline + 'T23:59:59');
  const end = t.status === 'open' ? Date.now() : Date.parse(t.closed_at || t.updated_at);
  const pct = Math.max(0, Math.min(100, (end - a) / Math.max(1, b - a) * 100)) || 0;   // a date that cannot be read draws an empty bar, not NaN
  const over = end > b;
  const color = t.status === 'done' ? '#2f9e44' : over ? '#e03131' : pct > 75 ? '#f76707' : dir(t.direction).color;
  return `<div class="dbar"><div class="dbar-t"><span>Asked ${esc(dateLabel(t.opened_at))}</span><span>${t.status === 'open' ? (over ? 'Past the deadline' : Math.round(pct) + '% of the time used') : (t.status === 'parked' ? 'Parked ' : 'Closed ') + esc(dateLabel(t.closed_at))}</span><span>Deadline ${esc(dateLabel(t.deadline))}</span></div>
    <div class="dbar-b"><i style="width:${pct}%;background:${color}"></i>${over ? '<b></b>' : ''}</div></div>`;
}

/** A small bar strip of mail per month. */
export function monthStrip(months) {
  if (!months?.length) return '';
  const max = Math.max(1, ...months.map(m => m.n));   // a year with no mail: no 0 / 0
  return `<div class="mstrip">${months.slice(-12).map(m => `<div title="${esc(m.m)}: ${m.n} emails"><i style="height:${Math.max(6, m.n / max * 100)}%"></i><span>${esc(monthLabel(m.m))}</span></div>`).join('')}</div>`;
}

/**
 * Opened and closed per week, side by side, with the number still open at the end of each week as a line. Drawn at
 * the width it is given, so the text keeps its size. Each bar opens its week in Insights.
 */
export function weekTrend(weeks, { width = 900, height = 250 } = {}) {
  const pl = 34, pr = 12, pt = 20, pb = 26, w = width - pl - pr, h = height - pt - pb, n = weeks.length;
  const raw = Math.max(1, ...weeks.flatMap(x => [x.opened, x.closed, x.backlog]));
  const p = 10 ** Math.floor(Math.log10(raw)), f = raw / p, top = Math.max(4, (f <= 1 ? 1 : f <= 2 ? 2 : f <= 4 ? 4 : f <= 5 ? 5 : 10) * p);
  const Y = u => pt + h - u / top * h, slot = w / n, cx = i => pl + (i + .5) * slot, bw = Math.max(4, Math.min(22, slot * .3));
  let s = `<svg class="trend" width="${width}" height="${height}" viewBox="0 0 ${width} ${height}">`;
  const steps = top % 5 === 0 && top >= 5 ? 5 : 4;
  for (let g = 0; g <= steps; g++) { const u = top * g / steps; s += `<line x1="${pl}" x2="${width - pr}" y1="${Y(u)}" y2="${Y(u)}" class="ig${g ? '' : ' base'}"/><text x="${pl - 8}" y="${Y(u) + 4}" text-anchor="end" class="ia">${Math.round(u * 10) / 10}</text>`; }
  const every = Math.max(1, Math.ceil(56 / slot));
  weeks.forEach((x, i) => {
    const tip = `Week of ${dateLabel(x.from)}: ${x.opened} opened, ${x.closed} closed, ${x.backlog} still open at the end`;
    if (x.opened) s += `<rect x="${cx(i) - bw - 1}" y="${Y(x.opened)}" width="${bw}" height="${Y(0) - Y(x.opened)}" rx="2" fill="#3b5bdb"><title>${esc(tip)}</title></rect>`;
    if (x.closed) s += `<rect x="${cx(i) + 1}" y="${Y(x.closed)}" width="${bw}" height="${Y(0) - Y(x.closed)}" rx="2" fill="#40a065"><title>${esc(tip)}</title></rect>`;
    if (x.opened) s += `<text x="${cx(i) - bw / 2 - 1}" y="${Y(x.opened) - 5}" text-anchor="middle" class="it">${x.opened}</text>`;
    if (x.closed) s += `<text x="${cx(i) + bw / 2 + 1}" y="${Y(x.closed) - 5}" text-anchor="middle" class="it">${x.closed}</text>`;
    if (i % every === 0) s += `<text x="${cx(i)}" y="${height - 7}" text-anchor="middle" class="ix">${esc(dateLabel(x.from))}</text>`;
  });
  s += `<polyline points="${weeks.map((x, i) => `${cx(i)},${Y(x.backlog)}`).join(' ')}" fill="none" stroke="#c8822f" stroke-width="2" stroke-dasharray="5 4" stroke-linejoin="round"/>`;
  weeks.forEach((x, i) => { s += `<circle cx="${cx(i)}" cy="${Y(x.backlog)}" r="3.2" fill="#fff" stroke="#c8822f" stroke-width="2"><title>${x.backlog} still open at the end of the week of ${esc(dateLabel(x.from))}</title></circle>`; });
  return s + '</svg>';
}

/** A score from 0 to 5 as a colour: green when low, through amber, to red when high. */
export const heat = v => ['#2f9e44', '#66a80f', '#d4a20b', '#f08c00', '#e8590c', '#c92a2a'][Math.max(0, Math.min(5, v))];

/** The task radar: urgency, importance, sensitivity, effort and pressure on five spokes, 0 at the centre, 5 at the rim. */
export function radar(axes) {
  if (!axes?.length) return '';
  const n = axes.length, W = 320, H = 214, c = W / 2, cy = 112, R = 68;
  const pt = (i, v) => { const a = -Math.PI / 2 + i * 2 * Math.PI / n; return [c + Math.cos(a) * R * v / 5, cy + Math.sin(a) * R * v / 5]; };
  const ring = v => axes.map((_, i) => pt(i, v).map(x => x.toFixed(1)).join(',')).join(' ');
  const shape = axes.map((a, i) => pt(i, Math.max(a.v, 0.25)).map(x => x.toFixed(1)).join(',')).join(' ');
  const tip = axes.map(a => `${a.label} ${a.v}/5`).join(' · ');
  let s = `<svg class="radar" width="100%" style="max-width:${W}px" viewBox="0 0 ${W} ${H}" role="img" aria-label="${esc(tip)}">`;
  for (let v = 1; v <= 5; v++) s += `<polygon points="${ring(v)}" class="${v === 5 ? 'rd-rim' : 'rd-ring'}"/>`;
  axes.forEach((_, i) => { const [x, y] = pt(i, 5); s += `<line x1="${c}" y1="${cy}" x2="${x.toFixed(1)}" y2="${y.toFixed(1)}" class="rd-ring"/>`; });
  s += `<polygon points="${shape}" class="rd-shape"/>`;
  let dots = '';   // drawn last, so no label or line covers them
  axes.forEach((a, i) => {
    // The point sits a little off the centre even at 0, so five low scores never pile up on one another.
    const [x, y] = pt(i, Math.max(a.v, 1.2)), [lx, ly] = pt(i, 6.1);
    const anchor = Math.abs(lx - c) < 4 ? 'middle' : lx > c ? 'start' : 'end';
    s += `<text x="${lx.toFixed(1)}" y="${(ly + 4).toFixed(1)}" text-anchor="${anchor}" class="rd-lbl" data-rd="${esc(a.k)}">${esc(a.label)} <tspan class="rd-v" style="fill:${heat(a.v)}">${a.v}</tspan></text>`;
    dots += `<g class="rd-pt" style="--k:${heat(a.v)}"><title>${esc(a.label)} ${a.v}/5: ${esc(a.why.join('; '))}</title><circle cx="${x.toFixed(1)}" cy="${y.toFixed(1)}" r="8"/><text x="${x.toFixed(1)}" y="${(y + 3.5).toFixed(1)}" text-anchor="middle">${a.v}</text></g>`;
  });
  return s + dots + '</svg>';
}

/** On a card: one thin line of five segments, a score each, green (low) to red (high), each as wide as its score;
 *  over a segment, its score and why. A zero keeps a stub so it can still be hovered. */
export const LEVEL = ['None', 'Very low', 'Low', 'Medium', 'High', 'Very high'];
export function scoreLine(axes) {
  if (!axes?.length) return '';
  const any = axes.some(a => a.v > 0);
  return `<div class="tc-scores" role="img" aria-label="${esc(axes.map(a => `${a.label} ${a.v}/5`).join(', '))}">${axes.map(a =>
    `<span class="sc-seg" style="--k:${heat(a.v)};flex-grow:${any ? Math.max(a.v, 0) : 1}"><i></i><span class="sc-tip" role="tooltip"><span><em></em>${esc(a.label)}<b>${a.v}/5 · ${LEVEL[a.v]}</b></span><small>${esc(a.why.join(' · '))}</small></span></span>`).join('')}</div>`;
}
