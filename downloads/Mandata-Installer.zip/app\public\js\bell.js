// The bell in the status bar: the tasks asked of you (alone or among others) found in mail that has just arrived. A task read from old mail (your history, a
// thread read again) is never on it: the server only lists tasks whose email came after Mandata's first mail check, and
// lately (GET /api/bell), newest email first. Its count is the unread ones: each stays unread, with its dot, until you
// open the task or press Mark all as read. Opening the list alone reads nothing.
import { esc, icon, ago, api, GET, dir, toast, $ } from './ui.js';
import { S, on } from './store.js';

let btn, pop = null;

export function initBell(el) {
  btn = el;
  btn.innerHTML = icon('bell', 14);
  btn.setAttribute('aria-haspopup', 'dialog');
  btn.onclick = () => pop ? close() : open();
  on('status', renderBell);
  on('tasks', () => { if (pop) load(); });
  on('seen', () => { if (pop) load(); });
  renderBell();
}

function renderBell() {
  if (!btn) return;
  const n = S.status?.counts?.bell || 0;
  const tip = `${n ? `${n} unread new task${n > 1 ? 's' : ''}` : 'New tasks'} from mail that just arrived

Only tasks assigned to me, and to me among others: not tasks I assigned, nor tasks between others.`;
  btn.title = tip; btn.setAttribute('aria-label', tip);
  btn.classList.toggle('has', !!n);
  let em = $('em', btn);
  if (!n) { em?.remove(); return; }
  if (!em) em = btn.appendChild(document.createElement('em'));
  const t = n > 99 ? '99+' : String(n);
  if (em.textContent !== t) em.textContent = t;
}

function place() {
  if (!pop) return;
  const r = btn.getBoundingClientRect(), w = Math.min(380, innerWidth - 16);
  pop.style.width = w + 'px';
  pop.style.top = r.bottom + 8 + 'px';
  pop.style.left = Math.max(8, Math.min(innerWidth - w - 8, r.right - w)) + 'px';
}

function open() {
  pop = document.createElement('div');
  pop.className = 'bellpop'; pop.setAttribute('role', 'dialog'); pop.setAttribute('aria-label', 'New tasks');
  pop.innerHTML = `<div class="bell-h"><b>${icon('bell', 14)} New tasks</b><span class="muted small">Mandate tasks assigned to me, from mail that just arrived</span>
    <button class="bell-all" disabled title="Mark every task in this list as read">${icon('check', 13)}Mark all as read</button></div><div class="bell-list"><div class="bell-empty muted">Loading…</div></div>
    <div class="bell-f"><a href="#/tasks/?dir=to_me,among&nature=work&arr=new" data-go="#/tasks/?dir=to_me,among&nature=work&arr=new">See new tasks in Tasks</a></div>`;
  document.body.append(pop);
  btn.classList.add('on');
  place();
  // Any click on a task inside opens it (the app's click router) and closes the list; a click elsewhere closes it too.
  setTimeout(() => document.addEventListener('click', outside, true));
  document.addEventListener('keydown', esc_);
  addEventListener('resize', place);
  $('.bell-all', pop).onclick = () => api('POST', '/api/bell/seen').then(load).catch(e => toast(e.message, true));
  load();
}

function close() {
  pop?.remove(); pop = null;
  btn.classList.remove('on');
  document.removeEventListener('click', outside, true);
  document.removeEventListener('keydown', esc_);
  removeEventListener('resize', place);
}
const outside = e => {
  if (btn.contains(e.target)) return;
  if (!pop?.contains(e.target)) return close();
  if (e.target.closest('[data-task],[data-go]')) setTimeout(close);
};
const esc_ = e => { if (e.key === 'Escape') { close(); btn.focus(); } };

async function load() {
  let r;
  try { r = await GET('/api/bell'); } catch (e) { if (pop) $('.bell-list', pop).innerHTML = `<div class="bell-empty muted">${esc(e.message)}</div>`; return; }
  if (!pop) return;
  $('.bell-list', pop).innerHTML = r.items.length ? r.items.map(item).join('')
    : `<div class="bell-empty muted">${icon('bell', 22)}<div>No new tasks</div><small>Tasks found in new emails show here. Old mail never does.</small></div>`;
  $('.bell-all', pop).disabled = !r.items.some(t => t.fresh);
}

function item(t) {
  const d = dir(t.direction);
  const who = t.direction === 'by_me' ? t.owner_name || t.owner_email : t.requester_name || t.requester_email;
  const due = t.days_left == null ? '' : t.days_left < 0 ? `<span class="bell-due late">Overdue</span>`
    : t.days_left === 0 ? `<span class="bell-due soon">Due today</span>` : t.days_left === 1 ? `<span class="bell-due soon">Due tomorrow</span>`
    : `<span class="bell-due${t.due_soon ? ' soon' : ''}">Due in ${t.days_left} days</span>`;
  return `<button class="bell-i${t.fresh ? ' fresh' : ''}" data-task="${t.id}" style="--c:${d.color}">
    <span class="bell-ic">${icon(d.icon, 13)}</span>
    <span class="bell-b"><span class="bell-t clamp2">${esc(t.title)}</span>
      <span class="bell-m">${who ? `<span class="clamp1">${t.direction === 'by_me' ? 'With' : 'From'} ${esc(who)}</span>` : ''}${due}<span class="bell-at" title="When the email arrived">${esc(ago(t.opened_at))}</span></span></span>
  </button>`;
}
