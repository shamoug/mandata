// Signing in to Microsoft 365, how mail is read on macOS and Linux (and on Windows without classic Outlook). Microsoft
// gives a short code; you enter it on Microsoft's own page in your browser and sign in there. Mandata never sees your
// password. The dialog closes by itself once the sign-in is done.
import { api, esc, icon, modal, toast, $, LOCALE, safeUrl } from './ui.js';
import { S, on, loadStatus } from './store.js';

const timeOf = iso => new Date(iso).toLocaleTimeString(LOCALE, { hour: '2-digit', minute: '2-digit' });

export async function openSignIn() {
  let done = false;
  const m = modal({ title: 'Sign in to Microsoft 365', size: 'small signin', body: `<div class="si"><div class="aim-load"><span class="spin"></span> Asking Microsoft for a sign-in code...</div></div>`,
    onClose: () => { if (!done) api('POST', '/api/mail/signin/cancel').catch(() => {}); } });
  let code;
  try { code = await api('POST', '/api/mail/signin'); }
  catch (e) { $('.si', m.el).innerHTML = `<p class="si-err">${esc(e.message)}</p><p class="muted small">Check the internet connection. If your organisation gave you an app ID for Mandata, enter it in Settings > Mail.</p>`; return; }
  // Closed while Microsoft answered: the sign-in it started is called off, not left waiting.
  if (!m.el.isConnected) { api('POST', '/api/mail/signin/cancel').catch(() => {}); return; }
  $('.si', m.el).innerHTML = `
    <ol class="si-steps">
      <li><b>Copy this code</b>
        <div class="si-code"><code>${esc(code.code)}</code><button class="btn" id="siCopy">${icon('copy', 14)} Copy</button></div></li>
      <li><b>Open Microsoft's sign-in page</b>, paste the code, and sign in with the account your Outlook mail is in.
        <div><a class="btn primary" id="siOpen" href="${esc(safeUrl(code.url))}" target="_blank" rel="noopener">${icon('out', 14)} Open the sign-in page</a></div></li>
    </ol>
    <p class="si-wait"><span class="spin"></span> Waiting for you to finish in the browser. The code works until ${esc(timeOf(code.expiresAt))}.</p>
    <p class="muted small">Mandata asks to read your mail, save drafts, and send the emails you confirm. Your password goes to Microsoft only.
      Mandata keeps the sign-in on this computer, and mail is still read by the AI on this computer only.</p>`;
  $('#siCopy', m.el).onclick = async () => { try { await navigator.clipboard.writeText(code.code); toast('Code copied'); } catch { toast('Select the code and copy it', true); } };
  // Done, refused or expired: the status that follows says which.
  const off = on('status', () => {
    const o = S.status?.outlook;
    if (!o || o.signIn) return;
    off();
    if (o.signedIn) { done = true; m.close(true); toast(`Signed in${o.defaultStore ? ' as ' + o.defaultStore : ''}. Reading your mail now.`); }
    else $('.si-wait', m.el).innerHTML = `<span class="si-err">${esc(o.error || 'The sign-in did not finish.')}</span> Close this and press Sign in again.`;
  });
  const close = m.close; m.close = s => { off(); close(s); };
  loadStatus().catch(() => {});
}
