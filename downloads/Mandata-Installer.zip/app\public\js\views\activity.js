// What the app did, newest first. Threads the AI got stuck on come first, above the log: they are the only thing here to act on.
import { GET, api, esc, $, icon, fullDate, when, busy, toast, pref, setPref, plural, latest, errorBox, segButtons } from '../ui.js';
import { onView, S } from '../store.js';

const KIND = { task: ['tasks', '#1c7ed6'], sync: ['mailIn', '#1098ad'], draft: ['draft', '#f59f00'], sent: ['send', '#2f9e44'], outlook: ['out', '#0f6cbd'], notask: ['noTask', '#0c8599'],
  skipped: ['skip', '#e8590c'], stuck: ['flag', '#d9480f'], error: ['alert', '#e03131'], people: ['user', '#1864ab'], lesson: ['bulb', '#1098ad'], report: ['report', '#5c940d'],
  ask: ['chat', '#1864ab'], system: ['gear', '#0b7285'] };
const LABEL = { task: 'Tasks', sync: 'Mail checks', draft: 'Drafts', sent: 'Sent', outlook: 'Outlook', notask: 'No tasks', skipped: 'Skipped', stuck: 'Stuck', error: 'Errors', people: 'People',
  lesson: 'Lessons', report: 'Reports', ask: 'Ask', system: 'System' };
// Each action its own picture, read from the entry's wording: the first rule that fits wins, else the icon of its kind.
// Problems (errors, skipped, stuck) keep the icon of their kind, whatever they are about.
const ACTION = [
  ['task', /^New Task:/, 'newTask'], ['task', /^Task Updated:/, 'edit'], ['task', /^Edited by you/, 'edit'],
  ['task', /^Closed by email:|^Closed as done|^Closed:/, 'done'], ['task', /^Closed as delegated/, 'send'], ['task', /^Closed as handled/, 'out'],
  ['task', /^Closed as cancelled/, 'x'], ['task', /^Closed as a duplicate/, 'copy'], ['task', /^(Closed as archived|Archived):/, 'archive'],
  ['task', /^Not a task:/, 'ban'], ['task', /^Parked:/, 'pause'], ['task', /^(Reopened|Resumed):/, 'reopen'],
  ['task', /^Acknowledged:/, 'thumb'], ['task', /^(Unacknowledged|Undone):/, 'undo'], ['task', /^(Pinned|Unpinned)/, 'pin'],
  ['task', /^Deleted /, 'trash'], ['task', /^Restored .*recycle bin/, 'restore'], ['task', /^Recycle bin:/, 'flame'],
  ['task', /^Reprocess|to reprocess|^Read again/, 'repeat'], ['task', /^Review: .*deadline/, 'calendarCheck'], ['task', /^Review/, 'review'],
  ['task', /^Folded/, 'merge'], ['task', /^Forwarded /, 'forward'], ['task', /^Read "/, 'book'],
  ['sync', /no new email|^Mail check/, 'inbox'],
  ['draft', /^Forward drafted/, 'forward'], ['draft', /^Acknowledgement drafted/, 'thumb'], ['draft', /^Draft edited/, 'edit'],
  ['draft', /^Draft rewritten/, 'spark'], ['draft', /^Draft discarded/, 'trash'],
  ['outlook', /saved to Outlook/, 'save'],
  ['people', /^Profile of/, 'profile'], ['people', /signature/i, 'idcard'], ['people', /^Organisation: .*(same|now one)/, 'merge'],
  ['people', /^Organisation:/, 'building'], ['people', /hidden by you/, 'eyeOff'], ['people', /shown again/, 'eye'], ['people', /edited by you$/, 'userEdit'],
  ['lesson', /strengthened/, 'trendUp'], ['lesson', /retired/, 'archive'], ['lesson', /restored/, 'reopen'], ['lesson', /deleted/, 'trash'],
  ['lesson', /added by you/, 'newTask'], ['lesson', /edited by you/, 'edit'],
  ['report', /exported/, 'download'],
  ['ask', /renamed/, 'edit'], ['ask', /pinned/, 'pin'], ['ask', /deleted/, 'trash'],
  ['system', /^(Started|Stopped)/, 'power'], ['system', /^Settings reset/, 'reopen'], ['system', /^Settings changed/, 'sliders'], ['system', /time frame/, 'calendar'],
  ['system', /^Database wiped/, 'eraser'], ['system', /^Backup .*restored/, 'history'], ['system', /^Backup .*made/, 'save'], ['system', /^Backup .*deleted/, 'trash'],
  ['system', /exported/, 'download'], ['system', /imported/, 'upload'], ['system', /^AI running/, 'play'], ['system', /^AI paused/, 'pause'],
  ['system', /^Download of .*cancelled/, 'stop'], ['system', /^(Downloading|Installing) /, 'download'], ['system', /^(Installed|Loaded|Unloaded) /, 'cpu'],
  ['system', /from the disk/, 'trash'], ['system', /^Speed test/, 'gauge'], ['system', /^Revision round/, 'doneAll'], ['system', /stuck threads? queued/, 'refresh'],
  ['system', /automatic replies/, 'robot'], ['system', /long threads? queued/, 'layers'], ['system', /^Corrected the people/, 'people'],
];
const iconOf = a => ACTION.find(([k, re]) => k === a.kind && re.test(a.text || ''))?.[2] || KIND[a.kind]?.[0] || 'pulse';
let root, show = pref('actshow', 'all');
export function mount(el) {
  root = el;
  el.innerHTML = `<div class="page"><div class="fbar"><h2 class="ptitle">${icon('pulse', 18)} Activity</h2><div class="seg" id="aSeg"></div></div><section class="panel stuckbox" id="aStuck" hidden></section><ol class="tl big" id="aList"><li id="aNow" hidden></li></ol></div>`;
  $('#aSeg', el).onclick = e => { const v = e.target.closest('button')?.dataset.v; if (v) { show = v; setPref('actshow', v); render(); } };
  $('#aStuck', el).onclick = e => { const b = e.target.closest('#aRetry'); if (b) busy(b, async () => { const r = await api('POST', '/api/stuck/retry'); toast(`${plural(r.queued, 'thread')} queued again, after the rest`); render(); }); };
  render(); onView('activity', render); onView('tasks', render); onView('threads', render); onView('status', renderNow);
}
// What is being done right now, at the top of the log and glowing until it is done; then its entry takes its place.
// The server says only what it is on, so the start is when this page first saw it.
const since = new Map();
function working() {
  const y = S.status?.sync, ai = S.status?.ai; if (!y) return [];
  const r = y.aiRef || '', ref = r.includes('@') ? `data-person="${esc(r)}"` : r ? `data-thread="${esc(r)}"` : '';
  return [ai?.focus && [ai.focus, 'ask', ''], y.running && [y.phase || 'Checking mail', 'sync', 'data-go="#/threads"'],
    !ai?.focus && y.aiBusy && y.aiPhase && [y.aiPhase, /^Reading thread|^Revising tasks/.test(y.aiPhase) ? 'task' : /signature|profile/.test(y.aiPhase) ? 'people' : /corrections/.test(y.aiPhase) ? 'lesson' : 'system', ref]].filter(Boolean);
}
function renderNow() {
  const at = $('#aNow', root); if (!at) return;
  const all = working(), now = all.filter(w => show === 'all' || w[1] === show), keys = new Set(all.map(w => w[0]));
  for (const k of since.keys()) if (!keys.has(k)) since.delete(k);
  for (const k of keys) if (!since.has(k)) since.set(k, new Date().toISOString());
  // Redrawn on its own, without fetching the log again: status comes often.
  [...root.querySelectorAll('#aList > li.now')].forEach(li => li.remove());
  at.insertAdjacentHTML('afterend', now.map(([text, kind, t]) => { const c = (KIND[kind] || [, '#0b7285'])[1];
    return `<li style="--c:${c}" ${t} class="now ${t ? 'act' : ''}"><span class="tl-ic">${icon('refresh', 12)}</span><div><p>${esc(text)}</p><small><span class="chip proc" style="--c:${c}"><i></i>Processing…</span> started ${esc(fullDate(since.get(text)))} · not done yet${t ? ` · <span class="lnk">Open ${icon('arrow', 10)}</span>` : ''}</small></div></li>`; }).join(''));
}
/** Where an entry leads: its task, thread, draft or page. */
function target(a) {
  const r = a.ref || '';
  if (a.kind === 'task') return /^\d+$/.test(r) ? `data-task="${r}"` : r ? `data-thread="${esc(r)}"` : 'data-go="#/tasks"';
  if (a.kind === 'draft' || a.kind === 'sent') return r ? `data-draft="${esc(r)}"` : 'data-go="#/drafts"';
  if (a.kind === 'notask') return r ? `data-thread="${esc(r)}"` : 'data-go="#/threads"';
  if (a.kind === 'sync') return 'data-go="#/threads"';
  if (a.kind === 'outlook') return /^\d+$/.test(r) ? `data-draft="${r}"` : r ? `data-thread="${esc(r)}"` : '';
  if (a.kind === 'report') return `data-go="#/reports${r ? '/' + esc(r) : ''}"`;
  if (a.kind === 'ask') return `data-go="#/ask${/^\d+$/.test(r) && !/deleted/.test(a.text) ? '/' + r : ''}"`;
  if (a.kind === 'people' && r) return `data-person="${esc(r)}"`;
  if ((a.kind === 'skipped' || a.kind === 'stuck' || a.kind === 'error') && r) return r.includes('@') ? `data-person="${esc(r)}"` : `data-thread="${esc(r)}"`;
  return '';
}
// Only the newest answer is drawn: the log is asked for again on every change, and answers can land out of order.
const render = latest(() => Promise.all([GET('/api/activity'), GET('/api/stuck').catch(() => [])]), draw,
  e => { const box = root && $('#aList', root); if (box) box.innerHTML = `<li id="aNow" hidden></li><li>${errorBox(e)}</li>`; });
function draw([list, stuck]) {
  // root is #main, there for every page: the view is still on screen only while its own list is.
  if (!$('#aList', root)) return;
  // Above the log: threads still stuck, to visit. They are tried again on their own, after everything else.
  const box = $('#aStuck', root);
  box.hidden = !stuck.length;
  box.innerHTML = stuck.length ? `<h3>${icon('flag', 15)} Stuck threads <span class="muted">${stuck.length} the AI could not read in time. Each waits at the end of the queue and is tried again on its own; open one to read it yourself, or press Read again there.</span>
      <button class="btn sm push" id="aRetry" data-busy="Queuing">${icon('refresh', 13)} Try them all again</button></h3>
    <ol class="tl">${stuck.map(t => `<li style="--c:#d9480f" data-thread="${esc(t.id)}" class="act"><span class="tl-ic">${icon('thread', 12)}</span><div><p><b>${esc(t.subject)}</b></p>
      <small>${plural(t.messages, 'email')} · last ${esc(when(t.last_at))} · ${t.attempts} tries${t.error ? ': ' + esc(t.error) : ''}${t.retry_at ? ` · next try ${esc(fullDate(t.retry_at))}` : ''} · <span class="lnk">Open ${icon('arrow', 10)}</span></small></div></li>`).join('')}</ol>` : '';
  const kinds = Object.keys(KIND).filter(k => list.some(a => a.kind === k));
  $('#aSeg', root).innerHTML = segButtons([['all', 'All', '#1c7ed6', list.length], ...kinds.map(k => [k, LABEL[k], KIND[k][1], list.filter(a => a.kind === k).length])], show);
  $('#aList', root).innerHTML = '<li id="aNow" hidden></li>' + (list.filter(a => show === 'all' || a.kind === show).map(a => { const c = (KIND[a.kind] || [, '#0b7285'])[1], ic = iconOf(a), t = target(a);
    return `<li style="--c:${c}" ${t} class="${t ? 'act' : ''}"><span class="tl-ic">${icon(ic, 12)}</span><div><p>${esc(a.text)}</p><small><span class="chip" style="--c:${c}"><i></i>${esc(LABEL[a.kind] || a.kind)}</span> ${esc(fullDate(a.at))}${t ? ` · <span class="lnk">Open ${icon('arrow', 10)}</span>` : ''}</small></div></li>`; }).join('')
    || '<li class="muted">Nothing here.</li>');
  renderNow();
}
