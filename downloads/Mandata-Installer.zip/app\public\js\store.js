// Shared state and pub/sub.
import { GET, applyMeta } from './ui.js';

export const S = { status: null, config: null, defaults: null, route: 'overview', arg: '' };
const subs = new Map();
export const on = (type, fn) => { if (!subs.has(type)) subs.set(type, new Set()); subs.get(type).add(fn); return () => subs.get(type).delete(fn); };
export const emit = (type, data) => subs.get(type)?.forEach(fn => fn(data));
// Subscriptions made by the mounted view; cleared on every route change so a view that is gone never repaints.
const viewOffs = [];
export const onView = (type, fn) => { viewOffs.push(on(type, fn)); };
/** Run fn when the mounted view goes (a ResizeObserver to disconnect, a timer to clear). */
export const onLeave = fn => { viewOffs.push(fn); };
export const clearViewSubs = () => { while (viewOffs.length) viewOffs.pop()(); };
export function go(route, arg = '') { location.hash = '#/' + route + (arg !== '' ? '/' + encodeURIComponent(arg) : ''); }

/** What the server's codes mean, its locale and limits: loaded once, before anything is drawn. */
export async function loadMeta() { applyMeta(await GET('/api/meta')); }
export async function loadStatus() { S.status = await GET('/api/status'); emit('status'); }
export async function loadConfig() { const r = await GET('/api/config'); Object.assign(S, { config: r.config, defaults: r.defaults }); emit('config'); }
export const isMe = email => { const e = String(email || '').trim().toLowerCase(); return !!e && (S.config?.me?.emails || []).some(m => String(m).trim().toLowerCase() === e); };
