// Ask Mandata: a conversation with the local AI about everything Mandata holds. Conversations on the left (searchable,
// pinned first, by day); the answer streams in the middle, each record it cites shown as a numbered pill that opens it;
// every record cited in the conversation on the right. While it answers, the AI works for you only (see lib/ask.js).
import { GET, api, esc, $, icon, toast, confirmBox, promptBox, dir, CLOSE, STATUS, dateLabel, avatar, LOCALE, plural, fullDate, busy, pdfSaved } from '../ui.js';
import { S, onView, onLeave, go } from '../store.js';

let root, convs = [], cur = null, search = '', streaming = null, info = null, draft = '';

export function mount(el, arg) {
  root = el;
  el.innerHTML = `<div class="ask">
    <aside class="ask-side">
      <div class="ask-side-head">
        <button class="btn primary ask-new" id="askNew" title="Start a new conversation (Ctrl+Shift+N)">${icon('plus', 14)} New conversation</button>
        <label class="search">${icon('search', 14)}<input type="search" id="askQ" placeholder="Search conversations" aria-label="Search conversations"></label>
      </div>
      <div class="ask-convs" id="askConvs"></div>
      <div class="ask-side-foot">${icon('eye', 12)}<span>Answers come from your own data, on this computer.</span></div>
    </aside>
    <section class="ask-main">
      <header class="ask-head" id="askHead"></header>
      <div class="ask-scroll" id="askScroll"><div class="ask-thread" id="askThread"></div></div>
      <div class="ask-composer">
        <div class="ask-box" id="askBox">
          <textarea id="askIn" rows="1" placeholder="Ask about your tasks, deadlines, people, threads or emails…" aria-label="Your question"></textarea>
          <button class="ask-send" id="askSend" title="Send (Enter)" aria-label="Send">${icon('up', 17)}</button>
        </div>
        <div class="ask-hint" id="askHint"></div>
      </div>
    </section>
    <aside class="ask-refs" id="askRefs"></aside>
  </div>`;
  const inp = $('#askIn', el);
  inp.value = draft;
  inp.oninput = () => { draft = inp.value; grow(); };
  inp.onkeydown = e => { if (e.key === 'Enter' && !e.shiftKey && !e.isComposing) { e.preventDefault(); submit(); } };
  $('#askSend', el).onclick = () => streaming ? streaming.stop() : submit();
  $('#askNew', el).onclick = newConversation;
  $('#askQ', el).oninput = e => { search = e.target.value; clearTimeout(mount.t); mount.t = setTimeout(loadList, 180); };
  $('#askConvs', el).addEventListener('click', onListClick);
  $('#askThread', el).addEventListener('click', onThreadClick);
  // On the page, not on #main (which outlives this view): one listener, gone with the view.
  el.firstElementChild.addEventListener('keydown', e => { if (e.ctrlKey && e.shiftKey && e.key.toLowerCase() === 'n') { e.preventDefault(); newConversation(); } });
  const ro = new ResizeObserver(() => grow());
  ro.observe($('#askBox', el));
  onLeave(() => ro.disconnect());
  onLeave(() => clearTimeout(mount.t));
  // An answer still being written when the view goes is stopped (the server keeps what was written), so nothing here is drawn after it.
  onLeave(drop);
  onView('ask', () => loadList());
  onView('status', () => renderHint());
  onView('tasks', () => cur && !streaming && reloadCur());
  loadList();
  select(arg);
}

export function select(arg) {
  const id = Number(arg) || null;
  if (streaming && id && id === cur?.id) { renderList(); return; }
  // Another conversation opened (Back, a link) while one is answered: that answer stops, as with Stop.
  drop();
  // Only the newest conversation asked for is drawn: one opened before it and landing late is dropped.
  const k = ++selN;
  if (!id) { cur = null; renderAll(); loadInfo(); focusInput(); return; }
  GET('/api/ask/' + id).then(c => { if (k !== selN) return; cur = c; renderAll(); scrollEnd(true); focusInput(); })
    .catch(e => { if (k !== selN || S.route !== 'ask') return; toast(e.message, true); go('ask'); });
}
let selN = 0;
function drop() { if (streaming) { streaming.stop(); streaming = null; } }
// A change to tasks redraws only the answers whose cited records changed, and the list of references; the rest stays as it is.
const reloadCur = () => GET('/api/ask/' + cur.id).then(c => {
  if (cur?.id !== c.id || streaming) return;
  const was = new Map(cur.list.map(m => [m.id, JSON.stringify(m.refs || [])]));
  if (c.list.length !== cur.list.length || c.list.some(m => !was.has(m.id))) { cur = c; renderThread(); renderRefs(); return; }
  const changed = c.list.filter(m => m.role !== 'user' && was.get(m.id) !== JSON.stringify(m.refs || []));
  cur = c;
  if (!changed.length) return;
  const box = $('#askThread', root);
  for (const m of changed) { const el = box?.querySelector(`.am-ai[data-mid="${m.id}"]`), i = c.list.indexOf(m); if (el) el.outerHTML = answerHtml(m, c.list[i - 1]); }
  renderRefs();
}).catch(() => {});
// Only the newest list is drawn: a search typed on, or a reload after an answer, is never overwritten by an older one landing late.
let listN = 0;
async function loadList() { const k = ++listN; try { const r = await GET('/api/ask' + (search.trim() ? '?q=' + encodeURIComponent(search.trim()) : '')); if (k === listN) { convs = r; renderList(); } } catch {} }
async function loadInfo() { try { info = await GET('/api/ask/starters'); if (!cur && root && $('#askThread', root)) { renderThread(); renderRefs(); } } catch {} }
function newConversation() { if (streaming) return toast('Wait for the answer, or press Stop'); draft = ''; const i = $('#askIn', root); if (i) i.value = ''; go('ask'); if (!cur) focusInput(); }
const focusInput = () => setTimeout(() => $('#askIn', root)?.focus(), 30);
// Grows with what you type, up to a limit; measured only once laid out (a hidden window has no width).
function grow() { const i = $('#askIn', root); if (!i || i.clientWidth < 60) return; i.style.height = 'auto'; i.style.height = Math.min(220, i.scrollHeight) + 'px'; i.style.overflowY = i.scrollHeight > 220 ? 'auto' : 'hidden'; }
function scrollEnd(force) {
  const s = $('#askScroll', root); if (!s) return;
  if (force || s.scrollHeight - s.scrollTop - s.clientHeight < 160) s.scrollTop = s.scrollHeight;
}

function renderAll() { renderList(); renderHead(); renderThread(); renderRefs(); renderHint(); grow(); }

// ---------- the conversations ----------
function groupOf(c) {
  if (c.pinned && !search.trim()) return 'Pinned';
  const d = new Date(c.updated_at), n = new Date(), day = 864e5;
  const start = new Date(n.getFullYear(), n.getMonth(), n.getDate()).getTime();
  if (d >= start) return 'Today';
  if (d >= start - day) return 'Yesterday';
  if (d >= start - 6 * day) return 'Previous 7 days';
  if (d >= start - 29 * day) return 'Previous 30 days';
  return d.toLocaleDateString(LOCALE, { month: 'long', year: 'numeric' });
}
function renderList() {
  const box = $('#askConvs', root); if (!box) return;
  if (!convs.length) {
    box.innerHTML = `<div class="ask-noconv">${icon(search.trim() ? 'search' : 'chat', 26)}<p>${search.trim() ? 'No conversation mentions that.' : 'Your conversations will be listed here.'}</p></div>`;
    return;
  }
  let html = '', last = '';
  for (const c of convs) {
    const g = groupOf(c);
    if (g !== last) { html += `<div class="ask-group">${esc(g)}</div>`; last = g; }
    const t = new Date(c.updated_at);
    const when = g === 'Today' || g === 'Pinned' && t.toDateString() === new Date().toDateString() ? t.toLocaleTimeString(LOCALE, { hour: '2-digit', minute: '2-digit' }) : dateLabel(c.updated_at);
    html += `<div class="ask-conv ${c.id === cur?.id ? 'on' : ''}" data-cid="${c.id}" role="button" tabindex="0" title="${esc(c.title)}">
      <div class="ac-top">${c.pinned ? `<span class="ac-pin">${icon('pin', 11)}</span>` : ''}<b class="clamp1">${esc(c.title)}</b><span class="ac-when">${esc(when)}</span></div>
      <div class="ac-sub clamp1">${c.snippet ? esc(c.snippet) : `${Math.ceil(c.messages / 2)} question${c.messages > 2 ? 's' : ''}`}</div>
      <div class="ac-acts"><button data-act="pin" title="${c.pinned ? 'Unpin' : 'Pin to the top'}">${icon('pin', 13)}</button><button data-act="rename" title="Rename">${icon('edit', 13)}</button><button data-act="delete" title="Delete">${icon('trash', 13)}</button></div></div>`;
  }
  box.innerHTML = html;
}
async function onListClick(e) {
  const row = e.target.closest('[data-cid]'); if (!row) return;
  const id = Number(row.dataset.cid), act = e.target.closest('[data-act]')?.dataset.act;
  if (!act) { if (streaming && id !== cur?.id) return toast('Wait for the answer, or press Stop'); return go('ask', id); }
  const c = convs.find(x => x.id === id); if (!c) return;
  try {
    if (act === 'pin') await api('PATCH', '/api/ask/' + id, { pinned: !c.pinned });
    if (act === 'rename') await rename(c);
    if (act === 'delete') {
      if (streaming && id === cur?.id) return toast('Wait for the answer, or press Stop');
      if (!await confirmBox('Delete this conversation?', `<b>${esc(c.title)}</b> and its answers will be deleted for good.`, 'Delete')) return;
      await api('DELETE', '/api/ask/' + id);
      if (id === cur?.id) go('ask');
    }
    await loadList();
    if (cur?.id === id && act !== 'delete') { cur = { ...cur, ...convs.find(x => x.id === id) }; renderHead(); }
  } catch (err) { toast(err.message, true); }
}
async function rename(c) {
  const t = await promptBox('Rename conversation', 'Title', { value: c.title, okLabel: 'Rename' });
  if (t == null || !t.trim() || t.trim() === c.title) return;
  await api('PATCH', '/api/ask/' + c.id, { title: t.trim() });
}

// ---------- the header of the conversation ----------
function renderHead() {
  const h = $('#askHead', root); if (!h) return;
  if (!cur) {
    h.innerHTML = `<div class="ah-title"><span class="ah-ic">${icon('spark', 15)}</span><div><h2>New conversation</h2><span class="muted small">Ask anything Mandata knows: tasks, deadlines, people, threads, emails, your organisation</span></div></div>`;
    return;
  }
  const n = cur.list?.filter(m => m.role === 'user').length || 0;
  h.innerHTML = `<div class="ah-title"><span class="ah-ic">${icon('chat', 15)}</span><div><h2 class="clamp1" title="${esc(cur.title)}">${esc(cur.title)}</h2>
      <span class="muted small">${plural(n, 'question')} · started ${esc(fullDate(cur.created_at))}</span></div></div>
    <div class="ah-acts"><button class="btn sm good" id="ahPdf" data-busy="Exporting" title="Save this conversation as a PDF file in Documents, Mandata reports, and open it">${icon('download', 13)}Export PDF</button><button class="btn sm ghost" id="ahPin">${icon('pin', 13)}${cur.pinned ? 'Unpin' : 'Pin'}</button><button class="btn sm ghost" id="ahRename">${icon('edit', 13)}Rename</button>
      <button class="btn sm ghost" id="ahDel">${icon('trash', 13)}Delete</button><button class="btn sm" id="ahNew">${icon('plus', 13)}New</button></div>`;
  const act = a => { const fake = document.createElement('div'); fake.dataset.cid = cur.id; const b = document.createElement('button'); b.dataset.act = a; fake.append(b); return onListClick({ target: b }); };
  $('#ahPin', h).onclick = () => act('pin');
  $('#ahRename', h).onclick = () => act('rename');
  $('#ahDel', h).onclick = () => act('delete');
  $('#ahNew', h).onclick = newConversation;
  $('#ahPdf', h).onclick = e => exportPdf(e.currentTarget);
}
/** Export is a file, never a print: the server prints the conversation to a PDF in Documents\Mandata reports and opens it. */
function exportPdf(btn) {
  if (streaming) return toast('Wait for the answer, or press Stop');
  if (!cur?.list?.some(m => m.role === 'assistant')) return toast('Nothing answered yet to export');
  return busy(btn, async () => {
    const r = await api('POST', `/api/ask/${cur.id}/export`);
    pdfSaved(r);
  });
}

// ---------- the messages ----------
function renderThread() {
  const box = $('#askThread', root); if (!box) return;
  if (!cur) { box.innerHTML = welcome(); return; }
  box.innerHTML = cur.list.map((m, i) => m.role === 'user' ? userHtml(m) : answerHtml(m, cur.list[i - 1])).join('');
  const lastQ = cur.list.at(-1);
  if (lastQ?.role === 'user' && !streaming) box.insertAdjacentHTML('beforeend', errorHtml('No answer was saved for this question.', lastQ.id));
}
const fmt = n => Number(n || 0).toLocaleString(LOCALE);
function welcome() {
  const k = info?.knows || {}, st = info?.starters || [];
  const tiles = [['tasks', 'Tasks found', k.tasks, `${fmt(k.open)} open`], ['alert', 'Overdue', k.late, 'open and past their deadline'], ['thread', 'Threads read', k.threads, `${fmt(k.emails)} emails`],
    ['people', 'People', k.people, 'met in task mail']];
  return `<div class="ask-welcome">
    <div class="aw-hero"><span class="aw-logo">${icon('spark', 26)}</span><div><h1>Ask Mandata</h1>
      <p>Ask about anything Mandata has read or found: who asked you for what, what is late, where a thread stands, what someone is working on. Each answer cites the tasks, people and emails it comes from.</p></div></div>
    <div class="aw-know">${tiles.map(([ic, l, v, s]) => `<div class="aw-tile"><span>${icon(ic, 15)}</span><div><b>${info ? fmt(v) : '…'}</b><em>${l}</em><small>${info ? esc(s) : ''}</small></div></div>`).join('')}</div>
    <h4 class="aw-h">Try asking</h4>
    <div class="aw-starters">${(st.length ? st : [{ icon: 'clock', text: 'What is due this week?' }, { icon: 'send', text: 'What have I asked others to do that is still open?' }])
      .map(s => `<button class="aw-q" data-q="${esc(s.text)}"><span>${icon(s.icon, 15)}</span>${esc(s.text)}<i>${icon('arrow', 13)}</i></button>`).join('')}</div>
    ${k.since ? `<p class="aw-foot">Mandata has read your mail since ${esc(new Date(k.since).toLocaleDateString(LOCALE, { day: 'numeric', month: 'long', year: 'numeric' }))}. Mail older than that, or never read, is not known to it.</p>` : ''}
  </div>`;
}
const userHtml = m => `<div class="am am-user" data-mid="${m.id}"><div class="am-bubble">${esc(m.content).replace(/\n/g, '<br>')}</div></div>`;
function answerHtml(m, q) {
  const meta = m.meta || {}, refs = m.refs || [];
  const cited = refs.filter(r => r.cited !== false), related = refs.filter(r => r.cited === false);
  return `<div class="am am-ai" data-mid="${m.id}"><span class="am-av">${icon('spark', 14)}</span><div class="am-body">
    <div class="am-text md">${m.content ? md(m.content, cited) : `<p class="muted">${meta.stopped ? 'Stopped before anything was written.' : 'No answer.'}</p>`}</div>
    ${cited.length ? `<div class="am-refs"><span class="am-rl">${icon('list', 12)}Sources</span>${cited.map((r, i) => pill(r, i + 1)).join('')}</div>` : ''}
    ${related.length ? `<div class="am-refs rel"><span class="am-rl">${icon('tasks', 12)}Related tasks</span>${related.map(r => pill(r)).join('')}</div>` : ''}
    <div class="am-meta">${meta.stopped ? '<span class="am-stopped">Stopped</span>' : ''}${meta.error ? `<span class="red">${esc(meta.error)}</span>` : ''}
      <span>${esc(new Date(m.created_at).toLocaleTimeString(LOCALE, { hour: '2-digit', minute: '2-digit' }))}</span>${meta.ms ? `<span>${(meta.ms / 1000).toFixed(meta.ms < 10000 ? 1 : 0)} s</span>` : ''}
      ${meta.records != null ? `<span title="Records Mandata found and gave the AI for this question">${plural(meta.records, 'record')} read</span>` : ''}
      <span class="sp"></span><button data-copy="${m.id}" title="Copy the answer">${icon('copy', 13)}Copy</button>${q ? `<button data-retry="${q.id}" title="Answer this question again">${icon('refresh', 13)}Retry</button>` : ''}</div>
  </div></div>`;
}
const errorHtml = (msg, qid) => `<div class="am am-ai am-err"><span class="am-av">${icon('alert', 14)}</span><div class="am-body"><div class="am-errbox">${esc(msg)}
  <button class="btn sm" data-retry="${qid}">${icon('refresh', 13)}Try again</button></div></div></div>`;

/** A record cited, as a pill that opens it: a task with its kind's colour and when it is due, a person, a thread, an email. */
function pill(r, n) {
  const num = n ? `<span class="rp-n">${n}</span>` : '';
  if (r.gone) return `<span class="rpill gone" title="No longer in Mandata">${num}${esc(r.label || r.tag)}</span>`;
  if (r.type === 'task') {
    const d = dir(r.direction);
    const st = r.status !== 'open' ? (CLOSE[r.close_reason] || STATUS[r.status] || {}).label || r.status
      : r.days_left == null ? 'Deadline: None' : r.overdue ? `${-r.days_left}d late` : r.days_left === 0 ? 'Today' : r.days_left === 1 ? 'Tomorrow' : dateLabel(r.deadline);
    const cls = r.status !== 'open' ? 'closed' : r.overdue ? 'late' : r.days_left != null && r.days_left <= 1 ? 'soon' : '';
    return `<button class="rpill task" data-task="${esc(r.id)}" style="--c:${d.color};--s:${d.soft}" title="${esc(d.label)}: ${esc(r.label)}${r.who ? '\n' + esc(r.who) : ''}">${num}<i></i><span class="clamp1">${esc(r.label)}</span><em class="${cls}">${esc(st)}</em></button>`;
  }
  if (r.type === 'person') return `<button class="rpill person" data-person="${esc(r.id)}" title="${esc(r.label)}${r.sub ? '\n' + esc(r.sub) : ''}">${num}${avatar(r.label, r.id, 'xs')}<span class="clamp1">${esc(r.label)}</span></button>`;
  if (r.type === 'thread') return `<button class="rpill" data-thread="${esc(r.id)}" title="Thread: ${esc(r.label)}">${num}${icon('thread', 12)}<span class="clamp1">${esc(r.label)}</span></button>`;
  if (r.type === 'email') return `<button class="rpill" data-msg="${esc(r.id)}" title="Email: ${esc(r.label)}${r.sub ? '\n' + esc(r.sub) : ''}">${num}${icon('mail', 12)}<span class="clamp1">${esc(r.label)}</span></button>`;
  return '';
}

/** The answer's text: paragraphs, lists, bold and code, with each citation a small numbered mark that opens its record. */
function md(text, refs = null) {
  const idx = new Map((refs || []).map((r, i) => [r.tag, [r, i + 1]]));
  const inline = s => tone(esc(s)).replace(/==(.+?)==/g, '<mark>$1</mark>').replace(/\*\*(.+?)\*\*/g, '<b>$1</b>').replace(/(^|[^*])\*([^*\s][^*]*?)\*(?!\*)/g, '$1<i>$2</i>').replace(/`([^`]+)`/g, '<code>$1</code>')
    .replace(/\[([TPHEU]\d+)\]/g, (m, tg) => {
      if (!refs) return `<span class="cite pending">${tg.charAt(0) === 'T' ? '#' + tg.slice(1) : '·'}</span>`;
      const x = idx.get(tg); if (!x) return '';
      const [r, n] = x, attr = r.gone ? '' : r.type === 'task' ? `data-task="${esc(r.id)}"` : r.type === 'person' ? `data-person="${esc(r.id)}"` : r.type === 'thread' ? `data-thread="${esc(r.id)}"`
        : r.type === 'email' ? `data-msg="${esc(r.id)}"` : '';
      return `<sup class="cite" ${attr} title="${esc(r.label || '')}">${n}</sup>`;
    }).replace(/<\/sup>\s*(?=<sup)/g, '</sup>');
  const out = []; let list = null;
  const close = () => { if (list) { out.push(`</${list}>`); list = null; } };
  for (const raw of String(text || '').replace(/\r/g, '').split('\n')) {
    const line = raw.trimEnd();
    const b = line.match(/^\s*[-*•]\s+(.*)$/), o = line.match(/^\s*\d+[.)]\s+(.*)$/), h = line.match(/^\s*#{1,4}\s+(.*)$/);
    if (b || o) { const kind = b ? 'ul' : 'ol'; if (list !== kind) { close(); out.push(`<${kind}>`); list = kind; } out.push(`<li>${inline((b || o)[1])}</li>`); continue; }
    close();
    if (!line.trim()) continue;
    out.push(h ? `<h4>${inline(h[1].replace(/^\*\*(.*)\*\*$/, '$1'))}</h4>` : `<p>${inline(line)}</p>`);
  }
  close();
  return out.join('');
}
/** Where a task stands, coloured wherever the answer says it: late in red, due today or tomorrow in orange, done in green. */
const tone = s => s
  .replace(/\b((?:\d+ days? )?overdue(?: by \d+ days?)?|\d+ days? late|\d+d late)\b/gi, '<span class="tone late">$1</span>')
  .replace(/\b(due (?:today|tomorrow)|due within (?:the next )?\d+ days?)\b/gi, '<span class="tone soon">$1</span>')
  .replace(/\b(completed|closed as done|marked done)\b/gi, '<span class="tone done">$1</span>');
const plain = (text, refs) => String(text || '').replace(/\[([TPHEU]\d+)\]/g, (m, tg) => { const r = refs.find(x => x.tag === tg); return r && r.type === 'task' ? ` (task #${r.id})` : ''; }).replace(/\*\*|==/g, '').replace(/^\s*#{1,4}\s+/gm, '');

function onThreadClick(e) {
  const qb = e.target.closest('[data-q]');
  if (qb) { send(qb.dataset.q); return; }
  const cp = e.target.closest('[data-copy]');
  if (cp) { const m = cur?.list.find(x => x.id === Number(cp.dataset.copy)); if (m) navigator.clipboard.writeText(plain(m.content, m.refs || [])).then(() => toast('Answer copied'), e => toast(e.message, true)); return; }
  const rt = e.target.closest('[data-retry]');
  if (rt) { if (streaming) return toast('Wait for the answer, or press Stop'); send('', Number(rt.dataset.retry)); }
}

// ---------- the references of the whole conversation ----------
function renderRefs() {
  const box = $('#askRefs', root); if (!box) return;
  if (!cur) {
    box.innerHTML = `<h3>${icon('spark', 14)} How it works</h3><ul class="ask-how">
      <li><span>${icon('search', 14)}</span><div><b>Finds the records</b>Mandata searches your tasks, threads, people, emails and organisation for each question.</div></li>
      <li><span>${icon('list', 14)}</span><div><b>Cites its sources</b>Every answer lists the records it used. Click one to open it.</div></li>
      <li><span>${icon('pause', 14)}</span><div><b>Puts you first</b>While it answers, mail reading and other background work pause, then resume.</div></li>
      <li><span>${icon('eye', 14)}</span><div><b>Stays private</b>The AI runs on this computer. Nothing leaves it.</div></li></ul>
      <div class="ask-tip">${icon('chat', 13)}<span>Follow up naturally: "and which of those are late?" Mandata remembers the conversation.</span></div>`;
    return;
  }
  const seen = new Map();
  for (const m of cur.list) for (const r of m.refs || []) if (r.cited !== false && !r.gone) seen.set(`${r.type}:${r.id}`, r);
  const all = [...seen.values()];
  const group = (type, title, ic) => { const rs = all.filter(r => r.type === type); return rs.length ? `<div class="ar-group"><h4>${icon(ic, 12)}${title}<em>${rs.length}</em></h4>${rs.map(r => pill(r)).join('')}</div>` : ''; };
  box.innerHTML = `<h3>${icon('list', 14)} In this conversation <em class="ar-n">${all.length}</em></h3>` + (all.length
    ? group('task', 'Tasks', 'tasks') + group('person', 'People', 'user') + group('thread', 'Threads', 'thread') + group('email', 'Emails', 'mail')
    : `<p class="muted small ar-empty">The tasks, people and emails the answers cite gather here, so you can open any of them later.</p>`);
}

function renderHint() {
  const h = $('#askHint', root); if (!h) return;
  const ai = S.status?.ai || {};
  h.classList.toggle('warn', !ai.online);
  h.innerHTML = streaming ? `${icon('pause', 12)}<span>Background reading is paused while Mandata answers. It resumes on its own.</span>`
    : !ai.online ? `${icon('alert', 12)}<span>The AI is offline: ${esc(ai.error || 'start it from the AI pill at the top right')}.</span>`
    : `<span><kbd>Enter</kbd> to send · <kbd>Shift</kbd>+<kbd>Enter</kbd> for a new line · answered by ${esc(ai.model || 'the local AI')} on this computer</span>`;
  const b = $('#askSend', root);
  if (b) { b.classList.toggle('stop', !!streaming); b.innerHTML = icon(streaming ? 'stop' : 'up', streaming ? 15 : 17); b.title = streaming ? 'Stop' : 'Send (Enter)'; }
}

// ---------- asking ----------
function submit() { const i = $('#askIn', root); const t = i?.value.trim(); if (!t) return; send(t); }
async function send(question, retry = null) {
  if (streaming) return;
  const i = $('#askIn', root);
  if (!retry) { draft = ''; if (i) { i.value = ''; grow(); } }
  const box = $('#askThread', root);
  if (!cur) box.innerHTML = '';
  // The question shows at once; the answer takes its place below as it is written.
  if (retry) {
    const qEl = box.querySelector(`[data-mid="${retry}"]`);
    let n = qEl?.nextElementSibling;
    while (n && !n.classList.contains('am-user')) { const x = n.nextElementSibling; n.remove(); n = x; }
    if (cur) { const k = cur.list.findIndex(m => m.id === retry); if (cur.list[k + 1]?.role === 'assistant') cur.list.splice(k + 1, 1); }
  } else box.insertAdjacentHTML('beforeend', `<div class="am am-user pending"><div class="am-bubble">${esc(question).replace(/\n/g, '<br>')}</div></div>`);
  const live = document.createElement('div');
  live.className = 'am am-ai live';
  live.innerHTML = `<span class="am-av">${icon('spark', 14)}</span><div class="am-body"><div class="am-phase"><span class="dots"><i></i><i></i><i></i></span><span class="ph">Starting</span></div><div class="am-text md"></div></div>`;
  box.append(live);
  scrollEnd(true);
  const ctrl = new AbortController();
  const me = streaming = { stop: () => ctrl.abort(), conv: cur?.id || null };
  renderHint();
  let text = '', raf = 0, failed = '', userId = retry;
  const paint = () => { raf = 0; $('.am-text', live).innerHTML = md(text) + '<span class="ask-caret"></span>'; scrollEnd(); };
  const handle = ev => {
    if (streaming !== me) return;
    if (ev.t === 'start') {
      userId = ev.user.id;
      const pend = box.querySelector('.am-user.pending'); if (pend) { pend.classList.remove('pending'); pend.dataset.mid = ev.user.id; }
      if (!cur || cur.id !== ev.conversation.id) {
        cur = { ...ev.conversation, list: [] };
        streaming.conv = cur.id;
        go('ask', cur.id);   // select() leaves a conversation being answered as it is
      }
      if (!retry) cur.list.push(ev.user);
      cur = { ...cur, ...ev.conversation, list: cur.list };
      renderHead(); loadList();
    } else if (ev.t === 'phase') $('.ph', live).textContent = ev.text;
    else if (ev.t === 'token') { text += ev.text; live.classList.add('writing'); if (!raf) raf = requestAnimationFrame(paint); }
    else if (ev.t === 'done') {
      cur = { ...cur, ...ev.conversation, list: [...cur.list, ev.message] };
      const q = cur.list.find(m => m.id === userId);
      live.outerHTML = answerHtml(ev.message, q);
    } else if (ev.t === 'error') failed = ev.error;
  };
  try {
    const r = await fetch('/api/ask/answer', { method: 'POST', headers: { 'content-type': 'application/json' }, signal: ctrl.signal,
      body: JSON.stringify({ conversation_id: cur?.id || null, question, retry }) });
    if (!r.ok || !r.body) throw new Error((await r.json().catch(() => ({}))).error || r.statusText);
    const reader = r.body.getReader(), dec = new TextDecoder();
    let buf = '';
    for (;;) {
      const { value, done } = await reader.read();
      if (done) break;
      buf += dec.decode(value, { stream: true });
      let k;
      while ((k = buf.indexOf('\n')) >= 0) { const line = buf.slice(0, k).trim(); buf = buf.slice(k + 1); if (!line) continue; let ev; try { ev = JSON.parse(line); } catch { continue; } handle(ev); }
    }
  } catch (e) { if (e.name !== 'AbortError') failed = e.message; }
  cancelAnimationFrame(raf);
  // Dropped (the view closed, or another conversation opened): what is on screen is no longer this answer's.
  if (streaming !== me) return void loadList();
  const stopped = ctrl.signal.aborted;
  streaming = null;
  if (live.isConnected) {
    if (failed) live.outerHTML = errorHtml(failed, userId || retry);
    else if (stopped) live.remove();
  }
  renderHint();
  // After a stop the server keeps what was written: the saved conversation is shown as it is.
  if (cur?.id) { const k = selN; try { const c = await GET('/api/ask/' + cur.id); if (S.route === 'ask' && k === selN && !streaming) { cur = c; renderAll(); scrollEnd(); } } catch {} }
  loadList();
  focusInput();
}
