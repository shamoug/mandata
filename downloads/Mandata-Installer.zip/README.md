# Mandata installer

A folder of scripts, not a setup program: nothing is built and nothing needs signing, so **no code-signing
certificate is needed**. It installs for the current user only, with no admin rights, on Windows 10 or 11 (x64 or
ARM64).

| File | What it does |
| --- | --- |
| `install.bat` | Installs Mandata, or updates it when it is already installed. |
| `uninstall.bat` | Removes it (also available from Settings > Apps > Mandata). |
| `pack.bat` | Makes a copy of this folder, with the app's files, to share with others. |

## Install

Double-click `install.bat`. It:

1. **Checks this computer:**
   - 64-bit Windows.
   - PowerShell allowed to run scripts (some IT policies block it).
   - Classic Outlook. The new Outlook doesn't work with the app; a missing classic Outlook only gives a warning.
   - Free disk space before each download.
   - That GitHub can be reached.

   Nothing else is needed: the app runtime includes everything it uses, and Ollama brings its own libraries.
2. **Gets the app runtime (Electron) if it's missing:** it downloads Electron from its official GitHub release, checks it against the published SHA-256, and unpacks it to `%LOCALAPPDATA%\Programs\Mandata`. `electron.exe` is renamed `Mandata.exe`. When the runtime is already there, only the app's files are replaced, which takes a few seconds.
3. **Copies the app's files** into `resources\app`. Data files are never copied, and your data in `%USERPROFILE%\.mandata` is never touched.
4. **Adds shortcuts:** one in the Start Menu and one on the Desktop. It also adds an entry in **Settings > Apps** so you can uninstall from there.
5. **Installs the local AI if it's missing.** That means the Ollama runtime plus the best model for this computer's memory and graphics card (`phi4-mini` without a separate graphics card, `qwen3:4b-instruct` with one), a download of 3 to 20 GB. It asks first, then checks that the model answers. The app starts with that model until another is chosen in Settings > AI. The log is in `%LOCALAPPDATA%\Mandata-setup\ai-setup.log`.
6. **Starts Mandata.** On its first start, the app registers itself to start with Windows; untick "Start with Windows" in its tray menu to stop that.

**Taskbar:** Windows doesn't let any installer pin apps to the taskbar. While Mandata runs, right-click its icon on
the taskbar and choose **Pin to taskbar**.

Options (pass them after `install.bat`):

| Option | Effect |
| --- | --- |
| `-AI no` / `-AI yes` | Skip the AI, or install it without asking. |
| `-Model qwen3:8b` | Install this model instead of the best one for the computer. |
| `-NoDesktopIcon` | No Desktop shortcut. |
| `-NoLaunch` | Don't start the app at the end. |

Run `install.bat` again at any time to update the app or to finish an AI install that didn't complete.

## Share it with others

Double-click `pack.bat`. It puts a `Mandata-Installer` folder and `Mandata-Installer-<version>.zip` (about 0.5 MB)
on your Desktop. The zip holds the folder's contents directly, so on the other computer Extract All, open the
folder it makes and double-click `install.bat`.
No data is ever packed: no database, backup or log file.

Options: `pack.bat -OutputDir D:\share` writes to another folder (made if missing), and `-ZipOnly` writes only the
zip there, without the `Mandata-Installer` folder.

## Why no certificate is needed

Windows SmartScreen ("Windows protected your PC", "Unknown publisher") checks only files that carry the
"downloaded from the internet" mark. Browsers, Outlook and Teams add that mark to what they download. There is no
setup program here to mark. The runtime is downloaded by the script itself, which adds no such mark, and the script
checks the file's SHA-256 instead. The script also clears the mark from every file it installs.

**If you received the zip by email or Teams:** before extracting it, right-click the zip → **Properties** → tick
**Unblock** → OK. Otherwise Windows may ask for confirmation before running `install.bat`. Once `install.bat` runs, it
clears the mark from the folder's other files itself.

## Uninstall

Settings > Apps > Mandata > Uninstall, or double-click `uninstall.bat`. This removes the app, its shortcuts, its
start-up entry and its Settings entry. It asks before deleting anything else:

- your data in `%USERPROFILE%\.mandata` (kept by default)
- the Ollama runtime and AI model, only if this installer installed them (kept by default)

## If something goes wrong

- **"PowerShell runs in ConstrainedLanguage mode"** or **the scripts don't run at all**: an IT policy blocks PowerShell scripts. Ask IT to allow them, or to install the app for you.
- **Mandata.exe is blocked from running**: some IT policies (AppLocker) allow programs only from Program Files. Ask IT to allow `%LOCALAPPDATA%\Programs\Mandata\Mandata.exe`. A certificate wouldn't change this.
- **A download fails**: check the internet connection or proxy. The installer uses the Windows proxy settings and signs in to the proxy as you. Then run `install.bat` again, and it continues where it stopped.
- **"Could not replace ..."**: quit Mandata from its tray icon and run `install.bat` again.
- **"Not enough disk space"**: the app needs about 0.8 GB, and the AI needs its model's size plus 2 GB (about 5 GB for `phi4-mini`).
