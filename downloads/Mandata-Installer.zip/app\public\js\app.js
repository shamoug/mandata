// Shell: top navigation, live connection status, server events.
import { esc, icon, ago, toast, api, $, $$, closeModalOf, modal, pref, setPref } from './ui.js';
import { S, emit, on, go, loadStatus, loadConfig, loadMeta, clearViewSubs } from './store.js';
import { openSettings } from './settings.js';
import { openAIManager } from './aimanage.js';
import { openSignIn } from './signin.js';
import { initUpdates, openUpdates, onUpdateEvent } from './updates.js';
import { initSortTables } from './sorttable.js';
import { initSelectSearch } from './selectsearch.js';
import { initTips } from './tips.js';
import { theme, toggleTheme, initTheme } from './theme.js';
initTheme();   // before the first await, so the dark rules are in place as the page first draws
import { closeTask, openTask, currentTask, openEmail, openDraft } from './panels.js';
import * as overview from './views/overview.js';
import * as tasks from './views/tasks.js';
import * as threads from './views/threads.js';
import * as people from './views/people.js';
import * as drafts from './views/drafts.js';
import * as activity from './views/activity.js';
import * as insights from './views/insights.js';
import * as bin from './views/bin.js';
import * as ask from './views/ask.js';
import * as reports from './views/reports.js';

const VIEWS = { overview, ask, reports, tasks, insights, threads, people, drafts, activity, bin };
// The main tabs, in the order of a working day: [route, label, icon, status count, colour, tooltip]. Each section has its own
// colour (as in Settings); the page takes it as --gc.
// Activity, the app's own log, sits with the status at the right (ACTIVITY).
const TABS = [['overview', 'Overview', 'home', 'overdue', '#4263eb', 'Overview: what needs you today'], ['tasks', 'Tasks', 'tasks', null, '#2f9e44', 'Every task found in your email'],
  ['drafts', 'Follow-ups', 'draft', 'drafts', '#f08c00', 'Follow-up and forward emails drafted for you'], ['threads', 'Threads', 'thread', null, '#1c7ed6', 'The email conversations read'],
  ['people', 'People', 'user', 'people', '#0c8599', 'The people in your task mail'], ['insights', 'Insights', 'grid', null, '#e8590c', 'Cross any two things about your tasks'],
  ['reports', 'Reports', 'report', null, '#087f5b', 'Weekly reports: the story of each week, exported as a PDF']];
const ACTIVITY = ['activity', 'Activity', 'pulse', null, '#c92a2a'];
// Ask Mandata is not a tab: a floating button opens it (askFab below).
const ASK = ['ask', 'Ask Mandata', 'chat', null, '#1864ab'];
// A route shown under another tab: the recycle bin under Tasks.
const UNDER = { bin: 'tasks' };
let current = null;

// The tabs are drawn once; each status only moves the highlight and the counts, so focus and hover stay where they are.
$('#nav').innerHTML = TABS.map(([id, label, ic, , col, tip]) => `<button data-r="${id}" title="${tip}" style="--gc:${col}">${icon(ic, 15)}<span>${label}</span></button>`).join('');
function renderNav() {
  const c = S.status?.counts || {};
  const r = UNDER[S.route] || S.route;
  document.documentElement.style.setProperty('--gc', ([...TABS, ACTIVITY, ASK].find(t => t[0] === r) || TABS[0])[4]);
  for (const b of $$('#nav button')) {
    const on = b.dataset.r === r, k = TABS.find(t => t[0] === b.dataset.r)[3], n = k === 'shown' ? S.taskCount : k && c[k];
    b.classList.toggle('on', on);
    if (on) b.setAttribute('aria-current', 'page'); else b.removeAttribute('aria-current');
    let em = $('em', b);
    if (!n) { em?.remove(); continue; }
    if (!em) em = b.appendChild(document.createElement('em'));
    em.className = k === 'overdue' ? 'red' : '';
    if (em.textContent !== String(n)) em.textContent = n;
  }
  $('#openActivity')?.classList.toggle('on', r === 'activity');
}
// ---------- Ask Mandata: a floating button, dragged anywhere and kept there ----------
// Its place is saved with the other preferences, as a share of the room left in the window, so it stays put when the window resizes.
// Hidden on the Ask screen itself and while a dialog is open (styles.css: body:has(.overlay)).
const fab = document.createElement('button');
fab.className = 'askfab'; fab.id = 'askFab'; fab.title = 'Ask Mandata anything about your tasks, threads, people and mail (drag to move it)';
fab.setAttribute('aria-label', 'Ask Mandata');
fab.innerHTML = `${icon('chat', 16)}<span>Ask Mandata</span>`;
document.body.append(fab);
const fabRoom = () => [Math.max(0, innerWidth - fab.offsetWidth - 16), Math.max(0, innerHeight - fab.offsetHeight - 16)];
function placeFab(p = pref('askFab', { x: 1, y: 0.88 })) {
  const [w, h] = fabRoom(), cl = v => Math.min(1, Math.max(0, Number(v) || 0));
  fab.style.left = 8 + cl(p.x) * w + 'px'; fab.style.top = 8 + cl(p.y) * h + 'px';
}
// Placed again whenever the window or the button changes size: a window that starts hidden (in the tray) has no size yet,
// and the button has none while it is hidden on the Ask screen.
placeFab(); new ResizeObserver(() => placeFab()).observe(document.documentElement); new ResizeObserver(() => placeFab()).observe(fab);
let fabDrag = null;
fab.addEventListener('pointerdown', e => {
  if (e.button !== 0) return;
  const r = fab.getBoundingClientRect();
  fabDrag = { dx: e.clientX - r.left, dy: e.clientY - r.top, x0: e.clientX, y0: e.clientY, moved: false };
  fab.setPointerCapture(e.pointerId);
});
fab.addEventListener('pointermove', e => {
  if (!fabDrag) return;
  if (!fabDrag.moved && Math.hypot(e.clientX - fabDrag.x0, e.clientY - fabDrag.y0) < 5) return;   // a click that wobbles is still a click
  fabDrag.moved = true; fab.classList.add('dragging');
  const [w, h] = fabRoom();
  placeFab({ x: w ? (e.clientX - fabDrag.dx - 8) / w : 0, y: h ? (e.clientY - fabDrag.dy - 8) / h : 0 });
});
const fabDrop = () => {
  if (!fabDrag) return;
  const moved = fabDrag.moved; fabDrag = null; fab.classList.remove('dragging');
  if (!moved) { location.hash = '#/ask'; return; }
  const [w, h] = fabRoom(), r = fab.getBoundingClientRect();
  setPref('askFab', { x: w ? (r.left - 8) / w : 0, y: h ? (r.top - 8) / h : 0 });
};
fab.addEventListener('pointerup', fabDrop);
fab.addEventListener('pointercancel', () => { if (fabDrag) { fabDrag.moved = true; fabDrop(); } });
// From the keyboard (Enter, Space) it opens Ask like a click; arrows move it.
fab.addEventListener('keydown', e => {
  const d = { ArrowLeft: [-1, 0], ArrowRight: [1, 0], ArrowUp: [0, -1], ArrowDown: [0, 1] }[e.key];
  if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); location.hash = '#/ask'; return; }
  if (!d) return;
  e.preventDefault();
  const p = pref('askFab', { x: 1, y: 0.88 }), st = e.shiftKey ? 0.1 : 0.02, cl = v => Math.min(1, Math.max(0, v));
  const np = { x: cl(p.x + d[0] * st), y: cl(p.y + d[1] * st) };
  setPref('askFab', np); placeFab(np);
});

// The Tasks tab always opens on Open and Assigned to me (links into Tasks with filters of their own keep theirs).
$('#nav').onclick = e => { const b = e.target.closest('button'); if (!b) return; if (b.dataset.r === 'tasks') tasks.resetFilters(); location.hash = '#/' + b.dataset.r; };

// The status bar is drawn once; each status changes only its words, colours and tooltips.
$('#status').innerHTML = `
  <div class="st" id="mailPill" data-go="#/activity"><span class="dot"></span><span class="clamp1 st-l"></span><span class="st-s"></span></div>
  <div class="st" id="aiPill"><span class="dot"></span><span class="clamp1 st-l"></span><span class="st-s"></span></div>
  <div class="st-btns"><button id="updBtn" class="updbtn" hidden></button><button id="syncNow" title="Check mail now">${icon('refresh', 14)}</button><button id="openActivity" data-go="#/activity" title="Activity: what the app did, and threads it got stuck on">${icon('pulse', 14)}</button><button id="themeBtn"></button><button id="openSettings" title="Settings">${icon('gear', 14)}</button></div>`;
$('#themeBtn').onclick = () => { toggleTheme(); renderTheme(); };
$('#syncNow').onclick = () => api('POST', '/api/sync').then(() => toast('Checking mail now')).catch(e => toast(e.message, true));
$('#openSettings').onclick = openSettings;
initUpdates();
$('#aiPill').onclick = () => openAIManager();
// Microsoft 365 not signed in: the mail pill signs you in instead of opening the activity log.
$('#mailPill').addEventListener('click', e => {
  const o = S.status?.outlook;
  if (o?.kind === 'microsoft365' && !o.signedIn) { e.stopImmediatePropagation(); e.preventDefault(); openSignIn(); }
}, true);
function renderTheme() {
  const b = $('#themeBtn'), dark = theme() === 'dark', tip = dark ? 'Switch to light mode' : 'Switch to dark mode';
  if (b.dataset.t === theme()) return;
  b.dataset.t = theme(); b.title = tip; b.setAttribute('aria-label', tip); b.innerHTML = icon(dark ? 'sun' : 'moon', 14);
}
renderTheme();
/** One pill: its state (ok, busy, bad), its long and short words, and its tooltip. Only what changed is touched. */
function pill(el, cls, long, short, tip) {
  if (el.className !== 'st ' + cls) el.className = 'st ' + cls;
  const l = $('.st-l', el), sh = $('.st-s', el);
  if (l.textContent !== long) l.textContent = long;
  if (sh.textContent !== short) sh.textContent = short;
  if (el.title !== tip) el.title = tip;
}
function renderStatus() {
  const s = S.status; if (!s) return;
  const o = s.outlook, y = s.sync, ai = s.ai;
  // Each pill has a short label that always fits (st-s) and, on wide screens, the whole story (st-l); the tooltip says it all.
  // Classic Outlook (Windows) or Microsoft 365 (macOS, Linux, or chosen in Settings > Mail).
  const name = o.kind === 'microsoft365' ? 'Microsoft 365' : 'Outlook', signIn = o.kind === 'microsoft365' && !o.signedIn;
  let cls = 'bad', txt = `${name} not connected`, short = `${o.kind === 'microsoft365' ? 'Mail' : 'Outlook'} off`;
  // The AI works on something you asked for: everything else waits, and the pill says so.
  if (ai.focus) { cls = 'busy focus'; txt = ai.focus + ' · background paused'; short = 'Working for you'; }
  else if (signIn) { cls = o.signIn ? 'busy' : 'bad'; txt = o.signIn ? 'Finish signing in to Microsoft 365' : 'Sign in to Microsoft 365 to read your mail'; short = 'Sign in'; }
  else if (y.running || y.aiBusy) { cls = 'busy'; txt = y.phase || y.aiPhase || 'Working'; short = 'Working'; }
  else if (o.connected) { cls = y.error ? 'bad' : 'ok'; txt = y.error ? 'Last mail check failed' : `${name} connected`; short = y.error ? 'Mail check failed' : name === 'Outlook' ? name : 'Mail'; }
  else if (o.error) txt = `${name}: ` + o.error.slice(0, 50);
  pill($('#mailPill'), cls, txt, short, txt + (o.user ? '\n' + o.user : '') + (y.lastOk ? '\nLast checked ' + ago(y.lastOk) : '') + (y.error ? '\n' + y.error : '') + (signIn ? '\n\nClick to sign in' : '\n\nClick for the activity log'));
  const aiLong = `AI ${ai.pull ? `downloading ${ai.pull.model} ${ai.pull.percent}%` : ai.paused ? 'paused' : ai.online ? ai.model + (ai.device === 'cpu' ? ' (CPU)' : '') : 'offline'}${y.threadsQueued ? ` · ${y.threadsQueued} to read` : ''}${y.threadsStuck ? ` · ${y.threadsStuck} stuck` : ''}`;
  const aiShort = `AI ${ai.pull ? ai.pull.percent + '%' : ai.paused ? 'paused' : !ai.online ? 'offline' : y.threadsQueued ? `· ${y.threadsQueued} to read` : 'ready'}`;
  pill($('#aiPill'), ai.paused || ai.pull ? 'busy' : ai.online ? 'ok' : 'bad', aiLong, aiShort,
    `AI management: models, install, speed\n\nAI ${ai.online ? ai.model : 'offline'}${ai.paused ? ' (paused in Settings)' : ''}${ai.device ? ` on the ${ai.device === 'gpu' ? 'GPU' : ai.device === 'cpu' ? 'processor (no GPU)' : 'GPU and processor'}` : ''}${ai.speed?.prompt ? `\nReads ${ai.speed.prompt} and writes ${ai.speed.output} tokens a second` : ''}${y.threadsStuck ? `\n${y.threadsStuck} stuck thread${y.threadsStuck > 1 ? 's' : ''}, listed at the top of Activity` : ''}\n${ai.error || 'Runs on this computer. Email never leaves it.'}`);
  renderTheme();
}

// About, from the icon at the top left: what the name means, the version, and where things are.
function openAbout() {
  const s = S.status || {};
  const ver = s.version ? s.version.replace(/\.0$/, '') : '';
  modal({ title: 'About Mandata', size: 'about', body: `
    <div class="about-hero"><img src="icon.png" alt=""><div><h3>Mandata</h3>${ver ? `<span class="ver">Version ${esc(ver)}</span>` : ''}
      <div class="muted" style="margin-top:4px">Tasks found in your email, followed to the end</div></div></div>
    <div class="about-name">
      <div class="word">mandata <i>Latin, /man·dá·ta/</i></div>
      <p><b>Things entrusted; instructions given to someone to carry out.</b> The plural of <i>mandatum</i>, a charge or commission.</p>
      <p class="root">From <i>mandare</i>, "to entrust, to place in someone's hand" (<i>manus</i>, hand + <i>dare</i>, to give). It is also the root of <i>mandate</i>, the word the UN uses for the work it is entrusted with.</p>
    </div>
    <div class="about-sec"><h4>Why the name</h4>
      <p>Every email that asks someone to do something hands them a <i>mandatum</i>. Mandata finds each one in your Outlook threads, notes who entrusted what to whom, and follows it from the email that opened it to the email that closed it.</p></div>
    <div class="about-sec"><h4>Private by design</h4>
      <p>The AI runs on this computer. Your email never leaves it.</p></div>
    <dl class="about-facts">
      ${s.ai?.model ? `<dt>AI model</dt><dd>${esc(s.ai.model)}</dd>` : ''}
      ${s.dataDir ? `<dt>Your data</dt><dd>${esc(s.dataDir)}</dd>` : ''}
      <dt>Publisher</dt><dd>United Nations Development Coordination Office</dd>
    </dl>` });
}
$('#about').onclick = openAbout;

// One click router for the whole app. Anything carrying one of these attributes is clickable, everywhere:
//   data-go="#/route/arg"  navigate        data-person="email"  open the profile    data-thread="id"  open the thread
//   data-task="id"         open the task   data-msg="email id"  read the email      data-draft="id"   open the draft
//   data-scroll="#id"      scroll to a section on the page
// The innermost one wins, so a person inside a task card opens the person. A button or field nested inside keeps its own click.
const CLICK = '[data-go],[data-person],[data-task],[data-msg],[data-draft],[data-thread],[data-scroll]';
document.addEventListener('click', e => {
  if (e.defaultPrevented || e.button !== 0) return;
  const el = e.target.closest(CLICK);
  if (!el) return;
  const ctl = e.target.closest('button,a[href],input,select,textarea,label');
  if (ctl && ctl !== el && el.contains(ctl)) return;
  const d = el.dataset;
  e.preventDefault(); e.stopPropagation();
  const leave = () => closeModalOf(el);
  if (d.go != null) { leave(); location.hash = d.go; }
  else if (d.person != null) { if (d.person) { leave(); go('people', d.person); } }
  else if (d.thread != null) { if (d.thread) { leave(); go('threads', d.thread); } }
  else if (d.task != null) { if (Number(d.task) !== currentTask() || !el.closest('#drawer')) { leave(); openTask(Number(d.task)); } }
  else if (d.msg != null) { if (d.msg) openEmail(d.msg); }
  else if (d.draft != null) openDraft(Number(d.draft));
  else if (d.scroll) { const t = document.querySelector(d.scroll); if (t) { t.scrollIntoView({ behavior: 'smooth', block: 'start' }); t.classList.remove('flash'); void t.offsetWidth; t.classList.add('flash'); } }
});
// Ctrl+Z undoes your last change (close, reopen, an edit, a hidden person, a discarded draft...) made on the screen you
// are on: moving to another screen clears what can be undone (see route). In a text field it stays the field's own undo.
document.addEventListener('keydown', async e => {
  if (!(e.ctrlKey || e.metaKey) || e.shiftKey || e.altKey || e.key.toLowerCase() !== 'z' || e.repeat) return;
  if (e.target.closest('input,textarea,select,[contenteditable]')) return;
  e.preventDefault();
  try {
    const r = await api('POST', '/api/undo');
    if (!r.label) return toast('Nothing to undo');
    toast(`Undone: ${r.label}`);
    if (r.table === 'tasks' && r.id === currentTask()) openTask(r.id);
  } catch (err) { toast(err.message, true); }
});

// Back: each screen you move to is a numbered step in the window's history (history.state.step), so Back (the button at
// the top, Alt+Left or the mouse's back button) returns to the screen you came from, with the task that was open there.
const NAMES = { ...Object.fromEntries([...TABS, ACTIVITY, ASK].map(t => [t[0], t[1]])), bin: 'Recycle bin' };
// "#/update" (the tray's Check for updates, an update notification) is not a screen: it opens the update dialog over
// the screen you are on, and leaves no step in the history.
let updateAsked = /^#\/update/.test(location.hash);
if (updateAsked) history.replaceState(history.state, '', pref('route', '#/overview') || '#/overview');
window.addEventListener('hashchange', e => {
  if (!/^#\/update/.test(location.hash)) return;
  e.stopImmediatePropagation(); history.back(); openUpdates();
});
// Opened without a screen (the app starting): the one you were on when you left.
{ const last = pref('route', ''); if (!location.hash && /^#\/[a-z]+(\/|$)/.test(last)) history.replaceState(history.state, '', last); }
const trail = [];   // per step: { hash, task }
let step = history.state?.step ?? 0;
if (history.state?.step == null) history.replaceState({ ...history.state, step }, '');
trail[step] = { hash: location.hash };
function track() {
  if (trail[step]) trail[step].task = currentTask();
  const s = history.state?.step;
  if (s == null) { step += 1; history.replaceState({ ...history.state, step }, ''); trail.length = step; }
  else step = s;
  trail[step] = { ...trail[step], hash: location.hash };
}
function renderBack() {
  const prev = trail[step - 1];
  const r = prev && ((prev.hash || '').match(/^#\/([^/]+)/) || [])[1];
  const tip = step > 0 ? `Back to ${prev ? NAMES[r] || 'Overview' : 'the previous screen'} (Alt+Left)` : 'Back: nothing to go back to yet';
  const b = $('#back');
  b.disabled = step <= 0; b.title = tip; b.setAttribute('aria-label', tip);
}
const goBack = () => { if (step > 0 && !document.querySelector('.overlay')) history.back(); };
$('#back').innerHTML = icon('back', 16);
$('#back').onclick = goBack;
document.addEventListener('keydown', e => { if (e.altKey && e.key === 'ArrowLeft' && !e.ctrlKey && !e.shiftKey && !e.target.closest('input,textarea,select,[contenteditable]')) { e.preventDefault(); goBack(); } });
document.addEventListener('mouseup', e => { if (e.button === 3) { e.preventDefault(); goBack(); } });

function route(force) {
  const [, r = 'overview', arg = ''] = location.hash.match(/^#\/([^/]+)\/?(.*)$/) || [];
  const name = VIEWS[r] ? r : 'overview';
  let a = arg; try { a = decodeURIComponent(arg); } catch {}   // a hand-typed "%" is not an escape: kept as typed
  // The filters a link to Tasks carried are kept as the filters themselves (tasks.js): the screen alone, or they would come back over your later changes.
  setPref('route', (location.hash || '#/overview').replace(/^#\/tasks\/\?.*$/, '#/tasks'));
  if (!force && current === name && S.arg === a) return;
  const same = !force && current === name;
  S.route = name; S.arg = a; renderNav(); fab.hidden = name === 'ask';
  if (same && VIEWS[name].select) return VIEWS[name].select(a);
  if (name !== 'tasks' || !/^\d+$/.test(a)) closeTask();
  if (current !== name) api('POST', '/api/undo/reset').catch(() => {});   // a new screen starts with nothing to undo
  current = name;
  clearViewSubs();
  $('#main').innerHTML = '';
  $('#main').scrollTop = 0;
  VIEWS[name].mount($('#main'), a);
}

// Server events: refresh only what changed; bursts collapse into one reload, and a steady stream still reloads every 1.5 s.
const timers = {};
const soon = (k, fn, ms = 400, maxWait = 1500) => {
  const t = timers[k] ||= { first: Date.now() };
  clearTimeout(t.id);
  t.id = setTimeout(() => { delete timers[k]; fn(); }, Math.max(0, Math.min(ms, t.first + maxWait - Date.now())));
};
const status = (ms = 200) => soon('status', () => loadStatus().catch(() => {}), ms);
function connectEvents() {
  const es = new EventSource('/api/events');
  es.onmessage = m => {
    let d; try { d = JSON.parse(m.data); } catch { return; }
    if (d.type === 'notify') return;   // shown by the desktop app
    if (d.type === 'update') return onUpdateEvent(d.update);   // at once: it moves the progress bar
    if (d.type === 'status') status();
    // New settings are loaded and announced (store 'config'): the views that draw with them draw again; nothing else is rebuilt.
    else if (d.type === 'config') soon('config', () => loadConfig().catch(() => {}));
    // Not every change comes with a status of its own (new people, drafts), and the counts in the tabs may have moved.
    else { status(600); soon(d.type, () => emit(d.type, d)); }
  };
  // Back after a break (the app restarted, the computer slept): what changed meanwhile is loaded, as events were missed.
  let lost = false;
  es.onopen = () => {
    if (!lost) return; lost = false; status(0); soon('config', () => loadConfig().catch(() => {}), 0);
    for (const k of ['tasks', 'threads', 'people', 'drafts', 'activity', 'lessons', 'reports', 'ask', 'models']) soon(k, () => emit(k, {}));
  };
  es.onerror = () => { lost = true; if (S.status) { S.status.outlook.connected = false; S.status.outlook.error = 'App server not reachable'; renderStatus(); } };
}

on('status', () => { renderStatus(); renderNav(); });
on('taskCount', renderNav);

(async () => {
  try { await Promise.all([loadMeta(), loadConfig(), loadStatus()]); }
  catch (e) { toast('Cannot reach the app server: ' + e.message, true); }
  window.addEventListener('hashchange', () => {
    track(); route(); renderBack();
    const t = trail[step]?.task;   // the task that was open on this screen when you left it
    if (t && t !== currentTask()) openTask(t);
  });
  initSortTables();
  initSelectSearch();
  initTips();
  route(); renderBack();
  tasks.trackCount();
  connectEvents();
  if (updateAsked) openUpdates();
})();
