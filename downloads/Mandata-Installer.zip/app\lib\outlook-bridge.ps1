﻿# Mandata: long-lived bridge to classic Outlook desktop (COM).
# Protocol: one JSON request per line on stdin {id, cmd, args}; one JSON reply per line on stdout {id, ok, data|error}.
# Outlook is already signed in, so no app registration or password is needed.

$ErrorActionPreference = 'Stop'
[Console]::InputEncoding  = New-Object System.Text.UTF8Encoding $false
[Console]::OutputEncoding = New-Object System.Text.UTF8Encoding $false

$script:ol = $null
$script:ns = $null
$script:smtpCache = @{}

# While Outlook starts, closes or shows a dialog, its COM objects can come back empty (null) instead of failing.
# An empty link counts as no link: it is made again, and a mailbox that is still not there is a clear error.
function Connect-Outlook {
  if ($script:ns) {
    try { if ($null -ne $script:ns.CurrentUser -and $null -ne $script:ns.DefaultStore) { return } } catch {}
    $script:ol = $null; $script:ns = $null; $script:smtpCache = @{}
  }
  $script:ol = New-Object -ComObject Outlook.Application
  $script:ns = if ($script:ol) { $script:ol.GetNamespace('MAPI') } else { $null }
  if ($null -eq $script:ns -or $null -eq $script:ns.DefaultStore) {
    $script:ol = $null; $script:ns = $null
    throw 'Outlook is not ready (still starting, closing, or showing a dialog).'
  }
}

function Get-Store([string]$account) {
  if ($account) {
    foreach ($s in $script:ns.Stores) {
      if ($s.DisplayName -eq $account) { return $s }
    }
  }
  return $script:ns.DefaultStore
}

function Get-Folder([string]$account, [string]$which) {
  $store = Get-Store $account
  if ($null -eq $store) { throw "Outlook did not return the mailbox $account (Outlook is not ready)." }
  $id = if ($which -eq 'sent') { 5 } else { 6 }
  $f = $store.GetDefaultFolder($id)
  if ($null -eq $f) { throw "Outlook did not return the $which folder (Outlook is not ready)." }
  return $f
}

# SMTP addresses come from cached MAPI properties (fast, local). Exchange lookups are only a fallback.
$PR_SMTP = 'http://schemas.microsoft.com/mapi/proptag/0x39FE001F'
$PR_SENDER_SMTP = 'http://schemas.microsoft.com/mapi/proptag/0x5D01001F'

function Resolve-Entry($entry, [string]$fallback) {
  if (-not $entry) { return $fallback }
  $key = [string]$entry.Address
  if ($key -and $script:smtpCache.ContainsKey($key)) { return $script:smtpCache[$key] }
  $smtp = $fallback
  try {
    if ($entry.Type -eq 'EX') {
      $u = $entry.GetExchangeUser()
      if ($u) { $smtp = $u.PrimarySmtpAddress }
      else { $dl = $entry.GetExchangeDistributionList(); if ($dl) { $smtp = $dl.PrimarySmtpAddress } }
    } elseif ($key) { $smtp = $key }
  } catch {}
  if ($key) { $script:smtpCache[$key] = $smtp }
  return $smtp
}

# To (type 1) and Cc (type 2) in one pass over the recipients. Lists, so each stays a JSON array with 0 or 1 entries.
function Get-Recipients($item) {
  $out = @{ to = New-Object 'System.Collections.Generic.List[object]'; cc = New-Object 'System.Collections.Generic.List[object]' }
  foreach ($r in $item.Recipients) {
    if ($r.Type -eq 1) { $list = $out.to } elseif ($r.Type -eq 2) { $list = $out.cc } else { continue }
    $smtp = ''
    try { $smtp = [string]$r.PropertyAccessor.GetProperty($PR_SMTP) } catch {}
    if (-not $smtp) { $smtp = [string](Resolve-Entry $r.AddressEntry $r.Address) }
    $list.Add(@{ name = [string]$r.Name; email = $smtp.ToLower() })
  }
  return $out
}

function Convert-Item($item, [string]$folder, [int]$maxBody) {
  $senderEmail = ''
  try { $senderEmail = [string]$item.PropertyAccessor.GetProperty($PR_SENDER_SMTP) } catch {}
  if (-not $senderEmail) {
    try {
      if ($item.SenderEmailType -eq 'EX') { $senderEmail = Resolve-Entry $item.Sender $item.SenderEmailAddress }
      else { $senderEmail = $item.SenderEmailAddress }
    } catch {}
  }
  $body = [string]$item.Body
  if ($body.Length -gt $maxBody) { $body = $body.Substring(0, $maxBody) }
  # Sent items carry SentOn; items found through a conversation may sit in any folder, so they use SentOn too.
  $when = if ($folder -eq 'inbox') { $item.ReceivedTime } else { $item.SentOn }
  $atts = New-Object 'System.Collections.Generic.List[object]'
  try { foreach ($a in $item.Attachments) { $atts.Add([string]$a.FileName) } } catch {}
  $rcp = Get-Recipients $item
  return @{
    id             = $item.EntryID
    folder         = $folder
    conversationId = [string]$item.ConversationID
    subject        = [string]$item.Subject
    fromName       = [string]$item.SenderName
    fromEmail      = ([string]$senderEmail).ToLower()
    to             = $rcp.to
    cc             = $rcp.cc
    receivedAt     = ([datetime]$when).ToUniversalTime().ToString('o')
    body           = $body
    importance     = [int]$item.Importance
    sensitivity    = [int]$item.Sensitivity
    attachments    = $atts
  }
}

function Invoke-Fetch($a) {
  $folder = Get-Folder $a.account $a.folder
  $field = if ($a.folder -eq 'sent') { '[SentOn]' } else { '[ReceivedTime]' }
  # Outlook parses Restrict dates in the Windows regional format, so format them the same way (never a fixed pattern).
  $fmt = { param($d) ([datetime]$d).ToLocalTime().ToString('g') }
  $filter = "$field >= '$(& $fmt $a.since)'"
  if ($a.until) { $filter += " AND $field < '$(& $fmt $a.until)'" }
  $items = $folder.Items
  if ($null -eq $items) { throw "Outlook did not return the $($a.folder) items (Outlook is not ready)." }
  $found = $items.Restrict($filter)
  if ($null -eq $found) { return ,@() }
  $found.Sort($field, $true)   # newest first: a sort set before Restrict is not kept by what it returns
  $max = if ($a.max) { [int]$a.max } else { 300 }
  $maxBody = if ($a.maxBody) { [int]$a.maxBody } else { 12000 }
  $out = New-Object 'System.Collections.Generic.List[object]'
  $i = $found.GetFirst()
  while ($i -and $out.Count -lt $max) {
    if ($i.Class -eq 43) {   # mail only: meeting requests and receipts carry no tasks
      try { $out.Add((Convert-Item $i $a.folder $maxBody)) } catch {}
    }
    $i = $found.GetNext()
  }
  return ,$out
}

# Every mail in the conversation of one item, wherever it was filed (subfolders, archive), so a thread is read whole.
function Invoke-Conversation($a) {
  $item = $script:ns.GetItemFromID($a.entryId)
  $conv = $null
  try { if ($item) { $conv = $item.GetConversation() } } catch {}
  if (-not $conv) { return ,@() }
  $max = if ($a.max) { [int]$a.max } else { 60 }
  $maxBody = if ($a.maxBody) { [int]$a.maxBody } else { 12000 }
  $script:convOut = New-Object 'System.Collections.Generic.List[object]'
  $walk = {
    param($items)
    foreach ($i in $items) {
      if ($script:convOut.Count -ge $max) { return }
      if ($i.Class -eq 43) { try { $script:convOut.Add((Convert-Item $i 'conv' $maxBody)) } catch {} }
      try { & $walk $conv.GetChildren($i) } catch {}
    }
  }
  & $walk $conv.GetRootItems()
  return ,$script:convOut
}

# Where the quoted thread of a reply or forward starts: Outlook's header block, best found by its _MailOriginal bookmark.
$QUOTE_START = @('(?i)name=["'']?_MailOriginal', '(?i)id=["'']?divRplyFwdMsg', '(?i)border-top:solid #E1E1E1')

function Set-Body($mail, [string]$html, [bool]$keepSignature) {
  # Reply() and Forward() already carry your Outlook signature above the quoted thread (new mail gets none, because no
  # editor is opened). Without the signature: our text, then the quoted thread from its header on. With it: our text first.
  $existing = [string]$mail.HTMLBody
  $b = [regex]::Match($existing, '<body[^>]*>', 'IgnoreCase')
  if (-not $b.Success) { $mail.HTMLBody = $html + $existing; return }
  $head = $existing.Substring(0, $b.Index + $b.Length)
  if ($keepSignature) { $mail.HTMLBody = $head + $html + $existing.Substring($head.Length); return }
  foreach ($re in $QUOTE_START) {
    $q = [regex]::Match($existing.Substring($head.Length), $re)
    if (-not $q.Success) { continue }
    $start = $existing.LastIndexOf('<div', $head.Length + $q.Index, [StringComparison]::OrdinalIgnoreCase)
    if ($start -lt $head.Length) { $start = $head.Length + $q.Index }
    elseif ($start -ge $head.Length + 5 -and $existing.Substring($start - 5, 5) -eq '<div>') { $start -= 5 }   # its wrapper
    $mail.HTMLBody = $head + $html + $existing.Substring($start)
    return
  }
  $mail.HTMLBody = $head + $html + '</body></html>'   # nothing quoted: only our text
}

function Add-Recips($mail, $list, [int]$type) {
  foreach ($addr in @($list)) {
    if (-not $addr) { continue }
    $r = $mail.Recipients.Add([string]$addr); $r.Type = $type
  }
}

function Invoke-Draft($a) {
  # mode: new | reply | replyAll | forward (the email with its attachments). Saved to Drafts, never sent here.
  if ($a.mode -and $a.mode -ne 'new' -and $a.sourceId) {
    $src = $script:ns.GetItemFromID($a.sourceId)
    $mail = if ($a.mode -eq 'replyAll') { $src.ReplyAll() } elseif ($a.mode -eq 'forward') { $src.Forward() } else { $src.Reply() }
  } else {
    $mail = $script:ol.CreateItem(0)
  }
  # Recipients are always the ones you approved in the app, not whatever Reply() filled in.
  while ($mail.Recipients.Count -gt 0) { $mail.Recipients.Remove(1) }
  Add-Recips $mail $a.to 1
  if ($a.cc) { Add-Recips $mail $a.cc 2 }
  if ($a.subject) { $mail.Subject = [string]$a.subject }
  $mail.Recipients.ResolveAll() | Out-Null
  foreach ($f in @($a.attachments)) { if ($f -and (Test-Path -LiteralPath ([string]$f))) { $null = $mail.Attachments.Add([string]$f) } }
  Set-Body $mail ([string]$a.html) ([bool]$a.keepSignature)
  $mail.Save()
  return @{ entryId = $mail.EntryID }
}

function Invoke-Command2($req) {
  $a = $req.args
  switch ($req.cmd) {
    'ping' {
      Connect-Outlook
      $stores = @(); foreach ($s in $script:ns.Stores) { try { $null = $s.GetDefaultFolder(6); $stores += [string]$s.DisplayName } catch {} }
      return @{ user = [string]$script:ns.CurrentUser.Name; defaultStore = [string]$script:ns.DefaultStore.DisplayName; stores = $stores }
    }
    'fetch'        { Connect-Outlook; return (Invoke-Fetch $a) }
    'conversation' { Connect-Outlook; return (Invoke-Conversation $a) }
    'draft'        { Connect-Outlook; return (Invoke-Draft $a) }
    'send'         { Connect-Outlook; $m = $script:ns.GetItemFromID($a.entryId); $m.Send(); return @{ sent = $true } }
    'display'      { Connect-Outlook; $m = $script:ns.GetItemFromID($a.entryId); $m.Display(); return @{ shown = $true } }
    'discard' {
      # Only an unsent item that sits in Drafts is removed, and only to Deleted Items (recoverable).
      Connect-Outlook
      try { $m = $script:ns.GetItemFromID($a.entryId) } catch { return @{ discarded = $false } }
      $drafts = (Get-Store $a.account).GetDefaultFolder(16)
      if ($m.Sent -or $m.Parent.EntryID -ne $drafts.EntryID) { return @{ discarded = $false } }
      $m.Delete(); return @{ discarded = $true }
    }
    'exists' {
      Connect-Outlook
      try { $m = $script:ns.GetItemFromID($a.entryId) } catch { return @{ exists = $false } }
      return @{ exists = $true; sent = [bool]$m.Sent }
    }
    default { throw "unknown command $($req.cmd)" }
  }
}

while ($true) {
  $line = [Console]::In.ReadLine()
  if ($null -eq $line) { break }
  if (-not $line.Trim()) { continue }
  $id = $null
  try {
    $req = $line | ConvertFrom-Json
    $id = $req.id
    try { $data = Invoke-Command2 $req }
    catch {
      # Outlook restarted, dropped the COM link or handed back an empty object: reconnect once and retry. Only what reads:
      # a send or a draft may have gone through before the link dropped, and doing it again would send or save it twice.
      if ($req.cmd -notin @('ping', 'fetch', 'conversation', 'exists') -or $_.Exception.Message -notmatch '800706BA|80010108|800706BE|8001010A|RPC|disconnected|null-valued|not ready') { throw }
      $script:ol = $null; $script:ns = $null; $script:smtpCache = @{}
      Start-Sleep -Seconds 3
      $data = Invoke-Command2 $req
    }
    $resp = @{ id = $id; ok = $true; data = $data }
  } catch {
    $resp = @{ id = $id; ok = $false; error = [string]$_.Exception.Message }
  }
  [Console]::Out.WriteLine((ConvertTo-Json -InputObject $resp -Compress -Depth 8))
  [Console]::Out.Flush()
}
