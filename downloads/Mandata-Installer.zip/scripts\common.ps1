# Shared helpers for install.ps1, uninstall.ps1, ai-setup.ps1 and pack.ps1. Dot-source it: . "$PSScriptRoot\common.ps1"
# Written for Windows PowerShell 5.1 (every Windows 10 and 11) and newer. Plain ASCII on purpose: PowerShell 5.1
# reads a file without a byte order mark in the system code page.

$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'   # Invoke-WebRequest's progress bar makes it many times slower in 5.1

$script:ElectronVersion = '44.5.1'
$script:DefaultModel = 'qwen3:4b'           # the app's default (lib/config.js, ai.model)
$script:StateDir = Join-Path $env:LOCALAPPDATA 'Mandata-setup'
$script:OllamaDir = Join-Path $env:LOCALAPPDATA 'Programs\Ollama'
$script:OllamaApi = 'http://127.0.0.1:11434'

# ---------- messages ----------
function Write-Step([string]$Text) { Write-Host ''; Write-Host "== $Text" -ForegroundColor Cyan }
function Write-Ok([string]$Text) { Write-Host "   OK   $Text" -ForegroundColor Green }
function Write-Info([string]$Text) { Write-Host "        $Text" }
function Write-Note([string]$Text) { Write-Host "   NOTE $Text" -ForegroundColor Yellow }
function Stop-Setup([string]$Text) { throw [System.Exception]::new($Text) }

# ---------- progress: to the setup wizard (a small file it reads) or to the console ----------
# The file holds one line: "progress|<percent>|<title>|<detail>", then "done|100|<summary>" or "error|<percent>|<message>".
$script:ProgressPath = $null
$script:Stage = @{ From = 0; To = 100; Title = '' }
$script:LastSent = [DateTime]::MinValue
function Write-ProgressFile([string]$Line) {
  if (-not $script:ProgressPath) { return }
  for ($i = 0; $i -lt 10; $i++) {
    try { [IO.File]::WriteAllText($script:ProgressPath, $Line, (New-Object Text.UTF8Encoding($false))); return } catch { Start-Sleep -Milliseconds 50 }
  }
}
function Set-Stage([int]$From, [int]$To, [string]$Title) {
  $script:Stage = @{ From = $From; To = $To; Title = $Title }
  Write-Host "== $Title"
  Send-Progress 0 '' -Force
}
function Send-Progress([double]$Fraction, [string]$Detail, [switch]$Force) {
  $now = [DateTime]::UtcNow
  if (-not $Force -and ($now - $script:LastSent).TotalMilliseconds -lt 400) { return }
  $script:LastSent = $now
  $f = [Math]::Max(0, [Math]::Min(1, $Fraction))
  $pct = [int]($script:Stage.From + ($script:Stage.To - $script:Stage.From) * $f)
  if ($script:ProgressPath) { Write-ProgressFile "progress|$pct|$($script:Stage.Title)|$Detail" }
  elseif ($Detail) { Write-Host -NoNewline ("`r        $Detail" + (' ' * 20)) }
}

function Format-Size([double]$Bytes) {
  if ($Bytes -ge 1GB) { return '{0:N1} GB' -f ($Bytes / 1GB) }
  if ($Bytes -ge 1MB) { return '{0:N0} MB' -f ($Bytes / 1MB) }
  return '{0:N0} KB' -f ($Bytes / 1KB)
}

# Asks the running app to close, so it closes its data file cleanly. Nothing happens when it is not running.
function Request-AppShutdown([int]$Port) {
  try {
    $req = New-Request "http://127.0.0.1:$Port/api/shutdown"
    $req.Proxy = $null; $req.Method = 'POST'; $req.ContentType = 'application/json'; $req.Timeout = 3000
    $req.Headers['origin'] = "http://127.0.0.1:$Port"
    $b = [Text.Encoding]::UTF8.GetBytes('{}'); $req.ContentLength = $b.Length
    $s = $req.GetRequestStream(); $s.Write($b, 0, $b.Length); $s.Close()
    $req.GetResponse().Close()
    return $true
  } catch { return $false }
}

# ---------- state: what setup put on this computer, so uninstall removes only that ----------
function Get-SetupState {
  $f = Join-Path $script:StateDir 'state.json'
  $s = @{}
  if (Test-Path $f) {
    try { (Get-Content -Raw $f | ConvertFrom-Json).PSObject.Properties | ForEach-Object { $s[$_.Name] = $_.Value } } catch {}
  }
  return $s
}
function Set-SetupState([hashtable]$Patch) {
  $s = Get-SetupState
  foreach ($k in $Patch.Keys) { $s[$k] = $Patch[$k] }
  New-Item -ItemType Directory -Force $script:StateDir | Out-Null
  ([pscustomobject]$s | ConvertTo-Json) | Set-Content -Encoding UTF8 (Join-Path $script:StateDir 'state.json')
}

# ---------- this computer ----------
function Get-NativeArch {
  # The registry gives the real processor even when this PowerShell runs as 32-bit or under x64 emulation on ARM.
  $a = $null
  try { $a = (Get-ItemProperty 'HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\Environment').PROCESSOR_ARCHITECTURE } catch {}
  if (-not $a) { $a = if ($env:PROCESSOR_ARCHITEW6432) { $env:PROCESSOR_ARCHITEW6432 } else { $env:PROCESSOR_ARCHITECTURE } }
  switch -Regex ($a) { '^ARM64$' { return 'arm64' } '^(AMD64|x64|IA64)$' { return 'x64' } default { return 'x86' } }
}

function Get-Gpus {
  $names = @()
  try { $names = @(Get-CimInstance Win32_VideoController -ErrorAction Stop | ForEach-Object { $_.Name }) }
  catch { try { $names = @(Get-WmiObject Win32_VideoController | ForEach-Object { $_.Name }) } catch {} }
  $names = @($names | Where-Object { $_ -and $_ -notmatch 'DisplayLink|Basic Display|Remote Display|Hyper-V|VMware|VirtualBox|Citrix|Parsec|Mirage|Meta Virtual' })
  [pscustomobject]@{
    Names       = $names
    Nvidia      = [bool]($names -match 'NVIDIA')
    AmdDiscrete = [bool]($names -match 'Radeon\s*(\(TM\)\s*)?(RX|Pro|VII)|Instinct')
    Integrated  = [bool]($names -match 'Intel|Radeon\s*(\(TM\)\s*)?Graphics|Radeon\s+\d{3}M|Adreno|Qualcomm|Arc')
  }
}

# ---------- the AI model for this computer ----------
# Same rules as the app (lib/ai.js, fitFor and bestFor), from the same file: lib/models.json.
function Get-ModelCatalog {
  # Installed app (setup\ next to resources\), a packed installer folder (app\ next to scripts\), or the project.
  foreach ($p in (Join-Path $PSScriptRoot '..\resources\app\lib\models.json'), (Join-Path $PSScriptRoot '..\app\lib\models.json'), (Join-Path $PSScriptRoot '..\..\lib\models.json')) {
    if (Test-Path $p) { return (Get-Content -Raw -Encoding UTF8 $p | ConvertFrom-Json) }
  }
  return $null
}

function Get-Capacity {
  # Memory, and the separate graphics card's own memory (built-in graphics share the main memory).
  $ram = [math]::Round((Get-CimInstance Win32_ComputerSystem).TotalPhysicalMemory / 1GB, 1)
  $vram = 0
  Get-ChildItem 'HKLM:\SYSTEM\CurrentControlSet\Control\Class\{4d36e968-e325-11ce-bfc1-08002be10318}' -ErrorAction SilentlyContinue | ForEach-Object {
    $p = Get-ItemProperty $_.PSPath -ErrorAction SilentlyContinue
    if ($p.DriverDesc -and $p.DriverDesc -match 'NVIDIA|Radeon\s*(\(TM\)\s*)?(RX|Pro|VII)|Instinct') {
      $b = $p.'HardwareInformation.qwMemorySize'
      if (-not $b) { $b = $p.'HardwareInformation.MemorySize'; if ($b -is [byte[]]) { $b = [BitConverter]::ToUInt32($b, 0) } }
      if ($b) { $vram = [math]::Max($vram, [math]::Round([double]$b / 1GB, 1)) }
    }
  }
  [pscustomobject]@{ RamGb = $ram; VramGb = $vram }
}

function Select-BestModel($Pc) {
  # Without a separate graphics card: cpuDefault; with one: gpuDefault. Otherwise the most accurate model of minQuality stars or more that
  # runs well here; the smallest of them when none does.
  $cat = Get-ModelCatalog
  if (-not $cat) { return $script:DefaultModel }
  $r = $cat.rules
  if (-not $Pc.VramGb -and $r.cpuDefault) { return [string]$r.cpuDefault }
  if ($Pc.VramGb -and $r.gpuDefault) { return [string]$r.gpuDefault }
  $tier = @{ good = 0; slow = 1; no = 2 }
  $i = 0   # on a tie, the model listed first in models.json (Sort-Object does not keep the list's order)
  $ok = foreach ($m in $cat.models) {
    $i++
    if ($m.quality -lt $r.minQuality) { continue }
    $need = $m.gb * $r.memFactor
    $active = if ($m.active) { $m.gb * $m.active / $m.params } else { $m.gb }
    $fit = if ($Pc.VramGb -and $need + $r.gpuHeadroomGb -le $Pc.VramGb) { 'good' }
           elseif ($need -gt $Pc.RamGb - $r.reserveGb) { 'no' }
           elseif ($active -le $r.cpuActiveMaxGb) { 'good' } else { 'slow' }
    [pscustomobject]@{ Name = $m.name; Quality = $m.quality; Params = $m.params; Gb = $m.gb; Tier = $tier[$fit]; Index = $i }
  }
  $good = @($ok | Where-Object { $_.Tier -eq 0 } | Sort-Object @{ e = 'Quality'; d = $true }, @{ e = 'Params'; d = $true }, 'Gb', 'Index')
  if ($good) { return $good[0].Name }
  $rest = @($ok | Sort-Object 'Tier', 'Gb', @{ e = 'Quality'; d = $true }, @{ e = 'Params'; d = $true }, 'Index')
  if ($rest) { return $rest[0].Name }
  return $script:DefaultModel
}

function Get-FreeBytes([string]$Path) {
  try {
    $root = [IO.Path]::GetPathRoot([IO.Path]::GetFullPath($Path))
    return (New-Object IO.DriveInfo($root)).AvailableFreeSpace
  } catch { return [long]::MaxValue }
}

function Test-ClassicOutlook {
  # Classic Outlook registers its COM server; the new Outlook (olk.exe) does not and cannot be read by the app.
  foreach ($k in 'Registry::HKEY_CLASSES_ROOT\Outlook.Application\CLSID', 'HKLM:\SOFTWARE\Classes\Outlook.Application\CLSID',
                 'HKLM:\SOFTWARE\WOW6432Node\Classes\Outlook.Application\CLSID', 'HKCU:\SOFTWARE\Classes\Outlook.Application\CLSID') {
    if (Test-Path $k) { return $true }
  }
  return $false
}

# ---------- network ----------
function Initialize-Network {
  # TLS 1.2 (and 1.3 where .NET knows it): Windows PowerShell 5.1 still offers TLS 1.0 by default, which GitHub refuses.
  $p = [Net.SecurityProtocolType]::Tls12
  try { $p = $p -bor [Net.SecurityProtocolType]'Tls13' } catch {}
  try { [Net.ServicePointManager]::SecurityProtocol = $p } catch { [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 }
  # Behind an office proxy, sign in to it as the current Windows user.
  try {
    $proxy = [Net.WebRequest]::GetSystemWebProxy()
    $proxy.Credentials = [Net.CredentialCache]::DefaultNetworkCredentials
    [Net.WebRequest]::DefaultWebProxy = $proxy
  } catch {}
}

function Get-ProxyFor([string]$Url) {
  try {
    $u = [Uri]$Url
    $p = [Net.WebRequest]::DefaultWebProxy
    if ($p -and -not $p.IsBypassed($u)) { $r = $p.GetProxy($u); if ($r -and $r.AbsoluteUri -ne $u.AbsoluteUri) { return $r.AbsoluteUri.TrimEnd('/') } }
  } catch {}
  return $null
}

function New-Request([string]$Url) {
  $req = [Net.HttpWebRequest][Net.WebRequest]::Create($Url)
  $req.UserAgent = 'Mandata-Setup/2.0 (Windows PowerShell)'
  $req.Timeout = 60000
  $req.ReadWriteTimeout = 300000
  $req.AutomaticDecompression = [Net.DecompressionMethods]::None
  return $req
}

function Get-WebText([string]$Url, [string]$Accept) {
  $req = New-Request $Url
  if ($Accept) { $req.Accept = $Accept }
  $resp = $req.GetResponse()
  try { $sr = New-Object IO.StreamReader($resp.GetResponseStream()); return $sr.ReadToEnd() } finally { $resp.Close() }
}

function Get-RedirectTarget([string]$Url) {
  $req = New-Request $Url
  $req.AllowAutoRedirect = $false
  $req.Method = 'HEAD'
  $resp = $null
  try { $resp = $req.GetResponse() } catch [Net.WebException] { $resp = $_.Exception.Response }
  if (-not $resp) { return $null }
  try { return $resp.Headers['Location'] } finally { $resp.Close() }
}

function Test-FileSha256([string]$Path, [string]$Sha256) {
  if (-not $Sha256) { return $true }
  return ((Get-FileHash -Algorithm SHA256 -LiteralPath $Path).Hash -eq $Sha256)
}

<#
  Downloads Url to Dest with a progress line, resumes a broken download from where it stopped, retries, and checks
  the SHA-256 when one is given. Uses the system proxy (see Initialize-Network).
#>
function Get-Download([string]$Url, [string]$Dest, [string]$Sha256, [string]$Label) {
  if (-not $Label) { $Label = Split-Path -Leaf $Dest }
  if ((Test-Path -LiteralPath $Dest) -and $Sha256 -and (Test-FileSha256 $Dest $Sha256)) { Write-Info "$Label already downloaded"; return }
  New-Item -ItemType Directory -Force (Split-Path -Parent $Dest) | Out-Null
  $part = "$Dest.part"
  $lastError = $null
  # A dropped connection is tried again every 5 seconds, resuming where it stopped, for as long as the download makes
  # progress; it gives up after 15 minutes with none.
  $progressAt = [DateTime]::UtcNow
  for ($try = 1; ; $try++) {
    $resp = $null; $out = $null; $before = if (Test-Path -LiteralPath $part) { (Get-Item -LiteralPath $part).Length } else { [long]0 }
    try {
      $have = if (Test-Path -LiteralPath $part) { (Get-Item -LiteralPath $part).Length } else { [long]0 }
      $req = New-Request $Url
      if ($have -gt 0) { $req.AddRange([long]$have) }
      try { $resp = $req.GetResponse() }
      catch [Net.WebException] {
        # 416: the part file is already whole.
        if ($_.Exception.Response -and [int]$_.Exception.Response.StatusCode -eq 416) { $_.Exception.Response.Close(); $resp = $null }
        else { throw }
      }
      if ($resp) {
        if ($have -gt 0 -and [int]$resp.StatusCode -ne 206) { $have = 0 }   # the server ignored the range: start again
        $total = if ($resp.ContentLength -ge 0) { $resp.ContentLength + $have } else { -1 }
        $mode = if ($have -gt 0) { [IO.FileMode]::Append } else { [IO.FileMode]::Create }
        $out = New-Object IO.FileStream($part, $mode, [IO.FileAccess]::Write, [IO.FileShare]::None, 1MB)
        $in = $resp.GetResponseStream()
        $buf = New-Object byte[] (1MB)
        $done = $have; $t0 = [DateTime]::UtcNow; $lastShow = [DateTime]::MinValue; $fromHere = $have
        while (($n = $in.Read($buf, 0, $buf.Length)) -gt 0) {
          $out.Write($buf, 0, $n); $done += $n
          $now = [DateTime]::UtcNow
          if (($now - $lastShow).TotalMilliseconds -ge 500) {
            $lastShow = $now
            $secs = [Math]::Max(0.5, ($now - $t0).TotalSeconds)
            $rate = ($done - $fromHere) / $secs
            $of = if ($total -gt 0) { ' of ' + (Format-Size $total) } else { '' }
            Send-Progress $(if ($total -gt 0) { $done / $total } else { 0 }) ("$Label`: " + (Format-Size $done) + $of + ', ' + (Format-Size $rate) + '/s')
          }
        }
        Write-Host ("`r        $Label  " + (Format-Size $done) + ' downloaded' + (' ' * 30))
        Send-Progress 1 "$Label`: downloaded" -Force
        $out.Close(); $out = $null
        $resp.Close(); $resp = $null
        if ($total -gt 0 -and (Get-Item -LiteralPath $part).Length -ne $total) { throw "the download stopped early" }
      }
      if (-not (Test-FileSha256 $part $Sha256)) {
        Remove-Item -Force -LiteralPath $part
        throw "the file is damaged (its SHA-256 does not match)"
      }
      if (Test-Path -LiteralPath $Dest) { Remove-Item -Force -LiteralPath $Dest }
      Move-Item -LiteralPath $part -Destination $Dest
      return
    } catch {
      $lastError = $_.Exception.Message
      if ($out) { $out.Close() }
      if ($resp) { $resp.Close() }
      Write-Host ''
      $now = if (Test-Path -LiteralPath $part) { (Get-Item -LiteralPath $part).Length } else { [long]0 }
      if ($now -gt $before) { $progressAt = [DateTime]::UtcNow }
      if ($lastError -match 'SHA-256' -or ([DateTime]::UtcNow - $progressAt).TotalMinutes -gt 15) { break }
      Write-Note "Download of $Label interrupted ($lastError). Trying again in 5 s (attempt $($try + 1))..."
      Send-Progress 0 "Connection lost; trying again (attempt $($try + 1))"
      Start-Sleep -Seconds 5
    }
  }
  Stop-Setup "Could not download $Url`n       $lastError`n       Check the internet connection (or proxy), or try again on another network."
}

# Reads "<sha>  <name>" lines (sha256sum and Electron's SHASUMS256 formats) and returns the hash for one file name.
function Find-Sha256([string]$SumsText, [string]$FileName) {
  foreach ($line in ($SumsText -split "`n")) {
    if ($line -match '^\s*([0-9a-fA-F]{64})\s+[\*\./]*(.+?)\s*$' -and $Matches[2] -eq $FileName) { return $Matches[1].ToUpper() }
  }
  return $null
}

# ---------- files ----------
# Copies a file's contents only: the "downloaded from the internet" mark (an alternate data stream) is not carried
# over, so a file that came in a downloaded zip is not blocked, and antivirus does not hold it for a scan.
function Copy-Plain([string]$From, [string]$To) {
  New-Item -ItemType Directory -Force (Split-Path -Parent $To) | Out-Null
  [IO.File]::WriteAllBytes($To, [IO.File]::ReadAllBytes($From))
}
# The app's own files (server.js, package.json, lib\, public\, desktop\), from the project or a packed app\ folder.
# Data is never copied: no database, backup, log or mail file, and nothing in a backups folder.
$script:NoData = '*.bak*', '*.db', '*.db-*', '*.sqlite*', '*.log', '*.pst', '*.msg', '*.eml', 'data.json', 'tasks.json', 'people.json', 'settings.json', 'installed.json', 'install-defaults.json'
function Copy-AppFiles([string]$From, [string]$To) {
  foreach ($f in 'server.js', 'package.json') { Copy-Plain (Join-Path $From $f) (Join-Path $To $f) }
  foreach ($d in 'lib', 'public', 'desktop') {
    $dir = (Resolve-Path (Join-Path $From $d)).Path
    Get-ChildItem -Recurse -File $dir -Exclude $script:NoData | ForEach-Object {
      $rel = $_.FullName.Substring($dir.Length).TrimStart('\')
      if ($rel -notmatch '(^|\\)backups\\') { Copy-Plain $_.FullName (Join-Path (Join-Path $To $d) $rel) }
    }
  }
}
# ---------- zip files ----------
function Initialize-Zip {
  Add-Type -AssemblyName System.IO.Compression
  Add-Type -AssemblyName System.IO.Compression.FileSystem
}

<#
  Reads a remote zip with HTTP range requests, so single entries can be taken out of it without downloading the
  rest. Used to take Ollama without its NVIDIA CUDA libraries (about 1.3 GB) on computers without an NVIDIA GPU.
#>
function Initialize-RangeStream {
  if ('TaskManagerSetup.HttpRangeStream' -as [type]) { return $true }
  try {
    Add-Type -Language CSharp -TypeDefinition @'
using System;
using System.IO;
using System.Net;
namespace TaskManagerSetup {
  public class HttpRangeStream : Stream {
    private readonly string url;
    private long length, pos;
    private byte[] buf = new byte[0];
    private long bufStart = -1;
    private const int Chunk = 8 * 1024 * 1024;
    public long Downloaded;
    public HttpRangeStream(string url) {
      this.url = url;
      using (var r = Get(0, 0)) {
        var cr = r.Headers["Content-Range"];
        if ((int)r.StatusCode != 206 || cr == null) throw new NotSupportedException("The server does not take range requests");
        length = long.Parse(cr.Substring(cr.LastIndexOf('/') + 1));
      }
    }
    private HttpWebResponse Get(long from, long to) {
      var req = (HttpWebRequest)WebRequest.Create(url);
      req.UserAgent = "Mandata-Setup/2.0";
      req.Timeout = 60000; req.ReadWriteTimeout = 300000;
      req.AddRange(from, to);
      return (HttpWebResponse)req.GetResponse();
    }
    private void Fill(long at) {
      long end = Math.Min(length, at + Chunk) - 1;
      Exception last = null;
      for (int attempt = 0; attempt < 5; attempt++) {
        try {
          using (var r = Get(at, end)) {
            if ((int)r.StatusCode != 206) throw new NotSupportedException("The server ignored a range request");
            var data = new byte[end - at + 1];
            int got = 0;
            using (var s = r.GetResponseStream()) {
              while (got < data.Length) { int n = s.Read(data, got, data.Length - got); if (n <= 0) break; got += n; }
            }
            if (got != data.Length) throw new IOException("Short read");
            buf = data; bufStart = at; Downloaded += got;
            return;
          }
        } catch (NotSupportedException) { throw; }
        catch (Exception e) { last = e; System.Threading.Thread.Sleep(2000 * (attempt + 1)); }
      }
      throw new IOException("Download failed: " + (last != null ? last.Message : ""), last);
    }
    public override int Read(byte[] buffer, int offset, int count) {
      if (pos >= length || count <= 0) return 0;
      if (bufStart < 0 || pos < bufStart || pos >= bufStart + buf.Length) Fill(pos);
      int i = (int)(pos - bufStart);
      int n = Math.Min(count, buf.Length - i);
      Buffer.BlockCopy(buf, i, buffer, offset, n);
      pos += n;
      return n;
    }
    public override long Seek(long offset, SeekOrigin origin) {
      pos = origin == SeekOrigin.Begin ? offset : origin == SeekOrigin.Current ? pos + offset : length + offset;
      return pos;
    }
    public override bool CanRead { get { return true; } }
    public override bool CanSeek { get { return true; } }
    public override bool CanWrite { get { return false; } }
    public override long Length { get { return length; } }
    public override long Position { get { return pos; } set { pos = value; } }
    public override void Flush() { }
    public override void SetLength(long value) { throw new NotSupportedException(); }
    public override void Write(byte[] buffer, int offset, int count) { throw new NotSupportedException(); }
  }
}
'@
    return $true
  } catch { return $false }
}

<#
  Gives a program file an .ico file's icon and new names in its version details (Strings: name -> value), with
  Windows' resource functions (no tool to download). electron.exe carries Electron's icon and calls itself "Electron":
  Windows shows both for Mandata.exe, and Electron names the Start Menu shortcut it makes for notifications after it.
#>
function Set-ExeIdentity([string]$Exe, [string]$Ico, [hashtable]$Strings) {
  if (-not ('TaskManagerSetup.ExeIcon' -as [type])) {
    Add-Type -Language CSharp -TypeDefinition @'
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Runtime.InteropServices;
namespace TaskManagerSetup {
  public static class ExeIcon {
    const int RT_ICON = 3, RT_GROUP_ICON = 14, RT_VERSION = 16;
    delegate bool NameProc(IntPtr module, IntPtr type, IntPtr name, IntPtr param);
    delegate bool LangProc(IntPtr module, IntPtr type, IntPtr name, ushort lang, IntPtr param);
    [DllImport("kernel32", SetLastError = true, CharSet = CharSet.Unicode)] static extern IntPtr LoadLibraryEx(string file, IntPtr reserved, uint flags);
    [DllImport("kernel32")] static extern bool FreeLibrary(IntPtr module);
    [DllImport("kernel32", CharSet = CharSet.Unicode)] static extern bool EnumResourceNames(IntPtr module, IntPtr type, NameProc cb, IntPtr param);
    [DllImport("kernel32", CharSet = CharSet.Unicode)] static extern bool EnumResourceLanguages(IntPtr module, IntPtr type, IntPtr name, LangProc cb, IntPtr param);
    [DllImport("kernel32")] static extern IntPtr FindResourceEx(IntPtr module, IntPtr type, IntPtr name, ushort lang);
    [DllImport("kernel32")] static extern IntPtr LoadResource(IntPtr module, IntPtr res);
    [DllImport("kernel32")] static extern IntPtr LockResource(IntPtr data);
    [DllImport("kernel32")] static extern uint SizeofResource(IntPtr module, IntPtr res);
    [DllImport("kernel32", SetLastError = true, CharSet = CharSet.Unicode)] static extern IntPtr BeginUpdateResource(string file, bool deleteExisting);
    [DllImport("kernel32", SetLastError = true)] static extern bool UpdateResource(IntPtr update, IntPtr type, IntPtr name, ushort lang, byte[] data, uint size);
    [DllImport("kernel32", SetLastError = true)] static extern bool EndUpdateResource(IntPtr update, bool discard);

    // A resource name is a number (up to 0xFFFF) or a pointer to a string, which is copied before the file is closed.
    static object Name(IntPtr p) { return (long)p >> 16 == 0 ? (object)(ushort)(long)p : Marshal.PtrToStringUni(p); }

    static List<KeyValuePair<object, ushort>> List(IntPtr module, int type) {
      var found = new List<KeyValuePair<object, ushort>>();
      LangProc onLang = (m, t, n, lang, p) => { found.Add(new KeyValuePair<object, ushort>(Name(n), lang)); return true; };
      NameProc onName = (m, t, n, p) => { EnumResourceLanguages(m, t, n, onLang, IntPtr.Zero); return true; };
      EnumResourceNames(module, (IntPtr)type, onName, IntPtr.Zero);
      return found;
    }

    static bool Update(IntPtr u, int type, object name, ushort lang, byte[] data) {
      IntPtr n = name is string ? Marshal.StringToHGlobalUni((string)name) : (IntPtr)(ushort)name;
      try { return UpdateResource(u, (IntPtr)type, n, lang, data, data == null ? 0u : (uint)data.Length); }
      finally { if (name is string) Marshal.FreeHGlobal(n); }
    }

    static byte[] Read(IntPtr module, int type, object name, ushort lang) {
      IntPtr res = FindResourceEx(module, (IntPtr)type, (IntPtr)(ushort)name, lang);
      if (res == IntPtr.Zero) return null;
      var data = new byte[SizeofResource(module, res)];
      Marshal.Copy(LockResource(LoadResource(module, res)), data, 0, data.Length);
      return data;
    }

    // The version details are a tree of blocks: length, value length, type (1: text), a key, then the value and the
    // child blocks, each starting on a 4-byte boundary. The strings under StringFileInfo are rewritten; nothing else.
    class Block { public string Key; public ushort Type, ValueLength; public byte[] Value; public List<Block> Children = new List<Block>(); }

    static int Align(int n) { return (n + 3) & ~3; }

    static Block Parse(byte[] d, int at) {
      var b = new Block();
      int end = at + BitConverter.ToUInt16(d, at);
      b.ValueLength = BitConverter.ToUInt16(d, at + 2);
      b.Type = BitConverter.ToUInt16(d, at + 4);
      int p = at + 6;
      while (BitConverter.ToUInt16(d, p) != 0) p += 2;
      b.Key = System.Text.Encoding.Unicode.GetString(d, at + 6, p - at - 6);
      p = at + Align(p + 2 - at);
      int size = Math.Min(b.Type == 1 ? b.ValueLength * 2 : b.ValueLength, Math.Max(0, end - p));
      b.Value = new byte[size];
      Buffer.BlockCopy(d, p, b.Value, 0, size);
      p = at + Align(p + size - at);
      while (p + 6 <= end) {
        int len = BitConverter.ToUInt16(d, p);
        if (len == 0) break;
        b.Children.Add(Parse(d, p));
        p = at + Align(p + len - at);
      }
      return b;
    }

    static byte[] Write(Block b) {
      var m = new MemoryStream();
      var w = new BinaryWriter(m);
      w.Write((ushort)0); w.Write(b.ValueLength); w.Write(b.Type);
      w.Write(System.Text.Encoding.Unicode.GetBytes(b.Key + "\0"));
      while (m.Length % 4 != 0) w.Write((byte)0);
      w.Write(b.Value);
      foreach (var c in b.Children) {
        while (m.Length % 4 != 0) w.Write((byte)0);
        w.Write(Write(c));
      }
      var bytes = m.ToArray();
      BitConverter.GetBytes((ushort)bytes.Length).CopyTo(bytes, 0);
      return bytes;
    }

    static void Rename(Block b, System.Collections.IDictionary strings) {
      foreach (var table in b.Children) {
        if (table.Key != "StringFileInfo") continue;
        foreach (var lang in table.Children) foreach (var s in lang.Children) {
          if (!strings.Contains(s.Key)) continue;
          string v = strings[s.Key] + "\0";
          s.Type = 1; s.ValueLength = (ushort)v.Length; s.Value = System.Text.Encoding.Unicode.GetBytes(v);
        }
      }
    }

    public static void Set(string exe, string ico, System.Collections.IDictionary strings) {
      // The .ico file: a 6-byte header, then 16 bytes per image (12 bytes of size and colour data, then its offset).
      byte[] f = File.ReadAllBytes(ico);
      int count = BitConverter.ToUInt16(f, 4);
      if (BitConverter.ToUInt16(f, 2) != 1 || count == 0) throw new InvalidDataException(ico + " is not an icon file");

      IntPtr module = LoadLibraryEx(exe, IntPtr.Zero, 0x22);   // as a data file and image resource: nothing runs
      if (module == IntPtr.Zero) throw new Win32Exception();
      List<KeyValuePair<object, ushort>> groups, icons, versions;
      var versionData = new List<byte[]>();
      try {
        groups = List(module, RT_GROUP_ICON); icons = List(module, RT_ICON); versions = List(module, RT_VERSION);
        foreach (var r in versions) versionData.Add(r.Key is ushort ? Read(module, RT_VERSION, r.Key, r.Value) : null);
      }
      finally { FreeLibrary(module); }
      // The new icon takes the name of the program's first icon group: Windows shows the first one.
      object groupName = groups.Count > 0 ? groups[0].Key : (object)(ushort)1;
      ushort lang = groups.Count > 0 ? groups[0].Value : (ushort)1033;

      IntPtr u = BeginUpdateResource(exe, false);
      if (u == IntPtr.Zero) throw new Win32Exception();
      bool ok = false;
      try {
        foreach (var r in groups) if (!Update(u, RT_GROUP_ICON, r.Key, r.Value, null)) throw new Win32Exception();
        foreach (var r in icons) if (!Update(u, RT_ICON, r.Key, r.Value, null)) throw new Win32Exception();
        // The group lists the images as in the .ico file, with a 2-byte id in place of each 4-byte offset.
        var group = new byte[6 + 14 * count];
        Buffer.BlockCopy(f, 0, group, 0, 6);
        for (int i = 0; i < count; i++) {
          int e = 6 + 16 * i;
          int size = BitConverter.ToInt32(f, e + 8), offset = BitConverter.ToInt32(f, e + 12);
          var image = new byte[size];
          Buffer.BlockCopy(f, offset, image, 0, size);
          if (!Update(u, RT_ICON, (ushort)(i + 1), lang, image)) throw new Win32Exception();
          Buffer.BlockCopy(f, e, group, 6 + 14 * i, 12);
          BitConverter.GetBytes((ushort)(i + 1)).CopyTo(group, 6 + 14 * i + 12);
        }
        if (!Update(u, RT_GROUP_ICON, groupName, lang, group)) throw new Win32Exception();
        for (int i = 0; i < versions.Count; i++) {
          if (versionData[i] == null) continue;
          var root = Parse(versionData[i], 0);
          Rename(root, strings);
          if (!Update(u, RT_VERSION, versions[i].Key, versions[i].Value, Write(root))) throw new Win32Exception();
        }
        ok = true;
      } finally {
        if (!EndUpdateResource(u, !ok) && ok) throw new Win32Exception();
      }
    }
  }
}
'@
  }
  [TaskManagerSetup.ExeIcon]::Set($Exe, $Ico, $Strings)
}

<#
  Extracts a zip (a local file path, or a seekable stream) into Dest, leaving out entries whose path starts with one
  of SkipPrefixes. Writes into a new folder next to Dest first, so a failure never leaves half a program behind.
#>
function Expand-ZipTo($Source, [string]$Dest, [string[]]$SkipPrefixes = @(), [string]$Label = 'files', [switch]$Merge) {
  Initialize-Zip
  $stream = if ($Source -is [string]) { [IO.File]::OpenRead($Source) } else { $Source }
  $tmp = "$Dest.new"
  if (Test-Path -LiteralPath $tmp) { Remove-Item -Recurse -Force -LiteralPath $tmp }
  New-Item -ItemType Directory -Force $tmp | Out-Null
  $root = [IO.Path]::GetFullPath($tmp).TrimEnd('\') + '\'
  try {
    $zip = New-Object IO.Compression.ZipArchive($stream, [IO.Compression.ZipArchiveMode]::Read)
    $entries = @($zip.Entries | Where-Object { $e = $_; $e.Name -and -not ($SkipPrefixes | Where-Object { $e.FullName.StartsWith($_, [StringComparison]::OrdinalIgnoreCase) }) })
    $totalBytes = ($entries | Measure-Object -Property Length -Sum).Sum
    $done = [long]0; $lastShow = [DateTime]::MinValue
    foreach ($e in $entries) {
      $target = [IO.Path]::GetFullPath((Join-Path $tmp ($e.FullName -replace '/', '\')))
      if (-not $target.StartsWith($root, [StringComparison]::OrdinalIgnoreCase)) { continue }   # never outside Dest
      New-Item -ItemType Directory -Force (Split-Path -Parent $target) | Out-Null
      $in = $e.Open()
      try { $out = [IO.File]::Create($target); try { $in.CopyTo($out, 1MB) } finally { $out.Close() } } finally { $in.Close() }
      $done += $e.Length
      if (([DateTime]::UtcNow - $lastShow).TotalMilliseconds -ge 500 -and $totalBytes) {
        $lastShow = [DateTime]::UtcNow
        Send-Progress ($done / $totalBytes) ("$Label`: " + (Format-Size $done) + ' of ' + (Format-Size $totalBytes))
      }
    }
    Write-Host ("`r        $Label  " + (Format-Size $done) + ' in ' + $entries.Count + ' files' + (' ' * 30))
    $zip.Dispose()
  } finally { $stream.Close() }
  if ($Merge -and (Test-Path -LiteralPath $Dest)) {
    Copy-Item -Recurse -Force (Join-Path $tmp '*') $Dest
    Remove-Item -Recurse -Force -LiteralPath $tmp
  } else {
    if (Test-Path -LiteralPath $Dest) { Remove-Item -Recurse -Force -LiteralPath $Dest }
    Move-Item -LiteralPath $tmp -Destination $Dest
  }
}

# ---------- Ollama ----------
# Calls Ollama on this computer, never through a proxy. Returns the parsed JSON answer.
function Invoke-Local([string]$Path, $Body, [int]$TimeoutSec = 10) {
  $req = New-Request "$script:OllamaApi$Path"
  $req.Proxy = $null
  $req.Timeout = $TimeoutSec * 1000; $req.ReadWriteTimeout = $TimeoutSec * 1000
  if ($null -ne $Body) {
    $req.Method = 'POST'; $req.ContentType = 'application/json'
    $bytes = [Text.Encoding]::UTF8.GetBytes(($Body | ConvertTo-Json -Depth 5 -Compress))
    $req.ContentLength = $bytes.Length
    $rs = $req.GetRequestStream(); $rs.Write($bytes, 0, $bytes.Length); $rs.Close()
  }
  $resp = $req.GetResponse()
  try { return ((New-Object IO.StreamReader($resp.GetResponseStream())).ReadToEnd() | ConvertFrom-Json) } finally { $resp.Close() }
}

function Test-OllamaApi([int]$TimeoutSec = 3) {
  try { return [string](Invoke-Local '/api/version' $null $TimeoutSec).version } catch { return $null }
}

function Find-Ollama {
  $candidates = @((Join-Path $script:OllamaDir 'ollama.exe'))
  $cmd = Get-Command ollama.exe -ErrorAction SilentlyContinue
  if ($cmd) { $candidates += $cmd.Source }
  foreach ($c in $candidates) { if ($c -and (Test-Path -LiteralPath $c)) { return $c } }
  return $null
}

function Start-OllamaServe([string]$Exe, [int]$WaitSec = 45) {
  if (Test-OllamaApi) { return $true }
  Start-Process -FilePath $Exe -ArgumentList 'serve' -WindowStyle Hidden | Out-Null
  for ($i = 0; $i -lt $WaitSec; $i++) { Start-Sleep -Seconds 1; if (Test-OllamaApi) { return $true } }
  return $false
}

function Get-OllamaModelsDir {
  $d = $env:OLLAMA_MODELS
  if (-not $d) { $d = [Environment]::GetEnvironmentVariable('OLLAMA_MODELS', 'User') }
  if (-not $d) { $d = [Environment]::GetEnvironmentVariable('OLLAMA_MODELS', 'Machine') }
  if (-not $d) { $d = Join-Path $env:USERPROFILE '.ollama\models' }
  return $d
}

# "qwen3:4b" -> registry.ollama.ai / library / qwen3 / 4b. "someone/model" and "host/someone/model" too.
function Split-ModelName([string]$Name) {
  $tag = 'latest'
  $n = $Name.Trim()
  $slash = $n.LastIndexOf('/'); $colon = $n.LastIndexOf(':')
  if ($colon -gt $slash) { $tag = $n.Substring($colon + 1); $n = $n.Substring(0, $colon) }
  $parts = $n.Split('/')
  $hostName = 'registry.ollama.ai'; $ns = 'library'
  if ($parts.Count -eq 3) { $hostName, $ns, $repo = $parts } elseif ($parts.Count -eq 2) { $ns, $repo = $parts } else { $repo = $parts[0] }
  [pscustomobject]@{ Host = $hostName; Namespace = $ns; Repo = $repo; Tag = $tag
    ManifestRel = "manifests\$hostName\$ns\$repo\$tag"; Base = "https://$hostName/v2/$ns/$repo" }
}

function Get-ModelBlobs([string]$ManifestPath) {
  $m = Get-Content -Raw -LiteralPath $ManifestPath | ConvertFrom-Json
  $list = @()
  if ($m.config) { $list += $m.config }
  $list += @($m.layers)
  return $list | Where-Object { $_.digest } | ForEach-Object { [pscustomobject]@{ Digest = $_.digest; Size = [long]$_.size; File = ($_.digest -replace ':', '-') } }
}

function Test-ModelFiles([string]$ModelsDir, [string]$Name) {
  $p = Split-ModelName $Name
  $man = Join-Path $ModelsDir $p.ManifestRel
  if (-not (Test-Path -LiteralPath $man)) { return $false }
  try {
    foreach ($b in Get-ModelBlobs $man) {
      $f = Join-Path $ModelsDir "blobs\$($b.File)"
      if (-not (Test-Path -LiteralPath $f) -or (Get-Item -LiteralPath $f).Length -ne $b.Size) { return $false }
    }
    return $true
  } catch { return $false }
}

# Copies one model (its manifest and blobs) between two Ollama model folders, skipping blobs already there.
function Copy-ModelFiles([string]$FromDir, [string]$ToDir, [string]$Name) {
  $p = Split-ModelName $Name
  $src = Join-Path $FromDir $p.ManifestRel
  foreach ($b in Get-ModelBlobs $src) {
    $to = Join-Path $ToDir "blobs\$($b.File)"
    if ((Test-Path -LiteralPath $to) -and (Get-Item -LiteralPath $to).Length -eq $b.Size) { continue }
    New-Item -ItemType Directory -Force (Split-Path -Parent $to) | Out-Null
    Write-Info ("copying " + $b.File.Substring(0, 19) + '... (' + (Format-Size $b.Size) + ')')
    Copy-Item -Force -LiteralPath (Join-Path $FromDir "blobs\$($b.File)") -Destination $to
  }
  $dst = Join-Path $ToDir $p.ManifestRel
  New-Item -ItemType Directory -Force (Split-Path -Parent $dst) | Out-Null
  Copy-Item -Force -LiteralPath $src -Destination $dst
}

<#
  Downloads a model straight from the Ollama registry into an Ollama model folder, in the layout Ollama itself uses.
  Unlike "ollama pull", this goes through the Windows proxy settings (including proxies that need a Windows sign-in).
#>
function Save-ModelFromRegistry([string]$ModelsDir, [string]$Name) {
  $p = Split-ModelName $Name
  $manText = Get-WebText "$($p.Base)/manifests/$($p.Tag)" 'application/vnd.docker.distribution.manifest.v2+json'
  $tmpMan = Join-Path $script:StateDir 'manifest.tmp'
  New-Item -ItemType Directory -Force $script:StateDir | Out-Null
  [IO.File]::WriteAllText($tmpMan, $manText, (New-Object Text.UTF8Encoding($false)))
  foreach ($b in Get-ModelBlobs $tmpMan) {
    $to = Join-Path $ModelsDir "blobs\$($b.File)"
    if ((Test-Path -LiteralPath $to) -and (Get-Item -LiteralPath $to).Length -eq $b.Size) { continue }
    Get-Download "$($p.Base)/blobs/$($b.Digest)" $to ($b.Digest -replace '^sha256:', '').ToUpper() ("model part " + (Format-Size $b.Size))
  }
  $dst = Join-Path $ModelsDir $p.ManifestRel
  New-Item -ItemType Directory -Force (Split-Path -Parent $dst) | Out-Null
  Move-Item -Force -LiteralPath $tmpMan -Destination $dst
}

# Latest Ollama release tag ("v0.35.0"), read from GitHub's redirect so no API rate limit applies.
function Get-OllamaLatestTag {
  try {
    $loc = Get-RedirectTarget 'https://github.com/ollama/ollama/releases/latest'
    if ($loc -match '/tag/(v[^/?#]+)') { return $Matches[1] }
  } catch {}
  return $null
}

# ---------- user environment ----------
# Read and written as stored, so entries such as %USERPROFILE%\... stay as they are and the value keeps its type
# (Environment.SetEnvironmentVariable would save it expanded, as plain text).
function Edit-UserPath([scriptblock]$Change) {
  $k = [Microsoft.Win32.Registry]::CurrentUser.OpenSubKey('Environment', $true)
  try {
    $cur = [string]$k.GetValue('Path', '', [Microsoft.Win32.RegistryValueOptions]::DoNotExpandEnvironmentNames)
    $kind = if ($k.GetValueNames() -contains 'Path') { $k.GetValueKind('Path') } else { [Microsoft.Win32.RegistryValueKind]::ExpandString }
    $parts = @($cur.Split(';') | Where-Object { $_ })
    $next = @(& $Change $parts)
    if (($next -join ';') -eq ($parts -join ';')) { return $false }
    $k.SetValue('Path', ($next -join ';'), $kind)
  } finally { $k.Close() }
  # Tells Windows the environment changed, so new programs see it without signing out.
  [Environment]::SetEnvironmentVariable('MANDATA_SETUP_REFRESH', '1', 'User')
  [Environment]::SetEnvironmentVariable('MANDATA_SETUP_REFRESH', $null, 'User')
  return $true
}
function Test-SamePath([string]$A, [string]$B) {
  [Environment]::ExpandEnvironmentVariables($A).TrimEnd('\') -ieq [Environment]::ExpandEnvironmentVariables($B).TrimEnd('\')
}
function Add-UserPath([string]$Dir) {
  $added = Edit-UserPath { param($p) if ($p | Where-Object { Test-SamePath $_ $Dir }) { $p } else { $p + $Dir } }
  if (-not (($env:Path.Split(';')) -contains $Dir)) { $env:Path = "$env:Path;$Dir" }
  return $added
}
function Remove-UserPath([string]$Dir) {
  $null = Edit-UserPath { param($p) $p | Where-Object { -not (Test-SamePath $_ $Dir) } }
}