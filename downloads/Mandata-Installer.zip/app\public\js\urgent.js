// The most important tasks: a task from newly arrived mail (never your history), asked of you, whose radar averages at
// least the number set in Settings > Tasks. The server keeps them (GET /api/urgent) until you press OK here, so one that
// came while the window was closed still shows when it opens. A message in the middle of the screen, with a sound when set.
import { esc, icon, api, GET, modal, $ } from './ui.js';
import { openTask } from './panels.js';
import { radar } from './viz.js';

let box = null, busy = false;

export async function checkUrgent() {
  if (busy) return;
  busy = true;
  try {
    const { items = [], sound } = await GET('/api/urgent');
    const ids = new Set(items.map(t => t.id));
    if (box && box.ids.every(id => ids.has(id)) && box.ids.length === ids.size) return;   // already on screen
    box?.m.close(true);
    box = null;
    if (!items.length) return;
    show(items, sound && !items.every(t => heard.has(t.id)));
    items.forEach(t => heard.add(t.id));
  } catch {} finally { busy = false; }
}
const heard = new Set();   // each task rings once, however often the list is shown again

function show(items, ring) {
  const one = items.length === 1;
  const card = t => `<div class="urg-card" data-id="${t.id}">
      <div class="urg-radar">${radar(t.radar)}</div>
      <div class="urg-body"><b class="urg-title">${esc(t.title)}</b>
        <div class="urg-meta">${esc(t.requester_name || t.requester_email || '')}${t.subject ? ` · ${esc(t.subject)}` : ''}</div>
        <div class="urg-score">Radar average <b>${t.average}</b> / 5</div>
        <button class="btn primary urg-open" data-id="${t.id}">${icon('tasks', 14)} Open the task</button></div></div>`;
  const m = modal({ title: one ? 'This task is the most important' : `These ${items.length} tasks are the most important`, size: 'urgent',
    body: `<div class="urg-head">${icon('flag', 22)}<p>${one ? 'A task that just arrived in your mail' : 'Tasks that just arrived in your mail'} scored high on the radar. Deal with ${one ? 'it' : 'them'} first.</p></div>${items.map(card).join('')}`,
    footer: '<div class="btnrow"><button class="btn ok">OK</button></div>',
    onClose: () => seen(items) });
  box = { m, ids: items.map(t => t.id) };
  $('.ok', m.el).onclick = () => m.close();
  m.el.addEventListener('click', e => { const b = e.target.closest('.urg-open'); if (!b) return; m.close(); openTask(Number(b.dataset.id)); });
  if (ring) chime();
}

function seen(items) {
  box = null;
  api('POST', '/api/urgent/seen', { ids: items.map(t => t.id) }).catch(() => {});
}

/** Three rising notes, twice: made here, no sound file needed. */
function chime() {
  try {
    const ac = new (window.AudioContext || window.webkitAudioContext)();
    const notes = [659.25, 830.61, 987.77];
    for (let r = 0; r < 2; r++) notes.forEach((f, i) => {
      const at = ac.currentTime + r * 0.9 + i * 0.16, o = ac.createOscillator(), g = ac.createGain();
      o.type = 'sine'; o.frequency.value = f;
      g.gain.setValueAtTime(0.0001, at); g.gain.exponentialRampToValueAtTime(0.35, at + 0.02); g.gain.exponentialRampToValueAtTime(0.0001, at + 0.5);
      o.connect(g).connect(ac.destination); o.start(at); o.stop(at + 0.55);
    });
    setTimeout(() => ac.close().catch(() => {}), 2500);
  } catch {}
}
