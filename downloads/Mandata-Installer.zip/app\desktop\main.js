// Mandata desktop app. Runs the local server inside this process, shows the app in its own window (no browser),
// and lives in the system tray (the menu bar on a Mac): closing the window keeps it running, checking mail and reading
// threads. Notifications for new tasks and deadlines come from here. Runs on Windows, macOS and Linux.
import { app, BrowserWindow, Tray, Menu, Notification, nativeImage, shell, dialog } from 'electron';
import path from 'node:path';
import fs from 'node:fs';
import os from 'node:os';
import http from 'node:http';
import { fileURLToPath } from 'node:url';

import { APP } from '../lib/defaults.js';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const PORT = Number(process.env.PORT || APP.port);
const BASE = `http://${APP.host}:${PORT}`;
const hidden = process.argv.includes('--hidden');
const WIN = process.platform === 'win32', MAC = process.platform === 'darwin';
const ICON = path.join(HERE, WIN ? 'icon.ico' : 'icon.png');
let win = null, tray = null, quitting = false, server = null, downloads = null;

app.setAppUserModelId('UN.Mandata');
if (!app.requestSingleInstanceLock()) { app.quit(); process.exit(0); }
app.on('second-instance', () => show());
// A Mac: clicking the Dock icon brings the window back.
app.on('activate', () => { if (server) show(); });

// ---------- window ----------
const stateFile = () => path.join(app.getPath('userData'), 'window.json');
const readState = () => { try { return JSON.parse(fs.readFileSync(stateFile(), 'utf8')); } catch { return {}; } };

function createWindow() {
  const s = readState();
  win = new BrowserWindow({
    width: s.width || 1440, height: s.height || 900, x: s.x, y: s.y, minWidth: 900, minHeight: 600,
    show: false, title: 'Mandata', icon: ICON, backgroundColor: '#f4f6fb', autoHideMenuBar: true,
    webPreferences: { contextIsolation: true, nodeIntegration: false, sandbox: true, spellcheck: true },
  });
  if (!MAC) win.removeMenu();   // a Mac keeps the app menu: Copy, Paste and Quit live there
  if (s.maximized) win.maximize();
  win.loadURL(BASE + '/');
  win.once('ready-to-show', () => { if (!hidden) win.show(); });
  // Links to the web open in your browser; the app itself never leaves its own pages.
  win.webContents.setWindowOpenHandler(({ url }) => { if (/^(https?|mailto):/i.test(url)) shell.openExternal(url); return { action: 'deny' }; });
  // By origin, not by prefix: "http://127.0.0.1:4318@elsewhere" or another port is not the app.
  const ours = url => { try { return new URL(url).origin === new URL(BASE).origin; } catch { return false; } };
  win.webContents.on('will-navigate', (e, url) => { if (!ours(url)) { e.preventDefault(); if (/^(https?|mailto):/i.test(url)) shell.openExternal(url); } });
  // The page asks for nothing but copying text (Copy answer): camera, microphone, location and the rest are refused.
  if (!downloads) win.webContents.session.setPermissionRequestHandler((wc, permission, done) => done(['clipboard-sanitized-write', 'fullscreen'].includes(permission)));
  // A backup file is saved wherever you choose (Windows' Save As, opening in Documents), and you are told where it went.
  if (!downloads) downloads = win.webContents.session.on('will-download', (e, item) => {
    if (!/^Mandata backup .*\.db$/i.test(item.getFilename())) return;
    item.setSaveDialogOptions({ title: 'Save the Mandata backup', buttonLabel: 'Save backup', defaultPath: path.join(app.getPath('documents'), item.getFilename()),
      filters: [{ name: 'Mandata backup', extensions: ['db'] }, { name: 'All files', extensions: ['*'] }] });
    item.once('done', (ev, state) => {
      if (state === 'completed') notify('Backup saved', `${item.getSavePath()}\nRestore it any time from Settings > Data > Import a backup file.`);
      else if (state === 'interrupted') notify('The backup was not saved', 'Saving the file failed. Try again, or choose another folder.');
    });
  });
  // Saved once the window settles, not on every pixel of a drag.
  let saving;
  const write = () => { if (!win || win.isDestroyed()) return; const b = win.getNormalBounds(); try { fs.writeFileSync(stateFile(), JSON.stringify({ ...b, maximized: win.isMaximized() })); } catch {} };
  const save = () => { clearTimeout(saving); saving = setTimeout(write, 500); };
  win.on('resize', save); win.on('move', save); win.on('close', () => { clearTimeout(saving); write(); });
  // Closing hides to the tray. Quit from the tray menu (or the app menu on a Mac).
  let told = false;
  win.on('close', e => {
    if (quitting) return;
    e.preventDefault(); win.hide();
    if (!told) { told = true; notify('Mandata is still running', MAC ? 'It keeps watching your email. Quit from its menu bar icon, or with Cmd+Q.'
      : WIN ? 'It keeps watching your email from the system tray. Right-click the tray icon to quit.'
      : 'It keeps watching your email. Open Mandata from your apps to show it again; quit from its tray icon.'); }
  });
}
function show(hash) {
  if (!win || win.isDestroyed()) createWindow();
  if (hash) win.webContents.executeJavaScript(`location.hash=${JSON.stringify(hash)}`).catch(() => {});
  if (win.isMinimized()) win.restore();
  win.show(); win.focus();
}

// ---------- starting at sign-in ----------
const loginArgs = () => app.isPackaged ? ['--hidden'] : [app.getAppPath(), '--hidden'];
// Windows keeps it in its own list. A Mac gets a launch agent and Linux an autostart entry: both start the app hidden,
// which the Mac's own login items cannot do.
const LOGIN_FILE = MAC ? path.join(os.homedir(), 'Library', 'LaunchAgents', 'io.github.shamoug.mandata.plist')
  : WIN ? '' : path.join(process.env.XDG_CONFIG_HOME || path.join(os.homedir(), '.config'), 'autostart', 'mandata.desktop');
const LOGIN_LABEL = WIN ? 'Start with Windows' : MAC ? 'Open at login' : 'Start at login';
/** What starts the app: on Linux the launcher beside it (it knows when Chromium's sandbox cannot run), or the AppImage. */
function loginCommand() {
  const launcher = path.join(path.dirname(process.execPath), 'mandata');
  const exe = process.platform === 'linux' ? process.env.APPIMAGE || (fs.existsSync(launcher) ? launcher : process.execPath) : process.execPath;
  return [exe, ...loginArgs()];
}
const xml = s => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
const desktopArg = s => `"${String(s).replace(/(["`$\\])/g, '\\$1')}"`;
function writeLogin(on) {
  if (WIN) return app.setLoginItemSettings({ openAtLogin: on, args: loginArgs() });
  if (!on) { try { fs.unlinkSync(LOGIN_FILE); } catch {} return; }
  const cmd = loginCommand();
  fs.mkdirSync(path.dirname(LOGIN_FILE), { recursive: true });
  fs.writeFileSync(LOGIN_FILE, MAC
    ? `<?xml version="1.0" encoding="UTF-8"?>\n<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">\n<plist version="1.0"><dict>\n`
      + `<key>Label</key><string>io.github.shamoug.mandata</string>\n<key>ProgramArguments</key><array>${cmd.map(a => `<string>${xml(a)}</string>`).join('')}</array>\n`
      + `<key>RunAtLoad</key><true/>\n<key>ProcessType</key><string>Interactive</string>\n<key>LimitLoadToSessionType</key><string>Aqua</string>\n</dict></plist>\n`
    : `[Desktop Entry]\nType=Application\nName=Mandata\nComment=Tasks found in your email\nExec=${cmd.map(desktopArg).join(' ')}\nIcon=mandata\nTerminal=false\nX-GNOME-Autostart-enabled=true\n`);
}
// Asked once, then kept as you tick it: not on every refresh of the menu.
let login = null;
const startsAtLogin = () => login ??= WIN ? app.getLoginItemSettings({ args: loginArgs() }).openAtLogin : fs.existsSync(LOGIN_FILE);

// ---------- tray ----------
function trayMenu(counts = {}) {
  return Menu.buildFromTemplate([
    { label: 'Open Mandata', click: () => show(), type: 'normal' },
    { type: 'separator' },
    { label: `Open tasks assigned to me${counts.mine != null ? ` (${counts.mine})` : ''}`, click: () => show('#/tasks/?dir=to_me&status=open') },
    { label: `Overdue${counts.overdue != null ? ` (${counts.overdue})` : ''}`, click: () => show('#/tasks/?due=late') },
    { label: 'Check mail now', click: () => post('/api/sync') },
    { type: 'separator' },
    { label: LOGIN_LABEL, type: 'checkbox', checked: startsAtLogin(),
      click: m => { login = m.checked; try { writeLogin(m.checked); } catch (e) { notify(`Could not change "${LOGIN_LABEL}"`, e.message); } } },
    { label: 'Quit Mandata', click: () => { quitting = true; app.quit(); } },
  ]);
}
function createTray() {
  const px = MAC ? 18 : 16;   // the Mac menu bar's icon size
  const img = nativeImage.createFromPath(path.join(HERE, 'tray.png')).resize({ width: px, height: px });
  tray = new Tray(img);
  tray.setToolTip('Mandata');
  tray.setContextMenu(trayMenu());
  tray.on('click', () => (win?.isVisible() && win.isFocused() ? win.hide() : show()));
}
let lastTip = 0, tipTimer = null, menuFor = '';
function refreshTray() {
  clearTimeout(tipTimer);
  const wait = Math.max(0, 3000 - (Date.now() - lastTip));
  tipTimer = setTimeout(async () => {
    lastTip = Date.now();
    try {
      const s = await getJson('/api/status');
      const c = s.counts || {};
      tray?.setToolTip(`Mandata\n${c.mine ?? 0} open task${c.mine === 1 ? '' : 's'} assigned to me${c.overdue ? `, ${c.overdue} overdue` : ''}\n${s.sync?.phase || s.sync?.aiPhase || (s.outlook?.connected ? 'Outlook connected' : 'Outlook not connected')}`);
      // The menu is built again only when its counts changed.
      const key = `${c.mine}|${c.overdue}`;
      if (tray && key !== menuFor) { menuFor = key; tray.setContextMenu(trayMenu(c)); }
    } catch {}
  }, wait);
}

// ---------- notifications from the server ----------
// Normal Windows tips, one after another, never stacked: the next shows when the one on screen goes (or after GAP_MS,
// when Windows does not say it went).
const GAP_MS = 7000;
const tips = [];
let onScreen = null;   // held so it is not garbage-collected (and its click lost) while on screen
function notify(title, body, hash) {
  if (!Notification.isSupported()) return;
  tips.push({ title, body, hash });
  if (!onScreen) nextTip();
}
function nextTip() {
  const a = tips.shift();
  if (!a) { onScreen = null; return; }
  const n = onScreen = new Notification({ title: a.title, body: a.body, icon: ICON, silent: false });
  let over = false;
  const done = () => { if (over) return; over = true; clearTimeout(timer); setTimeout(nextTip, 800); };
  const timer = setTimeout(done, GAP_MS);
  n.on('click', () => { done(); show(a.hash); });
  n.on('close', done);
  n.on('failed', done);
  n.show();
}
function listen() {
  // Listened to again 3 s after the stream ends, breaks or never starts: once, whichever comes first.
  let again = false;
  const retry = () => { if (!again) { again = true; setTimeout(listen, 3000); } };
  const req = http.get(BASE + '/api/events', { headers: { host: `${APP.host}:${PORT}` } }, res => {
    let buf = '';
    res.setEncoding('utf8');
    res.on('data', d => {
      buf += d;
      let i;
      while ((i = buf.indexOf('\n\n')) >= 0) {
        const chunk = buf.slice(0, i); buf = buf.slice(i + 2);
        const line = chunk.split('\n').find(l => l.startsWith('data: '));
        if (!line) continue;
        let ev; try { ev = JSON.parse(line.slice(6)); } catch { continue; }
        if (ev.type === 'notify') notify(ev.title, ev.body, ev.route);
        if (['status', 'tasks'].includes(ev.type)) refreshTray();
      }
    });
    res.on('end', retry); res.on('error', retry); res.on('close', retry);
  });
  req.on('error', retry);
}

// ---------- helpers ----------
const getJson = p => fetch(BASE + p).then(r => r.json());
const post = p => fetch(BASE + p, { method: 'POST', headers: { 'content-type': 'application/json' }, body: '{}' }).catch(() => {});

/**
 * First run of the installed app: Start Menu and Desktop shortcuts (the Start Menu one carries the app id Windows
 * needs to show notifications), and start with Windows, which you can untick in the tray menu.
 */
function firstRun() {
  if (!app.isPackaged) return;
  if (!WIN) return firstRunElsewhere();
  removeVersion1();
  const flag = path.join(app.getPath('userData'), 'installed.json');
  // The icon comes from icon.ico rather than the .exe: Windows caches an .exe's icon by path and keeps the old one.
  const lnk = { target: process.execPath, icon: path.join(HERE, 'icon.ico'), iconIndex: 0, appUserModelId: 'UN.Mandata', description: 'Tasks found in your email' };
  const desktopLnk = path.join(app.getPath('desktop'), 'Mandata.lnk');
  const programs = path.join(app.getPath('appData'), 'Microsoft', 'Windows', 'Start Menu', 'Programs');
  try { shell.writeShortcutLink(path.join(programs, 'Mandata.lnk'), lnk); } catch {}
  // Electron makes one for notifications, named after the .exe's version details: with the app's id and no icon, the
  // taskbar would show Electron's icon. The installer renames the .exe, so this only clears one left from before.
  const stray = path.join(programs, 'Electron.lnk');
  try { if (shell.readShortcutLink(stray).target.toLowerCase() === process.execPath.toLowerCase()) fs.unlinkSync(stray); } catch {}
  if (fs.existsSync(flag)) {
    if (fs.existsSync(desktopLnk)) try { shell.writeShortcutLink(desktopLnk, lnk); } catch {}
    return;
  }
  try { shell.writeShortcutLink(desktopLnk, lnk); } catch {}
  app.setLoginItemSettings({ openAtLogin: true, args: loginArgs() });
  fs.writeFileSync(flag, JSON.stringify({ at: new Date().toISOString() }));
}

/** macOS and Linux: the installer or package made the app's launcher; the app starts at login from its first run, and
 *  the entry follows the app when it is moved (an AppImage moved to another folder, the app dragged elsewhere). */
function firstRunElsewhere() {
  const flag = path.join(app.getPath('userData'), 'installed.json');
  try {
    if (!fs.existsSync(flag)) { writeLogin(true); login = true; fs.writeFileSync(flag, JSON.stringify({ at: new Date().toISOString() })); }
    else if (fs.existsSync(LOGIN_FILE)) writeLogin(true);
  } catch (e) { console.error('Could not set Mandata to start at login:', e.message); }
}

/** A Mac's app menu: without one, Cmd+C, Cmd+V and Cmd+Q do nothing. */
function macMenu() {
  if (!MAC) return;
  Menu.setApplicationMenu(Menu.buildFromTemplate([{ role: 'appMenu' }, { role: 'editMenu' },
    { label: 'View', submenu: [{ role: 'reload' }, { type: 'separator' }, { role: 'resetZoom' }, { role: 'zoomIn' }, { role: 'zoomOut' }, { type: 'separator' }, { role: 'togglefullscreen' }] },
    { role: 'windowMenu' }]));
}

/** Version 1 was called Task Manager: its shortcuts and start-up entry would start the old copy. */
function removeVersion1() {
  for (const dir of [app.getPath('desktop'), path.join(app.getPath('appData'), 'Microsoft', 'Windows', 'Start Menu', 'Programs')]) {
    const f = path.join(dir, 'Task Manager.lnk');
    try { if (/Task Manager\.exe$/i.test(shell.readShortcutLink(f).target)) fs.unlinkSync(f); } catch {}
  }
  try { app.setLoginItemSettings({ openAtLogin: false, name: 'UN.TaskManager' }); } catch {}
}

// ---------- start ----------
app.whenReady().then(async () => {
  macMenu();
  firstRun();
  try {
    server = await import('../server.js');
    await server.startServer({ port: PORT });
  } catch (e) {
    console.error(e);
    // A failed start is nearly always the data file held for a moment longer: start again, quietly, up to 3 times.
    const tries = Number(process.argv.find(a => a.startsWith('--start-try='))?.split('=')[1] || 0);
    if (tries < 3) {
      app.relaunch({ args: [...process.argv.slice(1).filter(a => !a.startsWith('--start-try=')), `--start-try=${tries + 1}`] });
      setTimeout(() => app.exit(0), 3000 * (tries + 1));
      return;
    }
    // Still failing: said plainly, then closed. Nothing would answer the window, the tray or the live updates.
    dialog.showErrorBox('Mandata could not open its data', `Restart your computer, then open Mandata again. Your tasks are safe.\n\n${e?.message || e}`);
    quitting = true;
    try { server?.stopServer(); } catch {}
    app.exit(1);
    return;
  }
  createTray();
  createWindow();
  listen();
  refreshTray();
});
app.on('window-all-closed', () => {});   // keep running in the tray
app.on('before-quit', () => { quitting = true; try { server?.stopServer(); } catch {} });
