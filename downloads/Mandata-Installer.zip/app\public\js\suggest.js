// Text boxes suggest while you type: a short list under the box of what it can hold (people, task titles, subjects,
// model names), matched by every word typed. The box stays a plain text box: typing on without picking still works.
//   suggest(input, source, { list })
//   source: () => [{ label, sub?, value?, extra? }] or a promise of it; value defaults to label; extra is matched, not shown.
//   list: the box holds a list split by ";" or ",": only the word being typed is matched and replaced, and the first
//     suggestion is ready for Enter or Tab. Otherwise the whole box is matched and replaced, and Enter or Tab pick only
//     after Down has moved into the list, so Enter and Escape in a search box keep doing what they did.
// Picking fires the box's input event, so a search box filters at once.
import { GET } from './ui.js';

const fold = s => String(s || '').normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase();
let closeOpen = null; // closes the list that is showing, if any
addEventListener('resize', () => closeOpen?.());
document.addEventListener('scroll', e => { if (!e.target.closest?.('.ss-pop')) closeOpen?.(); }, true);

/** The word being typed in a list box: from just after the last separator before the caret, to the caret. */
function token(input) {
  const v = input.value, end = input.selectionStart ?? v.length;
  const start = Math.max(v.lastIndexOf(';', end - 1), v.lastIndexOf(',', end - 1)) + 1;
  return { start, end, text: v.slice(start, end).trim() };
}

export function suggest(input, source, { list = false, max = 8 } = {}) {
  if (!input || input.disabled || input.dataset.suggest) return;
  input.dataset.suggest = '1';
  input.setAttribute('autocomplete', 'off');
  let pop = null, items = [], idx = -1, n = 0;

  const close = () => { pop?.remove(); pop = null; items = []; idx = -1; if (closeOpen === close) closeOpen = null; };
  const move = i => {
    idx = Math.max(0, Math.min(items.length - 1, i));
    pop.querySelectorAll('.ss-opt').forEach((d, k) => d.classList.toggle('on', k === idx));
    pop.querySelector('.ss-opt.on')?.scrollIntoView({ block: 'nearest' });
  };
  const place = () => {
    const r = input.getBoundingClientRect(), w = Math.max(r.width, 260), below = innerHeight - r.bottom - 8, up = below < 180 && r.top > below;
    Object.assign(pop.style, { left: Math.max(8, Math.min(r.left, innerWidth - w - 8)) + 'px', width: w + 'px',
      top: up ? '' : r.bottom + 4 + 'px', bottom: up ? innerHeight - r.top + 4 + 'px' : '' });
    pop.firstChild.style.maxHeight = Math.min(300, (up ? r.top : below) - 20) + 'px';
  };
  const pick = it => {
    const val = it.value ?? it.label;
    if (list) {
      const { start, end } = token(input), v = input.value;
      const before = v.slice(0, start).replace(/\s*$/, start ? ' ' : ''), after = v.slice(end).replace(/^[\s;,]*/, '');
      input.value = before + val + '; ' + after;
      const caret = (before + val + '; ').length;
      input.setSelectionRange(caret, caret);
    } else input.value = val;
    close();
    input.dispatchEvent(new Event('input', { bubbles: true }));
    input.dispatchEvent(new Event('change', { bubbles: true }));
  };

  const draw = async () => {
    const k = ++n, text = list ? token(input).text : input.value, words = fold(text).split(/\s+/).filter(Boolean);
    if (!words.length) return close();
    let all;
    try { all = await source(); } catch { all = []; }
    if (k !== n || document.activeElement !== input) return;
    const taken = new Set(list ? fold(input.value).split(/[;,\s]+/) : []), seen = new Set();
    const starts = it => words.some(w => fold(it.label).startsWith(w) || fold(it.value).startsWith(w));
    items = (all || []).filter(it => {
      const v = fold(it.value ?? it.label);
      if (!it.label || seen.has(v) || taken.has(v) || (!list && v === fold(text).trim())) return false;
      seen.add(v);
      return words.every(w => fold(`${it.label} ${it.sub || ''} ${it.value || ''} ${it.extra || ''}`).includes(w));
    }).sort((a, b) => starts(b) - starts(a)).slice(0, max);
    if (!items.length) return close();
    if (!pop) {
      pop = document.createElement('div');
      pop.className = 'ss-pop sg-pop';
      pop.innerHTML = '<div class="ss-list" role="listbox"></div>';
      pop.onmousedown = e => e.preventDefault(); // keep focus in the box
      pop.onclick = e => { const d = e.target.closest('.ss-opt'); if (d) pick(items[+d.dataset.i]); };
      document.body.append(pop);
      closeOpen?.(); closeOpen = close;
    }
    const box = pop.firstChild;
    box.innerHTML = '';
    items.forEach((it, i) => {
      const d = document.createElement('div');
      d.className = 'ss-opt'; d.dataset.i = i; d.title = it.sub ? `${it.label} · ${it.sub}` : it.label;
      d.innerHTML = '<b></b> <span class="muted small"></span>';
      d.firstChild.textContent = it.label;
      d.lastChild.textContent = it.sub || '';
      d.onmousemove = () => idx !== i && move(i);
      box.append(d);
    });
    place();
    if (list) move(0); else idx = -1;
  };

  // Only what you type opens the list: a value set by the page (or by a pick) does not.
  input.addEventListener('input', e => { if (e.isTrusted) draw(); });
  input.addEventListener('blur', close);
  // Capture: runs before the box's own key handlers, so Escape closes the list without also clearing the search.
  input.addEventListener('keydown', e => {
    if (!pop) return;
    const stop = () => { e.preventDefault(); e.stopImmediatePropagation(); };
    if (e.key === 'ArrowDown') { stop(); move(idx + 1); }
    else if (e.key === 'ArrowUp') { stop(); if (idx <= 0 && !list) { idx = -1; pop.querySelectorAll('.ss-opt').forEach(d => d.classList.remove('on')); } else move(idx - 1); }
    else if ((e.key === 'Enter' || e.key === 'Tab') && idx >= 0) { stop(); pick(items[idx]); }
    else if (e.key === 'Escape') { stop(); close(); }
  }, true);
}

// ---------- sources shared by several boxes ----------
let people = null;
/** People, by name with their email, loaded once per page. */
export const peopleSource = () => people ||= GET('/api/people')
  .then(r => r.filter(p => p.email).map(p => ({ name: p.name || '', email: String(p.email).toLowerCase(), org: p.organization || '', aka: (p.aka || []).join(' ') })))
  .catch(() => (people = null, []));

/** An email address box (To, Cc): a list of addresses, suggested from People. */
export const emailSuggest = input => suggest(input, async () =>
  (await peopleSource()).map(p => ({ label: p.name || p.email, sub: p.name ? p.email : '', value: p.email, extra: p.aka })), { list: true });
