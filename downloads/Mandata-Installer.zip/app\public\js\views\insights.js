// Insights: any two things about tasks, crossed. Pick what runs along X and what splits it (the series), how many of
// each to keep, and read it as a table (a heat-map cross tab), stacked bars, shares, lines or areas. Click a cell, a
// bar or a point to see the tasks behind it. Presets cover the usual questions, such as who asks whom.
import { GET, esc, icon, DIR, STATUS, dateLabel, colorOf, modal, pref, setPref, $, plural, monthLabel, latest, errorBox, toast } from '../ui.js';
import { S as APP, onView, onLeave, isMe } from '../store.js';
import { taskCard } from '../panels.js';
import { whoFlow } from '../viz.js';

// ---------- dimensions ----------
const ymd = d => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
const monday = iso => { const d = new Date(iso); d.setHours(12, 0, 0, 0); d.setDate(d.getDate() - (d.getDay() + 6) % 7); return d; };
const week = iso => iso ? ymd(monday(iso)) : null;
const month = iso => iso ? String(iso).slice(0, 7) : null;
const nextWeek = k => { const d = new Date(k + 'T12:00:00'); d.setDate(d.getDate() + 7); return ymd(d); };
const nextMonth = k => { const [y, m] = k.split('-').map(Number); return m === 12 ? `${y + 1}-01` : `${y}-${String(m + 1).padStart(2, '0')}`; };
const monthName = k => monthLabel(k, { month: 'short', year: '2-digit' });

const DL = { Overdue: '#c92a2a', 'Due soon': '#f76707', 'Due this week': '#f2b705', Later: '#3b5bdb', 'No deadline': '#74c0fc', Parked: STATUS.parked.color, Closed: '#2f8a4f' };
const dlOf = t => t.status === 'parked' ? 'Parked' : t.status !== 'open' ? 'Closed' : t.days_left == null ? 'No deadline' : t.days_left < 0 ? 'Overdue'
  : t.due_soon ? 'Due soon' : t.days_left <= 7 ? 'Due this week' : 'Later';
const PRIC = { high: ['High', '#c92a2a'], normal: ['Normal', '#3b5bdb'], low: ['Low', '#74c0fc'] };
const SRC = { email: ['From the email', '#2f8f7f'], user: ['Set by you', '#1864ab'] };
const PAL = ['#3b5bdb', '#c8822f', '#2f8f7f', '#e8590c', '#0b7285', '#4a93b8', '#7d9b4f', '#b0715a', '#6c7fa8', '#f08c00', '#3f8f6b', '#b8862f'];

let names = new Map();
const pkey = (t, side) => {
  const e = t[side + '_email'], k = e || t[side + '_name'] || '?';
  names.set(k, isMe(e) ? 'Me' : t[side + '_name'] || e || 'Unknown');
  return k;
};
// You in a strong blue of your own: a near-black would vanish on the dark page (colours written here are not turned dark).
const pcolor = k => names.get(k) === 'Me' ? '#1864ab' : colorOf(k);
const person = { name: k => names.get(k) || k, color: pcolor, person: true };

const DIMS = {
  requester: { label: 'Asked by', val: t => pkey(t, 'requester'), ...person },
  owner: { label: 'Done by', val: t => pkey(t, 'owner'), ...person },
  kind: { label: 'Kind', val: t => DIR[t.direction] ? t.direction : 'others', name: k => DIR[k].label, color: k => DIR[k].color, order: Object.keys(DIR) },
  deadline: { label: 'Deadline', val: dlOf, name: k => k, color: k => DL[k], order: Object.keys(DL) },
  status: { label: 'Status', val: t => t.status, name: k => STATUS[k]?.label || k, color: k => STATUS[k]?.color || '#a0522d', order: ['open', 'parked', 'done', 'cancelled'] },
  priority: { label: 'Priority', val: t => t.priority || 'normal', name: k => PRIC[k]?.[0] || k, color: k => PRIC[k]?.[1] || '#a0522d', order: Object.keys(PRIC) },
  weekOpened: { label: 'Week opened', val: t => week(t.opened_at), name: k => dateLabel(k), chrono: nextWeek },
  monthOpened: { label: 'Month opened', val: t => month(t.opened_at), name: monthName, chrono: nextMonth },
  weekClosed: { label: 'Week closed', val: t => ['done', 'cancelled'].includes(t.status) ? week(t.closed_at) : null, name: k => dateLabel(k), chrono: nextWeek },
  source: { label: 'Deadline from', val: t => t.deadline ? (t.deadline_source === 'user' ? 'user' : 'email') : null, name: k => SRC[k]?.[0] || k, color: k => SRC[k]?.[1] || '#a0522d', order: Object.keys(SRC) },
};
const TOPN = [5, 8, 10, 15, 20, 30, 9999];
const MODES = [['table', 'Table', 'grid', 'A grid: one row per X, one column per series, the count in each cell'], ['flow', 'Flow', 'people', 'Ribbons from who asked to who does it, as wide as the number of tasks'],
  ['bar', 'Bars', 'tasks', 'Stacked bars: one per X, split by series'], ['pct', '% Bars', 'list', 'Stacked bars that each fill 100%: the share of each series'],
  ['line', 'Lines', 'pulse', 'A line per series across X'], ['area', 'Areas', 'spark', 'Stacked areas: a band per series across X']];
const SCOPES = [['open', 'Open', 'Only the tasks still to be done'], ['closed', 'Closed', 'Only the tasks done or cancelled'], ['all', 'All', 'Open and closed tasks together']];
const PRESETS = {
  who: { label: 'Who asks whom', x: 'requester', y: 'owner', mode: 'table', scope: 'open', tx: 15, ty: 15 },
  flow: { label: 'Who asks whom: flow', x: 'requester', y: 'owner', mode: 'flow', scope: 'open', tx: 10, ty: 10 },
  pace: { label: 'Weekly intake by kind', x: 'weekOpened', y: 'kind', mode: 'bar', scope: 'all', tx: 12, ty: 8 },
  deadlines: { label: 'Deadlines by person', x: 'owner', y: 'deadline', mode: 'bar', scope: 'open', tx: 15, ty: 8 },
  closing: { label: 'Closing pace', x: 'weekClosed', y: 'kind', mode: 'line', scope: 'closed', tx: 12, ty: 8 },
};
let S = { ...PRESETS.who, ...pref('insights', {}) };
// Saved by an older version, with a dimension or a view since renamed: start again from the first preset rather than fail to draw.
if (!DIMS[S.x] || !DIMS[S.y] || S.x === S.y || !MODES.some(([m]) => m === S.mode) || !SCOPES.some(([v]) => v === S.scope) || !TOPN.includes(S.tx) || !TOPN.includes(S.ty)) S = { ...PRESETS.who };
const save = () => setPref('insights', { x: S.x, y: S.y, mode: S.mode, scope: S.scope, tx: S.tx, ty: S.ty });

let root, tasks = [], cube = null;
export function mount(el, arg) {
  root = el;
  el.innerHTML = `<div class="page ins">
    <div class="fbar ins-head"><h2 class="ptitle">${icon('grid', 18)} Insights</h2><span class="muted small">Cross any two things about your tasks. Click a cell or a bar to see the tasks behind it.</span></div>
    <div class="ins-presets" id="iPre"></div>
    <section class="ins-card">
      <div class="ins-ctrl" id="iCtl"></div>
      <div class="ins-body" id="iBody"></div>
      <div class="ins-foot" id="iFoot"></div>
    </section></div>`;
  const page = el.firstElementChild;   // #main outlives this view, so listeners go on the page itself
  page.addEventListener('change', onChange);
  page.addEventListener('click', onClick);
  const ro = new ResizeObserver(() => { if (cube && $('#iBody', root) && S.mode !== 'table') draw(); });
  ro.observe($('#iBody', el));
  onLeave(() => ro.disconnect());
  select(arg);
  load();
  onView('tasks', load); onView('people', load);
  onView('config', () => cube && render());   // your name labels the flow
}
export function select(arg) { if (PRESETS[arg]) { S = { ...S, ...PRESETS[arg] }; save(); } if (cube) render(); }

const load = latest(() => GET('/api/tasks'), t => {
  if (!root?.querySelector('.page.ins')) return;   // left for another page while it loaded
  tasks = t.filter(x => x.status !== 'dismissed');
  render();
}, e => { const box = root?.querySelector('.page.ins #iBody'); if (box && !cube) box.innerHTML = errorBox(e); else if (box) toast(`Could not load the tasks: ${e.message}`, true); });

function onChange(e) {
  const k = e.target.dataset.k; if (!k) return;
  const v = k === 'tx' || k === 'ty' ? Number(e.target.value) : e.target.value;
  if (k === 'x' && v === S.y) S.y = S.x;
  if (k === 'y' && v === S.x) S.x = S.y;
  S[k] = v; save(); render();
}
function onClick(e) {
  const b = e.target.closest('[data-set]');
  if (b) { const [k, v] = b.dataset.set.split(':'); S[k] = v; save(); render(); return; }
  const p = e.target.closest('[data-preset]');
  if (p) { S = { ...S, ...PRESETS[p.dataset.preset] }; save(); render(); return; }
  if (e.target.closest('#iSwap')) { [S.x, S.y, S.tx, S.ty] = [S.y, S.x, S.ty, S.tx]; save(); render(); return; }
  const c = e.target.closest('[data-cell]');
  if (c && !e.target.closest('[data-person]')) showCell(c.dataset.cell);
}

// ---------- the cube: tasks per (x, series) ----------
function build() {
  const xd = DIMS[S.x], yd = DIMS[S.y];
  const rows = tasks.filter(t => S.scope === 'all' || (S.scope === 'open' ? t.status === 'open' : ['done', 'cancelled'].includes(t.status)));
  const cells = new Map(), xc = new Map(), yc = new Map();
  for (const t of rows) {
    const a = xd.val(t), b = yd.val(t);
    if (a == null || b == null) continue;
    xc.set(a, (xc.get(a) || 0) + 1); yc.set(b, (yc.get(b) || 0) + 1);
    const k = a + '\u0001' + b;
    if (!cells.has(k)) cells.set(k, []);
    cells.get(k).push(t);
  }
  const keys = (d, cnt, top) => {
    let ks = [...cnt.keys()];
    if (d.chrono && ks.length) {            // a time axis runs without gaps, and keeps the most recent
      ks.sort(); const all = []; for (let k = ks[0]; k <= ks[ks.length - 1] && all.length < 400; k = d.chrono(k)) all.push(k);
      return { keep: all.slice(-top), rest: all.slice(0, Math.max(0, all.length - top)) };
    }
    ks.sort((a, b) => cnt.get(b) - cnt.get(a) || String(d.name(a)).localeCompare(d.name(b)));
    const keep = ks.slice(0, top), rest = ks.slice(top);
    if (d.order) keep.sort((a, b) => d.order.indexOf(a) - d.order.indexOf(b));
    return { keep, rest };
  };
  const X = keys(xd, xc, S.tx), Y = keys(yd, yc, S.ty);
  const ys = Y.keep.slice(); if (Y.rest.some(k => yc.get(k))) ys.push('__other');
  const restY = new Set(Y.rest);
  const at = (x, y) => y === '__other' ? [...restY].flatMap(r => cells.get(x + '\u0001' + r) || []) : cells.get(x + '\u0001' + y) || [];
  const grid = X.keep.map(x => ys.map(y => at(x, y)));
  return { xd, yd, xs: X.keep, ys, grid, hiddenX: X.rest.filter(k => xc.get(k)).length, total: rows.length };
}
const yName = (c, y) => y === '__other' ? 'Everyone / everything else' : c.yd.name(y);
const yColor = (c, y, j) => y === '__other' ? '#ced4da' : c.yd.color ? c.yd.color(y) : PAL[j % PAL.length];

// ---------- render ----------
function render() {
  cube = build();
  const opt = (k, cur) => Object.entries(DIMS).map(([id, d]) => `<option value="${id}" ${id === cur ? 'selected' : ''}>${d.label}</option>`).join('');
  const top = (k, cur) => `<select data-k="${k}" class="ins-top" title="How many to show: the biggest first, the rest left out">${TOPN.map(n => `<option value="${n}" ${n === cur ? 'selected' : ''}>${n === 9999 ? 'All' : 'Top ' + n}</option>`).join('')}</select>`;
  $('#iPre', root).innerHTML = `<span class="ins-pl">Quick views</span>` + Object.entries(PRESETS).map(([k, p]) =>
    `<button data-preset="${k}" class="${p.x === S.x && p.y === S.y && p.mode === S.mode && p.scope === S.scope ? 'on' : ''}">${esc(p.label)}</button>`).join('');
  $('#iCtl', root).innerHTML = `
    <label class="ins-ax"><span>X</span><select data-k="x">${opt('x', S.x)}</select>${top('tx', S.tx)}</label>
    <button class="ins-swap" id="iSwap" title="Swap X and series">⇄</button>
    <label class="ins-ax"><span>Series</span><select data-k="y">${opt('y', S.y)}</select>${top('ty', S.ty)}</label>
    <div class="seg" title="Which tasks">${SCOPES.map(([v, l, tip]) => `<button data-set="scope:${v}" title="${tip}" class="${S.scope === v ? 'on' : ''}">${l}</button>`).join('')}</div>
    <span class="sp"></span>
    <div class="seg">${MODES.map(([v, l, ic, tip]) => `<button data-set="mode:${v}" title="${tip}" class="${S.mode === v ? 'on' : ''}">${icon(ic, 13)}${l}</button>`).join('')}</div>`;
  draw();
}

function draw() {
  const c = cube, body = $('#iBody', root), foot = $('#iFoot', root);
  if (!c.xs.length) { body.innerHTML = `<div class="empty">${icon('grid', 36)}<p>No tasks for this view.</p></div>`; foot.innerHTML = ''; return; }
  if (S.mode === 'flow') { flow(body, foot); return; }
  body.innerHTML = S.mode === 'table' ? table(c) : chart(c, Math.max(300, body.clientWidth - 28));
  const n = c.grid.flat().reduce((s, l) => s + l.length, 0);
  foot.innerHTML = `<div class="ins-legend">${S.mode === 'table' ? '' : c.ys.map((y, j) => `<span><i style="background:${yColor(c, y, j)}"></i>${esc(yName(c, y))}</span>`).join('')}</div>
    <span class="muted">${plural(n, 'task')} shown${c.hiddenX ? ` · ${c.hiddenX} more ${esc(c.xd.label.toLowerCase())} not shown (raise the Top)` : ''}</span>`;
}

/** The flow diagram: who asked on the left, who does it on the right, bands as wide as the number of tasks. */
function flow(body, foot) {
  const list = tasks.filter(t => S.scope === 'all' || (S.scope === 'open' ? t.status === 'open' : ['done', 'cancelled'].includes(t.status)));
  const max = Math.min(S.tx, 25), W = Math.max(320, body.clientWidth - 28);
  body.innerHTML = `<div class="ins-flow">${whoFlow(list, { meLabel: APP.config?.me?.name || 'Me', max, width: W, height: Math.max(380, (max + 1) * 38),
    status: S.scope === 'closed' ? 'all' : S.scope, labelW: Math.min(260, W * .22), chars: 34 })}</div>`;
  foot.innerHTML = `<div class="ins-legend">${Object.values(DIR).map(d => `<span><i style="background:${d.color}"></i>${esc(d.label)}</span>`).join('')}</div>
    <span class="muted">Always Asked by → Done by, top ${max} on each side · click a name for the profile, a band for its tasks</span>`;
}

/** The cross tab: X down the side, the series across the top, cells shaded by count, totals on both edges. */
function table(c) {
  const v = c.grid.map(r => r.map(l => l.length));
  const max = Math.max(1, ...v.flat());
  const colTot = c.ys.map((_, j) => v.reduce((s, r) => s + r[j], 0)), all = colTot.reduce((a, b) => a + b, 0);
  const short = (d, k) => { const n = d === c.yd && k === '__other' ? 'Others' : d.name(k); if (!d.person || n === 'Me') return n; const p = String(n).split(/\s+/); return p.length > 1 ? `${p[0]} ${p[p.length - 1][0]}.` : n; };
  const late = l => l.filter(t => t.overdue).length;
  const head = (d, k, j, long) => {
    const sw = `<i style="background:${d === c.yd ? yColor(c, k, j) : d.color ? d.color(k) : PAL[j % PAL.length]}"></i>`;
    const label = long ? esc(d.name(k)) : esc(short(d, k));
    return d.person && k !== '__other' && names.get(k) !== 'Me' ? `${sw}<a data-person="${esc(k)}" title="${esc(d.name(k))}: open the profile">${label}</a>` : `${sw}<span title="${esc(d === c.yd ? yName(c, k) : d.name(k))}">${label}</span>`;
  };
  return `<div class="xt-wrap"><table class="xt"><colgroup><col style="width:22%">${c.ys.map(() => '<col>').join('')}<col style="width:84px"></colgroup>
    <thead><tr><th class="xt-corner"><span>${esc(c.xd.label)}</span> <em>↓</em> &nbsp;<span>${esc(c.yd.label)}</span> <em>→</em></th>
      ${c.ys.map((y, j) => `<th class="xt-col">${head(c.yd, y, j)}</th>`).join('')}<th class="xt-tot">Total</th></tr></thead>
    <tbody>${c.xs.map((x, i) => { const rt = v[i].reduce((a, b) => a + b, 0), rl = late(c.grid[i].flat());
      return `<tr><th class="xt-row" data-sort="${esc(c.xd.name(x))}">${head(c.xd, x, i, true)}</th>${v[i].map((n, j) => { const h = n / max, l = late(c.grid[i][j]);
        return `<td class="xt-c ${n ? '' : 'z'}" data-sort="${n}" ${n ? `data-cell="${i}|${j}"` : ''} style="${n ? `background:rgba(59,91,219,${(0.08 + h * 0.82).toFixed(3)});color:${h > 0.5 ? '#fff' : 'var(--ink)'}` : ''}"
          title="${esc(c.xd.name(x))} · ${esc(yName(c, c.ys[j]))}: ${plural(n, 'task')}${l ? `, ${l} overdue` : ''}">${n || '·'}${l ? '<b class="xt-late"></b>' : ''}</td>`; }).join('')}
        <td class="xt-tot" data-sort="${rt}" data-cell="${i}|*">${rt}${rl ? ` <span class="xt-rl">${rl} late</span>` : ''}</td></tr>`; }).join('')}</tbody>
    <tfoot><tr><th class="xt-row">Total</th>${colTot.map((n, j) => `<td class="xt-tot" data-cell="*|${j}">${n}</td>`).join('')}<td class="xt-tot xt-all">${all}</td></tr></tfoot>
  </table></div>
  <div class="xt-key"><span>Fewer</span><i></i><span>More</span><span class="xt-k2"><b class="xt-late"></b> has overdue tasks</span></div>`;
}

/** Stacked bars, 100% bars, lines or areas, drawn at the real width so the text stays one size. */
function chart(c, W) {
  const H = 400, pl = 44, pr = 14, pt = 22, pb = 52, w = W - pl - pr, h = H - pt - pb, n = c.xs.length;
  const v = c.grid.map(r => r.map(l => l.length)), tot = v.map(r => r.reduce((a, b) => a + b, 0));
  const pct = S.mode === 'pct', line = S.mode === 'line', area = S.mode === 'area';
  const raw = Math.max(1, ...(line ? v.flat() : tot));
  const nice = x => { const p = 10 ** Math.floor(Math.log10(x)), f = x / p; return (f <= 1 ? 1 : f <= 2 ? 2 : f <= 4 ? 4 : f <= 5 ? 5 : 10) * p; };
  const top = pct ? 100 : Math.max(4, nice(raw)), Y = u => pt + h - u / top * h, slot = w / n, cx = i => pl + (i + .5) * slot;
  const bw = Math.max(6, Math.min(56, slot * .62));
  let s = `<svg class="ins-svg" width="${W}" height="${H}" viewBox="0 0 ${W} ${H}">`;
  const steps = top % 5 === 0 && top >= 5 ? 5 : 4;
  for (let g = 0; g <= steps; g++) { const u = top * g / steps, y = Y(u); s += `<line x1="${pl}" x2="${W - pr}" y1="${y}" y2="${y}" class="ig${g ? '' : ' base'}"/><text x="${pl - 8}" y="${y + 4}" text-anchor="end" class="ia">${pct ? Math.round(u) + '%' : Math.round(u * 10) / 10}</text>`; }
  const every = Math.max(1, Math.ceil(52 / slot)), chars = Math.max(4, Math.floor(slot * every / 7));
  c.xs.forEach((x, i) => {
    if (i % every) return;
    const full = c.xd.name(x), t = full.length > chars ? full.slice(0, chars - 1) + '…' : full;
    s += `<text x="${cx(i)}" y="${H - pb + 18}" text-anchor="middle" class="ix"><title>${esc(full)}</title>${esc(t)}</text>`;
  });
  const tip = (i, j, n) => `<title>${esc(c.xd.name(c.xs[i]))} · ${esc(yName(c, c.ys[j]))}: ${plural(n, 'task')}\nClick to see them</title>`;
  if (line) {
    c.ys.forEach((y, j) => {
      const col = yColor(c, y, j), pts = c.xs.map((_, i) => `${cx(i)},${Y(v[i][j])}`);
      s += `<polyline points="${pts.join(' ')}" fill="none" stroke="${col}" stroke-width="2.4" stroke-linejoin="round" stroke-linecap="round"/>`;
      c.xs.forEach((_, i) => { if (v[i][j]) s += `<circle cx="${cx(i)}" cy="${Y(v[i][j])}" r="4" fill="#fff" stroke="${col}" stroke-width="2" class="ip" data-cell="${i}|${j}">${tip(i, j, v[i][j])}</circle>`; });
    });
  } else if (area) {
    const cum = c.xs.map(() => 0);
    c.ys.forEach((y, j) => {
      const col = yColor(c, y, j), up = [], dn = [];
      c.xs.forEach((_, i) => { dn.push(`${cx(i)},${Y(cum[i])}`); cum[i] += v[i][j]; up.push(`${cx(i)},${Y(cum[i])}`); });
      s += `<polygon points="${up.concat(dn.reverse()).join(' ')}" fill="${col}" fill-opacity=".72" stroke="${col}" stroke-width="1"><title>${esc(yName(c, y))}</title></polygon>`;
    });
  } else {
    c.xs.forEach((_, i) => {
      let cum = 0;
      c.ys.forEach((y, j) => {
        const n = v[i][j]; if (!n) return;
        const d = pct ? n / tot[i] * 100 : n, y1 = Y(cum), y2 = Y(cum + d);
        s += `<rect x="${cx(i) - bw / 2}" y="${y2}" width="${bw}" height="${Math.max(1, y1 - y2 - 1)}" rx="2" fill="${yColor(c, y, j)}" class="ib" data-cell="${i}|${j}">${tip(i, j, n)}</rect>`;
        cum += d;
      });
      if (tot[i] && !pct) s += `<text x="${cx(i)}" y="${Y(cum) - 6}" text-anchor="middle" class="it">${tot[i]}</text>`;
    });
  }
  return s + '</svg>';
}

function showCell(ref) {
  const c = cube, [a, b] = ref.split('|');
  const rows = a === '*' ? c.xs.map((_, i) => i) : [Number(a)], cols = b === '*' ? c.ys.map((_, j) => j) : [Number(b)];
  const list = rows.flatMap(i => cols.flatMap(j => c.grid[i][j]));
  const title = [a !== '*' && c.xd.name(c.xs[a]), b !== '*' && yName(c, c.ys[b])].filter(Boolean).join(' · ');
  modal({ title: `${title}: ${plural(list.length, 'task')}`, size: 'wide',
    body: `<div class="ins-list">${list.sort((x, y) => (y.overdue - x.overdue) || String(x.deadline || '9').localeCompare(String(y.deadline || '9'))).map(t => taskCard(t, { compact: true })).join('')}</div>` });
}
