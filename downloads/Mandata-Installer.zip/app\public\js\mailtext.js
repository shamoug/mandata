// Readable email: Outlook's plain text turned into paragraphs, lists and links, with the quoted thread folded away.
import { esc } from './ui.js';

// Where an earlier message starts in a reply (the same markers the server uses to find the newest part).
const QUOTE = /\n(?=From: .+\n(?:Sent|Date): |-----Original Message-----|On .{5,80} wrote:|_{20,}\n)/;
const HEAD = /^(From|Sent|Date|To|Cc|Subject):\s*(.*)$/i;
const BULLET = /^\s*(?:[•·▪◦\-–*]|o(?=\s))\s+/;
const NUMBER = /^\s*\d{1,2}[.)]\s+/;

/** Outlook wraps links in Safe Links; show and open the real address. */
function realUrl(u) {
  try {
    const x = new URL(u);
    if (/safelinks\.protection\.outlook\.com$/i.test(x.hostname) && x.searchParams.get('url')) return x.searchParams.get('url');
  } catch {}
  return u;
}
/** Only web addresses become links: a "javascript:" or "data:" address hidden in a Safe Link stays plain text. */
const safe = u => /^https?:\/\//i.test(u);
const shortUrl = u => { try { const x = new URL(u); const p = (x.pathname + x.search).replace(/\/$/, ''); return x.hostname.replace(/^www\./, '') + (p.length > 32 ? p.slice(0, 30) + '…' : p); } catch { return u; } };
const link = u => { const r = realUrl(u); if (!safe(r)) return esc(u); return `<a href="${esc(r)}" target="_blank" rel="noopener noreferrer" title="${esc(r)}">${esc(shortUrl(r))}</a>`; };

// A web address in text already escaped: it ends before a quote or an angle bracket (&quot; &#39; &lt; &gt;, which would
// otherwise run into the link) and before trailing punctuation.
const URL_IN = /https?:\/\/(?:(?!&(?:quot|#39|lt|gt);)[^\s<>"'])*(?!&(?:quot|#39|lt|gt);)[^\s<>"'.,;:!?)\]]/g;

/** One message's text: links become short anchors, bullet and numbered lines become lists, the rest paragraphs. */
function textHtml(text) {
  const links = [];
  let t = String(text)
    .replace(/\[cid:[^\]]*\]/gi, '')
    .replace(/<mailto:[^>]*>/gi, '')
    // "https://site <https://safelink...>": the address is already in the text, the wrapped copy adds nothing.
    .replace(/(https?:\/\/[^\s<>]+)\s*<(https?:\/\/[^>\s]+)>/g, (m, a, b) => realUrl(b) === a || realUrl(b).startsWith(a) ? a : `${a} ${b}`)
    // "Click here<https://...>": keep the words, and put the link right after them.
    .replace(/<(https?:\/\/[^>\s]+)>/g, (m, u) => { links.push(u); return `\u0001${links.length - 1}\u0002`; });
  const inline = s => esc(s)
    .replace(URL_IN, u => link(u.replace(/&amp;/g, '&')))
    .replace(/\u0001(\d+)\u0002/g, (m, i) => ' ' + link(links[+i]));
  const paras = t.replace(/[ \t]+\n/g, '\n').split(/\n\s*\n+/).map(p => p.replace(/^\n+|\n+$/g, '')).filter(p => p.trim());
  return paras.map(p => {
    const lines = p.split('\n').filter(l => l.trim());
    const isList = re => lines.length > 0 && lines.every(l => re.test(l));
    if (isList(BULLET)) return `<ul>${lines.map(l => `<li>${inline(l.replace(BULLET, ''))}</li>`).join('')}</ul>`;
    if (isList(NUMBER)) return `<ol>${lines.map(l => `<li>${inline(l.replace(NUMBER, ''))}</li>`).join('')}</ol>`;
    // A lone numbered or bulleted line joins the list around it visually, without guessing more structure.
    if (lines.length === 1 && (BULLET.test(lines[0]) || NUMBER.test(lines[0])))
      return `<p class="li">${inline(lines[0].trim())}</p>`;
    return `<p>${lines.map(l => inline(l.trim())).join('<br>')}</p>`;
  }).join('');
}

/** Split off a quoted message's From / Sent / To / Subject lines into a small header. */
function quoted(part) {
  const lines = part.replace(/^_{20,}\n?/, '').replace(/^-----Original Message-----\n?/i, '').split('\n');
  const head = [];
  while (lines.length && (HEAD.test(lines[0]) || (!lines[0].trim() && !head.length))) { const l = lines.shift(); if (l.trim()) head.push(l.match(HEAD)); }
  const meta = head.filter(h => /^(from|sent|date|subject)$/i.test(h[1]))
    .map(h => `<span><b>${esc(h[1])}</b> ${esc(h[2].replace(/<mailto:[^>]*>/gi, '').replace(/\s*\[mailto:[^\]]*\]/gi, ''))}</span>`).join('');
  const wrote = !head.length && /^On .{5,80} wrote:/.test(lines[0] || '') ? `<span>${esc(lines.shift())}</span>` : '';
  return `<div class="q-msg">${meta || wrote ? `<div class="q-head">${meta}${wrote}</div>` : ''}${textHtml(lines.join('\n'))}</div>`;
}

/** The whole body: the newest message in full, earlier ones folded under "Earlier in this thread". */
export function mailHtml(body) {
  const b = String(body || '').replace(/\r/g, '').replace(/ /g, ' ').trim();
  if (!b) return '<p class="muted">This email has no text.</p>';
  const [newest, ...older] = b.split(QUOTE);
  return `<div class="mailtext">${textHtml(newest) || '<p class="muted">No new text in this message.</p>'}</div>` +
    (older.length ? `<details class="quoted"><summary>Earlier in this thread <span class="muted">${older.length} message${older.length > 1 ? 's' : ''}</span></summary>
      <div class="mailtext">${older.map(quoted).join('')}</div></details>` : '');
}
