// Every long drop-down in the app can be searched by typing. When a <select> holds more than LONG choices, clicking it
// (or typing, Enter, Space or Alt+Down while it has focus) opens a list with a search box instead of the native list.
// The <select> stays the source of truth: picking a choice sets its value and fires the usual input/change events, so
// views need no wiring and short drop-downs keep the native behaviour.
const LONG = 10;
let pop = null; // { el, sel, input, list, items, idx }

const fold = s => String(s || '').normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase();
const long = s => s instanceof HTMLSelectElement && !s.multiple && !s.disabled && s.options.length > LONG;

function choices(sel) {
  const out = [];
  for (const node of sel.children) {
    if (node instanceof HTMLOptGroupElement) {
      out.push({ group: node.label });
      for (const o of node.children) if (o instanceof HTMLOptionElement) out.push({ o, group: node.label });
    } else if (node instanceof HTMLOptionElement) out.push({ o: node });
  }
  return out;
}

function draw() {
  const { sel, input, list } = pop, words = fold(input.value).split(/\s+/).filter(Boolean);
  const all = choices(sel);
  const hit = c => c.o && !c.o.hidden && words.every(w => fold(c.o.textContent + ' ' + c.o.value + ' ' + (c.group || '')).includes(w));
  pop.items = [];
  list.innerHTML = '';
  let lastGroup;
  for (const c of all) {
    if (!hit(c)) continue;
    if (c.group && c.group !== lastGroup) { const h = document.createElement('div'); h.className = 'ss-group'; h.textContent = c.group; list.append(h); }
    lastGroup = c.group;
    const d = document.createElement('div');
    d.className = 'ss-opt' + (c.o.disabled ? ' off' : '') + (c.o.selected ? ' cur' : '');
    d.textContent = c.o.textContent;
    d.dataset.i = pop.items.push(c.o) - 1;
    list.append(d);
  }
  if (!pop.items.length) list.innerHTML = '<div class="ss-none">Nothing matches</div>';
  const cur = pop.items.findIndex(o => o.selected);
  move(words.length ? pop.items.findIndex(o => !o.disabled) : Math.max(cur, 0), true);
}

function move(i, center) {
  if (!pop.items.length) return (pop.idx = -1);
  pop.idx = Math.max(0, Math.min(pop.items.length - 1, i));
  pop.list.querySelectorAll('.ss-opt').forEach(d => d.classList.toggle('on', +d.dataset.i === pop.idx));
  pop.list.querySelector('.ss-opt.on')?.scrollIntoView({ block: center ? 'center' : 'nearest' });
}

function place() {
  const r = pop.sel.getBoundingClientRect(), w = Math.max(r.width, 240), maxH = 340;
  const below = innerHeight - r.bottom - 8, up = below < 200 && r.top > below;
  Object.assign(pop.el.style, {
    left: Math.max(8, Math.min(r.left, innerWidth - w - 8)) + 'px', width: w + 'px',
    top: up ? '' : r.bottom + 4 + 'px', bottom: up ? innerHeight - r.top + 4 + 'px' : '',
  });
  pop.list.style.maxHeight = Math.min(maxH, (up ? r.top : below) - 60) + 'px';
}

function pick(o) {
  const sel = pop.sel;
  close();
  if (!o || o.disabled) return;
  if (sel.value !== o.value || sel.selectedIndex !== o.index) {
    sel.selectedIndex = o.index;
    sel.dispatchEvent(new Event('input', { bubbles: true }));
    sel.dispatchEvent(new Event('change', { bubbles: true }));
  }
}

function close(refocus = true) {
  if (!pop) return;
  const { el, sel } = pop;
  pop = null;
  el.remove();
  if (refocus && sel.isConnected) sel.focus({ preventScroll: true });
}

function open(sel, typed = '') {
  close(false);
  const el = document.createElement('div');
  el.className = 'ss-pop';
  el.innerHTML = '<input type="search" class="ss-q" placeholder="Type to search…" autocomplete="off" spellcheck="false"><div class="ss-list" role="listbox"></div>';
  document.body.append(el);
  pop = { el, sel, input: el.querySelector('.ss-q'), list: el.querySelector('.ss-list'), items: [], idx: -1 };
  pop.input.value = typed;
  place(); draw();
  pop.input.focus();
  pop.input.oninput = draw;
  pop.input.onkeydown = e => {
    if (e.key === 'ArrowDown') { e.preventDefault(); move(pop.idx + 1); }
    else if (e.key === 'ArrowUp') { e.preventDefault(); move(pop.idx - 1); }
    else if (e.key === 'PageDown') { e.preventDefault(); move(pop.idx + 8); }
    else if (e.key === 'PageUp') { e.preventDefault(); move(pop.idx - 8); }
    else if (e.key === 'Enter') { e.preventDefault(); pick(pop.items[pop.idx]); }
    else if (e.key === 'Escape') { e.preventDefault(); e.stopPropagation(); close(); }
    else if (e.key === 'Tab') close();
  };
  pop.list.onmousedown = e => e.preventDefault(); // keep focus in the search box
  pop.list.onclick = e => { const d = e.target.closest('.ss-opt'); if (d && !d.classList.contains('off')) pick(pop.items[+d.dataset.i]); };
  pop.list.onmousemove = e => { const d = e.target.closest('.ss-opt'); if (d && +d.dataset.i !== pop.idx) move(+d.dataset.i); };
}

export function initSelectSearch() {
  document.addEventListener('mousedown', e => {
    if (pop && !pop.el.contains(e.target)) { const same = e.target === pop.sel; close(false); if (same) return e.preventDefault(); }
    const sel = e.target.closest?.('select');
    if (e.button === 0 && long(sel)) { e.preventDefault(); open(sel); }
  }, true);
  document.addEventListener('keydown', e => {
    const sel = e.target;
    if (pop || !long(sel) || e.ctrlKey || e.metaKey) return;
    const printable = e.key.length === 1 && e.key !== ' ' && !e.altKey;
    if (printable || e.key === 'Enter' || e.key === ' ' || e.key === 'F4' || (e.altKey && e.key === 'ArrowDown')) {
      e.preventDefault(); e.stopPropagation(); open(sel, printable ? e.key : '');
    }
  }, true);
  addEventListener('resize', () => close(false));
  document.addEventListener('scroll', e => { if (pop && !pop.el.contains(e.target)) close(false); }, true);
}
