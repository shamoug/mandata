// Overview: where everything stands, at a glance. One header, one row of figures, then a 12-column grid of cards
// whose heights pair up, so the page reads as one tidy board with no dead space.
import { GET, esc, icon, avatar, DIR, dueBadge, firstName, pref, setPref, LOCALE, plural, latest, errorBox, toast } from '../ui.js';
import { S, onView, onLeave, isMe } from '../store.js';
import { weekTrend, donut } from '../viz.js';

let root, all = [], span = pref('ovWeeks', 12), data = null;
export function mount(el) {
  root = el; data = null;
  el.innerHTML = '<div class="page ov" id="ov"></div>';
  const page = el.firstElementChild;   // #main outlives this view, so listeners go on the page itself
  page.addEventListener('click', e => { const b = e.target.closest('[data-weeks]'); if (b) { span = Number(b.dataset.weeks); setPref('ovWeeks', span); drawTrend(); } });
  const ro = new ResizeObserver(() => drawTrend());
  ro.observe(page);
  onLeave(() => ro.disconnect());
  load();
  for (const t of ['tasks', 'people']) onView(t, load);
  // A task opened is seen: counted off here, without loading everything again.
  onView('seen', id => { const t = data?.[1].find(x => x.id === id); if (!t || t.seen) return; t.seen = 1; if (t.status === 'open') data[0].counts.unseen = Math.max(0, data[0].counts.unseen - 1); render(data); });
  onView('config', () => data && render(data));
}

const hello = () => { const h = new Date().getHours(); return h < 12 ? 'Good morning' : h < 18 ? 'Good afternoon' : 'Good evening'; };
const q = s => '#/tasks/' + s;

/** A card: title (opens the full list), a quiet subtitle, an optional count and a "View all" link. */
const card = (cls, { title, ic, go, sub = '', count = null, tone = '', more = 'View all', extra = '' }, body) => `<section class="ov-card ${cls}">
  <header class="ov-h"><h3 class="${tone}" data-go="${go}">${icon(ic, 14)}${title}</h3>${count != null ? `<span class="ov-count ${tone}">${count}</span>` : ''}
    ${sub ? `<span class="ov-sub">${sub}</span>` : ''}<span class="sp"></span>${extra}<a class="ov-more" data-go="${go}">${more}${icon('arrow', 12)}</a></header>
  ${body}</section>`;

/** One line per task: kind colour, title, who asked whom, deadline. */
const name = (n, e) => isMe(e) ? 'Me' : firstName(n) || e || '?';
const pname = (n, e) => e && !isMe(e) ? `<a data-person="${esc(e)}" title="${esc(n || e)}">${esc(name(n, e))}</a>` : `<span>${esc(name(n, e))}</span>`;
const row = t => `<div class="ov-row" data-task="${t.id}" style="--c:${(DIR[t.direction] || DIR.others).color}" title="${esc(t.title)}">
  <i class="ov-dot" title="${esc((DIR[t.direction] || DIR.others).label)}"></i>
  <div class="ov-row-main"><b>${esc(t.title)}</b><span>${pname(t.requester_name, t.requester_email)}${icon('arrow', 10)}${pname(t.owner_name, t.owner_email)}</span></div>
  <div class="ov-row-due">${dueBadge(t)}</div></div>`;
const list = (items, empty) => `<div class="ov-list">${items.map(row).join('') || `<div class="ov-empty">${icon('check', 16)}<span>${empty}</span></div>`}</div>`;

/** Who is waiting on whom: people who asked me, people I asked, and pairs of others, each ranked by open tasks. */
const hash = o => q('?' + new URLSearchParams({ status: 'open', ...o }));
function waiting(open) {
  const key = (t, side) => t[side + '_email'] || t[side + '_name'] || '?';
  const group = (list, kf) => {
    const m = new Map();
    for (const t of list) { const k = kf(t); const g = m.get(k) || { k, t, n: 0, late: 0 }; g.n++; g.late += t.overdue ? 1 : 0; m.set(k, g); }
    return [...m.values()].sort((a, b) => b.n - a.n || b.late - a.late);
  };
  const who = (t, side) => `${avatar(t[side + '_name'], t[side + '_email'], 'sm')}<a data-person="${esc(t[side + '_email'] || '')}" title="${esc(t[side + '_name'] || t[side + '_email'])}">${esc(t[side + '_name'] || t[side + '_email'] || '?')}</a>`;
  const pair = t => `<span class="ww-pair"><a data-person="${esc(t.requester_email || '')}" title="${esc(t.requester_name)}">${esc(firstName(t.requester_name) || '?')}</a>${icon('arrow', 10)}<a data-person="${esc(t.owner_email || '')}" title="${esc(t.owner_name)}">${esc(firstName(t.owner_name) || '?')}</a></span>`;
  const cols = [
    { title: 'Waiting on me', d: DIR.to_me, dir: 'to_me', list: open.filter(t => t.direction === 'to_me'),
      kf: t => key(t, 'requester'), label: g => who(g.t, 'requester'), go: g => hash({ from: g.k }) },
    { title: 'I am waiting on', d: DIR.by_me, dir: 'by_me', list: open.filter(t => t.direction === 'by_me'),
      kf: t => key(t, 'owner'), label: g => who(g.t, 'owner'), go: g => hash({ to: g.k }) },
    { title: 'Between others', d: DIR.others, dir: 'others', list: open.filter(t => t.direction === 'others'),
      kf: t => key(t, 'requester') + '\u0001' + key(t, 'owner'), label: g => pair(g.t),
      go: g => hash({ from: key(g.t, 'requester'), to: key(g.t, 'owner') }) },
  ];
  const MAX = 6;
  return `<div class="ww">${cols.map(col => {
    const gs = group(col.list, col.kf), mx = Math.max(1, ...gs.map(g => g.n)), late = col.list.filter(t => t.overdue).length;
    return `<div class="ww-col" style="--c:${col.d.color}">
      <div class="ww-h" data-go="${q('?status=open&dir=' + col.dir)}"><i></i><b>${col.title}</b><span class="ww-n num">${col.list.length}</span>${late ? `<span class="ww-late">${late} late</span>` : ''}</div>
      <div class="ww-list">${gs.slice(0, MAX).map(g => `<div class="ww-row" data-go="${esc(col.go(g))}" title="${plural(g.n, 'open task')}${g.late ? `, ${g.late} overdue` : ''}">
        <span class="ww-who">${col.label(g)}</span><span class="ww-bar"><i style="width:${g.n / mx * 100}%"></i></span><b class="num">${g.n}</b>${g.late ? `<span class="ww-dot" title="${g.late} overdue">${g.late}</span>` : '<span class="ww-dot z"></span>'}</div>`).join('')
        || '<div class="ww-empty">Nobody</div>'}</div>
      ${gs.length > MAX ? `<a class="ww-more" data-go="${q('?status=open&dir=' + col.dir)}">+${gs.length - MAX} more</a>` : ''}</div>`; }).join('')}</div>`;
}

/** Weeks counted here from all tasks, so the span can change without a trip to the server. */
function drawTrend() {
  const box = root?.querySelector('#ovTrend'); if (!box || !box.clientWidth) return;
  const now = Date.now(), W = 7 * 864e5, weeks = [];
  for (let i = span - 1; i >= 0; i--) {
    const a = new Date(now - (i + 1) * W).toISOString(), b = new Date(now - i * W).toISOString();
    weeks.push({ from: a.slice(0, 10), opened: all.filter(t => t.opened_at >= a && t.opened_at < b).length,
      closed: all.filter(t => ['done', 'cancelled'].includes(t.status) && t.closed_at && t.closed_at >= a && t.closed_at < b).length,
      backlog: all.filter(t => t.opened_at && t.opened_at < b && (t.status === 'open' || (t.closed_at && t.closed_at >= b))).length });
  }
  const o = weeks.reduce((s, w) => s + w.opened, 0), c = weeks.reduce((s, w) => s + w.closed, 0);
  root.querySelector('#ovTrendStats').innerHTML = `
    <div><span>Opened</span><b class="num" style="color:#3b5bdb">${o}</b></div><div><span>Closed</span><b class="num" style="color:#2f8a4f">${c}</b></div>
    <div><span>Net change</span><b class="num ${o - c > 0 ? 'red' : ''}">${o - c > 0 ? '+' : ''}${o - c}</b></div><div><span>Close rate</span><b class="num">${o ? Math.round(c / o * 100) : 0}%</b></div>
    <div><span>Open now</span><b class="num">${weeks.at(-1)?.backlog ?? 0}</b></div>`;
  root.querySelectorAll('[data-weeks]').forEach(b => b.classList.toggle('on', Number(b.dataset.weeks) === span));
  box.innerHTML = weekTrend(weeks, { width: box.clientWidth, height: 240 });
}

const load = latest(() => Promise.all([GET('/api/overview'), GET('/api/tasks')]), render,
  e => { const box = root?.querySelector('#ov'); if (!box) return; if (!data) box.innerHTML = errorBox(e); else toast(`Could not load the overview: ${e.message}`, true); });
function render(d) {
  if (!root?.querySelector('#ov')) return;   // left for another page while it loaded
  data = d;
  const [o, tasks] = d;
  all =tasks.filter(t => t.status !== 'dismissed');
  const open = tasks.filter(t => t.status === 'open');
  const c = o.counts;
  const me = firstName(S.config?.me?.name) || '';
  const later = Math.max(0, c.open - c.overdue - c.dueSoon);
  const soonDays = S.config?.tasks?.dueSoonDays ?? 3;
  const high = open.filter(t => t.priority === 'high').length, week = open.filter(t => t.days_left != null && t.days_left <= 7).length;
  const mx = Math.max(1, ...o.people.map(x => x.owns_open + x.gives_open));   // the longest load bar, once for the whole table
  const age = open.length ? Math.round(open.reduce((s, t) => s + (Date.now() - (Date.parse(t.opened_at) || Date.now())) / 864e5, 0) / open.length) : 0;

  const kpi = (n, label, sub, color, ic, go) => `<button class="ov-kpi" style="--k:${color}" data-go="${go}">
    <span class="ov-kpi-ic">${icon(ic, 16)}</span><span class="ov-kpi-t"><b class="num">${n}</b><span>${label}</span><small>${sub}</small></span></button>`;

  const health = c.open ? `<div class="ov-health"><h4>Deadlines of open tasks</h4>
      <div class="ov-hbar">${[[c.overdue, '#c92a2a', 'late', 'Overdue'], [c.dueSoon, '#c8822f', 'soon', 'Due soon'], [later, '#3b5bdb', 'week', 'Later']]
        .filter(x => x[0]).map(([n, col, f, l]) => `<i style="flex:${n};background:${col}" data-go="${f === 'week' ? q('?status=open') : q('?due=' + f)}" title="${l}: ${n}"></i>`).join('')}</div>
      <div class="ov-hleg">
        <span data-go="${q('?due=late')}"><i style="background:#c92a2a"></i>Overdue <b class="num">${c.overdue}</b></span>
        <span data-go="${q('?due=soon')}"><i style="background:#c8822f"></i>Due in ${soonDays} days <b class="num">${c.dueSoon}</b></span>
        <span data-go="${q('?status=open')}"><i style="background:#3b5bdb"></i>Later <b class="num">${later}</b></span></div></div>` : '';

  root.querySelector('#ov').innerHTML = `
  <header class="ov-head">
    <div><h1>${hello()}${me ? ', ' + esc(me) : ''}</h1>
      <p>${c.open ? `<a data-go="${q('?status=open')}">${plural(c.open, 'open task')}</a> found in your email · ${c.overdue ? `<a class="red" data-go="${q('?due=late')}">${c.overdue} overdue</a>` : 'none overdue'} · ${c.dueSoon} due in the next ${soonDays} days`
        : 'No open tasks yet. They appear here as the AI reads your email threads.'}</p></div>
    <div class="ov-date">${icon('clock', 14)}${new Date().toLocaleDateString(LOCALE, { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' })}</div>
  </header>

  <div class="ov-kpis">
    ${kpi(all.length, 'Total', 'tasks found so far', '#1c7ed6', 'layers', q('?status=open,parked,closed'))}
    ${kpi(c.open, 'Open', 'still running', '#3b5bdb', 'tasks', q('?status=open'))}
    ${kpi(c.overdue, 'Overdue', 'past the deadline', '#c92a2a', 'alert', q('?due=late'))}
    ${kpi(c.dueSoon, 'Due soon', `within ${soonDays} days`, '#c8822f', 'clock', q('?due=soon'))}
    ${kpi(c.unseen, 'New', 'not opened yet', '#1098ad', 'spark', q('?due=new'))}
    ${kpi(c.closed30, 'Closed', 'last 30 days', '#2f8a4f', 'check', q('?status=closed'))}
    ${kpi(c.people, 'People', `in ${c.threads} threads`, '#1098ad', 'people', '#/people')}
  </div>

  <div class="ov-grid">
    ${card('c8', { title: 'Who is waiting on whom', ic: 'people', go: '#/insights/who', sub: 'open tasks, by person', more: 'Cross tab',
      extra: `<a class="ov-more" data-go="#/insights/flow">Flow diagram${icon('arrow', 12)}</a>` }, waiting(open))}

    ${card('c4', { title: 'Open by kind', ic: 'grid', go: q('?status=open'), sub: 'and deadline health' },
      `<div class="ov-kind">${donut(Object.entries(DIR).map(([k, d]) => ({ n: o.openByDirection[k] || 0, color: d.color, label: d.label })), { size: 118 })}
        <ul>${Object.entries(DIR).map(([k, d]) => `<li data-go="${q('?dir=' + k)}"><i style="background:${d.color}"></i><span>${esc(d.label)}</span><b class="num">${o.openByDirection[k] || 0}</b><small class="num">/ ${o.allByDirection[k] || 0}</small></li>`).join('')}</ul></div>
      <div class="ov-mini ov-mini-kind">
        <div data-go="${q('?status=open&pri=high')}"><b class="num" style="color:#c92a2a">${high}</b><span>High priority</span></div>
        <div data-go="${q('?due=week')}"><b class="num">${week}</b><span>Due in 7 days</span></div>
        <div title="Average days since the open tasks were asked"><b class="num">${age}<small>d</small></b><span>Average age</span></div></div>
      <div class="ov-divider"></div>${health}`)}

    ${card('c4', { title: 'Overdue', ic: 'alert', go: q('?due=late'), count: c.overdue, tone: 'red' }, list(o.overdue, 'Nothing overdue.'))}
    ${card('c4', { title: 'Coming up', ic: 'clock', go: q('?due=week'), count: o.upcoming.length }, list(o.upcoming, 'Nothing coming up.'))}
    ${card('c4', { title: 'Recently closed', ic: 'check', go: q('?status=closed'), count: c.closed30, tone: 'green' }, list(o.recentClosed, 'Nothing closed yet.'))}

    ${card('c12', { title: 'Opened and closed', ic: 'pulse', go: '#/insights/pace', sub: 'per week · dashed line: still open at the end of each week', more: 'Explore',
      extra: `<div class="seg sm">${[8, 12, 26].map(n => `<button data-weeks="${n}">${n} weeks</button>`).join('')}</div>` },
      `<div class="ov-trend"><div class="ov-tstats" id="ovTrendStats"></div><div class="ov-tchart" id="ovTrend"></div></div>
      <div class="ov-legend"><span><i style="background:#3b5bdb"></i>Opened</span><span><i style="background:#40a065"></i>Closed</span><span><i class="dash"></i>Still open</span></div>`)}

    ${card('c12', { title: 'People with the most open work', ic: 'people', go: '#/people', count: c.people },
      `<div class="ov-tblwrap"><table class="ov-tbl"><colgroup><col style="width:26%"><col style="width:28%"><col style="width:11%"><col style="width:11%"><col style="width:8%"><col></colgroup><thead><tr><th>Person</th><th>Organisation</th><th class="r">Asked of them</th><th class="r">They asked</th><th class="r">Late</th><th>Load</th></tr></thead><tbody>
      ${o.people.map(p => `<tr data-person="${esc(p.email)}"><td><span class="pcell">${avatar(p.name, p.email, 'sm')}<b>${esc(p.name)}</b></span></td>
        <td><span class="ov-unit plain" title="${esc(p.organization || p.title || '')}">${esc(p.organization || p.title || '—')}</span></td>
        <td class="r num">${p.owns_open}</td><td class="r num">${p.gives_open}</td><td class="r num">${p.late ? `<span class="ov-late">${p.late}</span>` : '<span class="subtle">0</span>'}</td>
        <td data-sort="${p.owns_open + p.gives_open}"><div class="ov-load" title="${p.owns_open} asked of them · ${p.gives_open} they asked"><i style="width:${p.owns_open / mx * 100}%;background:${DIR.to_me.color}"></i><i style="width:${p.gives_open / mx * 100}%;background:${DIR.by_me.color}"></i></div></td></tr>`).join('') ||
        '<tr><td colspan="6" class="muted">Profiles appear as threads are read.</td></tr>'}</tbody></table></div>`)}
  </div>`;
  drawTrend();
}
