// Mandata server. Native Node (http, sqlite), no npm dependencies. Local only: binds 127.0.0.1 (phone access, off
// unless switched on in Settings > Phone, is a second server for paired phones: lib/phone.js).
// It finds tasks in email threads; nobody creates tasks by hand. It never sends email to anyone on its own: follow-ups
// are drafts, and sending is a separate action you confirm. The one exception is the daily deadlines email, from you to
// you, when you switch it on in Settings > Tasks. Runs inside the desktop app, or alone with `node server.js`.
import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { db, q, tx, localDate, now, lc, isEmail, getState, setState, logActivity, onActivity, DATA_DIR, SCHEMA } from './lib/db.js';
import { APP, REFERENCE, byCode } from './lib/defaults.js';
import { Emails, Tasks, People, Drafts, snapshot, restore as restoreSnapshot } from './lib/repo.js';
import { config, updateConfig, reloadConfig, resetSection, DEFAULT_CONFIG, myEmails, frameStart, TIME_FRAMES } from './lib/config.js';
import { outlook } from './lib/outlook.js';
import { dailyMailDue, sendDailyMail, isDailyMail } from './lib/dailymail.js';
import { auditDue, auditThread, fixQuotedDeadlines, skipAudit } from './lib/audit.js';
import { staleBios, noteRound, endRound, round } from './lib/revise.js';
import { aiState, checkAI, ensureModel, noDash, setModelLoaded, yieldPeople, listModels, deleteModel, testModel, cancelPull, noteThreadTime, stopAll, stopBackground, foreground, focused, onFocus } from './lib/ai.js';
import { ask, listConversations, getConversation, updateConversation, deleteConversation, starters } from './lib/ask.js';
import { listBackups, makeBackup, wipe, restore, deleteBackup, currentCounts, exportNow, exportBackup, importBackup, importTemp, dropTemp } from './lib/backup.js';
import { pipeline } from 'node:stream/promises';
import { BY_HAND } from './lib/backupfile.js';
import { isAutomated, ensureThread, touchThread, threadsDue, threadsQueued, threadsStuck, tries, rereadThreads, analyseThread, threadMessages, taskOut, tasksOut, addEvent,
  directionOf, personNamed, REVIEW, secondaryOf, repairTaskPeople, repairShared, repairUnsureShared, repairAutoReplies, repairMissedTasks, clearAssumedDeadlines, rereadLongThreads, flagNoTaskThreads, mergeSameAsks, cannotAck } from './lib/threads.js';
import { notePeople, bumpPerson, biosDue, writeBio, peopleList, profile } from './lib/people.js';
import { noteSignature, signaturesDue, readSignature, backfillSignatures } from './lib/signature.js';
import { noteNames, backfillNames, setOtherNames } from './lib/names.js';
import { draftFollowUp, toHtml, draftForward, redraftForward, forwardSent, noteSentForward, assignTask } from './lib/followup.js';
import { deleteTasks, restoreTasks, purgeTasks, purgeExpired, binTasks, binCount, binDays } from './lib/bin.js';
import { unparkDue, parkPeriod } from './lib/park.js';
import { noteCorrection, notePersonCorrection, lastCorrectionId, forgetCorrections, forgetPersonCorrections, correctionsDue, learnFrom, listLessons, updateLesson,
  deleteLesson, addLesson, updateCorrection, dropCorrection } from './lib/lessons.js';
import { listWeeks, hasReport, writeReport, reportForDoc, isWeekKey } from './lib/reports.js';
import { reportHtml } from './lib/reportdoc.js';
import { conversationHtml } from './lib/askdoc.js';
import { pdfFromUrl, savePdf, openFile } from './lib/pdf.js';
import { isDay, daysBetween, fmtDay } from './lib/fmt.js';
import * as updater from './lib/updater.js';
import { startPhone, stopPhone, phoneInfo, setPhone, newCode, forget as forgetPhone, phoneNotice } from './lib/phone.js';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const pkg = JSON.parse(fs.readFileSync(path.join(HERE, 'package.json'), 'utf8'));
const PUBLIC = path.join(HERE, 'public');
let PORT = Number(process.env.PORT || APP.port);
const today = localDate;
const I = APP.intervals, F = APP.fieldMax;
const CLOSE = byCode('close_reasons'), AXES = byCode('radar_axes');

// ---------- live events (SSE) ----------
const clients = new Set();
const broadcast = obj => { const msg = `data: ${JSON.stringify(obj)}\n\n`; for (const c of clients) c.write(msg); };
// A burst of status changes (each phase of a mail check, each thread read) goes out once.
let statusTimer = null;
const emit = (...types) => { for (const type of types) {
  if (type === 'status') statusTimer ||= setTimeout(() => { statusTimer = null; broadcast({ type }); }, 150);
  else broadcast({ type });
} };
// Every entry in the activity log refreshes the Activity page, a burst of them once.
let activityTimer = null;
onActivity(() => { activityTimer ||= setTimeout(() => { activityTimer = null; emit('activity'); }, 400); });
/** A desktop notification, shown by the desktop app (the page ignores it), and on paired Android phones (lib/phone.js). */
const notify = (title, body, route = '') => {
  if (!config().tasks.notify) return;
  broadcast({ type: 'notify', title, body, route });
  try { phoneNotice(title, body, route); } catch (e) { console.error('Phone notice not kept:', e.message); }
};
outlook.on('state', () => emit('status'));
// Microsoft 365 reads its sign-in app from Settings > Mail; signing in starts a mail check at once.
outlook.configure(() => config().sync);
outlook.on('signedin', () => { logActivity('sync', `Signed in to Microsoft 365 as ${outlook.state.defaultStore || outlook.state.user}`); runSync('signed in').finally(schedule); });
const mailName = () => outlook.kind === 'outlook' ? 'Outlook' : 'Microsoft 365';

// ---------- sync ----------
const sync = { running: false, lastOk: null, next: null, error: '', fetched: 0, phase: '', aiPhase: '', aiRef: '' };   // aiRef: the thread being read
let busyAI = false;
// While the data is wiped or restored, no mail is read and the AI does nothing (holding). Once the server stops, nothing starts.
let holding = false, stopping = false;

/** Store fetched mail; each new email marks its thread for reading. Returns how many were new. People are noted later,
 *  and only from threads that hold a task (notePeopleOf). */
function ingest(batch) {
  const mine = myEmails();
  const convs = new Set(), sent = [];
  let fresh = 0;
  tx(() => {
    for (const m of batch.sort((a, b) => a.receivedAt.localeCompare(b.receivedAt))) {
      if (!m.conversationId || !m.id) continue;
      const e = { id: m.id, folder: m.folder, conversation_id: m.conversationId, subject: m.subject || '(no subject)', from_name: m.fromName || '',
        from_email: lc(m.fromEmail), to: m.to || [], cc: m.cc || [], received_at: m.receivedAt, body: m.body || '',
        importance: m.importance ?? 1, sensitivity: m.sensitivity ?? 0, attachments: m.attachments || [] };
      e.mine = mine.has(e.from_email) ? 1 : 0;
      e.automated = !e.mine && isAutomated(e) || isDailyMail(e) ? 1 : 0;   // the daily deadlines email is never read for tasks
      ensureThread(e.conversation_id, e.subject);
      if (!Emails.insert(e)) continue;
      fresh++;
      // The other names people go by ("Dear Alaa" to Aladdin), from every email, task or not.
      try { noteNames(e); } catch (err) { logActivity('error', 'Could not read the names on an email: ' + err.message); }
      convs.add(e.conversation_id);
      if (e.mine) sent.push(e);
    }
    for (const c of convs) touchThread(c);
  });
  // A forward drafted here and now seen in Sent Items: its task takes that email (or is made, when sent from Outlook).
  let forwards = 0;
  for (const e of sent) try { if (noteSentForward(e)) forwards++; } catch (err) { logActivity('error', 'Could not link a forwarded task to its email: ' + err.message); }
  if (forwards) emit('tasks', 'drafts', 'status');
  if (convs.size) yieldPeople();   // new mail pauses people updates; they resume once it is read
  return fresh;
}

/** After a thread is read: when it holds a task, everyone on its emails gets a profile and their signatures are kept
 *  (which is where job titles and organisations come from). Mail with no task adds no people. Each email once. */
function notePeopleOf(convId) {
  if (!q(`SELECT 1 FROM tasks WHERE conversation_id=? AND status<>'dismissed' AND deleted_at IS NULL LIMIT 1`).get(convId)) return;
  const rows = Emails.hydrate(q('SELECT * FROM emails WHERE conversation_id=? AND people_noted=0 ORDER BY received_at').all(convId));
  // The emails that opened or closed a task bring everyone on them; the thread's other emails only their writer.
  const taskMail = new Set(q(`SELECT opened_email_id a, closed_email_id b FROM tasks WHERE conversation_id=? AND status<>'dismissed' AND deleted_at IS NULL`).all(convId).flatMap(r => [r.a, r.b]).filter(Boolean));
  // Marked in the same transaction, or on its own when reading them failed: each email once, either way.
  const noted = e => q('UPDATE emails SET people_noted=1 WHERE id=?').run(e.id);
  for (const e of rows) {
    try { tx(() => { notePeople(e, { senderOnly: !taskMail.has(e.id) }); noteSignature(e); noted(e); }); }
    catch (err) { logActivity('error', 'Could not read the people on an email: ' + err.message); noted(e); }
  }
  if (rows.length) emit('people');
}

async function connect() {
  sync.phase = `Connecting to ${mailName()}`; emit('status');
  const d = await outlook.ping();
  const c = config();
  // Your own mailbox only, and only the first time: a shared or delegate mailbox open in Outlook is not you, and the
  // addresses you set in Settings stand (an address removed there is not added back on the next connection).
  const own = [d.defaultStore].filter(s => String(s || '').includes('@')).map(lc);
  // Exchange gives "Surname, Given": turned into "Given Surname".
  const user = String(d.user || '').replace(/^\s*([^,]+),\s*(.+?)\s*$/, '$2 $1');
  updateConfig({ me: { name: c.me.name || user, emails: c.me.emails?.length ? c.me.emails : own },
    ...(c.sync.account ? {} : { sync: { account: String(d.defaultStore || '') } }) });
}

// While the AI works for you (focused), mail checks wait too: the check put off runs as soon as it is done.
let syncAfterFocus = '';
async function runSync(reason) {
  // Microsoft 365 before its first sign-in: nothing to read, and nothing failed. The status bar asks you to sign in.
  // Asked first: the checks below and marking the check as running happen with no wait between them, so two checks
  // started together can never both run.
  if (await outlook.needsSignIn()) { sync.error = ''; emit('status'); return; }
  if (holding || stopping) return;
  if (focused()) { syncAfterFocus ||= reason; return; }
  if (sync.running) return;
  sync.running = true; emit('status');
  if (reason === 'manual check') logActivity('sync', 'Mail check started by you');
  let fresh = 0;
  try {
    if (!outlook.state.connected) await connect();
    const c = config().sync;
    const started = now();
    if (!getState('baselineAt')) setState('baselineAt', started);
    const cursor = getState('sync.cursor'), start = frameStart();
    const step = c.windowDays * 864e5;
    // A window holding more mail than one call brings is split in two, and so on: no mail is left out of a busy week.
    const fetchFolder = async (folder, s, e) => {
      const got = await outlook.fetch(folder, new Date(s).toISOString(), c.account, { until: new Date(e).toISOString() });
      if (!got.full || e - s <= 3600e3) return got;
      const mid = s + Math.floor((e - s) / 2);
      return [...await fetchFolder(folder, s, mid), ...await fetchFolder(folder, mid, e)];
    };
    const fetchWindow = async (s, e) => ingest([...await fetchFolder('inbox', s, e), ...await fetchFolder('sent', s, e)]);
    // The time frame was widened: read the older mail, newest first, saving how far back has been read after each window.
    if (cursor) {
      let oldest = Date.parse(getState('sync.oldest') || q(`SELECT MIN(received_at) m FROM emails WHERE folder IN ('inbox','sent')`).get().m || cursor);
      for (; oldest > start + 864e5; oldest -= step) {
        if (focused()) { syncAfterFocus ||= reason; break; }
        const s = Math.max(start, oldest - step);
        sync.phase = `Reading older mail from ${new Date(s).toISOString().slice(0, 10)}`; emit('status');
        fresh += await fetchWindow(s, oldest);
        setState('sync.oldest', new Date(s).toISOString());
      }
    } else setState('sync.oldest', new Date(start).toISOString());
    const from = cursor ? Date.parse(cursor) - c.overlapMinutes * 60000 : start;
    // Oldest first, window by window, saving progress after each one: a dropped connection resumes where it stopped.
    const stop = Date.parse(started) + 60000;
    for (let s = from; s < stop; s += step) {
      if (focused()) { syncAfterFocus ||= reason; break; }   // where it got to is saved: it carries on after
      const e = Math.min(s + step, stop);
      sync.phase = e - s < step ? 'Checking mail' : `Reading mail from ${new Date(s).toISOString().slice(0, 10)}`; emit('status');
      fresh += await fetchWindow(s, e);
      setState('sync.cursor', new Date(Math.min(e, Date.parse(started))).toISOString());
    }
    sync.lastOk = now(); sync.error = '';
  } catch (e) {
    // The next check connects to Outlook afresh. The same failure is logged once, not every minute while it lasts.
    outlook.state.connected = false;
    if (e.message !== sync.error || Date.now() - (sync.errorAt || 0) > I.errorRepeatMin * 60000) {
      logActivity('error', `Mail check failed: ${e.message} It is tried again at the next check.`);
      sync.errorAt = Date.now();
    }
    sync.error = e.message;
  } finally {
    sync.fetched = fresh;
    if (fresh) { logActivity('sync', `${fresh} new email${fresh > 1 ? 's' : ''} (${reason})`); emit('threads', 'people'); }
    else if (reason === 'manual check' && !sync.error) logActivity('sync', 'Mail checked at your request: no new email');
    sync.running = false; sync.phase = '';
    emit('status', 'activity');
    pump();
  }
}

/** Before a thread is read: bring in its emails filed elsewhere in Outlook, so the whole conversation is seen. */
async function expandThread(thread) {
  if (!config().sync.expandThreads || !outlook.state.connected) return;
  if (thread.expanded_at && thread.expanded_at >= thread.last_at) return;
  const latest = q(`SELECT id FROM emails WHERE conversation_id=? AND folder<>'conv' ORDER BY received_at DESC LIMIT 1`).get(thread.id);
  if (!latest) return;
  try {
    const items = await outlook.conversation(latest.id);
    const mine = myEmails();
    ingest(items.filter(m => m.conversationId === thread.id).map(m => ({ ...m, folder: mine.has(lc(m.fromEmail)) ? 'sent' : 'conv' })));
  } catch (err) { logActivity('error', `Could not read the whole conversation "${thread.subject}": ${err.message}`); }
  q('UPDATE threads SET expanded_at=? WHERE id=?').run(now(), thread.id);
}

/** Mail still coming in or waiting to be read: people (titles, organizations, profiles) are not updated meanwhile. */
const mailWaiting = () => sync.running || threadsDue(1).length > 0;
const nameOf = email => q('SELECT name FROM people WHERE email=?').get(email)?.name || email;
const subjectOf = id => q('SELECT subject FROM threads WHERE id=?').get(id)?.subject;
/** What the AI is doing now, in the status bar; ref: the thread or person it is on. */
const phase = (text, ref = '') => { sync.aiPhase = text; sync.aiRef = ref; emit('status'); };
/** A background call given up: a time-out is skipped (done again later), anything else failed. */
const logSkip = (err, what, rest, ref, skipped = 'skipped') => logActivity(err.timedOut ? 'skipped' : 'error', `${what} ${err.timedOut ? skipped : 'failed'}: ${err.message}${rest}`, ref);
// Paused: by you in Settings, while the data is replaced, or while the AI works on something you asked for and wait on.
const aiIdle = () => holding || config().ai.paused || focused();
// The AI starts or stops working for you: the status bar says so, and once it is done the background work resumes.
onFocus(what => {
  emit('status');
  if (what) return;
  setTimeout(() => {
    if (focused() || stopping) return;
    pump();
    if (syncAfterFocus) { const r = syncAfterFocus; syncAfterFocus = ''; runSync(r); }
  }, I.resumeAfterHoldMs);
});

/** Your corrections, each turned into a lesson for the prompts that read tasks or people (lib/lessons.js). Before the
 *  next thread is read, not after the whole queue: a lesson learnt now already helps that thread, and a long queue of
 *  mail no longer keeps your corrections waiting. Each call is short: one correction. */
async function learnLessons({ asked = false } = {}) {
  let n = 0;
  for (let id; !holding && (asked || !aiIdle()) && aiState.online && (id = correctionsDue(1)[0]);) {
    if (!asked) phase('Learning from your corrections');
    try { const r = await learnFrom(id); if (r) n++; } catch (err) {
      if (err.preempted) break;
      if (err.offline) { await checkAI(); break; }
      logActivity('error', `Could not learn from a correction: ${err.message}. It is tried again${q('SELECT outcome FROM corrections WHERE id=?').get(id)?.outcome === 'failed' ? ' when you press Try again in Settings > Lessons' : ' later'}.`);
    }
    emit('lessons');
  }
  if (n) emit('lessons', 'activity');
  return n;
}
/** Learn now (Settings > Lessons): the AI works on your corrections only, until none waits. */
let learningNow = null;
function learnNow() {
  learningNow ||= foreground('Learning from your corrections', () => learnLessons({ asked: true }))
    .catch(err => logActivity('error', `Could not learn from your corrections: ${err.message}`))
    .finally(() => { learningNow = null; emit('lessons', 'activity', 'status'); });
  return learningNow;
}

/** Job titles and organizations from new signatures. Only once all mail is read: tasks first, people second. */
async function readSignatures() {
  let n = 0;
  for (const email of signaturesDue(config().people.signaturesPerRound)) {
    if (aiIdle() || mailWaiting()) break;
    phase(`Reading the signature of ${nameOf(email)}`, email);
    try { await readSignature(email); n++; } catch (err) {
      if (err.preempted) continue;
      if (err.offline) break;
      logSkip(err, `Signature of ${email}`, '. It is read again when a new one arrives.', email);
      q('UPDATE people SET sig_read_hash=sig_hash WHERE email=?').run(email);
    }
  }
  if (n) emit('people');
}

/** Nothing new to read and every profile written: revisions, for as long as nothing new comes in. The AI reviews the
 *  tasks it already made, thread by thread, for its own mistakes (direction, deadline, status, duplicates, no task at
 *  all), threads first whose deadline passed or whose conversation went on in a related thread; then profiles that aged
 *  are rewritten. New mail stops it at once (the call in progress is set aside); it
 *  resumes where it was once that mail is read. */
const peopleWaiting = () => signaturesDue(1).length > 0 || biosDue().length > 0;
const revising = () => !holding && !aiIdle() && aiState.online && !mailWaiting() && !peopleWaiting();
const revisionDue = () => auditDue(1).length > 0 || staleBios(1).length > 0;
async function revise() {
  if (!revising()) return;
  try { const n = fixQuotedDeadlines(); if (n) { noteRound('tasks', n); emit('tasks'); } } catch (err) { logActivity('error', 'Could not check the deadlines: ' + err.message); }
  for (let id; revising() && (id = auditDue(1)[0]);) {
    const subject = subjectOf(id);
    phase(`Revising tasks: ${String(subject).slice(0, F.subjectShown)}`, id);
    try { const n = await auditThread(id); noteRound('threads'); if (n) { noteRound('tasks', n); emit('tasks', 'threads'); } } catch (err) {
      if (err.preempted) return;                                   // new mail first; the revision resumes after it
      if (err.offline) { await checkAI(); return; }
      skipAudit(id);                                               // reviewed again when the thread grows, or some days on
      logSkip(err, `Review of "${subject}"`, '', id);
    }
  }
  for (let email; revising() && !auditDue(1).length && (email = staleBios(1)[0]);) {
    const before = q('SELECT bio_at FROM people WHERE email=?').get(email)?.bio_at;
    phase(`Revising the profile of ${nameOf(email)}`, email);
    await writeOneBio(email);
    const after = q('SELECT bio_at, bio_signals, signals FROM people WHERE email=?').get(email);
    if (after?.bio_at === before) {
      if (!revising()) return;                                     // set aside for new mail: written again after it
      q('UPDATE people SET bio_signals=signals WHERE email=?').run(email);   // failed: waits for new mail about them
    } else noteRound('profiles');
  }
  if (revising() && !revisionDue()) endRound();
}

async function writeOneBio(email) {
  const name = nameOf(email);
  phase(`Writing the profile of ${name}`, email);
  try { await writeBio(email); } catch (err) {
    if (err.preempted || err.offline) return;
    // Skipped until more is known about them; it is written then.
    logSkip(err, `Profile of ${name}`, '. It is written again once there is more mail about them.', email, 'skipped for now');
    q('UPDATE people SET bio_signals=signals WHERE email=?').run(email);
  }
  emit('people');
}

/** Background work, one model call at a time. Tasks first: every thread that grew is read, newest first. Only once
 *  none waits and no mail check runs are people updated: job titles and organizations from signatures, then profiles.
 *  New mail arriving meanwhile cuts the people call short; it is done again once that mail is read. What is learnt about
 *  people meanwhile is only noted (signals, signature text) and waits for that second pass. */
async function pump() {
  if (busyAI || stopping || aiIdle() || !aiState.online) return;
  busyAI = true;
  try {
    for (let id; !aiIdle() && aiState.online && (await learnLessons(), id = threadsDue(1)[0]);) {
      if (aiIdle() || !aiState.online) break;
      const subject = subjectOf(id);
      phase(`Reading thread: ${String(subject).slice(0, F.subjectShown)}`, id);
      try {
        const t0 = Date.now(), model = config().ai.model;
        const fresh = await analyseThread(id, { expand: expandThread });
        noteThreadTime(model, Date.now() - t0);
        notePeopleOf(id);
        // One tip per new task; the desktop app shows them one after another.
        for (const i of fresh) {
          const t = Tasks.get(i);
          if (t) { const tip = taskTip(t); notify(tip.title, tip.body, '#/tasks/' + i); }
        }
      } catch (err) {
        if (err.preempted) continue;
        if (err.offline) { await checkAI(); if (!aiState.online) break; continue; }   // waits for the AI server; the thread keeps its place
        // Skipped: the next thread is read now, and this one after all the others, with a shorter extract.
        const subj = `"${subject}"`;
        if (err.retryAt) logActivity('stuck', `Stuck: ${subj} could not be read in ${err.tries} tries (${err.message}). It waits at the end of the queue and is tried again from ${new Date(err.retryAt).toLocaleString(APP.locale, { dateStyle: 'medium', timeStyle: 'short' })}, or press Read again on the thread.`, id);
        else if (err.tries) logActivity('skipped', `Skipped ${subj} for now (${err.message}). Moving on to the next thread; this one is read again after the rest, with a shorter extract (try ${err.tries + 1} of ${tries()}).`, id);
        else logActivity('error', `Reading ${subj} failed: ${err.message}`, id);
        emit('activity');
        await checkAI(); if (!aiState.online) break;
      }
      emit('tasks', 'threads');
      await freeModel();
    }
    if (!aiIdle()) await learnLessons();
    if (!aiIdle() && !mailWaiting()) await readSignatures();
    for (const email of holding ? [] : biosDue()) {
      if (aiIdle() || mailWaiting() || signaturesDue(1).length) break;
      await writeOneBio(email);
    }
    if (!holding) await revise();
  } finally {
    busyAI = false;
    if (stopping) return;
    phase('');    // People wait while a mail check runs; it calls pump again when done.
    if (aiState.online && !config().ai.paused && (threadsDue(1).length || correctionsDue(1).length || (!sync.running && (peopleWaiting() || revisionDue())))) setTimeout(pump, I.pumpAgainMs);
    else freeModel();   // nothing left to do: the model's memory is given back now
  }
}

/**
 * The model's memory given back (Settings: free it after each thread): the next call loads it again, in about 12 s
 * on a 4 GB graphics card. Never while the AI works for you or the data is being replaced, nor when it is not loaded.
 */
async function freeModel() {
  if (!config().ai.freeAfterThread || focused() || holding) return;
  try { if ((await checkAI()).loaded.length) await setModelLoaded(false); } catch {}
}

/** Once a day: what is overdue and what is due today, as a desktop notification. */
function dailyDigest() {
  if (getState('digest.day') === today() || new Date().getHours() < config().tasks.digestHour) return;
  setState('digest.day', today());
  const count = op => q(`SELECT COUNT(*) n FROM tasks WHERE status='open' AND deleted_at IS NULL AND deadline${op}?`).get(today()).n;
  const late = count('<'), due = count('=');
  if (late || due) notify('Your tasks today', [due && `${due} due today`, late && `${late} overdue`].filter(Boolean).join(', '), '#/tasks');
}

/** The tip for a task just found: its title with a dot for how it stands (red overdue, orange due within the
 *  due-soon days, blue due later), when it is due, and who it is from or with. */
function taskTip(t) {
  const n = t.deadline ? daysBetween(today(), t.deadline) : null;
  const day = fmtDay(t.deadline, { weekday: 'short', day: 'numeric', month: 'short' });
  const dot = n == null ? '' : n < 0 ? ' 🔴' : n <= config().tasks.dueSoonDays ? ' 🟠' : ' 🔵';
  const when = n == null ? 'Deadline: None'
    : n < 0 ? `Overdue by ${-n === 1 ? '1 day' : `${-n} days`} · was due ${day}`
    : n === 0 ? 'Due today' : n === 1 ? `Due tomorrow · ${day}` : `Due in ${n} days · ${day}`;
  const who = t.direction === 'by_me' ? t.owner_name || t.owner_email : t.requester_name || t.requester_email;
  return { title: t.title + dot, body: [when,
    who && `${t.direction === 'by_me' ? 'With' : 'From'} ${who}`].filter(Boolean).join('\n') };
}

/** The daily deadlines email, once the time set has passed: checked every minute and as the app starts, so one missed
 *  while the app was closed goes at once. A failure is tried again after a while, not every minute. */
let mailing = false, mailFailedAt = 0;
async function dailyMail() {
  if (mailing || holding || Date.now() - mailFailedAt < I.dailyMailRetryMin * 60000 || !dailyMailDue()) return;
  mailing = true;
  try {
    const { to } = await sendDailyMail();
    mailFailedAt = 0;
    logActivity('sent', `Daily deadlines email sent to ${to}`);
    emit('activity');
  } catch (err) {
    mailFailedAt = Date.now();
    logActivity('error', 'Could not send the daily deadlines email: ' + err.message);
    notify('Daily deadlines email not sent', err.message, '#/activity');
  } finally { mailing = false; }
}

let timer = null;
function schedule() {
  clearTimeout(timer);
  if (stopping) return;
  const ms = Math.max(I.minPollSec, config().sync.pollSeconds) * 1000;
  sync.next = new Date(Date.now() + ms).toISOString();
  timer = setTimeout(() => runSync('scheduled check').finally(schedule), ms);   // a check that throws never stops the polling
}

// ---------- drafts to Outlook ----------
// One Outlook action per draft at a time: a double click or a retry while the first is under way cannot make a second
// copy in Outlook, or send it twice.
const draftBusy = new Set();
async function onlyOnce(d, fn) {
  if (!d) throw new Error('Draft not found');
  if (draftBusy.has(d.id)) throw new Error('This draft is already on its way to Outlook. Wait a moment.');
  draftBusy.add(d.id);
  try { return await fn(); } finally { draftBusy.delete(d.id); }
}
/** Editing, rewriting or discarding a draft waits until it is in Outlook (or sent). */
const notBusy = d => { if (d && draftBusy.has(d.id)) throw Object.assign(new Error('This draft is on its way to Outlook. Wait a moment.'), { status: 409 }); return d; };
async function pushDraft(d, { sending = false } = {}) {
  if (!d) throw new Error('Draft not found');
  if (d.outlook_id) {
    // No answer is not "gone": taken as gone, it would make a second copy, or say it was sent or deleted there.
    const x = await outlook.exists(d.outlook_id).catch(() => { throw new Error('Outlook did not answer; try again.'); });
    // Sent from Outlook already: it is never made and sent again.
    if (x.sent) { Drafts.update(d.id, { status: 'sent', updated_at: now() }); emit('drafts'); throw new Error('This draft was already sent from Outlook.'); }
    if (x.exists && d.status === 'outlook') return d.outlook_id;
    // Its Outlook copy is gone: perhaps sent from there, perhaps deleted. Sending a new one could send it twice.
    if (!x.exists && sending && d.status === 'outlook') throw new Error('Its copy in Outlook is gone: sent or deleted there. Check Sent Items in Outlook; to send it anyway, edit the draft and press Send again.');
    // Edited since it was saved: the old copy goes to Deleted Items (recoverable) so it cannot be sent by mistake.
    if (x.exists && !x.sent) await outlook.discard(d.outlook_id, config().sync.account).catch(() => {});
  }
  const src = d.source_email_id && q(`SELECT 1 FROM emails WHERE id=?`).get(d.source_email_id);
  const { entryId } = await outlook.draft({ mode: src ? d.mode : 'new', sourceId: src ? d.source_email_id : null, to: d.to, cc: d.cc,
    subject: d.subject, html: toHtml(d.body), keepSignature: !!config().voice.outlookSignature });
  Drafts.update(d.id, { outlook_id: entryId, status: 'outlook', updated_at: now() });
  return entryId;
}
/** Send a draft through Outlook. Marked before sending: if Outlook times out after submitting, it is never sent twice. */
const sendDraft = d => onlyOnce(d, () => sendNow(d));
async function sendNow(d) {
  if (!d || ['sent', 'discarded'].includes(d.status)) throw new Error('This draft cannot be sent');
  if (d.status === 'sending') throw new Error('An earlier attempt to send this may have gone out. Check Sent Items in Outlook before trying again.');
  if (!d.to.length) throw new Error('Add at least one recipient');
  const entryId = await pushDraft(d, { sending: true });
  Drafts.update(d.id, { status: 'sending', updated_at: now() });
  try { await outlook.send(entryId); }
  catch (err) { emit('drafts'); throw new Error(`Outlook did not confirm the send (${err.message}). Check Sent Items before trying again.`); }
  Drafts.update(d.id, { status: 'sent', updated_at: now() });
  if (d.task_id) addEvent(d.task_id, 'followup', `${d.mode === 'forward' ? 'Forward' : 'Follow-up'} sent to ${d.to.join(', ')}`);
  // A forward makes the task it asks of them now; it takes its email once Sent Items is read.
  if (d.mode === 'forward') forwardSent(Drafts.get(d.id));
  logActivity('sent', `Sent: ${d.subject} to ${d.to.join(', ')}`, String(d.id));
  emit('drafts', 'tasks', 'status', 'activity');
}

function discardDraft(d) {
  Drafts.update(d.id, { status: 'discarded', updated_at: now() });
  if (d.outlook_id) outlook.discard(d.outlook_id, config().sync.account).catch(() => {});
}
/** Drafts with the title of their task: one query for the whole list. */
function draftsOut(list) {
  const ids = [...new Set(list.map(d => d.task_id).filter(Boolean))];
  const titles = new Map(ids.length ? q('SELECT id, title FROM tasks WHERE id IN (SELECT value FROM json_each(?))').all(JSON.stringify(ids)).map(r => [r.id, r.title]) : []);
  return list.map(d => ({ ...d, task_title: d.task_id ? titles.get(d.task_id) : '' }));
}
const draftOut = d => d && draftsOut([d])[0];

// ---------- read models ----------
const msgOut = (e, body = false) => ({ id: e.id, folder: e.folder, conversation_id: e.conversation_id, subject: e.subject, from_name: e.from_name, from_email: e.from_email, mine: e.mine,
  automated: e.automated, received_at: e.received_at, to: e.to, cc: e.cc, attachments: e.attachments, ...(body ? { body: e.body } : {}) });

function threadDetail(id) {
  const th = q('SELECT * FROM threads WHERE id=?').get(id);
  if (!th) return null;
  // The last AI failure goes out as ai_error: a top-level "error" reads as a failed request in the page, which would hide the emails.
  const { error, ...rest } = th;
  // Its tasks, and those you forwarded from them that went on in a thread of their own. Repeats folded into another task are left out.
  return { ...rest, ai_error: error || '', messages: threadMessages(id).map(e => msgOut(e, true)),
    tasks: tasksOut(Tasks.where(`(conversation_id=? OR parent_id IN (SELECT id FROM tasks WHERE conversation_id=?)) AND status<>'dismissed' AND COALESCE(close_reason,'')<>'duplicate' AND deleted_at IS NULL ORDER BY opened_at`, id, id), { events: true }) };
}

function overview() {
  const O = APP.overview;
  const all = tasksOut(Tasks.where(`status<>'dismissed' AND deleted_at IS NULL`));
  const open = all.filter(t => t.status === 'open'), ended = all.filter(t => ['done', 'cancelled'].includes(t.status));
  const by = (list, k) => list.reduce((m, t) => (m[t[k]] = (m[t[k]] || 0) + 1, m), {});
  const since = new Date(Date.now() - O.closedDays * 864e5).toISOString();
  // Opened and closed per week over the last weeks.
  const weeks = [];
  for (let i = O.weeks - 1; i >= 0; i--) {
    const a = new Date(Date.now() - (i + 1) * 7 * 864e5).toISOString(), b = new Date(Date.now() - i * 7 * 864e5).toISOString();
    weeks.push({ from: a.slice(0, 10), opened: all.filter(t => t.opened_at >= a && t.opened_at < b).length,
      closed: ended.filter(t => t.closed_at && t.closed_at >= a && t.closed_at < b).length });
  }
  const byDeadline = (a, b) => String(a.deadline).localeCompare(String(b.deadline));
  return {
    counts: { open: open.length, overdue: open.filter(t => t.overdue).length, dueSoon: open.filter(t => t.due_soon).length,
      closed30: ended.filter(t => t.closed_at >= since).length, parked: all.filter(t => t.status === 'parked').length, unseen: open.filter(t => !t.seen).length,
      threads: q(`SELECT COUNT(*) n FROM threads`).get().n, people: q('SELECT COUNT(*) n FROM people WHERE hidden=0').get().n },
    openByDirection: by(open, 'direction'), allByDirection: by(all, 'direction'), byStatus: by(all, 'status'), weeks,
    upcoming: open.filter(t => !t.overdue && t.deadline).sort(byDeadline).slice(0, O.upcoming),
    overdue: open.filter(t => t.overdue).sort(byDeadline).slice(0, O.overdue),
    recentClosed: ended.slice().sort((a, b) => String(b.closed_at).localeCompare(String(a.closed_at))).slice(0, O.recentClosed),
    people: peopleList().filter(p => p.owns_open + p.gives_open > 0).sort((a, b) => b.owns_open + b.gives_open - a.owns_open - a.gives_open).slice(0, O.people),
  };
}

// ---------- routes ----------
// fn(query, params, body) returns what is sent as JSON. raw: fn(req, res, url, params) answers itself (streams, files).
// fg: it starts AI work you wait on, refused while the data is wiped or restored.
const routes = [];
const on = (method, pattern, fn, { raw = false, fg = false } = {}) => routes.push({ method, re: new RegExp('^' + pattern.replace(/:(\w+)/g, '(?<$1>[^/]+)') + '$'), fn, raw, fg });
const id$ = p => decodeURIComponent(p.id);
const notFound = what => { throw Object.assign(new Error(`${what} not found`), { status: 404 }); };
const needTask = id => Tasks.get(id) || notFound('Task');
const needDraft = id => Drafts.get(id) || notFound('Draft');
const stuckCount = () => q('SELECT COUNT(*) n FROM threads WHERE dirty=1 AND attempts>=? AND last_at>=?').get(tries(), new Date(frameStart()).toISOString()).n;

on('GET', '/api/status', () => ({
  version: pkg.version, schema: SCHEMA, outlook: outlook.state, platform: process.platform, ai: aiState, dataDir: DATA_DIR, me: config().me, update: updater.updateState(),
  sync: { ...sync, aiBusy: busyAI, threadsQueued: threadsQueued(), threadsStuck: stuckCount(), revision: { ...round } },
  counts: q(`SELECT (SELECT COUNT(*) FROM tasks WHERE status='open' AND deleted_at IS NULL) open, (SELECT COUNT(*) FROM tasks WHERE status='open' AND deleted_at IS NULL AND direction='to_me') mine, (SELECT COUNT(*) FROM tasks WHERE status='open' AND deleted_at IS NULL AND deadline<?1) overdue,
    (SELECT COUNT(*) FROM tasks WHERE status='open' AND deleted_at IS NULL AND seen=0) unseen, (SELECT COUNT(*) FROM drafts WHERE status IN ('draft','outlook')) drafts,
    (SELECT COUNT(*) FROM people WHERE hidden=0) people, (SELECT COUNT(*) FROM tasks WHERE deleted_at IS NOT NULL) bin`).get(today()),
}));
/** What the codes stored in the data mean, and the app's fixed values the page needs: one source for the page and the server. */
on('GET', '/api/meta', () => ({ ...Object.fromEntries(Object.entries(REFERENCE).filter(([k]) => k !== 'about')), locale: APP.locale, review: Object.fromEntries(Object.entries(REVIEW).map(([k, v]) => [k, v.label])),
  limits: { maxSecondary: config().tasks.maxSecondary, maxForward: config().tasks.maxForward, dueSoonDays: config().tasks.dueSoonDays, parkPeriod: parkPeriod() } }));
on('POST', '/api/sync', () => { runSync('manual check').finally(schedule); return { started: true }; });   // logged as it really starts
// Microsoft 365: the code to enter at Microsoft's sign-in page; the sign-in finishes in the background (status shows it).
on('POST', '/api/mail/signin', async () => outlook.signIn());
on('POST', '/api/mail/signin/cancel', () => { outlook.cancelSignIn(); return { ok: true }; });
on('POST', '/api/mail/signout', () => {
  const who = outlook.state.defaultStore;
  outlook.signOut();
  logActivity('sync', `Signed out of Microsoft 365${who ? ` (${who})` : ''}. The mail already read stays in Mandata.`);
  return { ok: true };
});

// ---------- updates (lib/updater.js): checked on GitHub every few hours, installed when you agree or by themselves ----------
on('GET', '/api/update', () => updater.updateState());
on('POST', '/api/update/check', () => updater.checkNow({ manual: true }));
// background: answered at once, the download going on (the phone follows it by GET /api/update rather than wait minutes).
on('POST', '/api/update/download', (q_, p, b) => {
  const run = updater.downloadUpdate({ install: !!b?.install });
  if (!b?.background) return run;
  run.catch(() => {});
  return updater.updateState();
});
on('POST', '/api/update/cancel', () => updater.cancelDownload());
on('POST', '/api/update/install', () => updater.installNow());
on('POST', '/api/update/later', () => updater.later());
on('POST', '/api/update/skip', () => updater.skip());
on('POST', '/api/update/seen', () => updater.seen());
on('PUT', '/api/update/settings', (q_, p, b) => updater.setUpdateSettings(b));

on('GET', '/api/config', () => ({ config: config(), defaults: DEFAULT_CONFIG }));
// How you left the app (dark mode, the screen, filters, sorts): kept with your data, handed to the page as it loads.
on('GET', '/api/prefs', () => getState('ui.prefs', {}));
on('POST', '/api/prefs', (p, g, b) => {
  const v = b?.prefs;
  if (!v || typeof v !== 'object' || Array.isArray(v) || JSON.stringify(v).length > 64 * 1024) throw Object.assign(new Error('Preferences not understood'), { status: 400 });
  setState('ui.prefs', v);
  return { ok: true };
});
// The test button in Settings > Tasks: today's deadlines email, sent to you now. The daily one still goes.
on('POST', '/api/dailymail/test', async () => {
  const r = await sendDailyMail({ test: true });
  logActivity('sent', `Test deadlines email sent to ${r.to}`);
  return r;
});
on('PUT', '/api/config', async (q_, p, b) => {
  const before = config().sync.pollSeconds, frame = config().sync.lookbackDays;
  if (b.tasks?.dailyEmailTime != null && !/^([01]\d|2[0-3]):[0-5]\d$/.test(b.tasks.dailyEmailTime)) throw new Error('Set the daily email time as hours and minutes, like 09:00.');
  if (b.sync?.source != null && !(process.platform === 'win32' ? ['auto', 'outlook', 'microsoft365'] : ['auto', 'microsoft365']).includes(b.sync.source))
    throw new Error(process.platform === 'win32' ? 'Choose classic Outlook or Microsoft 365.' : 'Classic Outlook is on Windows only: mail is read through Microsoft 365 here.');
  if (b.me?.emails) b.me.emails = [...new Set([].concat(b.me.emails).map(lc).filter(Boolean))];
  const meBefore = JSON.stringify(config().me);
  updateConfig(b);
  if (outlook.use(config().sync.source)) {
    logActivity('sync', `Mail is now read through ${mailName()}`);
    runSync('mail source changed').finally(schedule);
  }
  if (JSON.stringify(config().me) !== meBefore) {
    // You are someone else now (a name or an address changed): which mail is yours, and every task's direction, follow.
    const mine = [...myEmails()];
    tx(() => {
      q(`UPDATE emails SET mine=CASE WHEN from_email IN (SELECT value FROM json_each(?)) THEN 1 ELSE 0 END`).run(JSON.stringify(mine));
      for (const t of Tasks.where('1')) { const d = directionOf(t); if (d !== t.direction) Tasks.update(t.id, { direction: d }, { touch: false }); }
    });
    emit('tasks');
  }
  if (b.ai) { if (b.ai.model) prepareAI(); else { await checkAI(); pump(); } }
  if (b.tasks?.binDays != null && purgeExpired()) emit('tasks');   // a shorter stay in the recycle bin applies at once
  if (config().sync.lookbackDays !== frame) {
    const label = TIME_FRAMES.find(([d]) => d === Number(config().sync.lookbackDays))?.[1] || `${config().sync.lookbackDays} days`;
    logActivity('system', `Processing time frame set to ${label}`);
    runSync('time frame changed').finally(schedule);
  } else if (config().sync.pollSeconds !== before) schedule();
  logActivity('system', `Settings changed: ${Object.keys(b).join(', ')}`);
  emit('config', 'status'); return { config: config() };
});
// ---------- your data: wipe, backups, restore ----------
/** Mail reading and the AI stop (the call in progress is cut short), fn runs, then all starts again from what is there. */
async function withHold(fn) {
  if (holding) throw new Error('The data is already being changed. Wait a moment.');
  holding = true; emit('status');
  try {
    stopAll();
    // What you asked of the AI just before is cut short too (stopAll), and waited for like the rest.
    const busy = () => sync.running || busyAI || focused();
    for (const t = Date.now(); busy() && Date.now() - t < APP.holdWaitSec * 1000;) await new Promise(r => setTimeout(r, 250));
    if (busy()) throw new Error('Mandata is busy reading mail or working for you and could not stop. Try again in a minute.');
    undoStack.length = 0;   // what undo would put back is no longer there
    return fn();
  } finally {
    holding = false; reloadConfig(); outlook.use(config().sync.source);
    try { clearAssumedDeadlines(); } catch (err) { logActivity('error', 'Could not remove the assumed deadlines: ' + err.message); }   // a restored older backup may hold some
    emit('config', 'tasks', 'threads', 'people', 'activity', 'status');
    setTimeout(() => { runSync('after the data changed').finally(schedule); pump(); }, I.resumeAfterHoldMs);
  }
}
on('GET', '/api/data', () => ({ dataDir: DATA_DIR, current: currentCounts(), backups: listBackups() }));
on('POST', '/api/data/wipe', async (q_, p, b) => {
  if (b.confirm !== 'WIPE') throw new Error('Type WIPE to confirm');
  const kept = await withHold(() => {
    const name = b.backup === false ? null : makeBackup('Before wiping the database');
    wipe({ keepSettings: b.keepSettings !== false });
    return name;
  });
  logActivity('system', `Database wiped${b.keepSettings !== false ? ', settings kept' : ', settings too'}${kept ? '. A backup was kept: it can be restored in Settings > Data' : '. No backup was kept'}`);
  return { backup: kept, backups: listBackups(), current: currentCounts() };
});
on('POST', '/api/data/backup', () => { const backup = makeBackup(BY_HAND); logActivity('system', `Backup ${backup} made by you`); return { backup, backups: listBackups() }; });
on('POST', '/api/data/restore', async (q_, p, b) => {
  const before = await withHold(() => restore(String(b.name || '')));
  logActivity('system', `Backup ${b.name} restored. What was there before is kept as a backup too`);
  return { before, backups: listBackups(), current: currentCounts() };
});
on('POST', '/api/data/delete', (q_, p, b) => { deleteBackup(String(b.name || '')); logActivity('system', `Backup ${b.name} deleted by you`); return { backups: listBackups() }; });

/** A backup as a file to save anywhere: the data as it is now (?name= absent) or one of the backups. */
function exportFile(req, res, url) {
  const name = url.searchParams.get('name');
  let x, size;
  const done = () => { try { x?.done(); } catch {} };
  try { x = name ? exportBackup(name) : exportNow(); size = fs.statSync(x.file).size; } catch (e) { done(); return send(res, e.status || 500, { error: e.message }); }
  res.writeHead(200, { 'content-type': 'application/octet-stream', 'cache-control': 'no-store', 'content-length': size,
    'content-disposition': `attachment; filename="${x.name}"` });
  // Logged once the whole file has gone out, not as it starts.
  res.on('finish', () => { logActivity('system', name ? `Backup ${name} exported as ${x.name}` : `Your data exported as the backup file ${x.name}`); emit('activity'); });
  fs.createReadStream(x.file).on('error', () => { res.destroy(); done(); }).on('close', done).pipe(res);
}
/** A backup file from anywhere, sent as the request body: checked, then added to the backups (it can then be restored). */
async function importFile(req, res) {
  const f = importTemp();
  let from = '';
  try { from = decodeURIComponent(String(req.headers['x-file-name'] || '')); } catch {}
  try {
    await pipeline(req, fs.createWriteStream(f));
    const backup = importBackup(f, from);
    logActivity('system', `${from ? `Backup file ${path.basename(from)}` : 'A backup file'} imported (${backup.counts?.tasks ?? 0} tasks). It can be restored in Settings > Data`);
    emit('activity');
    send(res, 200, { backup, backups: listBackups() });
  } catch (e) { dropTemp(f); send(res, e.status || 500, { error: e.message }); }
}
on('GET', '/api/data/export', exportFile, { raw: true });
on('POST', '/api/data/import', importFile, { raw: true });
on('POST', '/api/config/reset/:id', async (q_, p) => { resetSection(p.id); if (p.id === 'ai') await checkAI(); logActivity('system', `Settings reset to the defaults: ${p.id}`); emit('config'); return { config: config() }; });

/** The AI server running and the model there (downloaded when missing), then the usual check and the background reading. */
async function prepareAI(model) {
  const pulling = () => { emit('status'); if (aiState.pull?.status === 'starting') logActivity('system', `Downloading ${aiState.pull.model} to the AI server`); };
  const ok = await ensureModel(model, pulling);
  await checkAI();
  if (!ok) logActivity('error', aiState.error);
  emit('status'); pump();
  return ok;
}

// Run: use this model, load it and read mail in the background. Pause: stop background reading and free the model's memory.
on('POST', '/api/ai/run', async (q_, p, b) => {
  const model = b.model ? modelName(b) : config().ai.model;
  if (model !== config().ai.model) await setModelLoaded(false).catch(() => {});   // free the old model first
  updateConfig({ ai: { model, paused: false } });
  await prepareAI(model);
  if (!aiState.online) throw new Error(aiState.error || 'The AI is offline');
  await setModelLoaded(true);
  await checkAI();
  logActivity('system', `AI running: ${model}`);
  pump(); emit('config', 'status');
  return { ai: aiState, config: config() };
});
on('POST', '/api/ai/pause', async () => {
  updateConfig({ ai: { paused: true } });
  // The thread being read stops now (it is read again on Run), or its next call would load the model straight back.
  stopBackground('Set aside: the AI is paused');
  await setModelLoaded(false).catch(() => {});
  await checkAI();
  logActivity('system', 'AI paused');
  emit('config', 'status');
  return { ai: aiState, config: config() };
});

// AI management: every model on the AI server and the ones offered for install; install, remove, load, unload and time them.
const modelName = b => { const m = String(b?.model || '').trim(); if (!/^[\w.\-\/]+(:[\w.\-]+)?$/.test(m)) throw new Error('Not a model name: ' + m); return m; };
on('GET', '/api/ai/models', () => listModels());
on('POST', '/api/ai/pull', (q_, p, b) => {
  const model = modelName(b);
  if (aiState.pull) throw new Error(`Already downloading ${aiState.pull.model}`);
  logActivity('system', `Installing ${model} on the AI server`);
  ensureModel(model, () => emit('status')).then(async ok => {
    await checkAI();
    logActivity(ok ? 'system' : 'error', ok ? `Installed ${model}` : aiState.error);
    emit('status'); broadcast({ type: 'models', model, ok, error: ok ? '' : aiState.error });
  });
  return { ok: true };
});
on('POST', '/api/ai/pull/cancel', () => { const model = aiState.pull?.model, ok = cancelPull(); if (ok) logActivity('system', `Download of ${model || 'the model'} cancelled by you`); return { ok }; });
on('POST', '/api/ai/delete', async (q_, p, b) => {
  const model = modelName(b);
  const sizeBefore = (await listModels()).installed.find(m => m.name === model)?.gb || 0;
  const r = await deleteModel(model);
  await checkAI();
  logActivity('system', `Deleted ${model} from the disk (${sizeBefore} GB freed)`);
  emit('status'); return { ...r, gb: sizeBefore };
});
on('POST', '/api/ai/load', async (q_, p, b) => { const model = modelName(b); await setModelLoaded(true, model); await checkAI(); logActivity('system', `Loaded ${model} into memory`); emit('status'); return { ok: true }; });
on('POST', '/api/ai/unload', async (q_, p, b) => { const model = modelName(b); await setModelLoaded(false, model); await checkAI(); logActivity('system', `Unloaded ${model} from memory`); emit('status'); return { ok: true }; });
on('POST', '/api/ai/test', async (q_, p, b) => {
  const model = modelName(b);
  const r = await foreground(`Testing the speed of ${model}`, () => testModel(model));
  await checkAI();
  logActivity('system', `Speed test of ${model}: reads ${r.speed.prompt}, writes ${r.speed.output} tokens a second, about ${r.perEmailSec} s an email`);
  emit('status'); return r;
}, { fg: true });

on('GET', '/api/overview', () => overview());

/** Every task, with its latest news. */
on('GET', '/api/tasks', () => {
  // News is what happened after the task opened: not the opening, nor the first deadline it was given.
  const last = new Map(q(`SELECT task_id, kind, text, at FROM task_events WHERE id IN (SELECT MAX(id) FROM task_events WHERE kind<>'opened'
    AND NOT (kind='deadline' AND (text LIKE 'No deadline in the email%' OR text LIKE 'Deadline from the email%')) GROUP BY task_id)`).all().map(e => [e.task_id, e]));
  // When the latest email touching each task arrived (the one that opened it, or a later reply that moved it): what Updates sorts by.
  // Mandata's own doings (a park ending, a deadline it rethought, a draft) are not news from the mailbox, and when it read the mail never counts.
  const mail = new Map(q(`SELECT e.task_id, MAX(m.received_at) at FROM task_events e JOIN emails m ON m.id=e.email_id GROUP BY e.task_id`).all().map(r => [r.task_id, r.at]));
  // How many times each task was forwarded on, by email or without (each forward is a task of its own, linked by parent_id).
  const fwd = new Map(q(`SELECT parent_id, COUNT(*) n FROM tasks WHERE parent_id IS NOT NULL AND status<>'dismissed' AND deleted_at IS NULL GROUP BY parent_id`).all().map(r => [r.parent_id, r.n]));
  // How many follow-up emails you sent about each task (not forwards, not acknowledgements).
  const fol = new Map(q(`SELECT task_id, COUNT(*) n FROM drafts WHERE task_id IS NOT NULL AND status='sent' AND mode<>'forward' AND ack=0 GROUP BY task_id`).all().map(r => [r.task_id, r.n]));
  return tasksOut(Tasks.where(`(status<>'dismissed' OR updated_at>=?) AND deleted_at IS NULL ORDER BY deadline`, new Date(Date.now() - 864e5).toISOString()))
    .map(t => ({ ...t, last: last.get(t.id) || null, mail_at: [mail.get(t.id), t.opened_at].filter(Boolean).sort().pop() || null, forwarded: fwd.get(t.id) || 0, followups: fol.get(t.id) || 0 }));
});
on('GET', '/api/tasks/:id', (q_, p) => {
  const t = needTask(p.id);
  // Where it was forwarded from, and to whom it was forwarded on (each a task of its own).
  const brief = k => k && { id: k.id, title: k.title, status: k.status, close_reason: k.close_reason, direction: k.direction, owner_name: k.owner_name, owner_email: k.owner_email,
    requester_name: k.requester_name, requester_email: k.requester_email, secondary: secondaryOf(k), deadline: k.deadline, opened_at: k.opened_at };
  return { ...taskOut(t, { events: true }), thread: threadDetail(t.conversation_id),
    parent: brief(t.parent_id && Tasks.get(t.parent_id)),
    forwards: Tasks.where(`parent_id=? AND status<>'dismissed' AND deleted_at IS NULL ORDER BY id`, t.id).map(brief),
    drafts: draftsOut(Drafts.where(`task_id=? AND status<>'discarded' ORDER BY id DESC`, t.id)) };
});
on('POST', '/api/tasks/:id/seen', (q_, p) => { if (q('UPDATE tasks SET seen=1 WHERE id=? AND seen=0').run(p.id).changes) emit('status'); return { ok: true }; });
/**
 * Undo (Ctrl+Z): each change you make by hand keeps the thing as it was (every table that holds part of it), newest last.
 * Undo puts the newest back and removes the history lines that change wrote. Kept in memory only: a restart starts a
 * fresh history. It covers the screen you are on: moving to another screen clears it (POST /api/undo/reset).
 */
const undoStack = [];
const pushUndo = u => { undoStack.push(u); if (undoStack.length > APP.undoDepth) undoStack.shift(); };
const lastEventId = () => q('SELECT MAX(id) m FROM task_events').get().m || 0;
/** Before a change: what to put back. Call the returned function once the change is written. */
function remember(label, table, id, extra = () => {}) {
  const before = snapshot(table, id);
  if (!before) return () => {};
  const ev0 = lastEventId();
  return () => {
    const ev1 = lastEventId();
    pushUndo({ label, before, events: table === 'tasks' && ev1 > ev0 ? [id, ev0, ev1] : null, extra });
  };
}
on('POST', '/api/undo', () => {
  const u = undoStack.pop();
  if (!u) return { label: null };
  const befores = [].concat(u.before);
  tx(() => {
    befores.forEach(restoreSnapshot);
    if (u.events) q('DELETE FROM task_events WHERE task_id=? AND id>? AND id<=?').run(...u.events);
    u.extra();
  });
  logActivity('task', `Undone: ${u.label}`);
  emit('tasks', 'status', 'people', 'drafts');
  return { label: u.label, table: befores[0].table, id: befores[0].id, left: undoStack.length };
});
on('POST', '/api/undo/reset', () => { undoStack.length = 0; return { ok: true }; });
// No route creates a task from nothing. You can close, reopen, dismiss, or correct one the AI found, forward it (the
// task a forward by email asks of someone is made only once that email is sent; one without email makes it at once).
// Each part of a change by hand, written into set (the fields) and edited (what is yours now), inside one transaction.
// x: { t, b, set, edited, learn }.
function applyAction(x) {
  const { t, b, set, edited } = x;
  // The same change sent again (a phone's outbox, a second tap) changes nothing, and is neither logged nor learnt twice.
  if (b.action === 'close') {
    // A task between other people is only followed, for information: it is not yours to close, only to archive once
    // seen. Their emails close it.
    const others = directionOf(t) === 'others';
    if (others && b.reason !== 'archived') throw new Error('This task is between other people: you can archive it, and it closes when their emails show it done');
    // Done, delegated and handled leave your plate as done; parked sets it aside until you resume it; the others end it
    // without the work being delivered.
    const r = CLOSE.get(b.reason)?.status === 'dismissed' ? CLOSE.get('done') : CLOSE.get(b.reason) || CLOSE.get('done');
    if (t.status === r.status && t.close_reason === r.code) return;
    x.acted = true;
    Object.assign(set, { status: r.status, close_reason: r.code, closed_by: 'user', closed_at: now(), closed_email_id: null, close_note: noDash(b.note || '') });
    addEvent(t.id, r.status === 'done' ? 'closed' : r.status === 'parked' ? 'parked' : 'cancelled', `${r.event} by you${r.status === 'parked' ? ` for ${parkPeriod()}, then it is open again` : ''}${b.note ? ': ' + b.note : ''}`);
    // Every close is kept: a duplicate is the AI listing the same work twice; done, cancelled or handled by hand may
    // be an email the AI did not read as closing it (the learner skips it when the email does not show it). Parking
    // is only setting it aside.
    // Archiving a task between others is only having seen it: the AI got nothing wrong.
    if (r.status !== 'parked' && t.status === 'open' && !others) noteCorrection(t, { kind: 'close', field: r.code, was: t.status, now: r.label, note: b.note });
  } else if (b.action === 'acknowledge') {
    throw new Error('Acknowledge from the task: it drafts the reply to whoever asked');
  } else if (b.action === 'reopen') {
    if (t.status === 'open') return;
    x.acted = true;
    Object.assign(set, { status: 'open', close_reason: null, closed_by: null, closed_at: null, closed_email_id: null, close_note: '' });
    addEvent(t.id, 'reopened', t.status === 'parked' ? 'Resumed by you' : 'Reopened by you');
    // You take back your own close or "not a task": what it would have taught is taken back too, if not learnt yet.
    if (t.closed_by === 'user') forgetCorrections(t.id, 0, ['close', 'dismiss']);
    // An email had closed it (the AI read the work as done or cancelled): it was not.
    if (t.closed_by === 'email' && t.status !== 'parked') noteCorrection(t, { kind: 'reopen', field: 'status', was: `${t.status}${t.close_note ? ` (${t.close_note})` : ''}`, now: 'open', note: b.note });
  } else if (b.action === 'confirm') {
    // A task the AI was not sure of, and you say it is one: the flag goes, and why it is a task is learnt from.
    if (!t.unsure) return;
    x.acted = true;
    Object.assign(set, { unsure: '' }); edited.add('unsure');
    addEvent(t.id, 'reviewed', `Confirmed by you: it is a task${b.note ? ': ' + b.note : ''}`);
    noteCorrection(t, { kind: 'confirm', field: 'task', was: `not sure: ${t.unsure}`, now: 'a task', note: b.note });
  } else if (b.action === 'dismiss') {
    const r = CLOSE.get('notask');
    if (t.status === r.status && t.close_reason === r.code) return;
    x.acted = true;
    Object.assign(set, { status: r.status, close_reason: r.code, closed_by: 'user', closed_at: now(), close_note: noDash(b.note || '') });
    addEvent(t.id, 'dismissed', `${r.event} by you${b.note ? ': ' + b.note : ''}`);
    noteCorrection(t, { kind: 'dismiss', field: 'task', was: 'a task', now: 'not a task', note: b.note });
  }
}
/** A date you set is the deadline. */
function applyDeadline({ t, b, set, edited, learn }) {
  if (!isDay(b.deadline) || b.deadline === t.deadline) return;
  learn('deadline', `${t.deadline || 'none'}${t.deadline_note ? `, because: ${t.deadline_note}` : ''}`, b.deadline);
  Object.assign(set, { deadline: b.deadline, deadline_source: 'user', deadline_note: '' }); edited.add('deadline');
  addEvent(t.id, 'deadline', `Deadline changed by you to ${b.deadline} (was ${t.deadline || 'none'})`);
}
function applyFields({ t, b, set, edited, learn }) {
  if (b.priority != null && !REFERENCE.priorities.some(x => x.code === b.priority)) throw new Error('Unknown priority');
  for (const k of ['title', 'detail', 'priority']) if (b[k] != null && b[k] !== t[k]) { set[k] = noDash(String(b[k])).slice(0, F.edit); learn(k, t[k], set[k]); edited.add(k); }
}
function applyPeople({ t, b, set, edited, learn }) {
  if (!['owner_email', 'owner_name', 'requester_email', 'requester_name', 'secondary'].some(k => b[k] != null)) return;
  for (const k of ['owner_email', 'owner_name', 'requester_email', 'requester_name']) if (b[k] != null) set[k] = k.endsWith('email') ? lc(b[k]) : noDash(b[k]);
  // Secondary people: addresses (a list or comma-separated text), named from their profile when they have one.
  if (b.secondary != null) {
    const owner = lc(set.owner_email ?? t.owner_email);
    set.secondary = [...new Set([].concat(b.secondary).flatMap(s => String(s?.email ?? s).split(/[,;\s]+/)).map(lc))]
      .filter(e => isEmail(e) && e !== owner).slice(0, config().tasks.maxSecondary).map(email => ({ email, name: nameOf(email) }));
  }
  // You made yourself the one who must do it: it is yours to answer for, not one of many.
  if (set.owner_email != null && myEmails().has(set.owner_email) && !myEmails().has(lc(t.owner_email))) set.shared = 0;
  set.direction = directionOf({ ...t, ...set });
  const pair = x => `${x.requester_name || x.requester_email || '?'} asked ${x.owner_name || x.owner_email || '?'}`;
  if (pair({ ...t, ...set }) !== pair(t)) learn('people', pair(t), pair({ ...t, ...set }));
  edited.add('people');
  const also = secondaryOf({ ...t, ...set }).map(x => x.name);
  addEvent(t.id, 'people', `People corrected by you: ${set.requester_name ?? t.requester_name} asked ${set.owner_name ?? t.owner_name}${also.length ? ` (secondary: ${also.join(', ')})` : ''}`);
}
/**
 * Yours alone, or one of many ({ shared: false | true }): you say whether the task singles you out. Made yours alone,
 * you lead it and whoever led it is asked with you. Later readings leave it as you set it: the people are yours now.
 */
function applyShared({ t, b, set, edited, learn }) {
  if (b.shared == null) return;
  const cur = { ...t, ...set }, mine = myEmails(), isMine = p => mine.has(lc(p.email));
  const me = isMine({ email: cur.owner_email }) ? null : secondaryOf(cur).find(isMine);
  if (!isMine({ email: cur.owner_email }) && !me) throw new Error('This task was not asked of you');
  const was = directionOf(cur);
  set.shared = b.shared ? 1 : 0;
  if (!b.shared && me) Object.assign(set, { owner_name: me.name, owner_email: me.email,
    secondary: [{ name: cur.owner_name || cur.owner_email, email: cur.owner_email }, ...secondaryOf(cur).filter(p => p !== me)].filter(p => p.email) });
  set.direction = directionOf({ ...cur, ...set });
  if (set.direction === was) return;
  const among = set.direction === 'among';
  learn('people', among ? 'asked of me alone' : 'asked of me among others', among ? 'asked of me among others: a group, or someone else answers for it' : 'asked of me alone: I answer for it');
  edited.add('people');
  addEvent(t.id, 'people', among ? 'Among others, set by you: asked of you as one of many, not of you alone' : 'Assigned to you, set by you: you answer for it');
}
/** A radar score set by hand ({ radar: { urgency: 4 } }); null gives that score back to the rules. */
function applyRadar({ t, b, set }) {
  if (!b.radar || typeof b.radar !== 'object') return;
  const mine = { ...t.radar_set };
  for (const [k, v] of Object.entries(b.radar)) if (AXES.has(k)) {
    const label = AXES.get(k).label;
    if (v == null) { if (k in mine) { delete mine[k]; addEvent(t.id, 'update', `${label} given back to the rules by you`); } }
    else { const n = Math.max(0, Math.min(5, Math.round(+v))); if (Number.isFinite(n) && mine[k] !== n) { mine[k] = n; addEvent(t.id, 'update', `${label} set by you to ${n}/5`); } }
  }
  // A score you set by hand is kept too: it says how much the task matters, which its priority may not have.
  for (const [k, v] of Object.entries(mine)) if (t.radar_set?.[k] !== v)
    noteCorrection(t, { kind: 'edit', field: `${AXES.get(k).label.toLowerCase()} score`, was: `set by the rules, priority ${t.priority}`, now: `${v}/5` });
  set.radar_set = mine;
}
on('PATCH', '/api/tasks/:id', (q_, p, b) => {
  const t = needTask(p.id);
  const verb = { close: 'Close', reopen: 'Reopen', dismiss: 'Not a task', confirm: 'Confirm', acknowledge: 'Acknowledge' }[b.action] || 'Edit';
  const c0 = lastCorrectionId();
  const done = remember(`${verb} "${t.title}"`, 'tasks', t.id, () => forgetCorrections(t.id, c0));
  // What you put right in the AI's reading is kept, to learn from (lib/lessons.js). A field you corrected before is
  // already yours, not the AI's: changing it again teaches nothing.
  const learn = (field, was, value) => { if (!t.edited.includes(field)) noteCorrection(t, { kind: 'edit', field, was, now: value }); };
  const x = { t, b, set: {}, edited: new Set(t.edited), learn };
  const { set, edited } = x;
  tx(() => {
    for (const apply of [applyAction, applyDeadline, applyFields, applyPeople, applyShared, applyRadar]) apply(x);
    Tasks.update(t.id, { ...set, edited: [...edited], seen: 1 });
  });
  if (x.acted || Object.keys(set).length) done();
  if (x.acted) logActivity('task', `${b.action === 'close' ? CLOSE.get(set.close_reason)?.event || 'Closed' : { reopen: t.status === 'parked' ? 'Resumed' : 'Reopened', dismiss: CLOSE.get('notask').activity, confirm: 'Confirmed as a task', acknowledge: 'Acknowledged' }[b.action]}: "${t.title}"`, String(t.id));
  // What you changed by hand besides closing it: the fields, by name.
  const fields = { deadline: 'deadline', title: 'title', detail: 'detail', priority: 'priority', owner_email: 'people', owner_name: 'people', requester_email: 'people',
    requester_name: 'people', secondary: 'people', shared: 'whether it is yours alone', radar_set: 'radar scores' };
  const changed = [...new Set(Object.keys(set).map(k => fields[k]).filter(Boolean))];
  if (changed.length && b.action !== 'close' && b.action !== 'dismiss') logActivity('task', `Edited by you (${changed.join(', ')}): "${set.title || t.title}"`, String(t.id));
  emit('tasks', 'status', 'people');
  return taskOut(Tasks.get(t.id), { events: true });
});
// Pin a task to the top of the list, or unpin it ({ pinned: true | false }). Only where it sits: not an edit, so the
// task keeps its updated time and its history.
on('POST', '/api/tasks/:id/pin', (q_, p, b) => {
  const t = needTask(p.id);
  Tasks.update(t.id, { pinned_at: b.pinned ? t.pinned_at || now() : null }, { touch: false });
  // Pinning a task the AI gave a normal or low priority says it matters more; unpinning takes that back.
  if (b.pinned && !t.pinned_at && t.priority !== 'high' && !t.edited.includes('priority')) noteCorrection(t, { kind: 'pin', field: 'priority', was: t.priority, now: 'pinned' });
  if (!b.pinned && t.pinned_at) forgetCorrections(t.id, 0, ['pin']);
  if (!!b.pinned !== !!t.pinned_at) logActivity('task', `${b.pinned ? 'Pinned to the top' : 'Unpinned'}: "${t.title}"`, String(t.id));
  emit('tasks');
  return { id: t.id, pinned_at: Tasks.get(t.id).pinned_at };
});
/**
 * Reprocess a task the AI read wrong: you say what was wrong (and why, if you like), and the AI reads the whole thread
 * again, told that its earlier reading was wrong and on which points. What you flagged takes the new reading; the
 * correction is kept on the task so later readings of the thread do not make the same mistake.
 */
on('POST', '/api/tasks/:id/reprocess', async (q_, p, b) => {
  const t = needTask(p.id);
  const issues = [...new Set([].concat(b.issues || []))].filter(k => REVIEW[k]);
  const note = noDash(String(b.note || '').trim()).slice(0, F.note);
  if (!issues.length && !note) throw new Error('Say what was wrong');
  // Who must do it (or who asked) is wrong and your note names that person in the thread: no reading needed, it is set.
  const who = issues.filter(k => k === 'owner' || k === 'requester');
  const named = who.length === 1 && note ? personNamed(note, t.conversation_id) : null;
  const needAI = !named || issues.length > 1;
  if (needAI && !aiState.online) await checkAI();
  if (needAI && !aiState.online) throw new Error(aiState.error || 'The AI is offline');
  const what = issues.map(k => REVIEW[k].label).join(', ');
  const corrections = [what && `wrong: ${what}`, note && `"${note}"`].filter(Boolean).join('. ');
  // Your own corrections of what you flagged give way to the new reading.
  const edited = new Set(t.edited);
  for (const k of issues) REVIEW[k].edited.forEach(f => edited.delete(f));
  Tasks.update(t.id, { edited: [...edited], corrections }, { touch: false });
  const review = { task: { ...t, edited: [...edited], corrections }, issues: named ? issues.filter(k => k !== who[0]) : issues, note, found: !needAI };
  if (needAI) {
    try {
      await foreground(`Reprocessing "${String(t.title).slice(0, F.subjectShown)}"`, async () => {
        await analyseThread(t.conversation_id, { expand: expandThread, review }); notePeopleOf(t.conversation_id);
      });
    } catch (err) {
      // No new reading: your corrections stand as they were.
      Tasks.update(t.id, { edited: t.edited, corrections: t.corrections }, { touch: false });
      throw err;
    }
  }
  if (named) {
    const cur = Tasks.get(t.id), side = who[0] === 'owner' ? 'owner' : 'requester';
    const set = { [`${side}_name`]: named.name, [`${side}_email`]: named.email };
    if (side === 'owner' && myEmails().has(lc(named.email))) set.shared = 0;   // you said you must do it: yours to answer for
    Tasks.update(t.id, { ...set, direction: directionOf({ ...cur, ...set }), edited: [...new Set([...cur.edited, 'people'])] });
    [t[`${side}_email`], named.email].forEach(bumpPerson);
  }
  const after = Tasks.get(t.id);
  const label = { owner_name: 'who must do it', requester_name: 'who asked', deadline: 'deadline', opened_at: 'asked on', title: 'title', status: 'status', priority: 'priority' };
  const show = (k, v) => k === 'opened_at' ? String(v || '').slice(0, 10) : v || 'none';
  const changes = Object.keys(label).filter(k => show(k, t[k]) !== show(k, after[k])).map(k => `${label[k]}: ${show(k, t[k])} → ${show(k, after[k])}`);
  noteCorrection(t, { kind: 'reprocess', field: issues.map(k => REVIEW[k].label).join(', ') || 'the reading', was: issues.map(k => REVIEW[k].was(t)).join('; '),
    now: !review.found ? 'not found on a second reading' : changes.join('; '), note });
  addEvent(t.id, 'reviewed', `Reprocessed at your request (${corrections}). ` + (!review.found ? 'The AI did not find this task on a second reading: if it is not a task, mark it so.'
    : changes.length ? `Corrected ${changes.join('; ')}.` : 'The AI kept its reading: correct it by hand if it is still wrong.'));
  logActivity('task', `Reprocessed: "${t.title}"`, String(t.id));
  emit('tasks', 'threads', 'people', 'status');
  return { ...taskOut(after, { events: true }), review: { found: review.found, changes } };
}, { fg: true });
// ---------- lessons learnt from your corrections (Settings > Lessons) ----------
on('GET', '/api/lessons', () => listLessons());
on('POST', '/api/lessons', (q_, p, b) => { const l = addLesson(b); emit('lessons', 'activity'); return l; });
on('PATCH', '/api/lessons/:id', (q_, p, b) => { const l = updateLesson(Number(p.id), b); emit('lessons', 'activity'); return l; });
on('DELETE', '/api/lessons/:id', (q_, p) => { const r = deleteLesson(Number(p.id)); emit('lessons', 'activity'); return r; });
/** Learn now from the corrections waiting, rather than once the AI is next free. */
on('POST', '/api/lessons/learn', () => {
  const waiting = correctionsDue(1e6).length;
  if (!waiting) return { waiting };
  if (!aiState.online) throw new Error(aiState.error || 'The AI is offline: the corrections are learnt from once it is back');
  if (!learningNow) logActivity('lesson', `Learning now from ${waiting} correction${waiting > 1 ? 's' : ''}, at your request`);
  learnNow(); emit('lessons');
  return { waiting };
}, { fg: true });
// A correction waiting to be learnt from: say why it was wrong, try a failed one again, or drop it.
on('PATCH', '/api/corrections/:id', (q_, p, b) => { const c = updateCorrection(Number(p.id), b); emit('lessons'); pump(); return c; });
on('DELETE', '/api/corrections/:id', (q_, p) => { const r = dropCorrection(Number(p.id)); emit('lessons'); return r; });

/** Archive every open task between other people at once: seen, nothing for you to do. One Ctrl+Z brings them all back. */
on('POST', '/api/tasks/archive-others', () => {
  const list = Tasks.where(`status='open' AND deleted_at IS NULL`).filter(t => directionOf(t) === 'others');
  if (!list.length) return { archived: 0 };
  const r = CLOSE.get('archived'), at = now(), ev0 = lastEventId(), ids = list.map(t => t.id);
  const befores = ids.map(id => snapshot('tasks', id)).filter(Boolean);
  tx(() => {
    for (const t of list) {
      // Only having seen them: the AI got nothing wrong, so nothing is kept to learn from.
      Tasks.update(t.id, { status: r.status, close_reason: r.code, closed_by: 'user', closed_at: at, closed_email_id: null, close_note: '', seen: 1 });
      addEvent(t.id, 'cancelled', `${r.event} by you, with every task between others`);
    }
  });
  pushUndo({ label: `Archive ${ids.length} task${ids.length === 1 ? '' : 's'} between others`, before: befores, events: null,
    extra: () => q(`DELETE FROM task_events WHERE id>? AND task_id IN (SELECT value FROM json_each(?))`).run(ev0, JSON.stringify(ids)) });
  logActivity('task', `Archived ${ids.length} task${ids.length === 1 ? '' : 's'} between others at once`);
  emit('tasks', 'status');
  return { archived: ids.length };
});

// ---------- the recycle bin ----------
// Delete sends tasks to the bin (Ctrl+Z or Restore brings them back); they are removed for good after tasks.binDays.
const idsOf = b => [...new Set([].concat(b.ids || []).map(Number).filter(Boolean))].slice(0, APP.lists.reprocessBatch);
const titled = ids => ids.length === 1 ? `"${q('SELECT title FROM tasks WHERE id=?').get(ids[0])?.title || 'task'}"` : `${ids.length} tasks`;
on('POST', '/api/tasks/delete', (q_, p, b) => {
  const ids = idsOf(b);
  if (!ids.length) throw new Error('No task chosen');
  const befores = ids.map(id => snapshot('tasks', id)).filter(Boolean), ev0 = lastEventId(), c0 = lastCorrectionId();
  // Deleting a task the AI found (still open, not already put right as not a task or a duplicate) says it should not
  // have been listed: kept, to learn from.
  const found = ids.map(id => Tasks.get(id)).filter(t => t && t.status === 'open' && !t.deleted_at);
  const done = deleteTasks(ids);
  if (!done.length) return { deleted: 0 };
  for (const t of found) if (done.includes(t.id)) noteCorrection(t, { kind: 'delete', field: 'task', was: 'a task', now: 'deleted', note: b.note });
  pushUndo({ label: `Delete ${titled(done)}`, before: befores.filter(x => done.includes(x.id)), events: null,
    extra: () => { q(`DELETE FROM task_events WHERE kind='deleted' AND id>? AND task_id IN (SELECT value FROM json_each(?))`).run(ev0, JSON.stringify(done)); done.forEach(id => forgetCorrections(id, c0)); } });
  logActivity('task', `Deleted ${titled(done)}: in the recycle bin for ${binDays()} days`, done.length === 1 ? String(done[0]) : null);
  emit('tasks', 'status', 'people', 'threads');
  return { deleted: done.length, days: binDays() };
});
on('GET', '/api/bin', () => ({ days: binDays(), tasks: tasksOut(binTasks()) }));
on('POST', '/api/bin/restore', (q_, p, b) => {
  const ids = idsOf(b);
  const label = titled(ids), done = restoreTasks(ids);
  done.forEach(id => forgetCorrections(id, 0, ['delete']));   // restored: the delete teaches nothing, if not learnt yet
  if (done.length) logActivity('task', `Restored ${label} from the recycle bin`, done.length === 1 ? String(done[0]) : null);
  emit('tasks', 'status', 'people', 'threads');
  return { restored: done.length };
});
/** Remove tasks from the bin for good: the ones given, or all of them (empty the bin). */
on('POST', '/api/bin/purge', (q_, p, b) => {
  const ids = b.all ? binTasks().map(t => t.id) : idsOf(b);
  const n = purgeTasks(ids);
  if (n) logActivity('task', `Recycle bin: ${n} task${n > 1 ? 's' : ''} removed for good by you`);
  emit('tasks', 'status');
  return { purged: n, left: binCount() };
});

/** Read the emails of these tasks again, from scratch, in the background: one task or many. What you corrected by hand is kept. */
on('POST', '/api/reprocess', (q_, p, b) => {
  const ids = idsOf(b);
  if (!ids.length) throw new Error('No task chosen');
  const rows = ids.map(id => q('SELECT title, conversation_id FROM tasks WHERE id=?').get(id)).filter(Boolean);
  const convs = [...new Set(rows.map(r => r.conversation_id))];
  rereadThreads(convs, { thorough: true });
  logActivity('task', `${ids.length === 1 ? `Reprocess: "${rows[0]?.title}"` : `${ids.length} tasks to reprocess`}: ${convs.length} thread${convs.length === 1 ? '' : 's'} queued`);
  pump(); emit('threads', 'status', 'activity');
  return { queued: convs.length };
});
/** Forward a task to others: the AI drafts the email, you review it, and sending it makes their task. */
on('POST', '/api/tasks/:id/forward', async (q_, p, b) => {
  const id = await foreground('Drafting your forward', () => draftForward(Number(p.id), { people: b.people, cc: b.cc, note: String(b.note || '').slice(0, F.note), deadline: b.deadline, close: !!b.close, source: b.source }));
  emit('drafts', 'tasks', 'status');
  return draftOut(Drafts.get(id));
}, { fg: true });
/** Forward a task to others without any email: their task is made now. */
on('POST', '/api/tasks/:id/assign', (q_, p, b) => {
  const id = assignTask(Number(p.id), { people: b.people, note: String(b.note || '').slice(0, F.note), deadline: b.deadline, close: !!b.close });
  emit('tasks', 'status', 'people');
  return { id };
});
/**
 * Acknowledge a task someone else asked of you: it is marked acknowledged and, when you ask for it (reply), the AI drafts
 * the reply telling them you have it, which you review before it is sent. When that draft fails, the task is left as it was.
 */
on('POST', '/api/tasks/:id/acknowledge', async (q_, p, b) => {
  const t = needTask(p.id);
  const why = cannotAck(t);
  if (why) throw new Error(why);
  const id = b.reply ? await foreground('Drafting your acknowledgement', () => draftFollowUp(t.id, String(b.note || '').slice(0, F.note), { ack: true, ccAll: !!b.ccAll })) : null;
  const done = remember(`Acknowledge "${t.title}"`, 'tasks', t.id);
  tx(() => {
    addEvent(t.id, 'acknowledged', `Acknowledged by you${id ? `: reply drafted to ${t.requester_name || t.requester_email}` : ''}`);
    Tasks.update(t.id, { acknowledged_at: now(), seen: 1 });
  });
  done();
  logActivity('task', `Acknowledged: "${t.title}"`, String(t.id));
  emit('drafts', 'tasks', 'status');
  return id ? draftOut(Drafts.get(id)) : { ok: true };
}, { fg: true });
/** Take an acknowledgement back. discard: also discard the acknowledgement emails not yet sent (a sent one stays sent). */
on('POST', '/api/tasks/:id/unacknowledge', (q_, p, b) => {
  const t = needTask(p.id);
  if (!t.acknowledged_at) throw new Error('This task is not acknowledged');
  const unsent = b.discard ? Drafts.where(`task_id=? AND status IN ('draft','outlook')`, t.id).filter(d => d.meta?.ack) : [];
  const done = remember(`Unacknowledge "${t.title}"`, 'tasks', t.id);
  tx(() => {
    addEvent(t.id, 'unacknowledged', `Acknowledgement taken back by you${unsent.length ? `; the unsent acknowledgement email was discarded` : ''}`);
    Tasks.update(t.id, { acknowledged_at: null, seen: 1 });
  });
  unsent.forEach(discardDraft);
  done();
  logActivity('task', `Unacknowledged: "${t.title}"`, String(t.id));
  emit('drafts', 'tasks', 'status');
  return { ok: true, discarded: unsent.length };
});
on('POST', '/api/tasks/:id/followup', async (q_, p, b) => {
  const id = await foreground('Drafting your follow-up', () => draftFollowUp(Number(p.id), String(b.instruction || '').slice(0, F.note), { ack: !!b.ack }));
  emit('drafts', 'tasks', 'status');
  return draftOut(Drafts.get(id));
}, { fg: true });

on('GET', '/api/threads', () => q(`SELECT t.*, COALESCE(k.open_tasks, 0) open_tasks, COALESCE(k.all_tasks, 0) all_tasks FROM threads t
  LEFT JOIN (SELECT conversation_id, SUM(status='open') open_tasks, SUM(status<>'dismissed' AND COALESCE(close_reason,'')<>'duplicate') all_tasks FROM tasks WHERE deleted_at IS NULL GROUP BY conversation_id) k ON k.conversation_id=t.id
  ORDER BY t.last_at DESC LIMIT ?`).all(APP.lists.threads));
on('GET', '/api/threads/:id', (q_, p) => threadDetail(id$(p)) || notFound('Thread'));
on('POST', '/api/threads/:id/reread', (q_, p) => {
  rereadThreads([id$(p)], { thorough: true });
  logActivity('task', `Read again carefully at your request, looking for a missed task: "${subjectOf(id$(p)) || 'a thread'}"`, id$(p));
  pump(); emit('threads', 'status'); return { ok: true };
});
// Stuck threads: the ones the AI failed on several times, waiting at the end of the queue.
on('GET', '/api/stuck', () => threadsStuck());
/** Try every stuck thread again now, still after the threads not yet tried. They keep their short extract. */
on('POST', '/api/stuck/retry', () => {
  const n = q(`UPDATE threads SET retry_at=? WHERE dirty=1 AND attempts>=?`).run(now(), tries()).changes;
  if (n) logActivity('system', `${n} stuck thread${n > 1 ? 's' : ''} queued again, after the rest`);
  pump(); emit('threads', 'status', 'activity'); return { queued: n };
});
on('GET', '/api/emails/:id', (q_, p) => { const e = Emails.get(id$(p)); return e ? msgOut(e, true) : notFound('Email'); });
on('POST', '/api/emails/:id/open', async (q_, p) => {
  const r = await outlook.display(id$(p)), e = Emails.get(id$(p));
  logActivity('outlook', `Email opened in Outlook: "${e?.subject || 'untitled'}"`, e?.conversation_id || null);
  return r;
});

on('GET', '/api/drafts', () => draftsOut(Drafts.where(`status<>'discarded' ORDER BY updated_at DESC LIMIT ?`, APP.lists.drafts)));
on('GET', '/api/drafts/:id', (q_, p) => draftOut(needDraft(p.id)));
on('PATCH', '/api/drafts/:id', (q_, p, b) => {
  const d = notBusy(needDraft(p.id));
  if (['sent', 'sending', 'discarded'].includes(d.status)) throw new Error('This draft can no longer be edited');
  const list = v => v == null ? null : [].concat(v).map(lc).filter(isEmail);
  const to = list(b.to), cc = list(b.cc);
  const changed = ['subject', 'body'].some(k => b[k] != null && b[k] !== d[k]) || (to && JSON.stringify(to) !== JSON.stringify(d.to)) || (cc && JSON.stringify(cc) !== JSON.stringify(d.cc));
  if (!changed) return draftOut(d);
  Drafts.update(d.id, { subject: noDash(b.subject ?? d.subject), body: noDash(b.body ?? d.body), ...(to ? { to } : {}), ...(cc ? { cc } : {}), status: 'draft', updated_at: now() });
  logActivity('draft', `Draft edited by you: ${b.subject ?? d.subject}`, String(d.id));
  emit('drafts'); return draftOut(Drafts.get(d.id));
});
/** Ask the AI for a new version with an instruction; the old draft is discarded. */
on('POST', '/api/drafts/:id/rewrite', async (q_, p, b) => {
  const d = notBusy(needDraft(p.id));
  if (!d.task_id || ['sent', 'sending'].includes(d.status)) throw new Error('This draft cannot be rewritten');
  const instruction = String(b.instruction || '').slice(0, F.note);
  const id = await foreground('Rewriting your draft', () => d.mode === 'forward' ? redraftForward(d, instruction) : draftFollowUp(d.task_id, instruction, { ack: d.meta.ack, ccAll: d.meta.ack && d.cc.length > 0 }));
  discardDraft(d);
  logActivity('draft', `Draft rewritten by the AI${instruction ? ` (${instruction})` : ''}: ${Drafts.get(id)?.subject || d.subject}`, String(id));
  emit('drafts', 'tasks'); return draftOut(Drafts.get(id));
}, { fg: true });
on('DELETE', '/api/drafts/:id', (q_, p) => {
  const d = notBusy(Drafts.get(p.id));
  if (d && ['draft', 'outlook'].includes(d.status)) {
    // Its Outlook copy is deleted with it, so an undo brings it back as a draft in Mandata only.
    const done = remember(`Discard draft "${d.subject || 'untitled'}"`, 'drafts', d.id,
      () => q(`UPDATE drafts SET status='draft', outlook_id=NULL WHERE id=?`).run(d.id));
    discardDraft(d); done();
    logActivity('draft', `Draft discarded by you: ${d.subject || 'untitled'}`, String(d.id));
  }
  emit('drafts', 'status'); return { ok: true };
});
on('POST', '/api/drafts/:id/outlook', async (q_, p) => { const d = needDraft(p.id); await onlyOnce(d, () => pushDraft(d)); logActivity('outlook', `Draft saved to Outlook: ${d.subject}`, String(d.id)); emit('drafts'); return { ok: true }; });
on('POST', '/api/drafts/:id/open', async (q_, p) => { const d = needDraft(p.id); await outlook.display(await onlyOnce(d, () => pushDraft(d))); logActivity('outlook', `Draft opened in Outlook: ${d.subject}`, String(d.id)); emit('drafts'); return { ok: true }; });
on('POST', '/api/drafts/:id/send', async (q_, p, b) => {
  if (b.confirm !== true) throw new Error('Sending needs your explicit confirmation');
  await sendDraft(needDraft(p.id));
  setTimeout(() => runSync('after sending'), I.afterSendSyncSec * 1000);
  return { ok: true };
});

on('GET', '/api/people', () => peopleList());
on('GET', '/api/people/:id', (q_, p) => profile(lc(id$(p)), tasksOut) || notFound('Person'));
on('PATCH', '/api/people/:id', (q_, p, b) => {
  const email = lc(id$(p)), x = People.get(email);
  if (!x) notFound('Person');
  const c0 = lastCorrectionId();
  const done = remember(b.hidden ? `Hide ${x.name || email}` : `Edit ${x.name || email}`, 'people', email, () => forgetPersonCorrections(email, c0));
  const edited = new Set(x.edited), set = {};
  for (const k of ['name', 'title', 'organization', 'unit', 'bio', 'tasking', 'relationship', 'notes']) {
    if (b[k] == null || b[k] === x[k]) continue;
    set[k] = noDash(String(b[k]).trim());
    if (k === 'notes') continue;
    // What the AI read (from a signature or emails), put right by you, is kept to learn from; your own words changed again are not.
    if (!x.edited.includes(k) && set[k] !== String(x[k] || '').trim()) notePersonCorrection(x, { field: k, was: x[k], now: set[k] });
    edited.add(k);
  }
  if (b.hidden != null) set.hidden = b.hidden ? 1 : 0;
  People.update(email, { ...set, edited: [...edited] });
  // Other names: the list you give is theirs; one the mail suggested and you left out is not shown again.
  const aka = Array.isArray(b.aka) ? setOtherNames(email, b.aka) : { added: [], removed: [] };
  done();
  if (aka.added.length || aka.removed.length) logActivity('people', `${set.name || x.name || email}: other names ${[aka.added.length ? `${aka.added.join(', ')} added` : '', aka.removed.length ? `${aka.removed.join(', ')} removed` : ''].filter(Boolean).join(', ')} by you`, email);
  const what = Object.keys(set).filter(k => k !== 'hidden');
  if (b.hidden != null && !!b.hidden !== !!x.hidden) logActivity('people', `${x.name || email} ${b.hidden ? 'hidden' : 'shown again'} by you`, email);
  if (what.length) logActivity('people', `${set.name || x.name || email}: ${what.join(', ')} edited by you`, email);
  emit('people'); return profile(email, tasksOut);
});
on('POST', '/api/people/:id/bio', async (q_, p) => { const email = lc(id$(p)); await foreground('Writing a profile you asked for', () => writeBio(email, { asked: true })); emit('people'); return profile(email, tasksOut); }, { fg: true });

// ---------- Ask Mandata: conversations with the AI about what Mandata holds (the answer itself streams: see askStream) ----------
on('GET', '/api/ask', q_ => listConversations(q_.get('q') || ''));
on('GET', '/api/ask/starters', () => starters());
on('GET', '/api/ask/:id', (q_, p) => getConversation(p.id));
on('PATCH', '/api/ask/:id', (q_, p, b) => {
  const r = updateConversation(p.id, { title: b.title, pinned: b.pinned });
  if (b.title != null) logActivity('ask', `Conversation renamed by you: ${b.title}`, String(p.id));
  if (b.pinned != null) logActivity('ask', `Conversation ${b.pinned ? 'pinned' : 'unpinned'} by you`, String(p.id));
  return r;
});
/** Export: the conversation printed to a PDF file in Documents\Mandata reports, then opened in the PDF viewer. */
on('POST', '/api/ask/:id/export', async (q_, p) => {
  const c = getConversation(p.id);
  // A file name from the title: no character Windows refuses, and not too long.
  const name = `Mandata conversation - ${c.title.replace(/[\\/:*?"<>|\u0000-\u001f]+/g, ' ').replace(/\s+/g, ' ').trim().slice(0, 80).replace(/[. ]+$/, '')}`;
  const file = await savePdf(await pdfFromUrl(`http://${APP.host}:${PORT}/api/ask/${c.id}/html`), name);
  logActivity('ask', `Conversation exported to ${file}`, String(c.id));
  emit('activity');
  await openFile(file).catch(e => logActivity('error', `Could not open ${file}: ${e.message}`));
  return { file };
}, { fg: true });
/** A conversation as a page: what its PDF prints. */
on('GET', '/api/ask/:id/html', (req, res, url, p) => {
  try {
    const html = conversationHtml(getConversation(p.id), { me: config().me?.name || '' });
    res.writeHead(200, { 'content-type': 'text/html; charset=utf-8', 'cache-control': 'no-store' });
    res.end(html);
  } catch (e) { send(res, e.status || 500, { error: e.message }); }
}, { raw: true });
on('DELETE', '/api/ask/:id', (q_, p) => { const ok = deleteConversation(p.id); if (ok) logActivity('ask', 'Conversation deleted by you'); return { ok }; });

/**
 * A question to Ask Mandata, answered as it is written: one JSON line per event (start, phase, token, done or error).
 * Closing the request (Stop on the page) stops the AI; what it wrote by then is kept.
 */
async function askStream(req, res) {
  const b = await bodyOf(req, res);
  if (!aiState.online) await checkAI();
  res.writeHead(200, { 'content-type': 'application/x-ndjson; charset=utf-8', 'cache-control': 'no-store', 'x-accel-buffering': 'no' });
  const stop = new AbortController();
  let finished = false;
  res.on('close', () => { if (!finished) stop.abort(); });
  const send = ev => { if (!res.writableEnded) res.write(JSON.stringify(ev) + '\n'); };
  try {
    if (!aiState.online) throw new Error(aiState.error || 'The AI is offline: Ask Mandata needs it to answer.');
    const question = String(b.question || '').trim();
    if (question || b.retry) logActivity('ask', b.retry ? 'Asked Mandata to answer again' : `Asked Mandata: ${question.slice(0, 160)}`, b.conversation_id ? String(b.conversation_id) : null);
    await ask({ conversationId: b.conversation_id || null, question: b.question, retry: b.retry || null, signal: stop.signal, send });
  } catch (e) { send({ t: 'error', error: e.message }); }
  finished = true;
  res.end();
  emit('ask');
}
on('POST', '/api/ask/answer', askStream, { raw: true, fg: true });

// One day of the log at a time (this computer's calendar), with every day that has entries, newest first, to pick another.
on('GET', '/api/activity', s => {
  const day = /^\d{4}-\d{2}-\d{2}$/.test(s.get('day') || '') ? s.get('day') : localDate();
  return { day, list: q(`SELECT * FROM activity WHERE date(at, 'localtime') = ? ORDER BY id DESC`).all(day),
    days: q(`SELECT date(at, 'localtime') AS day, COUNT(*) AS n FROM activity GROUP BY 1 ORDER BY 1 DESC`).all() };
});

// ---------- weekly reports (the document itself: see reportPage) ----------
const needWeek = p => { const k = id$(p).toUpperCase(); if (!isWeekKey(k)) throw Object.assign(new Error('Not a week: ' + k), { status: 400 }); return k; };
on('GET', '/api/reports', () => ({ weeks: listWeeks() }));
on('POST', '/api/reports/:id/generate', async (q_, p) => { const r = await writeReport(needWeek(p)); emit('reports', 'activity'); return r; }, { fg: true });
/** Export: the report printed to a PDF file in Documents\Mandata reports, then opened in the PDF viewer. Written first when it never was. */
on('POST', '/api/reports/:id/export', async (q_, p) => {
  const key = needWeek(p);
  if (!hasReport(key)) { await writeReport(key); emit('reports'); }
  const file = await savePdf(await pdfFromUrl(`http://${APP.host}:${PORT}/api/reports/${key}/html`), `Mandata weekly report ${key}`);
  logActivity('report', `Weekly report for ${key} exported to ${file}`, key);
  emit('activity');
  await openFile(file).catch(e => logActivity('error', `Could not open ${file}: ${e.message}`));
  return { file };
}, { fg: true });

/** The report of a week as a page: what the PDF prints (?view=screen: as shown on screen). */
function reportPage(req, res, url, p) {
  try {
    const key = needWeek(p), html = reportHtml(reportForDoc(key), { screen: url.searchParams.get('view') === 'screen' });
    res.writeHead(200, { 'content-type': 'text/html; charset=utf-8', 'cache-control': 'no-store' });
    res.end(html);
  } catch (e) { send(res, e.status || 500, { error: e.message }); }
}
on('GET', '/api/reports/:id/html', reportPage, { raw: true });

// ---------- http ----------
const MIME = { '.html': 'text/html', '.js': 'text/javascript', '.css': 'text/css', '.svg': 'image/svg+xml', '.json': 'application/json', '.png': 'image/png', '.ico': 'image/x-icon',
  '.woff2': 'font/woff2', '.woff': 'font/woff' };
const TEXT = /^text\/|\/(json|svg\+xml)$/;
// An answer already under way (a stream, a file) is only ended: its headers are gone.
const send = (res, code, body, headers = {}) => {
  if (res.headersSent) { if (!res.writableEnded) res.end(); return; }
  res.writeHead(code, { 'content-type': 'application/json', 'cache-control': 'no-store', ...headers }); res.end(JSON.stringify(body));
};
// Decoded once, whole: a character split across two chunks stays whole. Bodies over 10 MB are refused: told so, then the
// connection is closed. A body that is not a JSON object (a list, a number) is taken as empty.
const bodyOf = (req, res) => new Promise((ok, bad) => {
  const parts = []; let n = 0, over = false;
  req.on('data', d => {
    if (over) return;
    n += d.length;
    if (n <= 10e6) return parts.push(d);
    over = true; parts.length = 0;
    const err = Object.assign(new Error('Request too large'), { status: 413 });
    // The rest is read and dropped for a moment, so the answer reaches the sender before the connection is cut.
    res.on('finish', () => setTimeout(() => req.destroy(), 1000).unref());
    send(res, 413, { error: err.message }, { connection: 'close' });
    bad(err);
  });
  req.on('end', () => { if (over) return; try { const s = Buffer.concat(parts).toString('utf8'), v = s ? JSON.parse(s) : {}; ok(v && typeof v === 'object' && !Array.isArray(v) ? v : {}); } catch (e) { bad(e); } });
  req.on('error', bad);
});

// Another website open in a browser must not be able to drive this app (for example, send a draft). Only requests
// addressed to this server by name (no DNS rebinding), and for changes, JSON sent from this app's own page, are served.
const hosts = () => new Set([`localhost:${PORT}`, `${APP.host}:${PORT}`]);
function allowed(req) {
  const H = hosts();
  if (!H.has(String(req.headers.host || '').toLowerCase())) return false;
  // A page on another site can still make the browser fetch a GET (an image, a link): refused when the browser says so.
  const site = req.headers['sec-fetch-site'];
  if (site && site !== 'same-origin' && site !== 'none') return false;
  if (['GET', 'HEAD'].includes(req.method)) return true;
  const origin = req.headers.origin;
  if (origin && !H.has(origin.replace(/^https?:\/\//, '').toLowerCase())) return false;
  const type = req.headers['content-type'] || '';
  // A backup file is sent as itself. A page on another site cannot send this type without asking first (CORS), and is refused.
  if (req.method === 'POST' && req.url.split('?')[0] === '/api/data/import') return /^application\/octet-stream\b/i.test(type);
  return /^application\/json\b/i.test(type);
}

// Phone access (lib/phone.js): switched on, paired and signed out from Settings > Phone, on this computer only.
on('GET', '/api/phone', () => phoneInfo());
on('PUT', '/api/phone', (q_, p, b) => setPhone(b));
on('POST', '/api/phone/code', () => newCode());
on('POST', '/api/phone/forget', (q_, p, b) => forgetPhone(b.id ? String(b.id) : null));

// Live updates: the page and the desktop app listen here.
on('GET', '/api/events', (req, res) => {
  res.writeHead(200, { 'content-type': 'text/event-stream', 'cache-control': 'no-store', connection: 'keep-alive' });
  res.write(`retry: ${I.sseRetryMs}\n\n`); clients.add(res);
  const ka = setInterval(() => res.write(': keep-alive\n\n'), I.sseKeepAliveSec * 1000);
  req.on('close', () => { clients.delete(res); clearInterval(ka); });
}, { raw: true });

// index.html read again only when it changed (an update), not on every load.
let indexFile = { mtime: 0, html: '' };
function indexHtml(f) {
  const mtime = fs.statSync(f).mtimeMs;
  if (mtime !== indexFile.mtime) indexFile = { mtime, html: fs.readFileSync(f, 'utf8') };
  return indexFile.html;
}

/** An API request, answered by its route. Also called by phone access for the routes a paired phone may use. */
async function serveApi(req, res, url) {
  for (const r of routes) {
    const m = r.method === req.method && url.pathname.match(r.re);
    if (!m) continue;
    if (r.fg && holding) return send(res, 409, { error: 'The data is being changed. Try again in a moment.' });
    if (r.raw) return r.fn(req, res, url, m.groups || {});
    try {
      const b = ['POST', 'PUT', 'PATCH'].includes(req.method) ? await bodyOf(req, res) : {};
      return send(res, 200, await r.fn(url.searchParams, m.groups || {}, b) ?? {});
    } catch (e) { return send(res, e.status || (e instanceof SyntaxError ? 400 : 500), { error: e.message }); }
  }
  return send(res, 404, { error: 'No such API route' });
}

async function handle(req, res) {
  if (!allowed(req)) return send(res, 403, { error: 'Requests must come from the Mandata app' });
  const url = new URL(req.url, 'http://localhost');
  if (url.pathname.startsWith('/api/')) return serveApi(req, res, url);
  let f = path.normalize(path.join(PUBLIC, decodeURIComponent(url.pathname === '/' ? '/index.html' : url.pathname)));
  if (!f.startsWith(PUBLIC + path.sep) || !fs.existsSync(f) || fs.statSync(f).isDirectory()) f = path.join(PUBLIC, 'index.html');
  // The page arrives with your saved preferences in it, so it opens as you left it before anything else loads.
  if (f === path.join(PUBLIC, 'index.html')) {
    let html;
    try { html = indexHtml(f); } catch { return res.destroy(); }
    let prefs = {};
    try { prefs = getState('ui.prefs', {}) || {}; } catch {}
    html = html.replace('<!--PREFS-->', `<script>window.MANDATA_PREFS = ${JSON.stringify(prefs).replace(/</g, '\\u003c')};</script>`);
    res.writeHead(200, { 'content-type': 'text/html; charset=utf-8', 'cache-control': 'no-store' });
    return res.end(html);
  }
  const type = MIME[path.extname(f)] || 'application/octet-stream';
  res.writeHead(200, { 'content-type': TEXT.test(type) ? type + '; charset=utf-8' : type, 'cache-control': 'no-store' });
  // A file locked or gone between the check and the read (an update, OneDrive) is an error for this request only.
  fs.createReadStream(f).on('error', () => res.destroy()).pipe(res);
}

const server = http.createServer(async (req, res) => {
  try { await handle(req, res); }
  catch (e) { if (!res.headersSent) send(res, 400, { error: e.message }); else res.end(); }
});

let started = null, intervals = [];
/** Start once. Resolves with the port when the server is listening. If another instance holds the port, it is asked to stop. */
export function startServer({ port } = {}) {
  if (started) return started;
  if (port) PORT = port;
  outlook.use(config().sync.source);
  // Background work runs unawaited (mail reading, AI start): a failure there is logged, in the desktop app too, never fatal.
  process.on('unhandledRejection', err => { console.error(err); try { logActivity('error', 'Unexpected error: ' + (err?.message || err)); } catch {} });
  started = new Promise((resolve, reject) => {
    let attempts = 0;
    server.on('error', async err => {
      if (err.code !== 'EADDRINUSE' || ++attempts > 10) return reject(err);
      if (attempts === 1) await fetch(`http://${APP.host}:${PORT}/api/shutdown`, { method: 'POST', headers: { 'content-type': 'application/json', origin: `http://${APP.host}:${PORT}` }, body: '{}' }).catch(() => {});
      setTimeout(() => server.listen(PORT, APP.host), 700);
    });
    server.on('listening', async () => {
      const n = t => q(`SELECT COUNT(*) n FROM ${t}`).get().n;
      console.log(`Mandata v${pkg.version} on http://localhost:${PORT}  (data: ${DATA_DIR}, schema ${SCHEMA})`);
      console.log(`Loaded ${n('emails')} emails, ${n('threads')} threads, ${n('tasks')} tasks, ${n('people')} people.`);
      logActivity('system', `Started v${pkg.version}`);
      resolve(PORT);
      // Repairs of what is stored, each on its own: [what it does, what it refreshes when it changed something, what failed].
      for (const [fn, events, failed] of [
        [backfillSignatures, [], 'Could not queue stored signatures'],
        [backfillNames, ['people'], 'Could not read the other names in stored mail'],
        [repairTaskPeople, ['tasks', 'people'], 'Could not check the people on tasks'],
        [repairShared, ['tasks'], 'Could not sort the tasks asked of you among others'],
        [repairUnsureShared, ['tasks'], 'Could not sort the doubtful tasks written to a group'],
        [repairAutoReplies, ['tasks'], 'Could not check automatic replies'],
        [() => repairMissedTasks(), ['threads'], 'Could not queue the threads with no task to read again'],
        [clearAssumedDeadlines, ['tasks'], 'Could not remove the assumed deadlines'],
        [mergeSameAsks, ['tasks'], 'Could not fold tasks of one ask'],
        [flagNoTaskThreads, ['threads'], 'Could not flag the threads with no task'],
      ]) try { if (fn() && events.length) emit(...events); } catch (err) { logActivity('error', `${failed}: ${err.message}`); }
      // The AI server started and the model pulled when missing, in the background: a first download takes minutes.
      prepareAI();
      intervals.push(setInterval(() => (aiState.online || config().ai.paused ? checkAI() : prepareAI()).then(() => {
        try { if (rereadLongThreads()) emit('threads'); } catch (err) { logActivity('error', 'Could not queue long threads: ' + err.message); }
        emit('status'); pump();
      }), I.aiCheckSec * 1000));
      const binSweep = () => { try { if (purgeExpired()) emit('tasks', 'status', 'activity'); } catch (err) { logActivity('error', 'Could not empty the recycle bin: ' + err.message); } };
      binSweep();
      // Days left change at midnight: the lists are refreshed once the date has changed, not at every check.
      let day = today();
      intervals.push(setInterval(() => { dailyDigest(); binSweep(); if (today() !== day) { day = today(); emit('tasks'); } }, I.digestMin * 60000));
      intervals.push(setTimeout(dailyDigest, I.digestFirstSec * 1000));   // timeouts too: clearInterval clears either
      // Parked tasks whose park period is over are open again (Settings > Tasks), checked every minute.
      const unparkSweep = () => { try { if (unparkDue()) emit('tasks', 'status', 'activity'); } catch (err) { logActivity('error', 'Could not bring back parked tasks: ' + err.message); } };
      unparkSweep();
      intervals.push(setInterval(unparkSweep, 60000));
      intervals.push(setInterval(dailyMail, I.dailyMailCheckSec * 1000));
      intervals.push(setTimeout(dailyMail, I.dailyMailFirstSec * 1000));   // missed while the app was closed: sent as it starts
      runSync('startup').finally(schedule);
      startPhone({ serveApi, publicDir: PUBLIC, emit });
      updater.startUpdater({ version: pkg.version, broadcast, notify: (title, body, route) => broadcast({ type: 'notify', title, body, route }), busy: () => !!aiState.focus || holding });
    });
    server.listen(PORT, APP.host);
  });
  return started;
}

/** Stop cleanly: fold the write-ahead log into the database file and close it, so the next start finds everything. */
// Nothing new starts once it stops (mail checks, background reading), and the model call in progress is cut short.
export function stopServer() {
  if (stopping) return;
  stopping = true;
  clearTimeout(timer); clearTimeout(statusTimer); clearTimeout(activityTimer); intervals.forEach(clearInterval); updater.stopUpdater();
  for (const c of clients) try { c.end(); } catch {}
  clients.clear();
  try { server.close(); } catch {}
  stopPhone();
  stopAll('Set aside: Mandata is stopping');
  outlook.stop();
  try { db.exec('PRAGMA optimize; PRAGMA wal_checkpoint(TRUNCATE)'); db.close(); } catch {}
}

/** The desktop app: how to restart it for an update, and whether its window shows (lib/updater.js). */
export const { setUpdateHost, onQuit: updateOnQuit, windowChanged: updateWindowChanged } = updater;

// Only one server may run: a newer start asks the old one to stop.
on('POST', '/api/shutdown', () => {
  logActivity('system', 'Stopped so a newer start could take over');
  setTimeout(() => { stopServer(); process.exit(0); }, 150);
  return { ok: true };
});

// Run on its own with `node server.js`; the desktop app imports it and calls startServer().
if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  for (const sig of ['SIGINT', 'SIGTERM', 'SIGBREAK', 'SIGHUP']) process.on(sig, () => { stopServer(); process.exit(0); });
  startServer().catch(e => { console.error(e.message); process.exit(1); });
}
