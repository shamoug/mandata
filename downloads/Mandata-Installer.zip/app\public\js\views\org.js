// Organisation: organisations hold divisions, then branches, sections and teams. The AI places people from their email signatures;
// here you create, rename, move and remove units, and put people in them by hand (your placement is kept).
import { GET, api, esc, $, $$, icon, avatar, toast, modal, confirmBox, enc, peopleSwitch, pref, setPref, latest, debounce, errorBox } from '../ui.js';
import { onView, go } from '../store.js';

const TYPE = { organization: { label: 'Organisation', color: '#c92a2a', child: 'division' }, division: { label: 'Division', color: '#1098ad', child: 'branch' },
  branch: { label: 'Branch', color: '#4263eb', child: 'section' }, section: { label: 'Section', color: '#0ca678', child: 'team' }, team: { label: 'Team', color: '#f76707', child: null } };
let root, units = [], people = [], q = pref('orgq', ''), focus = '';

export function mount(el, arg) {
  focus = arg || '';
  root = el;
  el.innerHTML = `<div class="page"><div class="fbar"><h2 class="ptitle">${icon('people', 18)} Organisation</h2>${peopleSwitch('org')}
    <span class="muted small" title="Organisations › Divisions › Branches › Sections › Teams">Read from email signatures; change anything by hand.</span><span class="sp"></span>
    <button class="btn primary" id="oNew">${icon('plus', 14)} New organisation</button></div>
    <div class="orggrid"><div id="oTree"></div><aside><section class="panel"><h3>${icon('user', 15)} Not placed yet <span class="muted" id="oCount"></span></h3>
      <label class="search" style="margin-bottom:8px">${icon('search', 14)}<input type="search" id="oQ" placeholder="Search people"></label>
      <div id="oFree" class="freelist"></div>
      <div class="btnrow" style="margin-top:8px"><select id="oTo" style="flex:1"></select><button class="btn sm primary" id="oPut">Place</button></div></section></aside></div></div>`;
  $('#oNew', el).onclick = () => editUnit({ type: 'organization' });
  $('#oQ', el).value = q;
  $('#oQ', el).oninput = debounce(e => { q = e.target.value.toLowerCase(); setPref('orgq', q); if ($('#oFree', root)) renderFree(); }, 150);
  $('#oPut', el).onclick = async () => {
    const emails = $$('#oFree input:checked', el).map(i => i.value);
    if (!emails.length) return toast('Tick the people to place', true);
    try { await api('POST', '/api/org/assign', { emails, unit_id: $('#oTo', el).value }); toast(`Placed ${emails.length}`); } catch (e) { toast(e.message, true); }
  };
  $('#oTree', el).onclick = treeClick;
  load(); onView('org', load); onView('people', load);
}

const load = latest(() => Promise.all([GET('/api/org'), GET('/api/people')]), ([o, p]) => { units = o.units; people = p; render(); },
  e => { const box = root && $('#oTree', root); if (box && !units.length) box.innerHTML = errorBox(e); else if (box) toast(`Could not load the organisation: ${e.message}`, true); });
const kids = id => units.filter(u => (u.parent_id || null) === id).sort((a, b) => a.name.localeCompare(b.name));
const members = id => people.filter(p => p.unit_id === id);
const optionList = () => units.map(u => `<option value="${esc(u.id)}">${esc(TYPE[u.type]?.label)}: ${esc(u.name)}</option>`).join('');

function unitBox(u, depth = 0) {
  const t = TYPE[u.type] || TYPE.team, m = members(u.id);
  return `<div class="ubox d${depth}" style="--c:${t.color}" data-u="${esc(u.id)}">
    <div class="ub-head"><span class="ub-type">${t.label}</span><b data-go="#/tasks/?unit=${enc(u.id)}" title="Tasks of this ${t.label.toLowerCase()}">${esc(u.name)}</b>${u.lead_email ? `<a class="uchip" data-person="${esc(u.lead_email)}" title="Lead">${icon('user', 10)} ${esc(people.find(x => x.email === u.lead_email)?.name || u.lead_email)}</a>` : ''}${u.auto ? '<span class="muted small" title="Found in email signatures">· from signatures</span>' : ''}
      <span class="sp"></span><span class="badge" data-go="#/tasks/?unit=${enc(u.id)}" title="Tasks of these people">${m.length} ${m.length === 1 ? 'person' : 'people'}</span>${m.some(p => p.late) ? `<span class="badge red" title="Late tasks">${m.reduce((n, p) => n + p.late, 0)} late</span>` : ''}
      <button class="mini" data-a="tasks" title="Tasks of this ${t.label.toLowerCase()}">${icon('list', 13)}</button>
      <button class="mini" data-a="add" title="Put people here">${icon('user', 13)}</button>
      ${t.child ? `<button class="mini" data-a="sub" title="Add a ${TYPE[t.child].label.toLowerCase()}">${icon('plus', 13)}</button>` : ''}
      <button class="mini" data-a="edit" title="Edit">${icon('edit', 13)}</button><button class="mini" data-a="del" title="Remove">${icon('trash', 13)}</button></div>
    ${m.length ? `<div class="ub-people">${m.map(p => `<a class="mchip" data-person="${esc(p.email)}">${avatar(p.name, p.email, 'xs')}${esc(p.name)}${p.owns_open ? `<em title="${p.owns_open} open task${p.owns_open > 1 ? 's' : ''}">${p.owns_open}</em>` : ''}</a>`).join('')}</div>` : ''}
    ${kids(u.id).map(k => unitBox(k, depth + 1)).join('')}</div>`;
}

/** #/org/<unit id> opens the page on that unit, highlighted. */
export function select(arg) { focus = arg || ''; showFocus(); }
function showFocus() {
  if (!focus || !root || !$('#oTree', root)) return;
  const b = root.querySelector(`[data-u="${CSS.escape(focus)}"]`); if (!b) return;
  focus = '';
  b.scrollIntoView({ behavior: 'smooth', block: 'center' }); b.classList.remove('flash'); void b.offsetWidth; b.classList.add('flash');
}

function render() {
  // root is #main, there for every page: the view is still on screen only while its own list is.
  if (!root || !$('#oTree', root)) return;
  const rank = t => Object.keys(TYPE).indexOf(t);
  const tops = units.filter(u => !u.parent_id || !units.some(x => x.id === u.parent_id)).sort((a, b) => rank(a.type) - rank(b.type) || a.name.localeCompare(b.name));
  $('#oTree', root).innerHTML = tops.map(u => unitBox(u)).join('') || `<div class="empty">${icon('people', 40)}<p>No units yet. They appear as the AI reads signatures, or create one.</p><button class="btn primary" data-a="new">${icon('plus', 14)} New organisation</button></div>`;
  $('#oTo', root).innerHTML = optionList();
  renderFree();
  showFocus();
}
function renderFree() {
  // The people you ticked stay ticked when the list is drawn again (it is, each time mail brings someone new).
  const ticked = new Set([...root.querySelectorAll('#oFree input:checked')].map(i => i.value));
  const free = people.filter(p => !p.unit_id && (!q || [p.name, p.email, p.organization, p.unit].join(' ').toLowerCase().includes(q)));
  $('#oCount', root).textContent = people.filter(p => !p.unit_id).length;
  $('#oFree', root).innerHTML = free.slice(0, 300).map(p => `<label class="freep"><input type="checkbox" value="${esc(p.email)}" ${ticked.has(p.email) ? 'checked' : ''}>${avatar(p.name, p.email, 'xs')}<span><b>${esc(p.name)}</b><small class="muted clamp1">${esc(p.unit || p.organization || p.email)}</small></span></label>`).join('')
    || '<div class="muted small">Everyone is placed.</div>';
}

async function treeClick(e) {
  const b = e.target.closest('[data-a]'); if (!b) return;
  if (b.dataset.a === 'new') return editUnit({ type: 'organization' });
  const u = units.find(x => x.id === b.closest('[data-u]').dataset.u); if (!u) return;   // removed since the tree was drawn
  const a = b.dataset.a;
  if (a === 'tasks') go('tasks', '?unit=' + u.id);
  if (a === 'sub') editUnit({ type: TYPE[u.type].child, parent_id: u.id });
  if (a === 'edit') editUnit(u);
  if (a === 'add') addPeople(u);
  if (a === 'del' && await confirmBox('Remove unit', `Remove <b>${esc(u.name)}</b>? Its people and sub-units move up one level.`, 'Remove')) { try { await api('DELETE', '/api/org/' + enc(u.id)); toast('Removed'); } catch (e) { toast(e.message, true); } }
}

function editUnit(u) {
  const parents = units.filter(x => x.id !== u.id);
  const m = modal({ title: u.id ? 'Edit unit' : `New ${TYPE[u.type]?.label.toLowerCase() || 'unit'}`, size: 'small', body: `
    <label class="f">Name</label><input type="text" id="uName" value="${esc(u.name || '')}">
    <label class="f">Kind</label><select id="uType" style="width:100%">${Object.entries(TYPE).map(([k, t]) => `<option value="${k}" ${k === u.type ? 'selected' : ''}>${t.label}</option>`).join('')}</select>
    <label class="f">Part of</label><select id="uParent" style="width:100%"><option value="">(top level)</option>${parents.map(x => `<option value="${esc(x.id)}" ${x.id === u.parent_id ? 'selected' : ''}>${esc(TYPE[x.type]?.label)}: ${esc(x.name)}</option>`).join('')}</select>
    <label class="f">Lead (email)</label><input type="email" id="uLead" value="${esc(u.lead_email || '')}" list="uPeople"><datalist id="uPeople">${people.map(p => `<option value="${esc(p.email)}">${esc(p.name)}</option>`).join('')}</datalist>`,
    footer: `<div class="btnrow"><button class="btn primary" id="uSave">Save</button></div>` });
  $('#uName', m.el).focus();
  $('#uSave', m.el).onclick = async () => {
    const b = { name: $('#uName', m.el).value, type: $('#uType', m.el).value, parent_id: $('#uParent', m.el).value || null, lead_email: $('#uLead', m.el).value };
    try { await api(u.id ? 'PATCH' : 'POST', '/api/org' + (u.id ? '/' + enc(u.id) : ''), b); m.close(true); toast('Saved'); } catch (e) { toast(e.message, true); }
  };
}

function addPeople(u) {
  const m = modal({ title: `Put people in ${u.name}`, body: `<label class="search">${icon('search', 14)}<input type="search" id="apQ" placeholder="Search anyone"></label><div class="freelist tall" id="apList"></div>`,
    footer: `<div class="btnrow"><button class="btn primary" id="apGo">Place the ticked people</button></div>` });
  const draw = (s = '') => $('#apList', m.el).innerHTML = people.filter(p => !s || [p.name, p.email, p.organization].join(' ').toLowerCase().includes(s)).slice(0, 300)
    .map(p => `<label class="freep"><input type="checkbox" value="${esc(p.email)}" ${p.unit_id === u.id ? 'checked disabled' : ''}>${avatar(p.name, p.email, 'xs')}<span><b>${esc(p.name)}</b><small class="muted clamp1">${esc(p.unit_id ? 'In ' + (units.find(x => x.id === p.unit_id)?.name || '') : p.organization || p.email)}</small></span></label>`).join('');
  draw();
  $('#apQ', m.el).oninput = e => draw(e.target.value.toLowerCase());
  $('#apGo', m.el).onclick = async () => {
    const emails = $$('#apList input:checked:not(:disabled)', m.el).map(i => i.value);
    try { await api('POST', '/api/org/assign', { emails, unit_id: u.id }); m.close(true); toast(`Placed ${emails.length}`); } catch (e) { toast(e.message, true); }
  };
}
