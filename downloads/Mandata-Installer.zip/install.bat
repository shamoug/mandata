@echo off
rem Installs or updates Mandata for this Windows user: checks what is missing, downloads it, installs the app to
rem %LOCALAPPDATA%\Programs\Mandata and adds Start Menu and Desktop shortcuts. No admin rights, no setup program.
rem Options are passed on, for example:  install.bat -AI no -NoLaunch
title Install Mandata
cd /d "%~dp0"
set "MANDATA_DIR=%~dp0"

rem A zip received by email, Teams or a browser marks its files as downloaded, which can stop PowerShell from running
rem the scripts. The mark is removed from this folder's own files, as Properties > Unblock would.
powershell -NoProfile -Command "Get-ChildItem -LiteralPath $env:MANDATA_DIR -Recurse -File | Unblock-File -ErrorAction SilentlyContinue"

rem An IT policy that allows only signed scripts (or none) cannot be passed over: say so plainly.
powershell -NoProfile -Command "if (@((Get-ExecutionPolicy -Scope MachinePolicy), (Get-ExecutionPolicy -Scope UserPolicy)) -match '^(Restricted|AllSigned)$') { exit 3 }"
if errorlevel 3 (
  echo.
  echo   An IT policy on this computer blocks PowerShell scripts, so Mandata cannot be installed this way.
  echo   Ask IT to allow it, or to install Mandata for you.
  echo.
  pause
  exit /b 1
)

powershell -NoProfile -ExecutionPolicy Bypass -File "scripts\install.ps1" %*
echo.
pause
