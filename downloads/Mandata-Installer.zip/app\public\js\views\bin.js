// The recycle bin: tasks you deleted. Each waits here for the days set in Settings > Tasks, then is removed for good.
// Restore brings one back as it was; a new email about it brings it back on its own.
import { api, GET, esc, $, $$, icon, confirmBox, avatar, dirChip, statusChip, fullDate, dateLabel, toast, busy, plural, latest, errorBox } from '../ui.js';
import { onView } from '../store.js';

let root, list = [], days = 30;
const picked = new Set();

export function mount(el) {
  root = el;
  el.innerHTML = `<div class="page bin">
    <div class="fbar"><h2 class="ptitle">${icon('trash', 18)} Recycle bin</h2><span class="sp"></span>
      <button class="btn sm ghost" data-go="#/tasks">${icon('tasks', 13)} Back to tasks</button></div>
    <p class="muted small bin-hint" id="bHint"></p>
    <div class="pickbar" id="bBar"></div>
    <div id="bList"></div></div>`;
  $('#bBar', el).onclick = e => { const b = e.target.closest('[data-b]'); if (b) act(b.dataset.b, [...picked], b); };
  $('#bList', el).addEventListener('click', e => {
    const one = e.target.closest('[data-one]');
    if (one) { e.stopPropagation(); act(one.dataset.one, [Number(one.closest('[data-task]').dataset.task)], one); return; }
    const cb = e.target.closest('input[type=checkbox]');
    if (!cb) return;
    e.stopPropagation();
    if (cb.id === 'bAll') { picked.clear(); if (cb.checked) list.forEach(t => picked.add(t.id)); }
    else { const id = Number(cb.dataset.pick); cb.checked ? picked.add(id) : picked.delete(id); }
    paint();
  }, true);
  load();
  onView('tasks', load);
}

// Only the newest answer is drawn: the bin is asked for again on every change to the tasks, and answers can land out of order.
const load = latest(() => GET('/api/bin'), r => {
  ({ tasks: list, days } = r);
  for (const id of [...picked]) if (!list.some(t => t.id === id)) picked.delete(id);
  render();
}, e => { const box = root && $('#bList', root); if (box && !list.length) box.innerHTML = errorBox(e); else if (box) toast(`Could not load the recycle bin: ${e.message}`, true); });

const left = t => Math.max(0, Math.ceil((Date.parse(t.purge_at) - Date.now()) / 864e5));
const leftLabel = t => { const n = left(t); return n === 0 ? 'Today' : n === 1 ? 'Tomorrow' : `In ${n} days`; };

function render() {
  // root is #main, there for every page: the view is still on screen only while its own list is.
  if (!root || !$('#bList', root)) return;
  $('#bHint', root).innerHTML = `Deleted tasks stay here for <b>${plural(days, 'day')}</b> (change it in Settings, Tasks), then are removed for good.
    They are out of every list, and reading the mail again does not bring them back; only a new email about one does.`;
  const box = $('#bList', root);
  if (!list.length) {
    box.innerHTML = `<div class="empty">${icon('trash', 40)}<p>The recycle bin is empty.</p><p class="muted small">Delete a task from its pane (More, Delete) or pick several on the Tasks page.</p></div>`;
    paint(); return;
  }
  box.innerHTML = `<table class="tbl tasks-tbl fixed"><colgroup><col style="width:34px"><col><col style="width:14%"><col style="width:14%"><col style="width:120px"><col style="width:90px"><col style="width:80px"><col style="width:100px"><col style="width:136px"></colgroup>
    <thead><tr><th data-st-label="Pick"><input type="checkbox" id="bAll" title="Pick all"></th><th>Task</th><th>Asked by</th><th>Done by</th><th>Kind</th><th>Status</th><th>Deleted</th><th>Removed for good</th><th></th></tr></thead><tbody>
    ${list.map(t => `<tr data-task="${t.id}"><td><input type="checkbox" data-pick="${t.id}" ${picked.has(t.id) ? 'checked' : ''} aria-label="Pick this task"></td>
      <td data-sort="${esc(t.title)}"><b>${esc(t.title)}</b><div class="muted small clamp1">${esc(t.subject)}</div></td>
      <td><span class="pcell">${avatar(t.requester_name, t.requester_email, 'xs')}${esc(t.requester_name)}</span></td>
      <td><span class="pcell">${avatar(t.owner_name, t.owner_email, 'xs')}${esc(t.owner_name)}</span></td>
      <td>${dirChip(t.direction)}</td><td>${statusChip(t)}</td>
      <td class="num muted" data-sort="${esc(t.deleted_at)}" title="${esc(fullDate(t.deleted_at))}">${esc(dateLabel(t.deleted_at))}</td>
      <td class="num ${left(t) <= 3 ? 'red' : 'muted'}" data-sort="${esc(t.purge_at)}" title="${esc(fullDate(t.purge_at))}">${esc(leftLabel(t))}</td>
      <td class="bin-acts"><button class="btn sm" data-one="restore" data-busy="Restoring" title="Put it back where it was">${icon('undo', 12)} Restore</button>
        <button class="iconbtn sm" data-one="purge" title="Delete for good now">${icon('x', 13)}</button></td></tr>`).join('')}</tbody></table>`;
  paint();
}

function paint() {
  const bar = $('#bBar', root), n = picked.size;
  bar.hidden = !list.length;
  const all = $('#bAll', root);
  if (all) { all.checked = n > 0 && n === list.length; all.indeterminate = n > 0 && n < list.length; }
  $$('#bList [data-task]', root).forEach(r => r.classList.toggle('picked', picked.has(Number(r.dataset.task))));
  bar.innerHTML = `${icon('trash', 14)}<span><b class="num">${list.length}</b> task${list.length === 1 ? '' : 's'} in the bin${n ? `, <b class="num">${n}</b> picked` : ''}</span><span class="sp"></span>
    <button class="btn sm primary" data-b="restore" data-busy="Restoring" ${n ? '' : 'disabled'}>${icon('undo', 13)} Restore${n ? ' ' + n : ''}</button>
    <button class="btn sm danger" data-b="purge" data-busy="Deleting" ${n ? '' : 'disabled'}>${icon('x', 13)} Delete for good</button>
    <button class="btn sm danger" data-b="empty" data-busy="Emptying">${icon('trash', 13)} Empty the bin</button>`;
}

async function act(kind, ids, btn) {
  if (kind !== 'empty' && !ids.length) return;
  const what = ids.length === 1 ? `<b>${esc(list.find(t => t.id === ids[0])?.title || 'this task')}</b>` : `<b>${ids.length} tasks</b>`;
  if (kind === 'purge' && !await confirmBox('Delete for good', `${what} ${ids.length === 1 ? 'is' : 'are'} removed for good. <b class="red">This cannot be undone.</b>`, 'Delete for good')) return;
  if (kind === 'empty' && !await confirmBox('Empty the recycle bin', `All <b>${plural(list.length, 'task')}</b> in the bin are removed for good. <b class="red">This cannot be undone.</b>`, 'Empty the bin')) return;
  await busy(btn, async () => {
    if (kind === 'restore') {
      const r = await api('POST', '/api/bin/restore', { ids });
      toast(`Restored ${plural(r.restored, 'task')}`);
    } else {
      const r = await api('POST', '/api/bin/purge', kind === 'empty' ? { all: true } : { ids });
      toast(`${plural(r.purged, 'task')} removed for good`);
    }
    ids.forEach(id => picked.delete(id));
    if (kind === 'empty') picked.clear();
    await load();
  });
}
