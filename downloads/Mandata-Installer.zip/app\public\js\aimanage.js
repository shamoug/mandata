// AI management, from the AI status at the top: every model on the AI server and the ones offered for install,
// with what each is good at, its size and how long it takes per email. Install, delete, activate, pause, load, test.
// A second tab holds the local AI's settings (address, context size, text per thread, time allowed).
import { api, GET, esc, $, $$, modal, toast, icon, confirmBox, busy, pref, setPref, latest } from './ui.js';
import { S, on, loadConfig, loadStatus } from './store.js';
import { suggest } from './suggest.js';

const gb = n => n == null ? '' : n >= 10 ? Math.round(n) + ' GB' : (Math.round(n * 10) / 10) + ' GB';
const dur = s => s == null ? '' : s < 60 ? `${s} s` : `${Math.floor(s / 60)} min${s % 60 ? ` ${s % 60} s` : ''}`;
const DEV = { gpu: 'on the GPU', cpu: 'on the processor', mixed: 'on GPU and processor' };
const pace = s => s == null ? null : s <= 30 ? ['Fast', '#2f9e44'] : s <= 90 ? ['Medium', '#e8590c'] : ['Slow', '#e03131'];
// How a model suits this computer (fitFor in lib/ai.js); a model that runs well needs no tag.
const FIT = { slow: ['Slow on this computer', '#e8590c', 'Fits in memory, but the processor takes long for each word'],
  no: ['Too big for this computer', '#e03131', 'Needs more memory than this computer can spare'] };
// The local AI's settings, shown on the Settings tab: [path in the config, label, type].
const AI_FIELDS = [['endpoint', 'AI server address', 'text'], ['contextTokens', 'Context size (tokens)', 'number'],
  ['threadChars', 'Email text per thread (characters)', 'number'], ['timeoutSec', 'Skip a thread the AI has not read in (seconds), and read it again after the rest', 'number'],
  ['lighterOnCpu', 'Without a GPU, give the AI shorter extracts of each thread (faster)', 'bool'],
  ['freeAfterThread', 'Free the AI\'s memory after each thread (the model loads again for the next one, which takes a few seconds)', 'bool']];
// Orders for the model lists: [key, label, value to sort on, label ascending, label descending]. A model without the value
// (a speed nobody measured or could guess) always goes last. Recommended keeps the server's order (best for this computer).
const SORTS = [['rec', 'Recommended', null, 'Best first', 'Best last'],
  ['name', 'Name', x => x.name.toLowerCase(), 'A to Z', 'Z to A'],
  ['speed', 'Speed', x => x.perEmailSec, 'Fastest first', 'Slowest first'],
  ['quality', 'Accuracy', x => x.quality || null, 'Least accurate first', 'Most accurate first'],
  ['size', 'Size', x => x.gb, 'Smallest first', 'Largest first'],
  ['params', 'Parameters', x => x.params || null, 'Fewest first', 'Most first'],
  ['family', 'Family', x => (x.family || '').toLowerCase() || null, 'A to Z', 'Z to A']];
const sortOf = k => SORTS.find(s => s[0] === k) || SORTS[0];
const stars = n => n ?`<span class="stars" title="Accuracy on email tasks: ${n} of 5">${'★'.repeat(n)}<i>${'★'.repeat(5 - n)}</i></span>` : '';

export function openAIManager(tab = 'models') {
  const m = modal({ title: 'AI management', size: 'wide aimgr', body: `
    <div class="settabs aim-tabs"><button data-t="models">${icon('spark', 14)}Models</button><button data-t="settings">${icon('gear', 14)}Settings</button></div>
    <div class="aim-pane" data-p="models"><div class="aim-load"><span class="spin"></span> Asking the AI server...</div></div>
    <div class="aim-pane" data-p="settings"></div>` });
  const pane = $('.aim-pane[data-p="models"]', m.el);
  const show = t => { $$('.aim-tabs button', m.el).forEach(b => b.classList.toggle('on', b.dataset.t === t)); $$('.aim-pane', m.el).forEach(p => p.hidden = p.dataset.p !== t);
    if (t === 'settings') paintSettings(); };
  $('.aim-tabs', m.el).onclick = e => { const b = e.target.closest('button'); if (b) show(b.dataset.t); };
  let data = null, offs = [], lastPull = S.status?.ai?.pull?.model || null;
  const openMore = new Set();
  let query = '', sortKey = sortOf(pref('aimSort', 'rec'))[0], sortDir = pref('aimDir', 1) === -1 ? -1 : 1;
  // Only the newest answer is drawn: a status event, a finished install and an action can each ask again before the last lands.
  const load = latest(() => GET('/api/ai/models'), d => { data = d; paint(); },
    e => { pane.innerHTML = `<div class="aim-err">${icon('alert', 14)} ${esc(e.message)}</div>`; });
  // Download progress comes with every status event; the list reloads when a download ends.
  offs.push(on('status', () => {
    const p = S.status?.ai?.pull || null;
    if (data) { data.pull = p; paintPull(); }
    if (lastPull && !p) load();
    lastPull = p?.model || null;
  }));
  offs.push(on('models', d => { if (d?.ok) toast(`${d.model} installed`); else if (d?.error) toast(d.error, true); load(); }));
  const close = m.close; m.close = s => { offs.forEach(f => f()); close(s); };

  function timeCell(x) {
    const p = pace(x.perEmailSec);
    const how = x.perEmailFrom === 'measured' ? `Average of ${x.measured.threads} email threads read on this computer`
      : x.perEmailFrom === 'speed' ? 'From the reading and writing speed measured on this computer'
      : x.perEmailFrom === 'guess' ? `Estimate, scaled from ${esc(x.speedGuess?.from || 'a model measured here')} by size. Press Test speed for a real figure.` : '';
    // The bar is full at 30 s a thread or less and shrinks as a thread takes longer (a tenth at 5 minutes).
    const bar = x.perEmailSec ? Math.max(6, Math.min(100, Math.round(3000 / x.perEmailSec))) : 0;
    return `<div class="aim-time" title="${how}" ${p ? `style="--c:${p[1]}"` : ''}>
      ${p ? `<span class="aim-pace">${p[0]}${x.perEmailFrom === 'guess' ? ' · estimate' : x.perEmailFrom === 'measured' ? ' · measured' : ''}</span>
        <b>~${dur(x.perEmailSec)}</b><small>per email thread</small>
        <span class="aim-meter"><i style="width:${bar}%"></i></span>
        <small>${Math.max(1, Math.round(3600 / x.perEmailSec))} emails an hour</small>`
      : `<b class="muted">?</b><small>${x.installed ? 'Press Test speed' : 'Test any installed model first'}</small>`}</div>`;
  }
  // The facts that decide between models, as tiles; the rest under More details.
  function facts(x) {
    const sp = x.speed || x.speedGuess;
    const tiles = [[x.installed ? 'On disk' : 'Download', gb(x.gb)],
      ['Memory', x.memGb ? `${gb(x.memGb)} <small>${DEV[x.device] || ''}</small>` : `~${gb(x.gb * 1.2)}`, x.fit === 'no' ? 'More than this computer can spare' : ''],
      ['Parameters', x.params ? `${esc(x.params)} billion${x.active ? ` <small>${esc(x.active)} B active</small>` : ''}` : '?'],
      ['Longest text', x.ctx ? `${esc(x.ctx)}k tokens` : '?'],
      ['Writes', sp ? `${esc(sp.output)} tokens/s${x.speed ? '' : ' <small>estimate</small>'}` : '?']];
    const more = [x.quant && ['Precision', esc(x.quant)], sp?.prompt && ['Reads', `${esc(sp.prompt)} tokens/s${x.speed ? '' : ' (estimate)'}`],
      x.langs && ['Languages', esc(x.langs)], x.best && ['Best for', esc(x.best)],
      x.measured && ['Read so far', `${x.measured.threads} threads, the last one in ${dur(x.measured.lastSec)}`]].filter(Boolean);
    return `<div class="aim-specs">${tiles.map(([k, v, warn]) => `<div class="${warn ? 'warn' : ''}" ${warn ? `title="${warn}"` : ''}><span>${k}</span><b>${v}</b></div>`).join('')}</div>
      ${more.length ? `<details class="aim-more"><summary>More details</summary><dl>${more.map(([k, v]) => `<dt>${k}</dt><dd>${v}</dd>`).join('')}</dl></details>` : ''}`;
  }
  function card(x) {
    const ai = S.status?.ai || {}, pulling = data.pull?.model === x.name;
    const state = x.isActive ? (data.paused ? ['Active, paused', '#e8590c'] : ['Active: reads your mail', '#2f9e44'])
      : x.installed ? ['Installed', '#1864ab'] : ['Not installed', '#0b7285'];
    const acts = x.installed ? `
        ${x.isActive ? (data.paused ? `<button class="btn sm primary" data-a="run">${icon('play', 12)} Resume</button>` : `<button class="btn sm" data-a="pause" title="Stop reading mail and free the memory">${icon('pause', 12)} Deactivate</button>`)
          : `<button class="btn sm primary" data-a="run" title="Use this model to read your mail">${icon('check', 12)} Activate</button>`}
        ${x.loaded ? `<button class="btn sm" data-a="unload" title="Free the memory it holds">${icon('down', 12)} Unload</button>` : `<button class="btn sm" data-a="load" title="Load into memory now">${icon('refresh', 12)} Load</button>`}
        <button class="btn sm" data-a="test" data-busy="Testing" title="Time it on a sample email thread">${icon('clock', 12)} Test speed</button>
        <button class="btn sm danger push" data-a="delete" ${x.isActive ? 'disabled title="Activate another model first"' : 'title="Delete from the disk"'}>${icon('trash', 12)} Delete</button>`
      : pulling ? pullBar() + `<button class="btn sm" data-a="cancel">${icon('x', 12)} Cancel</button>`
      : `<button class="btn sm primary" data-a="pull" ${data.pull ? 'disabled title="Another model is downloading"' : ''}>${icon('down', 12)} Install · ${gb(x.gb)}</button>`;
    return `<div class="aim-card ${x.isActive ? 'on' : x.recommended ? 'rec' : ''}" data-m="${esc(x.name)}">
      <div class="aim-main">
        <div class="aim-head">
          <div class="aim-title"><code class="aim-name">${esc(x.name)}</code>${x.family ? `<span class="aim-fam">${esc(x.family)}</span>` : ''}${stars(x.quality)}</div>
          <div class="aim-tags">
            ${x.recommended ? `<span class="aim-tag rec" title="${x.fit === 'good' ? 'The most accurate model that runs well on this computer' : `No model of ${data.minQuality} stars or more runs well on this computer; this one strains it least`}">${icon('check', 11)} Recommended</span>` : ''}
            ${FIT[x.fit] ? `<span class="aim-tag" style="--c:${FIT[x.fit][1]}" title="${FIT[x.fit][2]}">${FIT[x.fit][0]}</span>` : ''}
            ${x.loaded ? `<span class="aim-tag" style="--c:#0c8599">In memory, ${DEV[x.device] || ''}</span>` : ''}
            <span class="aim-tag solid" style="--c:${state[1]}">${state[0]}</span></div>
        </div>
        ${x.features?.length ? `<div class="aim-feats">${x.features.map(f => `<span>${esc(f)}</span>`).join('')}</div>` : ''}
        ${facts(x)}
      </div>
      ${timeCell(x)}
      <div class="btnrow aim-acts">${acts}</div>
    </div>`;
  }
  // A download's bar, with how much has come so far.
  function pullBar() {
    const p = data.pull || {}, amount = p.totalGb ? `${gb(p.doneGb || 0)} of ${gb(p.totalGb)}` : '';
    return `<div class="aim-dl"><div class="aim-bar"><i style="width:${p.percent || 0}%"></i></div>
      <span class="aim-pst"><b>${p.percent || 0}%</b> ${esc(amount || p.status || 'starting')}</span></div>`;
  }
  function paint() {
    const d = data, active = d.installed.find(x => x.isActive);
    const used = Math.round((1 - d.ram.free / d.ram.total) * 100);
    const gpuName = d.pc?.gpu ? (d.pc.gpu.split(', ').find(g => /NVIDIA|Radeon/i.test(g)) || d.pc.gpu.split(', ')[0]) : '';
    pane.innerHTML = `
      <div class="aim-sum">
        <div class="${d.reachable ? 'ok' : 'bad'}"><span class="aim-ic">${icon('spark', 15)}</span><div>
          <span class="aim-k">AI server</span>
          <b>${d.reachable ? `<span class="dot on"></span>Running${d.version ? ` <small>version ${esc(d.version)}</small>` : ''}` : `<span class="dot"></span><span class="red">${esc(d.error || 'Not reachable')}</span>`}</b>
          <small>${esc(d.endpoint)}</small></div></div>
        <div><span class="aim-ic">${icon('grid', 15)}</span><div>
          <span class="aim-k">This computer</span>
          <b>${gb(d.ram.total / 1e9)} memory <small>${gb(d.ram.free / 1e9)} free</small></b>
          <span class="aim-meter mem" title="${used}% of the memory in use"><i style="width:${used}%"></i></span>
          <small title="${esc(d.cpu)}${d.pc?.gpu ? ' · ' + esc(d.pc.gpu) : ''}">${gpuName ? `${esc(gpuName)}${d.pc.vramGb ? `, ${gb(d.pc.vramGb)} of its own` : ' (shares the main memory)'}` : esc(d.cpu)}</small></div></div>
        <div class="${d.paused ? 'warn' : 'ok'}"><span class="aim-ic">${icon('check', 15)}</span><div>
          <span class="aim-k">Reading mail with</span>
          <b><code>${esc(d.active)}</code>${d.paused ? ' <span class="aim-tag" style="--c:#e8590c">paused</span>' : ''}</b>
          <small>${active?.perEmailSec ? `~${dur(active.perEmailSec)} per email thread, ${Math.max(1, Math.round(3600 / active.perEmailSec))} threads an hour` : 'One email thread is about ' + (d.perEmailTokens.prompt + d.perEmailTokens.output).toLocaleString() + ' tokens'}</small></div></div>
      </div>
      <div class="aim-tools">
        <label class="search">${icon('search', 14)}<input type="search" id="aimQ" placeholder="Search models: name, family, language, feature" aria-label="Search models" spellcheck="false"></label>
        <label class="aim-sort">Sort by <select id="aimSort" aria-label="Sort models by">${SORTS.map(([k, l]) => `<option value="${k}" ${k === sortKey ? 'selected' : ''}>${l}</option>`).join('')}</select></label>
        <button class="btn sm" id="aimDir"></button>
      </div>
      <div class="aim-lists"></div>
      <div class="aim-other"><label class="f">Install another model by name</label>
        <div class="btnrow"><input type="text" id="aimName" placeholder="for example qwen3:8b" spellcheck="false"><button class="btn sm primary" id="aimPull" ${d.pull ? 'disabled' : ''}>${icon('down', 12)} Install</button></div></div>`;
    $('#aimPull', m.el).onclick = () => { const n = $('#aimName', m.el).value.trim(); if (n) act('pull', n, $('#aimPull', m.el)); };
    const q = $('#aimQ', m.el);
    // Model names and families; the install box suggests the models not installed yet.
    const models = () => [...data.installed, ...data.available].flatMap(x => [{ label: x.name, sub: x.family }, { label: x.family, sub: 'Family' }]).filter(x => x.label);
    suggest(q, models);
    suggest($('#aimName', m.el), () => data.available.map(x => ({ label: x.name, sub: x.family })));
    q.value = query;
    q.oninput = () => { query = q.value; paintLists(); };
    $('#aimSort', m.el).onchange = e => { sortKey = e.target.value; setPref('aimSort', sortKey); paintLists(); };
    $('#aimDir', m.el).onclick = () => { sortDir = -sortDir; setPref('aimDir', sortDir); paintLists(); };
    paintLists();
  }
  // Searching and sorting redraw only the two lists, so the search box keeps its focus while typing.
  function paintLists() {
    const d = data, s = sortOf(sortKey), words = query.toLowerCase().split(/\s+/).filter(Boolean);
    const dirBtn = $('#aimDir', m.el);
    dirBtn.innerHTML = `<span class="aim-dir ${sortDir < 0 ? 'down' : ''}">${icon('up', 12)}</span> ${sortDir < 0 ? s[4] : s[3]}`;
    dirBtn.title = 'Reverse the order';
    const text = x => [x.name, x.family, x.langs, x.best, x.quant, ...(x.features || [])].filter(Boolean).join(' ').toLowerCase();
    const pick = list => {
      const out = list.filter(x => words.every(w => text(x).includes(w)));
      if (s[2]) {
        const v = s[2], cmp = (a, b) => typeof a === 'string' ? a.localeCompare(b) : a - b;
        out.sort((a, b) => { const va = v(a), vb = v(b);
          return (va == null) - (vb == null) || (va == null ? 0 : sortDir * cmp(va, vb)) || a.name.localeCompare(b.name); });
      } else if (sortDir < 0) out.reverse();
      return out;
    };
    const inst = pick(d.installed), avail = pick(d.available), filtered = words.length > 0;
    const box = $('.aim-lists', m.el);
    box.innerHTML = `
      <h3 class="aim-h">Installed <span class="aim-count">${filtered ? `${inst.length} / ${d.installed.length}` : d.installed.length}</span><span class="muted">${gb(d.installed.reduce((a, x) => a + x.gb, 0))} on disk</span></h3>
      ${inst.length ? inst.map(card).join('') : `<p class="muted">${d.installed.length ? 'No installed model matches the search.' : 'No model installed yet. Install one below.'}</p>`}
      <h3 class="aim-h">Available to install <span class="aim-count">${filtered ? `${avail.length} / ${d.available.length}` : d.available.length}</span><span class="muted">models of ${d.minQuality} stars or more${!filtered && sortKey === 'rec' && sortDir > 0 ? ', best for this computer first' : ''}</span></h3>
      ${avail.length ? avail.map(card).join('') : `<p class="muted">${filtered ? 'No model in the list matches the search. You can install any model from the Ollama library by name below.' : 'Every model in the list is installed.'}</p>`}`;
    for (const b of $$('[data-a]', box)) b.onclick = () => act(b.dataset.a, b.closest('[data-m]').dataset.m, b);
    // More details stays open across redraws (a search, a sort, a finished download).
    for (const det of $$('.aim-more', box)) {
      const name = det.closest('[data-m]').dataset.m;
      det.open = openMore.has(name);
      det.ontoggle = () => det.open ? openMore.add(name) : openMore.delete(name);
    }
  }
  // Only the progress bar moves while a model downloads; the rest of the screen stays as it is.
  function paintPull() {
    const p = data.pull, c = p && $(`.aim-card[data-m="${CSS.escape(p.model)}"]`, m.el);
    if (c && $('.aim-dl', c)) {   // in place, so the bar slides
      const t = document.createElement('div'); t.innerHTML = pullBar();
      $('.aim-bar i', c).style.width = (p.percent || 0) + '%'; $('.aim-pst', c).innerHTML = $('.aim-pst', t).innerHTML;
    }
    // A card not showing its bar yet is redrawn; so, once, is a download not in the lists (put in by name), to disable the
    // Install buttons: not on every tick, which would wipe what you are typing.
    else if (p && (c ? !$('.aim-bar', c) : !$('#aimPull', m.el)?.disabled)) paint();
  }
  async function act(a, model, btn) {
    if (a === 'delete') {
      const x = data.installed.find(y => y.name === model);
      if (!await confirmBox('Delete model', `Delete <b>${esc(model)}</b>? Its files are removed from the disk, freeing about ${gb(x?.gb)}. You can install it again later.`, 'Delete')) return;
    }
    await busy(btn, async () => {
      if (a === 'run') { await api('POST', '/api/ai/run', { model }); await Promise.all([loadConfig(), loadStatus()]); toast(`${model} is now reading your mail`); }
      else if (a === 'pause') { await api('POST', '/api/ai/pause'); await Promise.all([loadConfig(), loadStatus()]); toast('AI paused: mail is not being read'); }
      else if (a === 'pull') { await api('POST', '/api/ai/pull', { model }); toast(`Installing ${model}`); await loadStatus(); data.pull = S.status?.ai?.pull || { model, status: 'starting', percent: 0 }; lastPull = model; }
      else if (a === 'cancel') { await api('POST', '/api/ai/pull/cancel'); toast('Download cancelled'); }
      else if (a === 'delete') { const r = await api('POST', '/api/ai/delete', { model }); toast(`${model} deleted from the disk, ${gb(r.gb)} freed`); }
      else if (a === 'load') { await api('POST', '/api/ai/load', { model }); toast(`${model} loaded into memory`); }
      else if (a === 'unload') { await api('POST', '/api/ai/unload', { model }); toast(`${model} unloaded from memory`); }
      else if (a === 'test') { const r = await api('POST', '/api/ai/test', { model });
        toast(`${model}: loads in ${r.loadSec} s, reads ${r.speed.prompt} and writes ${r.speed.output} tokens/s, about ${dur(r.perEmailSec)} per email`); }
      await load();
    });
  }
  // The Settings tab: saved on its own, like a section of Settings.
  function paintSettings() {
    const c = S.config?.ai || {}, sp = $('.aim-pane[data-p="settings"]', m.el);
    sp.innerHTML = `<div class="aim-set">
      <p class="muted small">Reading mail with <b>${esc(c.model || '')}</b>${c.paused ? ' (paused)' : ''}. Choose the model on the Models tab with Activate.</p>
      ${AI_FIELDS.map(([k, label, type]) => type === 'bool'
        ? `<label class="tog"><input type="checkbox" data-k="${k}" data-t="bool" ${c[k] ? 'checked' : ''}><span>${esc(label)}</span></label>`
        : `<div class="sfield"><label class="f">${esc(label)}</label><input type="${type}" data-k="${k}" data-t="${type}" value="${esc(c[k] ?? '')}"></div>`).join('')}
      <div class="btnrow aim-setbtns"><button class="btn primary" id="aiSave" data-busy="Saving">${icon('check', 14)} Save</button>
        <button class="btn ghost push" id="aiReset" data-busy="Restoring">${icon('undo', 14)} Restore defaults</button></div></div>`;
    $('#aiSave', sp).onclick = e => busy(e.currentTarget, async () => {
      const ai = {};
      for (const i of $$('[data-k]', sp)) {
        const v = i.dataset.t === 'bool' ? i.checked : i.dataset.t === 'number' ? Number(i.value) : i.value.trim();
        if (JSON.stringify(v) !== JSON.stringify(c[i.dataset.k])) ai[i.dataset.k] = v;
      }
      if (!Object.keys(ai).length) return toast('Nothing changed');
      await api('PUT', '/api/config', { ai }); await Promise.all([loadConfig(), loadStatus()]); toast('AI settings saved'); paintSettings();
    });
    $('#aiReset', sp).onclick = async e => {
      if (!await confirmBox('Restore defaults', 'The AI settings go back to their defaults, and the model goes back to the one setup chose.', 'Restore')) return;
      await busy(e.target.closest('button'), async () => { await api('POST', '/api/config/reset/ai'); await Promise.all([loadConfig(), loadStatus()]); toast('AI settings restored'); paintSettings(); load(); });
    };
  }
  show(tab);
  load();
  return m;
}
