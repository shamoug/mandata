// Every table in the app sorts by its columns: click a header for ascending, again for descending, a third time for the
// original order. Works on any <table> a view renders, with no wiring in the view. A cell sorts by its data-sort value
// when it has one (dates, names next to avatars), otherwise by its text; numbers sort as numbers, empty cells go last.
// The choice is remembered per table, so it survives the views redrawing themselves when new data arrives, and the app
// closing (the last 50 tables, in your preferences).
import { pref, setPref } from './ui.js';
const saved = new Map(Array.isArray(pref('tableSorts')) ? pref('tableSorts') : []); // table key -> { col, dir }
const keep = () => setPref('tableSorts', [...saved].slice(-50));

const keyOf = t => (location.hash.split('?')[0] || '#') + '|' + (t.className || '') + '|' + headers(t).map(h => h.dataset.stLabel ?? h.textContent.trim()).join('/');
const headers = t => t.tHead?.rows.length ? [...t.tHead.rows[t.tHead.rows.length - 1].cells] : [];
const sortable = th => th.dataset.sort !== 'off' && !!(th.dataset.stLabel ?? th.textContent.trim());

function value(cell) {
  if (!cell) return '';
  if (cell.dataset.sort != null) return cell.dataset.sort;
  if (!cell.querySelector('.av')) return cell.textContent.trim();
  const c = cell.cloneNode(true); c.querySelectorAll('.av').forEach(a => a.remove());
  return c.textContent.trim();
}
const NUM = /^[-−]?\d[\d,]*(\.\d+)?/;
function compare(a, b) {
  const na = NUM.exec(a), nb = NUM.exec(b);
  if (na && nb) return parseFloat(na[0].replace(/,/g, '').replace('−', '-')) - parseFloat(nb[0].replace(/,/g, '').replace('−', '-')) || a.localeCompare(b, undefined, { numeric: true, sensitivity: 'base' });
  if (na || nb) return na ? -1 : 1;
  return a.localeCompare(b, undefined, { numeric: true, sensitivity: 'base' });
}

function apply(t) {
  const hs = headers(t), s = saved.get(keyOf(t));
  hs.forEach((h, i) => {
    const on = s && s.col === i;
    h.setAttribute('aria-sort', on ? (s.dir > 0 ? 'ascending' : 'descending') : 'none');
    const ind = h.querySelector(':scope > .st-ind');
    if (ind) ind.textContent = on ? (s.dir > 0 ? '▲' : '▼') : '↕';
  });
  for (const body of t.tBodies) {
    const rows = [...body.rows];
    // Rows that span the whole table ("Nobody here yet") stay put at the end.
    const data = rows.filter(r => r.cells.length >= hs.length), rest = rows.filter(r => r.cells.length < hs.length);
    // Each cell is read once, not on every comparison (a cell with an avatar is copied to be read).
    const v = new Map(s ? data.map(r => [r, value(r.cells[s.col])]) : []);
    data.sort((a, b) => {
      if (!s) return a._stI - b._stI;
      const va = v.get(a), vb = v.get(b);
      if (!va || !vb) return (!va) - (!vb) || a._stI - b._stI;
      return s.dir * compare(va, vb) || a._stI - b._stI;
    });
    [...data, ...rest].forEach(r => body.appendChild(r));
  }
}

function enhance(t) {
  if (t._st) return;
  const hs = headers(t);
  if (!hs.length || !t.tBodies.length) return;
  t._st = true;
  hs.forEach(h => { h.dataset.stLabel = h.textContent.trim(); });
  for (const body of t.tBodies) [...body.rows].forEach((r, i) => { r._stI = i; });
  hs.forEach((h, i) => {
    if (!sortable(h)) return;
    h.classList.add('st-h'); h.dataset.stCol = i;
    h.title ||= 'Sort by this column';
    h.insertAdjacentHTML('beforeend', '<span class="st-ind" aria-hidden="true">↕</span>');
  });
  if (saved.has(keyOf(t))) apply(t); else hs.forEach(h => h.classList.contains('st-h') && h.setAttribute('aria-sort', 'none'));
}

// Only what was added is looked at, and only when it is or holds a table: rows moved by a sort, or any other change, cost nothing.
const fresh = new Set();
const scan = () => { const ts = [...fresh]; fresh.clear(); ts.forEach(t => t.isConnected && enhance(t)); };

export function initSortTables() {
  new MutationObserver(ms => {
    const was = fresh.size;
    for (const m of ms) for (const n of m.addedNodes) {
      if (n.nodeType !== 1) continue;
      if (n.tagName === 'TABLE') fresh.add(n); else for (const t of n.getElementsByTagName('table')) fresh.add(t);
    }
    if (!was && fresh.size) queueMicrotask(scan);
  }).observe(document.body, { childList: true, subtree: true });
  document.querySelectorAll('table').forEach(enhance);
  document.addEventListener('click', e => {
    const h = e.target.closest('th.st-h');
    if (!h || e.button !== 0) return;
    // A link or button inside the header (a person's name) keeps its own click, except the sort arrow itself.
    if (!e.target.closest('.st-ind') && e.target.closest('a,button,input,select,[data-person],[data-go]')) return;
    const t = h.closest('table'), col = Number(h.dataset.stCol), k = keyOf(t), s = saved.get(k);
    if (!s || s.col !== col) saved.set(k, { col, dir: 1 });
    else if (s.dir > 0) saved.set(k, { col, dir: -1 });
    else saved.delete(k);
    // Moved to the end: the newest choice is the last one dropped.
    const v = saved.get(k); if (v) { saved.delete(k); saved.set(k, v); }
    keep();
    apply(t);
    e.preventDefault(); e.stopPropagation();
  }, true);
}
