var S=Object.defineProperty;var h=(t,c)=>S(t,"name",{value:c,configurable:!0});import{api as p,GET as A,esc as n,$ as i,$$ as T,icon as r,toast as l,busy as u,confirmBox as w,errorBox as M,fullDate as P}from"./ui.js";let g=null,b=0;async function O(t){if(!t)return;const c=++b;let a;try{a=await A("/api/phone")}catch(e){c===b&&(t.innerHTML=M(e,!0));return}if(c!==b||!document.body.contains(t))return;const m=a.enabled,k=m&&a.running;let s="android";try{s=localStorage.getItem("mandata.phoneOs")||"android"}catch{}const y=h(()=>{const e=new Date(a.codeExpires)-Date.now();return e>0?`${Math.ceil(e/6e4)} min`:"run out"},"left");t.innerHTML=`
    <label class="tog sph-tog"><input type="checkbox" id="phOn" ${m?"checked":""}><span><b>Let my phone use Mandata over the Wi-Fi</b><br>
      <span class="muted small">Your mail and tasks stay on this computer: a paired phone reads and changes them here while both are on the same network.</span></span></label>
    ${m&&!a.running?`<div class="sph-err">${r("alert",14)} ${n(a.problem||"Phone access is not running.")}</div>`:""}
    ${k?`
    <div class="sph-os" role="tablist" aria-label="Your phone">${["android","iphone"].map(e=>`<button role="tab" data-os="${e}" aria-selected="${e===s}" class="${e===s?"on":""}">${e==="android"?"Android":"iPhone"}</button>`).join("")}</div>
    <div class="sph">
      <div class="sph-qr">
        ${a.qr?`<div class="sph-code">${s==="android"?a.qr:a.qrIphone}</div><span class="muted small sph-qrhint sph-stack">${[["android","Opens the Mandata app, or Mandata in Chrome"],["iphone","Opens Mandata in Safari"]].map(([e,d])=>`<span class="${e===s?"":"off"}" ${e===s?"":'aria-hidden="true"'}>${d}</span>`).join("")}</span>`:`<div class="sph-noqr">${r("alert",16)} ${a.locked?"Pairing is locked for a few minutes after too many wrong codes.":"No network found: connect this computer to the Wi-Fi."}</div>`}
        ${a.code?`<div class="sph-pin"><span class="muted small">Or type this code on the phone</span><b>${n(a.code.slice(0,4))} ${n(a.code.slice(4))}</b>
          <span class="muted small" id="phLeft">Works once, for ${n(y())}</span></div>`:""}
        <button class="btn sm" id="phNew" data-busy="Making">${r("refresh",12)} New code</button>
      </div>
      <div class="sph-how">
        <h4>Pair your ${s==="android"?"Android phone":"iPhone"}</h4>
        <div class="sph-stack">
        <ol class="${s==="android"?"":"off"}" ${s==="android"?"":'aria-hidden="true"'}>
          <li>Scan the QR code with the phone's camera.</li>
          <li><b>With the Mandata app installed</b>, it opens in the app, paired.</li>
          <li><b>Without it</b>, Mandata opens in Chrome, paired. Install the app from there (Home, <b>Install the app</b>) and the next scan opens it.</li>
          <li>The phone must be on the same Wi-Fi as this computer.</li>
        </ol>
        <ol class="${s==="iphone"?"":"off"}" ${s==="iphone"?"":'aria-hidden="true"'}>
          <li>Scan the QR code with the iPhone's Camera and open it in Safari. The iPhone is paired.</li>
          <li>Tap Share, then <b>Add to Home Screen</b>: Mandata opens from its own icon.</li>
          <li>The iPhone must be on the same Wi-Fi as this computer. If the Home Screen app asks to pair again, type the code.</li>
        </ol>
        </div>
        <div class="sph-net">
          <label class="f">Address in the QR code</label>
          <div class="sph-row">
            <select id="phAddr">${a.addresses.map(e=>`<option value="${n(e.address)}" ${e.address===a.address?"selected":""}>${n(e.address)} (${n(e.name)}${e.vpn?", VPN":""})</option>`).join("")||"<option>No network</option>"}</select>
            <input type="number" id="phPort" min="1024" max="65535" value="${a.port}" title="Port">
            <button class="btn sm" id="phApply" data-busy="Applying">Apply</button>
          </div>
        </div>
        <p class="muted small sph-note">${r("alert",12)} If the phone cannot connect, let Mandata through Windows Firewall on private networks (Windows asks the first time). Office and public Wi-Fi often stop devices reaching each other: use your home Wi-Fi or a VPN such as Tailscale. On the network the connection is not encrypted: use networks you trust.</p>
      </div>
    </div>`:""}
    <div class="sph-devs">
      <div class="sph-dh"><h4>Paired phones</h4>${a.devices.length>1?'<button class="btn sm danger" id="phAll" data-busy="Signing out">Sign out all</button>':""}</div>
      ${a.devices.length?a.devices.map(e=>`<div class="sph-dev">${r("phone",16)}<div><b>${n(e.name)}</b>
        <small>Paired ${n(P(e.pairedAt))} · last seen ${n(P(e.seenAt))}${e.ip?` · ${n(e.ip)}`:""}</small></div>
        <button class="btn sm" data-forget="${n(e.id)}" data-busy="Signing out">${r("out",12)} Sign out</button></div>`).join(""):'<p class="muted small">No phone paired yet.</p>'}
    </div>`,clearInterval(g),a.code&&(g=setInterval(()=>{const e=t.isConnected&&i("#phLeft",t);if(!e)return clearInterval(g);e.textContent=`Works once, for ${y()}`},3e4));const o=h(()=>O(t),"redraw");i(".sph-os",t)?.addEventListener("click",e=>{const d=e.target.closest("button[data-os]");if(d){try{localStorage.setItem("mandata.phoneOs",d.dataset.os)}catch{}o()}}),i("#phOn",t).onchange=async e=>{try{await p("PUT","/api/phone",{enabled:e.target.checked}),l(e.target.checked?"Phone access is on":"Phone access is off")}catch(d){l(d.message,!0)}o()};const f=i("#phNew",t);f&&(f.onclick=()=>u(f,async()=>{await p("POST","/api/phone/code"),o()}));const v=i("#phApply",t);v&&(v.onclick=()=>u(v,async()=>{await p("PUT","/api/phone",{address:i("#phAddr",t).value,port:Number(i("#phPort",t).value)}),l("Saved"),o()}));for(const e of T("[data-forget]",t))e.onclick=()=>u(e,async()=>{await w("Sign this phone out?","It stops reaching Mandata until you pair it again.","Sign out")&&(await p("POST","/api/phone/forget",{id:e.dataset.forget}),l("Phone signed out"),o())});const $=i("#phAll",t);$&&($.onclick=()=>u($,async()=>{await w("Sign every phone out?","Each has to be paired again.","Sign out all")&&(await p("POST","/api/phone/forget",{}),l("Every phone signed out"),o())}))}h(O,"phoneTab");export{O as phoneTab};
