// Settings > Phone: switch phone access on, pair a phone with the QR code, and sign phones out (lib/phone.js).
// Each button acts at once; nothing here waits for Save.
import { api, GET, esc, $, $$, icon, toast, busy, confirmBox, errorBox, fullDate } from './ui.js';

const SITE = 'https://shamoug.github.io/mandata/phone.html';
let ticking = null;

/** Draw the Phone tab in box. Called when the tab opens and whenever phone access changes (event 'phone'). */
export async function phoneTab(box) {
  if (!box) return;
  let d;
  try { d = await GET('/api/phone'); } catch (e) { box.innerHTML = errorBox(e, true); return; }
  if (!document.body.contains(box)) return;
  const on = d.enabled, live = on && d.running;
  const left = () => { const ms = new Date(d.codeExpires) - Date.now(); return ms > 0 ? `${Math.ceil(ms / 60000)} min` : 'run out'; };
  box.innerHTML = `
    <label class="tog sph-tog"><input type="checkbox" id="phOn" ${on ? 'checked' : ''}><span><b>Let my phone use Mandata over the Wi-Fi</b><br>
      <span class="muted small">Your mail and tasks stay on this computer: a paired phone reads and changes them here while both are on the same network.</span></span></label>
    ${on && !d.running ? `<div class="sph-err">${icon('alert', 14)} ${esc(d.error || 'Phone access is not running.')}</div>` : ''}
    ${live ? `
    <div class="sph">
      <div class="sph-qr">
        ${d.qr ? `<div class="sph-code">${d.qr}</div>` : `<div class="sph-noqr">${icon('alert', 16)} ${d.locked ? 'Pairing is locked for a few minutes after too many wrong codes.' : 'No network found: connect this computer to the Wi-Fi.'}</div>`}
        ${d.code ? `<div class="sph-pin"><span class="muted small">Or type this code on the phone</span><b>${esc(d.code.slice(0, 4))} ${esc(d.code.slice(4))}</b>
          <span class="muted small" id="phLeft">Works once, for ${esc(left())}</span></div>` : ''}
        <button class="btn sm" id="phNew" data-busy="Making">${icon('refresh', 12)} New code</button>
      </div>
      <div class="sph-how">
        <h4>Pair your phone</h4>
        <ol>
          <li><b>iPhone:</b> scan the QR code with the Camera and open it in Safari. Then tap Share and <b>Add to Home Screen</b>: Mandata opens from its own icon.</li>
          <li><b>Android:</b> install the <a href="${SITE}#android" target="_blank" rel="noopener">Mandata app</a>, then scan the QR code with the camera and choose <b>Open in the Mandata app</b>. Or use it in Chrome.</li>
          <li>The phone must be on the same Wi-Fi as this computer. In the app, use the address <code>${esc(d.url || '')}</code> and the code.</li>
        </ol>
        <div class="sph-net">
          <label class="f">Address in the QR code</label>
          <div class="sph-row">
            <select id="phAddr">${d.addresses.map(a => `<option value="${esc(a.address)}" ${a.address === d.address ? 'selected' : ''}>${esc(a.address)} (${esc(a.name)}${a.vpn ? ', VPN' : ''})</option>`).join('') || '<option>No network</option>'}</select>
            <input type="number" id="phPort" min="1024" max="65535" value="${d.port}" title="Port">
            <button class="btn sm" id="phApply" data-busy="Applying">Apply</button>
          </div>
        </div>
        <p class="muted small sph-note">${icon('alert', 12)} If the phone cannot connect, let Mandata through Windows Firewall on private networks (Windows asks the first time). Office and public Wi-Fi often stop devices reaching each other: use your home Wi-Fi or a VPN such as Tailscale. On the network the connection is not encrypted: use networks you trust.</p>
      </div>
    </div>` : ''}
    <div class="sph-devs">
      <div class="sph-dh"><h4>Paired phones</h4>${d.devices.length > 1 ? '<button class="btn sm danger" id="phAll" data-busy="Signing out">Sign out all</button>' : ''}</div>
      ${d.devices.length ? d.devices.map(x => `<div class="sph-dev">${icon('phone', 16)}<div><b>${esc(x.name)}</b>
        <small>Paired ${esc(fullDate(x.pairedAt))} · last seen ${esc(fullDate(x.seenAt))}${x.ip ? ` · ${esc(x.ip)}` : ''}</small></div>
        <button class="btn sm" data-forget="${esc(x.id)}" data-busy="Signing out">${icon('out', 12)} Sign out</button></div>`).join('')
      : '<p class="muted small">No phone paired yet.</p>'}
    </div>`;
  clearInterval(ticking);
  if (d.code) ticking = setInterval(() => { const el = $('#phLeft', box); if (!el) return clearInterval(ticking); el.textContent = `Works once, for ${left()}`; }, 30000);
  const redraw = () => phoneTab(box);
  $('#phOn', box).onchange = async e => {
    try { await api('PUT', '/api/phone', { enabled: e.target.checked }); toast(e.target.checked ? 'Phone access is on' : 'Phone access is off'); } catch (err) { toast(err.message, true); }
    redraw();
  };
  const nb = $('#phNew', box);
  if (nb) nb.onclick = () => busy(nb, async () => { await api('POST', '/api/phone/code'); redraw(); });
  const ap = $('#phApply', box);
  if (ap) ap.onclick = () => busy(ap, async () => { await api('PUT', '/api/phone', { address: $('#phAddr', box).value, port: Number($('#phPort', box).value) }); toast('Saved'); redraw(); });
  for (const b of $$('[data-forget]', box)) b.onclick = () => busy(b, async () => {
    if (!await confirmBox('Sign this phone out?', 'It stops reaching Mandata until you pair it again.', 'Sign out')) return;
    await api('POST', '/api/phone/forget', { id: b.dataset.forget }); toast('Phone signed out'); redraw();
  });
  const all = $('#phAll', box);
  if (all) all.onclick = () => busy(all, async () => {
    if (!await confirmBox('Sign every phone out?', 'Each has to be paired again.', 'Sign out all')) return;
    await api('POST', '/api/phone/forget', {}); toast('Every phone signed out'); redraw();
  });
}
