// Follow-up and forward emails the AI drafted for you, and what happened to them.
import { GET, esc, $, icon, when, pref, setPref, latest, errorBox, segButtons } from '../ui.js';
import { onView } from '../store.js';
import { draftState } from '../panels.js';

let root, show = pref('drshow', 'all');
const COLOR = { draft: '#f59f00', outlook: '#1c7ed6', sending: '#e03131', sent: '#2f9e44' };
export function mount(el) {
  root = el;
  el.innerHTML = `<div class="page"><div class="fbar"><h2 class="ptitle">${icon('draft', 18)} Follow-ups</h2><div class="seg" id="dSeg"></div>
    <span class="muted small">Follow-ups and forwards, drafted by the AI when you ask on a task. Nothing is sent until you press Send.</span></div><div id="dList"></div></div>`;
  $('#dSeg', el).onclick = e => { const v = e.target.closest('button')?.dataset.v; if (v) { show = v; setPref('drshow', v); render(); } };
  render(); onView('drafts', render);
}
const render = latest(() => GET('/api/drafts'), draw, e => { const box = root && $('#dList', root); if (box) box.innerHTML = errorBox(e); });
function draw(all) {
  // root is #main, there for every page: the view is still on screen only while its own list is.
  if (!$('#dList', root)) return;
  // Badges by state: how many of each, and a click shows only those.
  const states = [...new Set(all.map(d => d.status))];
  $('#dSeg', root).innerHTML = segButtons([['all', 'All', '#1c7ed6', all.length], ...states.map(s => [s, draftState({ status: s }), COLOR[s] || '#0b7285', all.filter(d => d.status === s).length])], show);
  const list = show === 'all' ? all : all.filter(d => d.status === show);
  $('#dList', root).innerHTML = list.length ? `<table class="tbl fixed drafts-tbl"><colgroup><col style="width:30%"><col style="width:24%"><col style="width:20%"><col style="width:12%"><col></colgroup><thead><tr><th>Subject</th><th>Task</th><th>To</th><th>State</th><th>Updated</th></tr></thead><tbody>
    ${list.map(d => `<tr data-draft="${d.id}"><td data-sort="${esc(d.subject)}">${d.mode === 'forward' ? `<span class="fwdmark" title="Forwards the task: once sent, it is a task you asked of them">${icon('forward', 11)}Forward</span> ` : ''}<b>${esc(d.subject)}</b><div class="muted small clamp1">${esc(d.body.split('\n').slice(2, 3).join(' '))}</div></td>
      <td>${d.task_id ? `<a data-task="${d.task_id}" title="Open the task">${esc(d.task_title || 'Task')}</a>` : ''}</td>
      <td class="muted">${d.to.map(a => `<a data-person="${esc(a)}" class="muted">${esc(a)}</a>`).join(', ')}</td>
      <td><span class="chip" style="--c:${COLOR[d.status] || '#0b7285'}"><i></i>${esc(draftState(d))}</span></td><td class="muted" data-sort="${esc(d.updated_at || '')}">${esc(when(d.updated_at))}</td></tr>`).join('')}</tbody></table>`
    : `<div class="empty">${icon('mail', 40)}<p>No follow-ups yet. Open a task and press “Draft follow-up email”, or “Forward” to hand it to someone else.</p></div>`;
}
