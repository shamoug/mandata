// Settings: every value in lib/config.js, edited here and stored in the app's database.
import { api, GET, esc, $, $$, modal, toast, icon, splitList, confirmBox, promptBox, busy, LOCALE, plural, fullDate, errorBox, safeColor, latest } from './ui.js';
import { S, loadConfig, on } from './store.js';
import { openSignIn } from './signin.js';
import { updatesTab } from './updates.js';
import { phoneTab } from './phone.js';

// One entry per tab. `sub` lists the fields down the side and edits the one picked (used for the long prompts; each also
// has a line saying when it runs and the heading it is listed under). The local AI's settings are
// in AI management (aimanage.js), beside its models.
const FIELDS = [
  { name: 'You', icon: 'user', color: '#4263eb', hint: 'Who you are, so the app can tell your mail from everyone else\'s.',
    fields: [['me.name', 'Your name', 'text'], ['me.emails', 'Your email addresses (comma separated)', 'list']] },
  { name: 'Mail', icon: 'mail', color: '#1c7ed6', hint: 'Which mailbox to read and how often to check it.', mail: true,
    fields: [['sync.source', 'Read mail through', 'select', 'sources'], ['sync.account', 'Outlook mailbox (classic Outlook)', 'text', 'outlook'], ['sync.pollSeconds', 'Check mail every (seconds)', 'number'],
      ['sync.lookbackDays', 'First run reads mail from the last (days)', 'number'], ['sync.expandThreads', 'Also read thread emails filed in other folders', 'bool'],
      ['sync.msClientId', 'Microsoft 365 app ID (leave empty unless your IT gives you one for Mandata)', 'text', 'm365'],
      ['sync.msTenant', 'Microsoft 365 directory (leave empty for work and school accounts; your organisation\'s domain, or "common" to add personal accounts)', 'text', 'm365']] },
  { name: 'Tasks', icon: 'tasks', color: '#2f9e44', hint: 'Deadlines, reminders and which tasks to keep.',
    fields: [['tasks.dueSoonDays', '"Due soon" means within (days)', 'number'],
      ['tasks.digestHour', 'Daily digest from (hour)', 'number'],
      ['tasks.trackOthers', 'Keep tasks between other people', 'bool'], ['tasks.notify', 'Desktop notifications', 'bool'],
      ['tasks.dailyEmail', 'Email me my deadlines every day (from me to me, through Outlook): overdue first, then today, tomorrow and the days ahead. Missed while the app was closed: sent as soon as it opens', 'bool'],
      ['tasks.dailyEmailTime', 'Send the daily deadlines email at', 'time'],
      ['tasks.review', 'When idle, revise the tasks found: mistakes, duplicates, passed deadlines, replies in related threads', 'bool'], ['tasks.reviewEveryDays', 'Review open tasks again every (days)', 'number'],
      ['tasks.binDays', 'Keep deleted tasks in the recycle bin for (days), then remove them for good', 'number'],
      ['tasks.learn', 'Learn from my corrections: turn every change I make to a task or a person into a lesson the AI follows (Settings > Lessons)', 'bool'],
      ['tasks.reviewLessons', 'Show me each lesson the AI learns to approve before it is used (off: used at once)', 'bool'],
      ['tasks.maxLessons', 'Lessons given to the AI at most', 'number']] },
  { name: 'Your voice', icon: 'edit', color: '#e8590c', hint: 'How the emails drafted for you should sound and sign off.',
    fields: [['voice.signOff', 'Sign-off name', 'text'], ['voice.closing', 'Closing line', 'text'], ['voice.guide', 'Style guide', 'area'],
      ['voice.outlookSignature', 'Add your Outlook signature', 'bool']] },
  { name: 'Profiles', icon: 'people', color: '#0c8599', hint: 'When the AI writes and refreshes a profile for each person.',
    fields: [['people.bioMinMessages', 'Write a profile after this many emails', 'number'], ['people.bioEvery', 'Rewrite after this many new signals', 'number'],
      ['people.refreshDays', 'When idle, refresh a profile older than (days, 0 for never)', 'number']] },
  { name: 'Prompts', icon: 'draft', color: '#f08c00', hint: 'The instructions given to the AI. Pick one to edit it.', sub: true,
    fields: [['prompts.thread', 'Reading a thread', 'code', 'thread', 'Finds the tasks in each email thread: who asked whom to do what, by when.', 'Reading mail'],
      ['prompts.check', 'Checking its reading', 'code', 'check', 'A strict second look at the tasks the first reading found.', 'Reading mail'],
      ['prompts.answered', 'Checking for a later answer', 'code', 'check', 'A task the reading leaves open is checked against the later replies to its requester: one that delivered, answered or cancelled it closes it.', 'Reading mail'],
      ['prompts.same','Matching tasks already known', 'code', 'tasks', 'Before a task is made, checks it is not one the thread already has: a reply about it updates that task.', 'Reading mail'],
      ['prompts.reprocess', 'Reading again when told it was wrong', 'code', 'undo', 'Runs when you mark a task as read wrong, with your note.', 'Reading mail'],
      ['prompts.thorough', 'Reading again to find a missed task', 'code', 'repeat', 'Added when you ask for an email to be read again: a task was most probably missed. Tried up to the set number of times while nothing is found.', 'Reading mail'],
      ['prompts.audit', 'Reviewing the tasks found', 'code', 'spark', 'When idle: fixes mistakes, duplicates and passed deadlines.', 'Reading mail'],
      ['prompts.lesson', 'Learning from your corrections', 'code', 'flag', 'Turns a task you put right into a lesson for next time.', 'Reading mail'],
      ['prompts.lessonPeople', 'Learning from your corrections of people', 'code', 'flag', 'Turns a person you put right (job title, unit, profile) into a lesson for next time.', 'People'],
      ['prompts.profile', 'Writing a profile', 'code', 'user', 'Writes the short profile kept for each person.', 'People'],
      ['prompts.signature', 'Reading a signature', 'code', 'people', 'Reads where someone sits from their email signature.', 'People'],
      ['prompts.followup', 'Writing a follow-up', 'code', 'send', 'Drafts a short reminder about a task.', 'Writing for you'],
      ['prompts.forward', 'Forwarding a task', 'code', 'forward', 'Drafts the email that hands a task to colleagues.', 'Writing for you'],
      ['prompts.draftReview', 'Checking a drafted email', 'code', 'draft', 'Checks every draft against the facts before you see it.', 'Writing for you'],
      ['prompts.report', 'Writing a weekly report', 'code', 'report', 'Writes the story of your week: headline, summary, highlights, risks and priorities.', 'Writing for you'],
      ['prompts.ask', 'Answering in Ask Mandata', 'code', 'chat', 'Answers the questions you ask Mandata.', 'Chat']] },
  { name: 'Lessons', icon: 'flag', color: '#c92a2a', hint: 'What the AI learns from every change you make to a task or a person. Your changes wait here first, so you see them (and can say why, or drop one) before the AI learns from them. Active lessons are added to its instructions. Edit one, retire one you disagree with (it stays off and is never learnt again), or delete it.', lessons: true, fields: [] },
  { name: 'Phone', icon: 'phone', color: '#1098ad', hint: 'Use Mandata on your phone over the Wi-Fi: pair it once with a QR code. Your mail and tasks stay on this computer.', phone: true, foot: true, fields: [] },
  { name: 'Updates', icon: 'download', color: '#2b8a3e', hint: 'New versions of Mandata, found on GitHub: what is new, and whether they install by themselves or ask you first.', updates: true, foot: true, fields: [] },
  { name: 'Data', icon: 'database', color: '#0b7285', hint: 'Back up your data, save backup files anywhere and restore them, or wipe the database and start again.', data: true, foot: true, fields: [] },
];
const get = (o, p) => p.split('.').reduce((x, k) => x?.[k], o);
// Where mail is read from. Classic Outlook exists on Windows only; elsewhere it is always Microsoft 365.
const SOURCES = () => S.status?.platform === 'win32'
  ? [['auto', 'Classic Outlook on this computer (automatic)'], ['microsoft365', 'Microsoft 365, signed in here (for the new Outlook)']]
  : [['auto', 'Microsoft 365 (signed in here)']];
const isM365 = src => S.status?.platform !== 'win32' || src === 'microsoft365';

/** The Microsoft 365 sign-in, at the top of the Mail tab: who is signed in, or a button to sign in. */
function mailBox(m) {
  const box = $('.smail', m.el); if (!box) return;
  const o = S.status?.outlook || {}, src = $('[data-p="sync.source"]', m.el)?.value || S.config?.sync?.source;
  for (const f of $$('[data-only]', m.el)) f.closest('.sfield').hidden = f.dataset.only === 'm365' ? !isM365(src) : isM365(src);
  if (!isM365(src)) { box.innerHTML = `${icon('inbox', 16)}<div><b>Classic Outlook on this computer</b><p>Mandata reads the mailbox Outlook is signed in to. Keep Outlook signed in.</p></div>`; return; }
  if (o.kind !== 'microsoft365') { box.innerHTML = `${icon('mail', 16)}<div><b>Microsoft 365</b><p>Press Save, then sign in here.</p></div>`; return; }
  box.innerHTML = o.signedIn
    ? `${icon('check', 16)}<div><b>Signed in to Microsoft 365</b><p>${esc(o.defaultStore || o.user || '')}${o.connected ? '' : o.error ? ` · ${esc(o.error)}` : ''}</p></div><button class="btn ghost" id="smOut">Sign out</button>`
    : `${icon('mail', 16)}<div><b>Not signed in</b><p>Sign in once with the account your Outlook mail is in. Your password goes to Microsoft only.${o.error ? ` <span class="si-err">${esc(o.error)}</span>` : ''}</p></div><button class="btn primary" id="smIn">Sign in</button>`;
  const out = $('#smOut', box), inn = $('#smIn', box);
  if (inn) inn.onclick = () => openSignIn();
  if (out) out.onclick = async () => {
    if (!await confirmBox('Sign out of Microsoft 365?', 'Mandata stops reading your mail until you sign in again. The tasks and mail it already has stay here.', 'Sign out')) return;
    await api('POST', '/api/mail/signout'); toast('Signed out of Microsoft 365');
  };
}

const tabBtn = (g, i) => `<button data-i="${i}" style="--gc:${safeColor(g.color)}" class="${i ? '' : 'on'}">${icon(g.icon, 14)}${esc(g.name)}</button>`;

export function openSettings() {
  const c = S.config, st = S.status;
  const input = ([path, label, type, only]) => {
    const v = get(c, path);
    return type === 'bool' ? `<label class="tog"><input type="checkbox" data-p="${path}" data-t="bool" ${v ? 'checked' : ''}><span>${esc(label)}</span></label>`
      : type === 'area' || type === 'code' ? `<textarea data-p="${path}" data-t="text" rows="${type === 'code' ? 10 : 4}" class="${type === 'code' ? 'mono' : ''}" spellcheck="${type !== 'code'}">${esc(v)}</textarea>`
      : type === 'time' ? `<span class="stime"><input type="time" data-p="${path}" data-t="text" value="${esc(v)}" required><button type="button" class="btn" id="sMailTest" data-busy="Sending" title="Send today's deadlines email to you now, from you, to see how it looks">${icon('send', 14)} Send a test now</button></span>`
      : type === 'list' ? `<input type="text" data-p="${path}" data-t="list" value="${esc((v || []).join(', '))}">`
      : type === 'select' ? `<select data-p="${path}" data-t="text">${SOURCES().map(([k, l]) => `<option value="${k}" ${k === v ? 'selected' : ''}>${esc(l)}</option>`).join('')}</select>`
      : `<input type="${type === 'number' ? 'number' : 'text'}" data-p="${path}" data-t="${type}" value="${esc(v)}"${only ? ` data-only="${only}"` : ''}>`;
  };
  const field = f => f[2] === 'bool' ? input(f) : `<div class="sfield"><label class="f">${esc(f[1])}</label>${input(f)}</div>`;
  // The prompts: a list down the side, grouped, and an editor that fills the rest.
  const subLayout = g => {
    const heads = [...new Set(g.fields.map(f => f[5]))];
    return `<div class="pmt"><nav class="pmt-list">${heads.map(h => `<div class="pmt-h">${esc(h)}</div>${g.fields.map((f, j) => f[5] !== h ? '' :
        `<button data-j="${j}" class="${j ? '' : 'on'}" title="${esc(f[4])}"><span class="pmt-ic">${icon(f[3], 13)}</span><span class="pmt-n">${esc(f[1])}</span><i class="pmt-dot"></i></button>`).join('')}`).join('')}</nav>
      <div class="pmt-ed">${g.fields.map((f, j) => `<div class="subpane" data-s="${j}" ${j ? 'hidden' : ''}>
        <div class="pmt-top"><span class="pmt-big">${icon(f[3], 16)}</span><div><b>${esc(f[1])}</b><p>${esc(f[4])}</p></div></div>
        ${input(f)}
        <div class="pmt-foot"><span class="pmt-vars"></span><span class="pmt-count"></span></div></div>`).join('')}</div></div>`;
  };
  const group = (g, i) => `<div class="setgrp${g.sub ? ' hassub' : ''}" data-g="${i}" style="--gc:${safeColor(g.color)}" ${i ? 'hidden' : ''}>
    <div class="setban"><span class="setban-ic">${icon(g.icon, 18)}</span><div><h3>${esc(g.name)}</h3><p>${esc(g.hint)}</p></div></div>
    ${g.sub ? subLayout(g)
    : g.data ? '<div class="sdata"><div class="aim-load"><span class="spin"></span> Reading your data...</div></div>'
    : g.updates ? '<div class="supdates"></div>'
    : g.phone ? '<div class="sphone"></div>'
    : g.lessons ? '<div class="slessons"><div class="aim-load"><span class="spin"></span> Reading the lessons...</div></div>'
    : `${g.mail ? '<div class="smail"></div>' : ''}<div class="sfields">${g.fields.map(field).join('')}</div>`}</div>`;
  const m = modal({ title: 'Settings', size: 'wide settings', body: `
    <div class="setinfo"><span class="dot ${st?.ai?.online ? 'on' : ''}"></span>${icon('gear', 14)} Data: <code>${esc(st?.dataDir || '')}</code> · AI: ${st?.ai?.paused ? 'paused, ' + esc(st.ai.model) : st?.ai?.online ? 'online, ' + esc(st.ai.model) : esc(st?.ai?.error || 'offline')}${st?.ai?.device ? `, on the ${st.ai.device === 'gpu' ? 'GPU' : st.ai.device === 'cpu' ? 'processor (no GPU)' : 'GPU and processor'}` : ''}${st?.ai?.speed?.prompt ? ` · reads ${esc(st.ai.speed.prompt)}, writes ${esc(st.ai.speed.output)} tokens/s` : ''}</div>
    <div class="settabs">${FIELDS.map((g, i) => g.foot ? '' : tabBtn(g, i)).join('')}</div>
    <div class="setbody">${FIELDS.map(group).join('')}</div>`,
    // Data and Updates are not settings of the app's work: they sit apart, at the bottom right.
    footer: `<div class="btnrow"><button class="btn primary" id="sSave">${icon('check', 14)} Save</button><button class="btn ghost" id="sReset">${icon('undo', 14)} Restore this section's defaults</button>
      <div class="setfoot">${FIELDS.map((g, i) => g.foot ? tabBtn(g, i) : '').join('')}</div></div>` });
  let tab = 0;
  m.el.addEventListener('click', e => { const b = e.target.closest('.settabs button[data-i], .setfoot button[data-i]'); if (!b) return; tab = +b.dataset.i;
    $$('.settabs button, .setfoot button', m.el).forEach(x => x.classList.toggle('on', x === b)); $$('.setgrp', m.el).forEach(g => g.hidden = +g.dataset.g !== tab);
    $('.setbody', m.el).scrollTop = 0; $('#sReset', m.el).hidden = !!(FIELDS[tab].data || FIELDS[tab].lessons || FIELDS[tab].updates || FIELDS[tab].phone);
    // Nothing on the Data or Updates tab is saved with Save: each button acts at once.
    $('#sSave', m.el).hidden = !!(FIELDS[tab].data || FIELDS[tab].updates || FIELDS[tab].phone);
    if (FIELDS[tab].data) dataTab(m); if (FIELDS[tab].lessons) lessonsTab(m); if (FIELDS[tab].updates) updatesTab($('.supdates', m.el)); if (FIELDS[tab].phone) phoneTab($('.sphone', m.el)); });
  // A lesson learnt while the tab is open shows at once; closing the dialog, however it closes, stops listening.
  const off = on('lessons', () => { if (FIELDS[tab].lessons) lessonsTab(m); });
  // A phone paired or signed out while the Phone tab is open shows at once.
  const offPhone = on('phone', () => { if (FIELDS[tab].phone) phoneTab($('.sphone', m.el)); });
  // The sign-in box follows the status (signed in, out, a sign-in under way) and the source picked.
  const offMail = on('status', () => mailBox(m));
  const src = $('[data-p="sync.source"]', m.el);
  if (src) src.onchange = () => mailBox(m);
  mailBox(m);
  const close = m.close; m.close = s => { off(); offMail(); offPhone(); close(s); };
  for (const list of $$('.pmt-list', m.el)) {
    const grp = list.closest('.setgrp');
    list.onclick = e => { const b = e.target.closest('button'); if (!b) return;
      $$('button', list).forEach(x => x.classList.toggle('on', x === b)); $$('.subpane', grp).forEach(p => p.hidden = p.dataset.s !== b.dataset.j);
      $(`.subpane[data-s="${b.dataset.j}"] textarea`, grp).focus({ preventScroll: true }); };
    // Under each prompt: the {words} the app fills in (click one to put it at the cursor), its size, and a dot in the list once edited.
    for (const p of $$('.subpane', grp)) {
      const ta = $('textarea', p), dot = $(`button[data-j="${p.dataset.s}"] .pmt-dot`, list), was = ta.value;
      const vars = [...new Set(was.match(/\{[a-zA-Z]+\}/g) || [])];
      $('.pmt-vars', p).innerHTML = vars.length ? `<span class="subtle">Filled in by the app:</span> ${vars.map(v => `<button type="button" class="pmt-var" title="Put ${esc(v)} at the cursor">${esc(v)}</button>`).join('')}` : '';
      const count = () => { const t = ta.value; $('.pmt-count', p).textContent = `${t.split('\n').length} lines · ${(t.match(/\S+/g) || []).length} words`; dot.classList.toggle('on', t !== was); };
      ta.oninput = count; count();
      $('.pmt-vars', p).onclick = e => { const v = e.target.closest('.pmt-var'); if (!v) return;
        ta.setRangeText(v.textContent, ta.selectionStart, ta.selectionEnd, 'end'); ta.focus(); count(); };
    }
  }
  // The test goes to your saved address with the tasks as they stand; the daily one still goes at its time.
  const test = $('#sMailTest', m.el);
  if (test) test.onclick = () => busy(test, async () => { const r = await api('POST', '/api/dailymail/test'); toast(`Test email sent to ${r.to}. Check your inbox.`); });
  $('#sSave', m.el).onclick = async () => {
    const patch = {};
    for (const i of $$('[data-p]', m.el)) {
      const [sec, key] = i.dataset.p.split('.');
      const t = i.dataset.t, v = t === 'bool' ? i.checked : t === 'number' ? Number(i.value) : t === 'list' ? splitList(i.value.replace(/;/g, ',')).map(s => s.trim()) : i.value;
      if (JSON.stringify(v) === JSON.stringify(get(c, i.dataset.p))) continue;
      (patch[sec] ||= {})[key] = v;
    }
    if (!Object.keys(patch).length) return m.close();
    // Outlook and Microsoft 365 give the same email different ids: the mail already read would come in again as new.
    if (patch.sync?.source && S.status?.platform === 'win32' && (S.status?.counts?.open || S.status?.sync?.lastOk)
      && !await confirmBox('Read mail through ' + (isM365(patch.sync.source) ? 'Microsoft 365' : 'classic Outlook') + '?',
        'Mandata will read your mail again from there, and it cannot tell those emails from the ones it already has: tasks it found may appear a second time. Best on a fresh start (Settings &gt; Data &gt; Wipe), or close the repeats as duplicates.', 'Switch')) return;
    try { await api('PUT', '/api/config', patch); await loadConfig(); toast('Saved'); m.close(); } catch (e) { toast(e.message, true); }
  };
  $('#sReset', m.el).onclick = async () => {
    try { for (const sec of new Set(FIELDS[tab].fields.map(f => f[0].split('.')[0]))) await api('POST', '/api/config/reset/' + sec); await loadConfig(); } catch (e) { return toast(e.message, true); }
    m.close(); toast('Defaults restored'); openSettings();
  };
}

// ---------- Lessons: what the AI learnt from your corrections ----------
// Every change you make to what the AI read waits here first: you see it, say why, or drop it, before the AI learns from it.
const KIND = { edit: 'You changed', dismiss: 'You marked it not a task', delete: 'You deleted it', reopen: 'You reopened it', close: 'You closed it',
  pin: 'You pinned it to the top', reprocess: 'You had it read again', missed: 'Missed at first: found when you had it read again', person: 'You changed' };
const FIELD = { organization: 'organisation', bio: 'profile', tasking: 'what they do', relationship: 'how you work together', placement: 'place in the organisation' };
const fix = c => c.kind === 'edit' || c.kind === 'person' ? `${KIND.edit} the ${esc(FIELD[c.field] || c.field)}: <s>${esc(c.ai_value || 'none')}</s> → <b>${esc(c.user_value || 'none')}</b>`
  : c.kind === 'reprocess' ? `${KIND.reprocess}: wrong ${esc(c.field)}` : c.kind === 'close' ? `${KIND.close} as ${esc(c.user_value)}`
  : c.kind === 'pin' ? `${KIND.pin} (the AI gave it ${esc(c.ai_value)} priority)` : KIND[c.kind] || esc(c.kind);
const AREA = { tasks: 'Tasks', people: 'People' };
const what = c => c.person ? `${icon('user', 11)} ${esc(c.title || c.person)}` : esc(c.title ? `"${c.title}"` : '(task gone)');

// Only the newest answer is drawn: a tab click, a lesson learnt and an action can each ask again before the last answer lands.
const lessonsTab = latest(() => GET('/api/lessons'), drawLessons, (e, m) => { $('.slessons', m.el).innerHTML = errorBox(e, true); });
function drawLessons(d, m) {
  const box = $('.slessons', m.el);
  if (!document.body.contains(box)) return;
  const active = d.lessons.filter(l => l.status === 'active'), retired = d.lessons.filter(l => l.status === 'retired'), proposed = d.lessons.filter(l => l.status === 'proposed');
  const card = l => `<div class="dcard lesson${l.status === 'retired' ? ' off' : ''}" data-l="${l.id}"><div>
      <b>${esc(l.text)}</b>
      <small><span class="chip">${AREA[l.area] || 'Tasks'}</span> <span class="chip">${esc(l.topic || 'reading')}</span> ${l.status === 'retired' ? `Retired ${esc(fullDate(l.retired_at))}` : `${l.corrections.length ? 'Learnt' : 'Added'} ${esc(fullDate(l.created_at))}`}${l.user_edited ? ' · worded by you' : ''}${l.corrections.length ? ` · from ${plural(l.corrections.length, 'correction')}` : ''}</small>
      ${l.corrections.length ? `<details><summary>Learnt from</summary>${l.corrections.map(c => `<div class="lcase"><span class="muted">${esc(fullDate(c.at))}</span> ${what(c)}: ${fix(c)}${c.note ? ` <i>"${esc(c.note)}"</i>` : ''}</div>`).join('')}</details>` : ''}
    </div>
    <div class="btnrow"><button class="btn sm" data-a="edit">${icon('edit', 12)} Edit</button>
      ${l.status === 'proposed' ? `<button class="btn sm primary" data-a="restore" data-busy="Approving">${icon('check', 12)} Approve</button><button class="btn sm" data-a="retire" data-busy="Rejecting">${icon('x', 12)} Reject</button>`
        : l.status === 'active' ? `<button class="btn sm" data-a="retire" data-busy="Retiring">${icon('pause', 12)} Retire</button>` : `<button class="btn sm" data-a="restore" data-busy="Restoring">${icon('undo', 12)} Restore</button>`}
      <button class="btn sm danger" data-a="delete" data-busy="Deleting">${icon('trash', 12)} Delete</button></div></div>`;
  // A correction waiting: what you changed, your words, and what you can do before the AI learns from it.
  const waitCard = c => `<div class="dcard lesson" data-c="${c.id}"><div>
      <span>${what(c)}</span>
      <span class="small">${fix(c)}</span>
      ${c.note ? `<small><i>Your words: "${esc(c.note)}"</i></small>` : ''}
      <small><span class="chip">${c.person ? 'People' : 'Tasks'}</span> ${esc(fullDate(c.at))}${c.learning ? ' · <b>the AI is learning from it now</b>' : c.outcome === 'failed' ? ` · <b class="red">could not be learnt from in ${esc(c.tries)} tries</b>` : ''}</small>
    </div>
    <div class="btnrow">${c.learning ? '<span class="spin"></span>' : `
      <button class="btn sm" data-ca="note">${icon('edit', 12)} ${c.note ? 'Change why' : 'Say why'}</button>
      ${c.outcome === 'failed' ? `<button class="btn sm" data-ca="retry" data-busy="Queuing">${icon('undo', 12)} Try again</button>` : ''}
      <button class="btn sm" data-ca="drop" data-busy="Dropping">${icon('trash', 12)} Don't learn</button>`}</div></div>`;
  const skipCard = c => `<div class="lcase" data-c="${c.id}"><span class="muted">${esc(fullDate(c.at))}</span> ${what(c)}: ${fix(c)}${c.note ? ` <i>"${esc(c.note)}"</i>` : ''}
      ${c.reason ? `<br><span class="muted">AI: ${esc(c.reason)}</span>` : ''} <button class="btn sm ghost" data-ca="note">${icon('edit', 11)} Say why and learn again</button></div>`;
  const waiting = d.pending.filter(c => c.outcome !== 'failed').length;
  box.innerHTML = `
    <div class="dcard"><div><b>${active.length} active lesson${active.length === 1 ? '' : 's'}${proposed.length ? `, ${proposed.length} to approve` : ''}${retired.length ? `, ${retired.length} retired` : ''}</b>
      <small>${plural(d.total, 'correction')} kept${waiting ? `, ${waiting} waiting to be learnt from` : ''}${d.skipped ? `, ${d.skipped} with nothing general to learn` : ''}.${S.config?.tasks?.learn === false ? ' <b class="red">Learning is off (Settings > Tasks).</b>' : ''}</small></div>
      <div class="btnrow">${d.learning ? `<button class="btn sm" disabled><span class="spin"></span> Learning...</button>` : waiting ? `<button class="btn sm" id="lLearn" data-busy="Starting">${icon('spark', 12)} Learn now</button>` : ''}
      <button class="btn sm primary" id="lAdd">${icon('plus', 12)} Add a lesson</button></div></div>
    ${d.pending.length ? `<h4 class="dh">Waiting to be learnt from <span class="muted">every change you make to what the AI read. Say why to help it, or drop one it should not learn from</span></h4>${d.pending.map(waitCard).join('')}` : ''}
    ${proposed.length ? `<h4 class="dh">Proposed <span class="muted">learnt by the AI from your changes, not used until you approve them. Edit the words, approve, or reject (never learnt again)</span></h4>${proposed.map(card).join('')}` : ''}
    <h4 class="dh">Active <span class="muted">${active.length ? 'given to the AI, strongest first' : ''}</span></h4>
    ${active.length ? active.map(card).join('') : `<p class="muted small">No lessons yet. Every change you make to a task or a person the AI read (a title, deadline, people, priority, Not a task, a delete, a close, a pin, a job title, a unit) is listed above and learnt from ${d.pending.length ? 'now, or press Learn now' : 'as soon as you make it'}.</p>`}
    ${retired.length ? `<h4 class="dh">Retired <span class="muted">off, and never learnt again</span></h4>${retired.map(card).join('')}` : ''}
    ${d.skippedList.length ? `<details class="lesson"><summary class="dh">Nothing general to learn (${d.skipped})</summary>${d.skippedList.map(skipCard).join('')}</details>` : ''}`;
  $('#lAdd', box).onclick = async () => {
    const text = await promptBox('Add a lesson', 'One rule the AI should follow when reading tasks. Start with "People:" for one about reading people (signatures, profiles)', { type: 'textarea', okLabel: 'Add', placeholder: 'When a sender only shares a document "for information", it is not a task.' });
    if (text == null) return;
    const people = /^\s*people\s*:/i.test(text);
    try { await api('POST', '/api/lessons', { text: people ? text.replace(/^\s*people\s*:\s*/i, '') : text, area: people ? 'people' : 'tasks' }); toast('Lesson added'); lessonsTab(m); } catch (e) { toast(e.message, true); }
  };
  if ($('#lLearn', box)) $('#lLearn', box).onclick = e => busy(e.currentTarget, async () => {
    try { await api('POST', '/api/lessons/learn'); toast('Learning from your corrections now'); } catch (err) { toast(err.message, true); }
    lessonsTab(m);
  });
  const all = [...d.pending, ...d.skippedList];
  for (const b of $$('[data-ca]', box)) b.onclick = async () => {
    const id = b.closest('[data-c]').dataset.c, c = all.find(x => String(x.id) === id);
    try {
      if (b.dataset.ca === 'note') {
        const note = await promptBox('Why was the AI wrong?', 'Your words go with this correction: the lesson is learnt from them', { type: 'textarea', value: c.note || '', placeholder: 'It was only for information: nothing was asked of me.' });
        if (note == null) return;
        await api('PATCH', '/api/corrections/' + id, { note }); toast('Kept: it is learnt from with your words');
      } else if (b.dataset.ca === 'retry') {
        await busy(b, () => api('PATCH', '/api/corrections/' + id, { retry: true })); toast('It is learnt from again');
      } else {
        await busy(b, () => api('DELETE', '/api/corrections/' + id)); toast('Dropped: the AI does not learn from it');
      }
      lessonsTab(m);
    } catch (e) { toast(e.message, true); }
  };
  for (const b of $$('[data-a]', box)) b.onclick = async () => {
    const id = b.closest('[data-l]').dataset.l, l = d.lessons.find(x => String(x.id) === id);
    try {
      if (b.dataset.a === 'edit') {
        const text = await promptBox('Edit the lesson', 'Your words are kept: the AI never rewrites a lesson you edited', { type: 'textarea', value: l.text });
        if (text == null || text.trim() === l.text) return;
        await api('PATCH', '/api/lessons/' + id, { text }); toast('Lesson saved');
      } else if (b.dataset.a === 'retire') {
        await busy(b, () => api('PATCH', '/api/lessons/' + id, { status: 'retired' })); toast(l.status === 'proposed' ? 'Lesson rejected: it is never learnt again' : 'Lesson retired: the AI no longer follows it');
      } else if (b.dataset.a === 'restore') {
        await busy(b, () => api('PATCH', '/api/lessons/' + id, { status: 'active' })); toast(l.status === 'proposed' ? 'Lesson approved: the AI follows it from now on' : 'Lesson restored');
      } else {
        if (!await confirmBox('Delete lesson', `<b>${esc(l.text)}</b><br><br>The AI stops following it, and the corrections it came from are not learnt from again. To keep it but switch it off, Retire it instead.`, 'Delete')) return;
        await busy(b, () => api('DELETE', '/api/lessons/' + id)); toast('Lesson deleted');
      }
      lessonsTab(m);
    } catch (e) { toast(e.message, true); }
  };
}

// ---------- Data: backups, backup files kept anywhere, and wiping the database ----------
const size = b => b >= 1e9 ? (b / 1e9).toFixed(1) + ' GB' : b >= 1e6 ? Math.round(b / 1e6) + ' MB' : Math.max(1, Math.round(b / 1e3)) + ' KB';
const held = c => c ? `${c.tasks} tasks, ${c.people} people, ${c.threads} threads, ${c.emails} emails` : '';

const dataTab = latest(() => GET('/api/data'), drawData, (e, m) => { $('.sdata', m.el).innerHTML = errorBox(e, true); });
function drawData(d, m) {
  const box = $('.sdata', m.el);
  const n = v => Number(v || 0).toLocaleString(LOCALE), c = d.current;
  // Each backup says how it came to be: made by hand, imported from a file, or made by the app on its own (and why).
  const kind = b => b.reason === 'Made by hand' ? ['hand', 'By hand', '']
    : /^Imported/.test(b.reason || '') ? ['imp', 'Imported', b.reason.replace(/^Imported from /, 'From ')]
    : ['auto', 'Automatic', b.reason || ''];
  box.innerHTML = `
    <section class="dnow">
      <div class="dnow-top"><span class="dnow-ic">${icon('database', 18)}</span>
        <div class="dnow-t"><b>Your database now</b><small>In <code>${esc(d.dataDir)}</code></small></div></div>
      <div class="dstats">${[['tasks', c.tasks], ['people', c.people], ['threads', c.threads], ['emails', c.emails]].map(([k, v]) =>
        `<div><b class="num">${n(v)}</b><span>${k}</span></div>`).join('')}<div><b class="num">${size(c.bytes)}</b><span>on disk</span></div></div>
      <div class="dnow-act">
        <button class="btn primary" id="dBackup" data-busy="Backing up">${icon('plus', 14)} Back up now</button>
        <a class="btn" id="dExport" href="/api/data/export" download>${icon('download', 14)} Export to a file...</a>
        <button class="btn" id="dImport" data-busy="Importing">${icon('upload', 14)} Import a backup file...</button>
        <input type="file" id="dFile" accept=".db,.sqlite,.sqlite3,.bak" hidden></div>
      <p class="dnow-hint">Export saves a backup file anywhere you like: another drive, OneDrive, a USB stick. Import brings one back, on this computer or another.</p>
    </section>
    <div class="dh"><h4>Backups</h4>${d.backups.length ? `<span>${d.backups.length} · newest first</span>` : ''}</div>
    ${d.backups.length ? `<div class="bklist">${d.backups.map(b => { const [k, label, why] = kind(b); return `<div class="drow" data-b="${esc(b.name)}">
        <div class="drow-main"><div class="drow-h"><b>${esc(fullDate(b.at))}</b><span class="dtag ${k}">${label}</span></div>
          ${why ? `<span class="drow-why">${esc(why)}</span>` : ''}<small>${b.counts ? `<span>${n(b.counts.tasks)} tasks · ${n(b.counts.people)} people · ${n(b.counts.threads)} threads · ${n(b.counts.emails)} emails</span>` : ''}<span>${size(b.bytes)}</span></small></div>
        <div class="drow-act"><button class="btn sm" data-a="restore" data-busy="Restoring">${icon('undo', 12)} Restore</button>
          <a class="btn sm" href="/api/data/export?name=${encodeURIComponent(b.name)}" download title="Save this backup as a file anywhere you like">${icon('download', 12)} Export...</a>
          <button class="btn sm danger" data-a="delete" data-busy="Deleting" title="Delete this backup permanently">${icon('trash', 12)} Delete</button></div></div>`; }).join('')}</div>`
    : '<p class="dempty">No backups yet. Press <b>Back up now</b> to make one; one is also made every time you wipe the database.</p>'}
    <section class="dzone"><div><b>${icon('alert', 14)} Wipe the database</b><small>Erase every task, person, thread and email copy, and read mail again from the start. You can keep a backup first.</small></div>
      <button class="btn danger" id="dWipe">${icon('trash', 13)} Wipe database...</button></section>`;
  $('#dBackup', box).onclick = e => busy(e.currentTarget, async () => { await api('POST', '/api/data/backup'); toast('Backup made'); dataTab(m); });
  $('#dWipe', box).onclick = () => wipeDialog(d);
  for (const a of $$('a[download]', box)) a.addEventListener('click', () => toast('Choose where to save the backup file'));
  const pick = $('#dFile', box), imp = $('#dImport', box);
  imp.onclick = () => { pick.value = ''; pick.click(); };
  pick.onchange = async () => {
    const f = pick.files[0];
    if (!f) return;
    // Checked by the server before it joins the list: a file that is not a Mandata backup, or is damaged, is refused.
    const bk = await busy(imp, async () => {
      const r = await fetch('/api/data/import', { method: 'POST', headers: { 'content-type': 'application/octet-stream', 'x-file-name': encodeURIComponent(f.name) }, body: f });
      const j = await r.json().catch(() => ({}));
      if (!r.ok || j.error) throw new Error(j.error || r.statusText);
      return j.backup;
    });
    if (!bk) return;
    await dataTab(m);
    const row = $(`[data-b="${CSS.escape(bk.name)}"] [data-a="restore"]`, box);
    if (!await confirmBox('Restore the imported backup', `<b>${esc(f.name)}</b> holds ${esc(held(bk.counts)) || size(bk.bytes)}. It is now in your backups.<br><br>
      Restore it now? Your data is replaced by it, and what is in the database now is backed up first, so you can come back to it.`, 'Restore now')) { toast('Backup imported. Restore it from the list whenever you like'); return; }
    if (row) await restoreBackup(row, bk.name);
  };
  for (const b of $$('[data-a]', box)) b.onclick = async () => {
    const name = b.closest('[data-b]').dataset.b, bk = d.backups.find(x => x.name === name);
    if (b.dataset.a === 'restore') {
      if (!await confirmBox('Restore this backup', `Your data is replaced by the backup of <b>${esc(fullDate(bk.at))}</b> (${esc(held(bk.counts)) || size(bk.bytes)}).<br><br>
        What is in the database now is backed up first, so you can come back to it.`, 'Restore')) return;
      await restoreBackup(b, name);
    } else {
      if (!await confirmBox('Delete backup permanently', `The backup of <b>${esc(fullDate(bk.at))}</b> is deleted from the disk. <b class="red">This cannot be undone.</b>`, 'Delete permanently')) return;
      await busy(b, async () => { await api('POST', '/api/data/delete', { name }); toast('Backup deleted'); dataTab(m); });
    }
  };
}

const restoreBackup = (btn, name) => busy(btn, async () => { await api('POST', '/api/data/restore', { name }); toast('Backup restored'); setTimeout(() => location.reload(), 600); });

function wipeDialog(d) {
  const w = modal({ title: 'Wipe the database', size: 'small', body: `
    <div class="hazard">${icon('alert', 22)}<div><b>Danger: this erases your data</b>
      <span>Every task, person, organisation, draft, thread, email copy and activity entry in Mandata is erased (${esc(held(d.current))}). Mail is then read again from the start, which can take hours. Your Outlook mailbox is not touched.</span></div></div>
    <label class="tog"><input type="checkbox" id="wBak" checked><span>Keep a backup, so I can restore this data later (recommended)</span></label>
    <label class="tog"><input type="checkbox" id="wSet" checked><span>Keep my settings (name, mailbox, AI model, prompts)</span></label>
    <label class="f">Type <b>WIPE</b> to confirm</label><input type="text" id="wTxt" autocomplete="off" spellcheck="false" placeholder="WIPE">`,
    footer: '<div class="btnrow"><button class="btn danger solid" id="wGo" data-busy="Wiping" disabled>Wipe database</button><button class="btn ghost" id="wNo">Cancel</button></div>' });
  const go = $('#wGo', w.el), bak = $('#wBak', w.el), txt = $('#wTxt', w.el);
  const ok = () => { go.disabled = txt.value.trim() !== 'WIPE'; go.textContent = bak.checked ? 'Wipe database' : 'Wipe database, no backup'; };
  txt.oninput = ok; bak.onchange = ok; txt.focus();
  $('#wNo', w.el).onclick = () => w.close();
  go.onclick = async () => {
    if (!bak.checked && !await confirmBox('No backup', 'Without a backup, the data cannot be brought back. <b class="red">Erase it for good?</b>', 'Erase for good')) return;
    await busy(go, async () => {
      const r = await api('POST', '/api/data/wipe', { confirm: 'WIPE', backup: bak.checked, keepSettings: $('#wSet', w.el).checked });
      w.close(); toast(r.backup ? 'Database wiped. A backup was kept in Settings > Data' : 'Database wiped');
      setTimeout(() => location.reload(), 800);
    });
  };
}
