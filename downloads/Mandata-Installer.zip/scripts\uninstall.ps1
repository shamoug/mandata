<#
.SYNOPSIS
  Removes Mandata for the current user: the app, its shortcuts, its start-up entry and its Settings > Apps entry.
  Asks before removing your data (%USERPROFILE%\.mandata) and the local AI (only if Mandata's installer put it there).
  Run by uninstall.bat, from a copy in %TEMP% so the app's folder can be deleted.

.EXAMPLE
  powershell -ExecutionPolicy Bypass -File uninstall.ps1
  powershell -ExecutionPolicy Bypass -File uninstall.ps1 -Yes -KeepData -KeepAI
#>
[CmdletBinding()]
param([switch]$Yes, [switch]$KeepData, [switch]$KeepAI)

. (Join-Path $PSScriptRoot 'common.ps1')
$dest = Join-Path $env:LOCALAPPDATA 'Programs\Mandata'
$data = Join-Path $env:USERPROFILE '.mandata'
$port = 4318

function Ask([string]$Question, [bool]$Default) {
  if ($Yes) { return $Default }
  $hint = if ($Default) { '[Y/n]' } else { '[y/N]' }
  $a = Read-Host "        $Question $hint"
  if (-not $a.Trim()) { return $Default }
  return $a.Trim() -match '^(y|yes|o|oui)$'
}

try {
  Write-Host ''
  Write-Host '  Uninstalling Mandata' -ForegroundColor White
  if (-not (Ask 'Remove Mandata from this computer?' $true)) { Write-Info 'Nothing was changed.'; exit 0 }
  $state = Get-SetupState

  Write-Step 'Closing Mandata'
  if (Request-AppShutdown $port) { Start-Sleep -Seconds 2 }
  for ($i = 0; $i -lt 10; $i++) {
    $running = Get-Process -ErrorAction SilentlyContinue | Where-Object { try { $_.Path -and $_.Path.StartsWith($dest, [StringComparison]::OrdinalIgnoreCase) } catch { $false } }
    if (-not $running) { break }
    $running | Stop-Process -Force -ErrorAction SilentlyContinue
    Start-Sleep -Seconds 1
  }
  Write-Ok 'Closed'

  Write-Step 'Removing the app'
  foreach ($l in (Join-Path ([Environment]::GetFolderPath('Programs', 'Create')) 'Mandata.lnk'), (Join-Path ([Environment]::GetFolderPath('Desktop', 'Create')) 'Mandata.lnk')) {
    Remove-Item -Force $l -ErrorAction SilentlyContinue
  }
  # Start with Windows: the app registers itself under its app id.
  foreach ($k in 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Run', 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\StartupApproved\Run') {
    $p = Get-ItemProperty $k -ErrorAction SilentlyContinue
    if (-not $p) { continue }
    foreach ($v in $p.PSObject.Properties) {
      if ($v.Name -in @('Shamoug.Mandata', 'UN.Mandata') -or ($v.Value -is [string] -and $v.Value -like "*$dest*")) { Remove-ItemProperty -Path $k -Name $v.Name -ErrorAction SilentlyContinue }
    }
  }
  Remove-Item -Recurse -Force 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\Mandata' -ErrorAction SilentlyContinue
  for ($i = 0; $i -lt 10 -and (Test-Path $dest); $i++) { try { Remove-Item -Recurse -Force $dest -ErrorAction Stop } catch { Start-Sleep -Seconds 1 } }
  if (Test-Path $dest) { Write-Note "Some files in $dest are in use; delete the folder after restarting the computer." }
  # The window's size and the app's browser cache (not your data).
  Remove-Item -Recurse -Force (Join-Path $env:APPDATA 'Mandata') -ErrorAction SilentlyContinue
  Remove-Item -Recurse -Force (Join-Path $script:StateDir 'downloads') -ErrorAction SilentlyContinue
  Write-Ok 'App, shortcuts and start-up entry removed'

  if (-not $KeepData -and (Test-Path $data)) {
    Write-Step 'Your data'
    if (Ask "Also delete your tasks, people and settings in $data? This cannot be undone." $false) {
      Remove-Item -Recurse -Force $data
      Write-Ok 'Deleted'
    } else { Write-Ok "Kept in $data (installing Mandata again picks it up)" }
  }

  if (-not $KeepAI -and $state.ollamaInstalled) {
    Write-Step 'Local AI'
    if (Ask "Also remove the AI server and model that Mandata's installer added?" $false) {
      $aiArgs = @('-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', (Join-Path $PSScriptRoot 'ai-setup.ps1'), '-Remove')
      if ($state.model) { $aiArgs += '-RemoveModel', '-Model', [string]$state.model }
      & powershell @aiArgs
    } else { Write-Ok 'Kept' }
  }

  Write-Host ''
  Write-Host '  Mandata is uninstalled.' -ForegroundColor Green
  exit 0
} catch {
  Write-Host ''
  Write-Host "  UNINSTALL FAILED: $($_.Exception.Message)" -ForegroundColor Red
  exit 1
}
