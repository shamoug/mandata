// Threads: every conversation the AI read, its tasks branching off the emails that opened them, and the emails themselves.
import { GET, api, esc, $, $$, icon, avatar, when, fullDate, toast, busy, enc, pref, setPref, plural, latest, debounce, errorBox } from '../ui.js';
import { onView, go, isMe } from '../store.js';
import { taskCard, conversation } from '../panels.js';
import { mailHtml } from '../mailtext.js';
import { suggest } from '../suggest.js';
import { threadFlow } from '../viz.js';

let root, threads = [], sel = '', q = pref('thq', ''), only = pref('thonly', 'tasks'), scrollTo = '';
const STATE = { analysed: ['Read', '#2f9e44'], pending: ['Waiting', '#f59f00'], skipped: ['Automated', '#74c0fc'], notask: ['No task', '#0c8599'], stuck: ['Stuck: read again later', '#d9480f'], failed: ['Failed', '#e03131'] };

export function mount(el, arg) {
  root = el;
  el.innerHTML = `<div class="split"><aside class="listpane"><div class="lp-head">
      <label class="search">${icon('search', 14)}<input type="search" id="thQ" placeholder="Search threads"></label>
      <div class="seg sm" id="thOnly"><button data-v="tasks">With task</button><button data-v="none">No task</button></div></div>
      <div id="thList" class="lp-list"></div></aside>
    <section class="detailpane" id="thDetail"><div class="empty">${icon('thread', 40)}<p>Choose a thread to see how its tasks started and ended.</p></div></section></div>`;
  $('#thQ', el).value = q;
  $('#thQ', el).oninput = debounce(e => { q = e.target.value.toLowerCase(); setPref('thq', q); renderList(); }, 150);
  suggest($('#thQ', el), () => threads.filter(has).map(t => ({ label: t.subject })));
  $('#thOnly', el).onclick = e => { const v = e.target.closest('button')?.dataset.v; if (v) { only = v; setPref('thonly', v); renderList(); } };
  $('#thList', el).addEventListener('click', e => {
    const c = e.target.closest('[data-sc]'); if (!c) return;
    if (c.closest('[data-th]').dataset.th === sel) $(c.dataset.sc, root)?.scrollIntoView({ behavior: 'smooth' }); else scrollTo = c.dataset.sc;
  }, true);
  $('#thList', el).onclick = e => { const r = e.target.closest('[data-th]'); if (r) go('threads', r.dataset.th); };
  load().then(() => select(arg));
  onView('threads', () => load().then(() => sel && showDetail(sel, true)));
  onView('tasks', () => sel && showDetail(sel, true));
}
export function select(arg) {
  // Narrow screens show the list or the thread, not both: the class says which.
  $('.split', root)?.classList.toggle('has-sel', !!arg);
  // No thread asked for: keep the last one open, or open the first in the list, so the detail pane is never blank.
  if (!arg) {
    const vis = visible();
    if (!vis.some(t => t.id === sel)) sel = vis[0]?.id || '';
    renderList();
    if (sel) showDetail(sel);
    return;
  }
  sel = arg;
  // Opened from elsewhere (a task, an email): make sure the thread is in the list, then bring it into view.
  const t = threads.find(x => x.id === arg);
  if (t && !(has(t) && (!q || t.subject.toLowerCase().includes(q)))) {
    only = t.all_tasks ? 'tasks' : 'none'; q = ''; setPref('thonly', only); setPref('thq', ''); const s = $('#thQ', root); if (s) s.value = '';
  }
  renderList(); revealSel(); showDetail(arg);
}
// Centre the selected row in the list, unless it is already fully visible (so clicking a row does not jump).
function revealSel() {
  const list = $('#thList', root), row = list && $('.throw.on', list); if (!row) return;
  const lr = list.getBoundingClientRect(), rr = row.getBoundingClientRect();
  if (rr.top < lr.top || rr.bottom > lr.bottom) list.scrollTop += rr.top - lr.top - (lr.height - rr.height) / 2;
}
const load = latest(() => GET('/api/threads'), r => { threads = r; renderList(); }, e => toast(`Could not load the threads: ${e.message}`, true));
// Two lists: threads with a task, and threads with none.
const has = t => only === 'none' ? !t.all_tasks : !!t.all_tasks;
const visible = () => threads.filter(t => has(t) && (!q || t.subject.toLowerCase().includes(q)));

function renderList() {
  // root is #main, there for every page: the view is still on screen only while its own list is.
  if (!root || !$('#thList', root)) return;
  $$('#thOnly button', root).forEach(b => b.classList.toggle('on', b.dataset.v === only));
  const list = visible();
  $('#thList', root).innerHTML = list.map(t => { const [l, c] = STATE[t.state] || ['', '#74c0fc'];
    return `<button class="throw ${t.id === sel ? 'on' : ''}" data-th="${esc(t.id)}"><b>${esc(t.subject)}</b>
      <span class="muted small">${t.messages} email${t.messages > 1 ? 's' : ''} · ${esc(when(t.last_at))}</span>
      <span class="th-tags">${t.open_tasks ? `<span class="cnt" data-go="#/threads/${enc(t.id)}" data-sc="#thTasks" title="See the open tasks">${t.open_tasks} open</span>` : ''}${t.all_tasks - t.open_tasks ? `<span class="cnt done" data-go="#/threads/${enc(t.id)}" data-sc="#thTasks" title="See the closed tasks">${t.all_tasks - t.open_tasks} closed</span>` : ''}
      <span class="stdot" style="--c:${c}" title="${l}"></span></span></button>`; }).join('') || '<div class="empty sm">No threads.</div>';
}

// Only the newest answer is drawn: a refresh and a click landing out of order never show an older thread.
const showDetail = latest(id => GET('/api/threads/' + enc(id)), drawDetail,
  (e, id, quiet) => { const box = $('#thDetail', root); if (!quiet && sel === id && box?.isConnected) box.innerHTML = errorBox(e); });
function drawDetail(t, id) {
  const box = $('#thDetail', root);
  if (sel !== id || !box?.isConnected) return;
  const [l, c] = STATE[t.state] || ['', '#74c0fc'];
  // Everyone who wrote or was written to, most active first: each one opens their profile.
  const ppl = new Map();
  for (const m of t.messages) for (const r of [{ name: m.from_name, email: m.from_email }, ...m.to, ...m.cc]) {
    const k = String(r.email || '').toLowerCase(); if (!k) continue;
    const x = ppl.get(k) || { name: r.name || r.email, email: k, n: 0 }; x.n++; ppl.set(k, x);
  }
  if (!t.tasks.length) return plain(t, box, id);
  const openN = t.tasks.filter(x => x.status === 'open').length;
  box.innerHTML = `<a class="back th-back" data-go="#/threads">${icon('arrow', 12)} All threads</a><header class="th-head"><div><h2>${esc(t.subject)}</h2>
      <div class="muted small">${t.messages.length} emails · ${esc(fullDate(t.first_at))} to ${esc(fullDate(t.last_at))} · <span style="color:${c}">${l}</span>${t.ai_error ? ` · <span class="red">Last AI read failed: ${esc(t.ai_error)}</span>` : ''}</div>
      <div class="th-badges">${openN ? `<span class="chip" data-scroll="#thTasks" style="--c:#c8822f"><i></i>${openN} open task${openN > 1 ? 's' : ''}</span>` : ''}${t.tasks.length - openN ? `<span class="chip" data-scroll="#thTasks" style="--c:#2f8a4f"><i></i>${t.tasks.length - openN} closed</span>` : ''}
        <span class="chip" data-scroll="#thConvo" style="--c:#3b5bdb"><i></i>${plural(t.messages.length, 'email')}</span></div>
      <div class="th-people">${[...ppl.values()].sort((a, b) => b.n - a.n).slice(0, 14).map(x => isMe(x.email) ? `<span class="pchip2">${avatar('Me', x.email, 'xs')}Me<em>${x.n}</em></span>`
        : `<a class="pchip2" data-person="${esc(x.email)}" title="${esc(x.email)}">${avatar(x.name, x.email, 'xs')}${esc(x.name)}<em>${x.n}</em></a>`).join('')}</div></div>
      <button class="btn sm" id="reread" data-busy="Queued">${icon('refresh', 13)} Read again</button></header>
    ${t.summary ? `<div class="stand"><b>${icon('spark', 12)} What this thread is about</b>${esc(t.summary)}</div>` : ''}
    <section class="panel"><h3>${icon('thread', 15)} Task flow <span class="muted">each task branches off the email that opened it and merges back where it closed</span></h3>
      <div class="tflow-wrap big">${threadFlow(t, { width: box.clientWidth - 44 })}</div></section>
    <section class="panel" id="thTasks"><h3>${icon('tasks', 15)} Tasks in this thread</h3><div class="cards">${t.tasks.map(x => taskCard(x)).join('')}</div></section>
    <section class="panel" id="thConvo"><h3>${icon('mail', 15)} Conversation</h3>${conversation(t.messages, { tasks: t.tasks })}</section>`;
  reread(box, id);
  if (scrollTo) { $(scrollTo, box)?.scrollIntoView({ block: 'start' }); scrollTo = ''; }
}

/** A thread with no task: only its emails, as they came. Subject, from, to, cc, date, attachments and the text. */
function plain(t, box, id) {
  const [l, c] = STATE[t.state] || ['', '#74c0fc'];
  const who = (name, email) => isMe(email) ? 'Me' : email ? `<a data-person="${esc(email)}">${esc(name || email)}</a>${name && name !== email ? ` <span class="muted">&lt;${esc(email)}&gt;</span>` : ''}` : esc(name);
  const list = r => r.map(x => who(x.name, x.email)).join(', ');
  const row = (k, v) => v ? `<tr><th>${k}</th><td>${v}</td></tr>` : '';
  box.innerHTML = `<a class="back th-back" data-go="#/threads">${icon('arrow', 12)} All threads</a><header class="th-head"><div><h2>${esc(t.subject)}</h2>
      <div class="muted small">${plural(t.messages.length, 'email')} · <span style="color:${c}">${l}</span>${t.ai_error ? ` · <span class="red">Last AI read failed: ${esc(t.ai_error)}</span>` : ''}</div></div>
      <button class="btn sm" id="reread" data-busy="Queued">${icon('refresh', 13)} Read again</button></header>
    ${t.messages.map(m => `<section class="panel plainmail"><table class="mailhead">
      ${row('Subject', `<b>${esc(m.subject || t.subject)}</b>`)}${row('From', who(m.from_name, m.from_email))}${row('To', list(m.to))}${row('Cc', list(m.cc))}
      ${row('Date', esc(fullDate(m.received_at)))}${row('Attachments', (m.attachments || []).map(esc).join(', '))}</table>
      <div class="plainbody">${mailHtml(m.body)}</div>
      <button class="mini" data-msg="${esc(m.id)}" title="Open in a window">${icon('out', 12)}</button></section>`).join('')}`;
  reread(box, id);
}
const reread = (box, id) => { $('#reread', box).onclick = e => busy(e.currentTarget, async () => { await api('POST', `/api/threads/${enc(id)}/reread`); toast('The AI will read this thread again carefully, looking for a missed task'); }); };
