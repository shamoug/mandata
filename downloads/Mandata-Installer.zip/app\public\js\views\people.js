// People met in email threads: a profile for each, with a short bio and a statement of the tasks they give and receive.
import { GET, api, esc, $, $$, icon, avatar, colorOf, dueBadge, dueKey, statusChip, DIR, dateLabel, when, toast, busy, modal, pref, setPref, enc, labelOf, peopleSwitch, latest, debounce, errorBox } from '../ui.js';
import { onView, go, S } from '../store.js';
import { whoFlow, monthStrip } from '../viz.js';

let root, people = [], q = pref('pq', ''), sort = pref('psort', 'active'), layout = pref('playout', 'cards'), current = '', scrollTo = '';

export function mount(el, arg) {
  root = el;
  el.innerHTML = '<div class="page" id="pp"></div>';
  // A statistic on a person's card opens the profile at the matching section.
  // On the page, not on #main (which outlives this view): leaving the view takes the listener with it.
  el.firstElementChild.addEventListener('click', e => { const c = e.target.closest('[data-sc]'); if (c) scrollTo = c.dataset.sc; }, true);
  select(arg);
  // Not while you write your notes: a refresh would take what you typed with it.
  const writing = () => document.activeElement?.id === 'pfNotes';
  onView('people', () => current ? !writing() && showProfile(current, true) : loadList());
  onView('tasks', () => current && !writing() && showProfile(current, true));
  onView('config', () => current && !writing() && showProfile(current, true));   // your name labels the task flow
}
export function select(arg) { current = arg || ''; current ? showProfile(current) : loadList(); }

const loadList = latest(() => GET('/api/people'), r => { people = r; if (!current) renderList(); },
  e => { const box = $('#pp', root); if (box && !current && !people.length) box.innerHTML = errorBox(e); else if (box) toast(`Could not load the people: ${e.message}`, true); });

function renderList() {
  const box = $('#pp', root);
  // A search typed just before opening a profile lands after it: the list must not replace the profile.
  if (!box || current) return;
  if (!$('#pQ', box)) {
    box.innerHTML = `<div class="fbar"><h2 class="ptitle">${icon('people', 18)} People</h2>${peopleSwitch('people')}<span class="muted small" id="pCount"></span><span class="sp"></span>
      <label class="search">${icon('search', 14)}<input type="search" id="pQ" placeholder="Search name, short name, organisation, bio"></label>
      <select id="pSort"><option value="active">Most open work</option><option value="recent">Seen most recently</option><option value="mail">Most emails</option><option value="name">Name</option></select>
      <div class="seg icons" id="pLayout"><button data-v="cards" title="Cards">${icon('grid', 14)}</button><button data-v="table" title="Table">${icon('list', 14)}</button></div></div><div id="pList"></div>`;
    $('#pQ', box).oninput = debounce(e => { q = e.target.value.toLowerCase(); setPref('pq', q); renderList(); }, 150);
    $('#pSort', box).onchange = e => { sort = e.target.value; setPref('psort', sort); renderList(); };
    $('#pLayout', box).onclick = e => { const v = e.target.closest('button')?.dataset.v; if (v) { layout = v; setPref('playout', v); renderList(); } };
    $('#pCount', box).onclick = e => { if (e.target.closest('[data-clear]')) { q = ''; setPref('pq', ''); $('#pQ', box).value = ''; renderList(); } };
  }
  // The search survives a visit to a profile, so the rebuilt box must show it.
  if ($('#pQ', box).value.toLowerCase() !== q) $('#pQ', box).value = q;
  $('#pSort', box).value = sort;
  $$('#pLayout button', box).forEach(b => b.classList.toggle('on', b.dataset.v === layout));
  const S_ = { active: (a, b) => b.owns_open + b.gives_open - a.owns_open - a.gives_open || b.messages - a.messages, recent: (a, b) => String(b.last_seen).localeCompare(String(a.last_seen)),
    mail: (a, b) => b.messages - a.messages, name: (a, b) => a.name.localeCompare(b.name) };
  const list = people.filter(p => !q || [p.name, ...(p.aka || []), p.email, p.title, p.organization, p.unit, p.bio].join(' ').toLowerCase().includes(q)).sort(S_[sort]);
  $('#pCount', box).innerHTML = `${list.length} of ${people.length}${q ? ` · <a data-clear style="cursor:pointer;text-decoration:underline">Clear search</a>` : ''}`;
  const out = $('#pList', box);
  if (!list.length) { out.innerHTML = `<div class="empty">${icon('people', 40)}<p>${q ? 'Nobody matches this search.' : 'People appear here as the app reads your email.'}</p></div>`; return; }
  out.innerHTML = layout === 'table' ? `<table class="tbl fixed ppl-tbl"><colgroup><col style="width:20%"><col style="width:17%"><col style="width:21%"><col style="width:10%"><col style="width:9%"><col style="width:6%"><col style="width:7%"><col></colgroup><thead><tr><th>Name</th><th>Title</th><th>Organisation</th><th class="r">Asked of them</th><th class="r">They asked</th><th class="r">Late</th><th class="r">Emails</th><th>Last seen</th></tr></thead><tbody>
    ${list.map(p => `<tr data-person="${esc(p.email)}"><td><span class="pcell">${avatar(p.name, p.email, 'sm')}<b>${esc(p.name)}</b></span></td><td class="muted">${esc(p.title)}</td><td class="muted">${esc(p.organization)}${p.unit_id ? ` <span class="uchip" data-go="#/org/${enc(p.unit_id)}" title="Show in the organisation">${esc(p.unit || 'Unit')}</span>` : ''}</td>
      <td class="r num">${p.owns_open}<span class="muted">/${p.owns}</span></td><td class="r num">${p.gives_open}<span class="muted">/${p.gives}</span></td><td class="r num ${p.late ? 'red' : 'muted'}">${p.late ? `<span class="badge red">${p.late}</span>` : 0}</td>
      <td class="r num">${p.messages}</td><td class="muted" data-sort="${esc(p.last_seen || '')}">${esc(when(p.last_seen))}</td></tr>`).join('')}</tbody></table>`
    : `<div class="pgrid">${list.map(p => `<article class="pcard" data-person="${esc(p.email)}" style="--c:${colorOf(p.email)}">
      <div class="pc-band"></div>${avatar(p.name, p.email, 'lg')}<h4>${esc(p.name)}${p.aka?.length ? ` <span class="muted small" title="Also called">(${esc(p.aka.join(', '))})</span>` : ''}</h4>
      <div class="muted small clamp1">${esc([p.title, p.organization].filter(Boolean).join(' · ') || p.email)}</div>
      ${p.unit_id ? `<span class="uchip" data-go="#/org/${enc(p.unit_id)}" title="Show in the organisation">${esc(p.unit || 'Unit')}</span>` : ''}
      <p class="pc-bio">${esc(p.bio || 'Profile not written yet.')}</p>
      <div class="pc-stats"><span data-go="#/people/${enc(p.email)}" data-sc="#pfOwns" style="--c:${DIR.to_me.color}" title="Open tasks asked of them"><b class="num">${p.owns_open}</b>to do</span>
        <span data-go="#/people/${enc(p.email)}" data-sc="#pfGives" style="--c:${DIR.by_me.color}" title="Open tasks they asked of others"><b class="num">${p.gives_open}</b>asked</span>
        <span data-go="#/people/${enc(p.email)}" data-sc="#pfOwns" style="--c:#e03131" title="Their open tasks past the deadline"><b class="num">${p.late}</b>late</span>
        <span data-go="#/people/${enc(p.email)}" data-sc="#pfThreads" style="--c:#0b7285" title="Emails they appear in"><b class="num">${p.messages}</b>emails</span></div></article>`).join('')}</div>`;
}

// Where a short name came from: you, how they are greeted ("Dear Alaa"), how they sign ("Best, Alaa").
const akaHow = a => a.yours ? 'Added by you' : [a.greeted ? `greeted so in ${a.greeted} email${a.greeted > 1 ? 's' : ''}` : '', a.signed ? `signs so in ${a.signed}` : '']
  .filter(Boolean).join(', ').replace(/^./, c => c.toUpperCase());

let asked = 0;   // only the newest answer is drawn
async function showProfile(email, quiet) {
  const box = $('#pp', root), n = ++asked;
  let p;
  try { p = await GET('/api/people/' + enc(email)); } catch (e) { if (!quiet && n === asked && box?.isConnected) box.innerHTML = errorBox(e); return; }
  if (n !== asked || current !== email || !box?.isConnected) return;
  const c = colorOf(p.email);
  const theirs = p.tasks.filter(t => t.owner_email === p.email || (t.secondary || []).some(x => x.email === p.email)), given = p.tasks.filter(t => t.requester_email === p.email);
  const openN = l => l.filter(t => t.status === 'open').length, late = theirs.filter(t => t.overdue).length;
  const row = (t, other, otherEmail) => `<tr data-task="${t.id}" class="${t.overdue ? 'late' : ''}"><td><i class="bar" style="background:${DIR[t.direction]?.color}"></i></td><td data-sort="${esc(t.title)}"><b>${esc(t.title)}</b><div class="small clamp1"><a class="muted" data-thread="${esc(t.conversation_id)}" title="Open the thread">${esc(t.subject)}</a></div></td>
    <td><a class="pcell" data-person="${esc(otherEmail)}">${avatar(other, otherEmail, 'xs')}${esc(other || '?')}</a></td><td class="num muted" data-sort="${esc(t.opened_at || '')}">${esc(dateLabel(t.opened_at))}</td><td data-sort="${esc(dueKey(t))}">${dueBadge(t)}</td>
    <td>${statusChip(t)}</td></tr>`;
  const statement = (list, head, empty, side) => `<table class="tbl fixed stmt-tbl"><colgroup><col style="width:14px"><col><col style="width:24%"><col style="width:6.5em"><col style="width:10em"><col style="width:8em"></colgroup><thead><tr><th></th><th>Task</th><th>${head}</th><th>Opened</th><th>Deadline</th><th>Status</th></tr></thead><tbody>
    ${list.map(t => side === 'owner' ? row(t, t.requester_name, t.requester_email) : row(t, t.owner_name, t.owner_email)).join('') || `<tr><td></td><td colspan="5" class="muted">${empty}</td></tr>`}</tbody></table>`;
  const maxTie = Math.max(1, ...p.ties.map(x => x.asks + x.asked));
  box.innerHTML = `
  <a class="back" href="#/people">${icon('arrow', 13)} All people</a>
  <header class="profile" style="--c:${c}">
    ${avatar(p.name, p.email, 'xl')}
    <div class="pf-id"><h1>${esc(p.name)}</h1>${p.aka.length ? `<div class="pf-aka small">Also called ${p.aka.map(a => `<b title="${esc(akaHow(a))}">${esc(a.name)}</b>`).join(', ')}</div>` : ''}<div class="pf-role">${esc([p.title, p.organization].filter(Boolean).join(' · ') || 'Job title not known yet')}</div>
      <div class="pf-path">${p.path.length ? p.path.map(u => `<a data-go="#/org/${enc(u.id)}" title="Show this ${esc(u.type)} in the organisation">${esc(u.name)}</a>`).join(icon('arrow', 10)) : '<span class="muted">Not placed in the organisation yet</span>'}
        <button class="mini" id="pfUnit" title="Place in an organisation, division, branch, section or team">${icon('edit', 12)}</button></div>
      <div class="muted small">${icon('mail', 11)} <a href="mailto:${esc(p.email)}" style="color:inherit">${esc(p.email)}</a> · seen ${esc(dateLabel(p.first_seen))} to ${esc(dateLabel(p.last_seen))}${p.bio_at ? ` · profile written ${esc(when(p.bio_at))}` : ''}</div></div>
    <div class="pf-act"><button class="btn sm" id="pfBio" data-busy="Writing">${icon('spark', 13)} ${p.bio_at ? 'Rewrite profile' : 'Write profile'}</button>
      <button class="btn sm ghost" id="pfEdit">${icon('edit', 13)} Edit</button><button class="btn sm ghost" id="pfHide" title="Not a person, or not useful">${icon('eye', 13)} Hide</button></div>
  </header>
  <div class="mailcounts">
    <span data-scroll="#pfThreads" style="--c:#1c7ed6"><b class="num">${p.mail.from}</b>emails from them</span><span data-scroll="#pfThreads" style="--c:#0ca678"><b class="num">${p.mail.to}</b>to them</span>
    <span data-scroll="#pfThreads" style="--c:#1864ab"><b class="num">${p.mail.cc}</b>with them in cc</span><span data-scroll="#pfThreads" style="--c:#f76707"><b class="num">${p.mail.withMe}</b>you wrote to them</span>
    <span data-scroll="#pfOwns" style="--c:#1c7ed6"><b class="num">${p.tasks.length}</b>tasks in all</span></div>
  <div class="pf-tiles">
    <div class="ptile" data-scroll="#pfOwns" style="--c:${DIR.to_me.color}"><b class="num">${openN(theirs)}</b><span>open tasks asked of them</span><small>${theirs.length} in all</small></div>
    <div class="ptile" data-scroll="#pfGives" style="--c:${DIR.by_me.color}"><b class="num">${openN(given)}</b><span>open tasks they asked for</span><small>${given.length} in all</small></div>
    <div class="ptile" data-scroll="#pfOwns" style="--c:#e03131"><b class="num">${late}</b><span>of their tasks overdue</span><small>${theirs.filter(t => t.status === 'done').length} completed</small></div>
    <div class="ptile" data-scroll="#pfThreads" style="--c:#1098ad"><b class="num">${p.messages}</b><span>emails with them</span><small>${p.sent} written by them</small></div>
  </div>
  <div class="pf-grid">
    <div class="pf-main">
      <section class="panel bio"><h3>${icon('user', 15)} Profile</h3><p class="lead">${esc(p.bio || 'The AI writes this once it has seen enough of their email.')}</p>
        ${p.tasking ? `<h4>Tasking at a glance</h4><p>${esc(p.tasking)}</p>` : ''}${p.relationship ? `<h4>Working with you</h4><p>${esc(p.relationship)}</p>` : ''}</section>
      <section class="panel" id="pfOwns"><h3 style="color:${DIR.to_me.ink}">${icon('inbox', 15)} Statement of tasks: asked of ${esc(p.name.split(' ')[0])}</h3>${statement(theirs, 'Asked by', 'Nobody has asked them for anything in the mail read so far.', 'owner')}</section>
      <section class="panel" id="pfGives"><h3 style="color:${DIR.by_me.ink}">${icon('send', 15)} Statement of tasks: ${esc(p.name.split(' ')[0])} asked others</h3>${statement(given, 'Asked of', 'They have not asked anyone for anything in the mail read so far.', 'requester')}</section>
    </div>
    <aside class="pf-side">
      ${p.tasks.length ? `<section class="panel"><h3>${icon('people', 15)} Task flow</h3>${whoFlow(p.tasks, { meLabel: S.config?.me?.name || 'Me', height: Math.min(260, 90 + p.ties.length * 26), width: 420, max: 6, status: 'all' })}</section>` : ''}
      <section class="panel"><h3>${icon('people', 15)} Works with <span class="badge">${p.ties.length}</span></h3>${p.ties.map(x => `<div class="tie" ${x.me ? '' : `data-person="${esc(x.email)}"`}>${avatar(x.me ? 'Me' : x.name, x.email, 'sm')}<span class="clamp1">${esc(x.me ? 'You' : x.name)}</span>
        <div class="tiebar"><i style="width:${x.asks / maxTie * 100}%;background:${DIR.by_me.color}" title="They asked ${x.asks}"></i><i style="width:${x.asked / maxTie * 100}%;background:${DIR.to_me.color}" title="Asked them ${x.asked}"></i></div>
        <small class="num">${x.asks}↗ ${x.asked}↙</small></div>`).join('') || '<div class="muted small">No shared tasks yet.</div>'}
        <div class="legend"><span><i style="background:${DIR.by_me.color}"></i>they asked</span><span><i style="background:${DIR.to_me.color}"></i>asked them</span></div></section>
      <section class="panel"><h3>${icon('pulse', 15)} Emails per month</h3>${monthStrip(p.months)}</section>
      <section class="panel" id="pfThreads"><h3>${icon('thread', 15)} Threads <span class="badge">${p.threads.length}</span></h3>${p.threads.map(t => `<a class="thlink" href="#/threads/${enc(t.id)}">${esc(t.subject)}<small>${esc(when(t.last_at))}</small></a>`).join('') || '<div class="muted small">None</div>'}</section>
      <section class="panel"><h3>${icon('edit', 15)} Your notes</h3><textarea id="pfNotes" rows="4" placeholder="Private notes about working with ${esc(p.name.split(' ')[0])}">${esc(p.notes)}</textarea></section>
    </aside>
  </div>`;
  if (scrollTo) { $(scrollTo, box)?.scrollIntoView({ block: 'start' }); scrollTo = ''; }
  $('#pfBio', box).onclick = e => busy(e.currentTarget, async () => { await api('POST', `/api/people/${enc(email)}/bio`); showProfile(email, true); });
  $('#pfUnit', box).onclick = async () => {
    let units; try { ({ units } = await GET('/api/org')); } catch (e) { return toast(e.message, true); }
    const m = modal({ title: `Place ${p.name}`, size: 'small', body: `<label class="f">Organisation or unit</label><select id="puSel" style="width:100%"><option value="">(not placed)</option>
      ${units.map(u => `<option value="${esc(u.id)}" ${u.id === p.unit_id ? 'selected' : ''}>${esc(labelOf('unit_types', u.type))}: ${esc(u.name)}</option>`).join('')}</select>
      <p class="muted small">New units are made on the Organisation page. Your choice is kept: signatures never move them again.</p>`,
      footer: '<div class="btnrow"><button class="btn primary ok">Save</button></div>' });
    $('.ok', m.el).onclick = async () => { try { await api('POST', '/api/org/assign', { emails: [email], unit_id: $('#puSel', m.el).value || null }); } catch (e) { return toast(e.message, true); } m.close(true); showProfile(email, true); };
  };
  $('#pfHide', box).onclick = async () => { try { await api('PATCH', `/api/people/${enc(email)}`, { hidden: true }); } catch (e) { return toast(e.message, true); } toast('Hidden from People'); go('people'); };
  $('#pfNotes', box).onchange = e => api('PATCH', `/api/people/${enc(email)}`, { notes: e.target.value }).then(() => toast('Notes saved')).catch(err => toast(err.message, true));
  $('#pfEdit', box).onclick = async () => {
    // Organisation and unit are picked from the units on the Organisation page, so names stay consistent.
    let units; try { ({ units } = await GET('/api/org')); } catch (e) { return toast(e.message, true); }
    const unitOf = id => units.find(u => u.id === id), label = t => t[0].toUpperCase() + t.slice(1);
    const kids = id => units.filter(u => (u.parent_id || null) === id).sort((a, b) => a.name.localeCompare(b.name));
    const orgs = units.filter(u => u.type === 'organization').sort((a, b) => a.name.localeCompare(b.name));
    const orgId = p.path.find(u => u.type === 'organization')?.id || orgs.find(u => u.name.toLowerCase() === String(p.organization).trim().toLowerCase())?.id || '';
    const unitId = unitOf(p.unit_id)?.type !== 'organization' ? p.unit_id || '' : '';
    // With no organisation chosen, units that sit under no organisation are offered instead.
    const unitOpts = oid => {
      const out = [], walk = (id, d) => kids(id).forEach(u => { out.push(`<option value="${esc(u.id)}" ${u.id === unitId ? 'selected' : ''}>${' '.repeat(d)}${esc(label(u.type))}: ${esc(u.name)}</option>`); walk(u.id, d + 1); });
      if (oid) walk(oid, 0);
      else units.filter(u => u.type !== 'organization' && (!u.parent_id || !unitOf(u.parent_id))).sort((a, b) => a.name.localeCompare(b.name)).forEach(u => { out.push(`<option value="${esc(u.id)}" ${u.id === unitId ? 'selected' : ''}>${esc(label(u.type))}: ${esc(u.name)}</option>`); walk(u.id, 1); });
      return '<option value="">(none)</option>' + out.join('');
    };
    const orgOther = !orgId && p.organization ? `<option value="__text" selected>${esc(p.organization)} (not on the Organisation page)</option>` : '';
    const field = k => `<label class="f">${label(k)}</label>${['bio', 'tasking', 'relationship'].includes(k) ? `<textarea rows="3" data-k="${k}">${esc(p[k])}</textarea>` : `<input type="text" data-k="${k}" value="${esc(p[k])}">`}`;
    const akaField = `<label class="f">Other names</label><input type="text" id="peAka" value="${esc(p.aka.map(a => a.name).join(', '))}" placeholder="Short names they go by, comma separated">`;
    const m = modal({ title: 'Edit profile', body: field('name') + akaField + field('title') +
      `<label class="f">Organization</label><select id="peOrg" style="width:100%"><option value="">(none)</option>${orgOther}${orgs.map(u => `<option value="${esc(u.id)}" ${u.id === orgId ? 'selected' : ''}>${esc(u.name)}</option>`).join('')}</select>
       <label class="f">Division, branch, section or team</label><select id="peUnit" style="width:100%">${unitOpts(orgId)}</select>` +
      ['bio', 'tasking', 'relationship'].map(field).join('') +
      '<p class="muted small">What you change here is kept: the AI never overwrites it. New organisations and units are made on the Organisation page.</p>', footer: '<div class="btnrow"><button class="btn primary ok">Save</button></div>' });
    $('#peOrg', m.el).onchange = e => { $('#peUnit', m.el).innerHTML = unitOpts(e.target.value === '__text' ? '' : e.target.value); };
    $('.ok', m.el).onclick = async () => {
      const b = {}; $$('[data-k]', m.el).forEach(i => b[i.dataset.k] = i.value);
      b.aka = $('#peAka', m.el).value.split(',').map(x => x.trim()).filter(Boolean);
      const o = $('#peOrg', m.el).value, u = $('#peUnit', m.el).value;
      b.organization = o === '__text' ? p.organization : unitOf(o)?.name || '';
      b.unit = unitOf(u)?.name || '';
      const place = u || (o !== '__text' ? o : '') || null;
      try {
        await api('PATCH', `/api/people/${enc(email)}`, b);
        if (place !== (p.unit_id || null)) await api('POST', '/api/org/assign', { emails: [email], unit_id: place });
      } catch (e) { return toast(e.message, true); }
      m.close(true); showProfile(email, true);
    };
  };
}
