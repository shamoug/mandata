// Tasks found in email: filter by kind, state, deadline and person; cards grouped by urgency or by latest news, a table,
// or a board by kind. No way to add one by hand; you can close one from its card, or pin it (Pinned in What you did finds them).
import { api, GET, esc, $, $$, icon, confirmBox, avatar, DIR, dir, dirChip, dueBadge, dueKey, statusChip, statusGroup, STATUS, PRI, pref, setPref, dateLabel, ago, toast, CLOSE, plural, debounce, latest } from '../ui.js';
import { on, onView, emit, S } from '../store.js';
import { suggest } from '../suggest.js';
import { taskCard, taskActs, pinMark, unsureMark, openTask, currentTask, forwarded, followed } from '../panels.js';

let root, tasks = [], shown = [];
// Selecting tasks to reprocess in bulk.
let picking = false;
const picked = new Set();
// The dropdown filters hold lists of choices (any of them will do); empty is all. My open tasks is on by default:
// Open, and the tasks assigned to you and by you.
const blank = () => ({ dir: [], status: [], arr: [], due: [], mark: [], pri: 'any', from: '', to: '', q: '' });
const DEFAULTS = () => ({ status: ['open'], dir: ['to_me', 'by_me'] });
// The dropdowns you changed yourself since the defaults were last put in place: those stay white even on Open or To me.
const touched = new Set();
const F = { ...blank(), ...DEFAULTS(), ...savedFilters(), sort: pref('sort', 'deadline'), layout: pref('layout', 'cards') };
/** The filters as you left them last time, the ones still of the right kind (a list stays a list). */
function savedFilters() {
  // Saved as taskFilters3 since By me joined To me in My open tasks: filters saved before that start over once on My open tasks.
  const s = { ...pref('taskFilters3', {}) }, b = { ...blank(), status: [] };
  // New used to sit with the deadlines; it is about arrival, so a saved New moves to the Arrived dropdown (the old Deadline-source dropdown is gone).
  if (Array.isArray(s.due) && s.due.includes('new')) { s.due = s.due.filter(v => v !== 'new'); s.arr = [...new Set([...(Array.isArray(s.arr) ? s.arr : []), 'new'])]; }
  return Object.fromEntries(Object.entries(s || {}).filter(([k, v]) => k in b && Array.isArray(b[k]) === Array.isArray(v) && (Array.isArray(v) ? v.every(x => typeof x === 'string') : typeof v === 'string')));
}
const SORTS = [['deadline', 'Due date', '#c8822f'], ['news', 'Updates', '#2f9e44'], ['newest', 'Arrival date', '#3b5bdb'], ['priority', 'Priority', '#c92a2a']];

export function mount(el, arg) {
  root = el;
  el.innerHTML = `<div class="page tasks">
    <div class="fbar one">
      ${dd('dir', 'people', 'Kind of task')}${dd('status', 'check', 'Status')}${dd('arr', 'clock', 'Arrived', 'When the email that opened the task arrived')}${dd('due', 'flag', 'Deadline', 'A deadline is written in an email or set by you; a task with neither has none')}
      ${dd('mark', 'send', 'What you did', 'Tasks you acknowledged, forwarded to someone (by email or without), sent follow-up emails about, parked, or pinned')}
      <span class="sp"></span>
      <span class="sslot"><label class="search" title="Search tasks, people, threads (press /)">${icon('search', 14)}<input type="search" id="fQ" placeholder="Search tasks, people…"></label></span>
      ${dd('sort', 'newest', 'Sort by')}
      <button class="ibtn magic binbtn" id="fArchOthers" hidden title="Archive every open task between other people at once: seen, nothing for you to do (Ctrl+Z to undo)">${icon('spark', 15)}<em></em></button>
      <button class="ibtn" id="fPick" title="Select tasks to reprocess or delete">${icon('select', 15)}</button>
      <button class="ibtn binbtn" id="fBin" data-go="#/bin" title="Recycle bin: the tasks you deleted">${icon('trash', 15)}<em id="fBinN"></em></button>
      <div class="seg icons" id="fLayout">${[['cards', 'grid', 'Cards'], ['table', 'list', 'Table'], ['board', 'tasks', 'Board, a column per kind']].map(([k, i, l]) => `<button data-v="${k}" title="${l}" aria-label="${l}">${icon(i, 14)}</button>`).join('')}</div>
    </div>
    <div class="fchips" id="tChips"></div>
    <div class="pickbar" id="tPick" hidden></div>
    <div class="tbody" id="tList"></div></div>`;
  // On the page itself, not on el: el (#main) outlives this view, so listeners on it would pile up with every visit and cancel each other out.
  wireDropdowns($('.page', el));
  $('#fLayout', el).onclick = e => { const v = e.target.closest('button')?.dataset.v; if (v) { setPref('layout', v); set('layout', v); } };
  $('#fQ', el).value = F.q;
  // Filtered once you pause typing, not on every key: each pass counts every choice of every dropdown again.
  const search = debounce(e => set('q', e.target.value.trim().toLowerCase()), 150);
  $('#fQ', el).oninput = search;
  // Suggests task titles and the people in them.
  suggest($('#fQ', el), () => tasks.flatMap(t => [{ label: t.title, sub: 'Task' }, { label: t.requester_name, sub: 'Person' }, { label: t.owner_name, sub: 'Person' },
    ...(t.secondary || []).map(p => ({ label: p.name, sub: 'Person' }))]).filter(x => x.label));
  $('#fQ', el).onkeydown = e => { if (e.key === 'Escape' && e.target.value) { e.stopPropagation(); e.target.value = ''; set('q', ''); } };
  // The My open tasks switch: on puts Open, To me and By me in place, off takes them away; nothing else changes.
  // It is the only way to turn them off: while it is on they have no badge and Clear all leaves them.
  $('#tChips', el).onchange = e => {
    if (e.target.id !== 'fMine') return;
    if (e.target.checked) { Object.assign(F, DEFAULTS()); touched.delete('dir'); touched.delete('status'); }
    else { F.dir = []; F.status = []; touched.add('dir'); touched.add('status'); }
    render();
  };
  $('#tChips', el).onclick = e => {
    const b = e.target.closest('[data-clear]'), k = b?.dataset.clear; if (!k) return;
    // Clear all clears the filters that have badges; under My open tasks that leaves Status and Kind of task as they are. A chip of a dropdown removes just its own choice.
    if (k === 'all') { const keep = mineOn() ? ['dir', 'status'] : []; Object.assign(F, blank(), Object.fromEntries(keep.map(x => [x, F[x]]))); [...touched].forEach(x => keep.includes(x) || touched.delete(x)); }
    else touched.add(k), F[k] = Array.isArray(F[k]) ? F[k].filter(v => v !== b.dataset.v) : blank()[k];
    if (k === 'all' || k === 'q') $('#fQ', el).value = '';
    render();
  };
  $('#tList', el).addEventListener('click', e => { const b = e.target.closest('[data-done]'); if (b) { e.stopPropagation(); closeDone(b); } });
  $('#tList', el).addEventListener('click', e => { const b = e.target.closest('[data-pin]'); if (b) { e.stopPropagation(); togglePin(b); } });
  // While selecting, a click on a task picks it instead of opening it (caught here before the app's own click router).
  $('#tList', el).addEventListener('click', e => {
    if (!picking || e.target.closest('[data-pin],[data-done]')) return;
    const c = e.target.closest('[data-task]'); if (!c) return;
    e.preventDefault(); e.stopPropagation();
    const id = Number(c.dataset.task);
    picked.has(id) ? picked.delete(id) : picked.add(id);
    paintPicks();
  }, true);
  $('#fArchOthers', el).onclick = e => archiveOthers(e.currentTarget);
  $('#fPick', el).onclick = () => { picking = !picking; picked.clear(); render(); };
  $('#tPick', el).onclick = e => {
    const b = e.target.closest('[data-pick]'); if (!b) return;
    const k = b.dataset.pick;
    if (k === 'all') { shown.forEach(t => picked.add(t.id)); paintPicks(); }
    else if (k === 'none') { picked.clear(); paintPicks(); }
    else if (k === 'cancel') { picking = false; picked.clear(); render(); }
    else if (k === 'go') reprocessPicked(b);
    else if (k === 'del') deletePicked(b);
  };
  select(arg);
  load();
  onView('tasks', load); onView('seen', seen); onView('people', load);
  onView('status', paintBin); paintBin();
}

// "/" jumps to the search box while the task list is on screen.
document.addEventListener('keydown', e => {
  // root is #main, there on every page: the search box itself says whether the task list is on screen.
  const box = root && $('#fQ', root);
  if (e.key !== '/' || !box || e.ctrlKey || e.metaKey || e.altKey || document.querySelector('.overlay')) return;
  if (e.target.closest?.('input,textarea,select,[contenteditable]')) return;
  e.preventDefault(); box.focus();
});

/** The route argument is a task id, or filters such as "?dir=to_me&due=late,soon". An old "?due=new" link means Arrived: New. */
export function select(arg) {
  if (/^\d+$/.test(arg || '')) { openTask(Number(arg)); return; }
  if (arg?.startsWith('?')) {
    const p = new URLSearchParams(arg.slice(1));
    Object.assign(F, blank(), { status: ['open'] }); touched.clear();
    if (p.get('due')?.split(',').includes('new')) p.set('arr', [p.get('arr'), 'new'].filter(Boolean).join(','));
    for (const k of ['dir', 'status', 'arr', 'due', 'mark']) if (p.get(k)) { F[k] = tidy(k, p.get(k).split(',')); touched.add(k); }
    for (const k of ['pri', 'from', 'to']) if (p.get(k)) F[k] = p.get(k);
    if (SORTS.some(([k]) => k === p.get('sort'))) F.sort = p.get('sort');
    render();
  }
}
/** A click on the Tasks tab: back to My open tasks, whatever was set before (search too). */
export function resetFilters() {
  Object.assign(F, blank(), DEFAULTS()); touched.clear();
  const q = root && $('#fQ', root); if (q) q.value = '';
  render();
}
// ---------- the filter dropdowns: one look for all of them ----------
// Each shows the value in force, tints when it narrows the list, and keeps the width of its longest option, so the bar never moves.
// All but Sort take several choices at once (a task shows when any of them fits); their first row clears them.
const DD = {
  dir: { all: ['all', 'All kinds', '#1c7ed6'], opts: () => Object.entries(DIR).map(([k, d]) => [k, d.short, d.color]) },
  status: { all: ['all', 'All', '#1c7ed6'], opts: () => [['open', 'Open', '#2f9e44'], ['parked', 'Parked', STATUS.parked.color], ['closed', 'Closed', '#c92a2a']] },
  arr: { all: ['any', 'Any time', '#1c7ed6'], opts: () => [['new', 'New', '#1098ad'], ['d0', 'Today', '#2f9e44'], ['d1', 'Yesterday', '#3b5bdb'], ['d7', 'Last 7 days', '#1864ab'], ['d30', 'Last 30 days', '#c8822f'], ['old', 'Older', '#0b7285']] },
  due: { all: ['any', 'Any deadline', '#1c7ed6'], opts: () => [['late', 'Overdue', '#c92a2a'], ['soon', 'Due soon', '#c8822f'], ['week', 'This week', '#3b5bdb'], ['none', 'No deadline', '#0b7285']] },
  mark: { all: ['all', 'All', '#1c7ed6'], opts: () => [['unsure', 'Not sure', '#b35c00'], ['ack', 'Acknowledged', '#2f8f7f'], ['fwd', 'Forwarded', '#3b5bdb'], ['fol', 'Followed up', '#d9480f'], ['park', 'Parked', STATUS.parked.color], ['pin', 'Pinned', '#1098ad']] },
  sort: { opts: () => SORTS },
};
const multi = k => !!DD[k].all;
/** Known choices only, in menu order; every choice at once is the same as none. */
const tidy = (k, vals) => { const ok = DD[k].opts().map(o => o[0]).filter(v => vals.includes(v)); return ok.length === DD[k].opts().length ? [] : ok; };
const onlyOpen = () => F.status.length === 1 && F.status[0] === 'open';
/** A dropdown left as it is by default: Open in Status, To me in Kind of task, nothing elsewhere. */
const isDefault = k => { const d = DEFAULTS()[k] || []; return F[k].length === d.length && d.every(v => F[k].includes(v)); };
/** My open tasks is on: Status is just Open and Kind of task just To me and By me. */
const mineOn = () => isDefault('dir') && isDefault('status');
const choice = (k, v) => DD[k].opts().find(o => o[0] === v);
const dd = (k, ic, head, title = head) => `<div class="dd" data-dd="${k}"><button type="button" class="dd-btn" aria-haspopup="listbox" aria-expanded="false" title="${esc(title)}">${icon(ic, 14)}<span class="dd-val"></span><span class="chev">${icon('down', 13)}</span></button>
  <div class="dd-menu" role="listbox"${multi(k) ? ' aria-multiselectable="true"' : ''} hidden><div class="dd-h">${esc(head)}</div><div class="dd-list"></div></div></div>`;
const ddInner = ([, l, c], n, dot = true) => `${c && dot ? `<i class="dot" style="--c:${c}"></i>` : ''}<span class="lbl">${esc(l)}</span>${n != null ? `<span class="cnt">${n}</span>` : ''}`;
/** What a dropdown's button reads for a set of choices: the one, or the first and how many more. */
const shownAs = (k, vals) => {
  if (!multi(k)) return choice(k, vals[0]) || DD[k].opts()[0];
  const os = vals.map(v => choice(k, v)).filter(Boolean);
  return !os.length ? DD[k].all : os.length === 1 ? os[0] : [null, `${os[0][1]} +${os.length - 1}`, null];
};

function paintDropdowns(counts) {
  for (const box of $$('.dd', root)) {
    const k = box.dataset.dd, def = DD[k], opts = def.opts(), many = multi(k), vals = many ? F[k] : [F[k]];
    // Each choice shows how many tasks it alone would show, with the other filters as they are; sorting changes none.
    const n = v => k === 'sort' ? null : counts(k, v);
    const val = $('.dd-val', box), btn = $('.dd-btn', box);
    // The widest option sets the width; it only ever grows (a count gaining a digit), so nothing jumps while you filter.
    btn.style.minWidth = '';
    let w = Number(box.dataset.w || 0);
    for (const o of [def.all, ...opts].filter(Boolean)) { val.innerHTML = ddInner(o, k === 'dir' ? n(o === def.all ? [] : [o[0]]) : null, k === 'dir'); w = Math.max(w, btn.offsetWidth); }
    box.dataset.w = w; btn.style.minWidth = w + 'px';
    val.innerHTML = ddInner(shownAs(k, vals), k === 'dir' ? n(vals) : null, k === 'dir');
    // Open and To me + By me in light green while they are on as by default, so it shows they were picked for you; once you change Status
    // or Kind of task yourself it turns white like any button. The other dropdowns tint when they narrow the list.
    box.classList.toggle('def', many && !!DEFAULTS()[k] && !touched.has(k) && isDefault(k));
    box.classList.toggle('set', many && !DEFAULTS()[k] && !isDefault(k));
    const row = (o, on, cnt) => `<button type="button" class="dd-opt${many ? ' multi' : ''}" role="option" data-v="${o[0]}" aria-selected="${on}">${many ? `<span class="cb">${icon('check', 11)}</span>` : ''}${ddInner(o, cnt)}${many ? '' : `<span class="ck">${icon('check', 14)}</span>`}</button>`;
    $('.dd-list', box).innerHTML = many
      ? row(def.all, !vals.length, n([])).replace('dd-opt multi', 'dd-opt all') + '<div class="dd-sep"></div>' + opts.map(o => row(o, vals.includes(o[0]), n([o[0]]))).join('')
      : opts.map(o => row(o, o[0] === vals[0], null)).join('');
  }
}
function closeDropdowns(except) {
  for (const box of $$('.dd.open', root)) if (box !== except) { box.classList.remove('open'); $('.dd-menu', box).hidden = true; $('.dd-btn', box).setAttribute('aria-expanded', 'false'); }
}
function wireDropdowns(el) {
  el.addEventListener('click', e => {
    const box = e.target.closest('.dd');
    if (!box) return closeDropdowns();
    const opt = e.target.closest('.dd-opt');
    if (opt) {
      const k = box.dataset.dd, v = opt.dataset.v;
      // A choice of a multi-select ticks on or off and the menu stays open for more; its first row clears them and closes it.
      if (multi(k) && v !== DD[k].all[0]) {
        set(k, tidy(k, F[k].includes(v) ? F[k].filter(x => x !== v) : [...F[k], v]));
        $(`.dd-opt[data-v="${v}"]`, box)?.focus(); return;
      }
      closeDropdowns(); $('.dd-btn', box).focus();
      if (k === 'sort') setPref('sort', v);
      set(k, multi(k) ? [] : v); return;
    }
    if (!e.target.closest('.dd-btn')) return;
    const open = !box.classList.contains('open');
    closeDropdowns(box);
    box.classList.toggle('open', open); $('.dd-menu', box).hidden = !open; $('.dd-btn', box).setAttribute('aria-expanded', String(open));
    if (open) ($('.dd-opt[aria-selected="true"]', box) || $('.dd-opt', box))?.focus();
  });
  el.addEventListener('keydown', e => {
    const box = e.target.closest('.dd'); if (!box) return;
    const items = $$('.dd-opt', box), i = items.indexOf(document.activeElement);
    if (e.key === 'Escape' && box.classList.contains('open')) { e.stopPropagation(); closeDropdowns(); $('.dd-btn', box).focus(); }
    else if (e.key === 'ArrowDown' || e.key === 'ArrowUp') {
      e.preventDefault();
      if (!box.classList.contains('open')) { $('.dd-btn', box).click(); return; }
      items[(i + (e.key === 'ArrowDown' ? 1 : -1) + items.length) % items.length]?.focus();
    } else if (e.key === 'Tab' && box.classList.contains('open')) closeDropdowns();
  });
}
// A choice ticked in a menu is redrawn at once, so a click on it ends on a node no longer in the page: not a click outside.
document.addEventListener('click', e => { if (root && $('#tList', root) && e.target.isConnected && !e.target.closest('.dd')) closeDropdowns(); });
function set(k, v) { if (v == null) return; const st = F.status; touched.add(k); F[k] = withParked(k, v); if (F.status !== st) touched.add('status'); render(); }
/** Parked in What you did brings Parked into Status when only Open is on there, or it could never show a task. */
function withParked(k, v) { if (k === 'mark' && v.includes('park') && onlyOpen()) F.status = ['open', 'parked']; return v; }

// Only the latest answer is drawn: an older one landing late would bring back a task as it was.
const load = latest(() => GET('/api/tasks'), list => { tasks = list; render(); }, e => toast(`Could not load the tasks: ${e.message}`, true));
/** A task opened is seen: marked here, without loading every task again. */
function seen(id) { const t = tasks.find(x => x.id === id); if (t && !t.seen) { t.seen = 1; render(); } }

/** Close a task as done, archived or not a task, from its card, without opening it. */
async function closeDone(b) {
  const id = Number(b.dataset.done), t = tasks.find(x => x.id === id), reason = b.dataset.reason || 'done';
  b.disabled = true;
  // Not a task goes through dismiss, which also teaches the AI from the mistake.
  try { await api('PATCH', '/api/tasks/' + id, reason === 'notask' ? { action: 'dismiss' } : { action: 'close', reason }); toast(`Closed as ${(CLOSE[reason]?.label || reason).toLowerCase()}: ${t?.title || 'task'}. Ctrl+Z to undo`); }
  catch (e) { b.disabled = false; toast(e.message, true); }
}

/** Pin a task on top of the list, or unpin it. */
async function togglePin(b) {
  const id = Number(b.dataset.pin), t = tasks.find(x => x.id === id);
  if (!t) return;
  b.disabled = true;
  try {
    const r = await api('POST', `/api/tasks/${id}/pin`, { pinned: !t.pinned_at });
    t.pinned_at = r.pinned_at; render();
  } catch (e) { b.disabled = false; toast(e.message, true); }
}

function paintPicks() {
  if (!root || !$('#tList', root)) return;
  $$('#tList [data-task]', root).forEach(x => x.classList.toggle('picked', picked.has(Number(x.dataset.task))));
  const bar = $('#tPick', root);
  bar.hidden = !picking;
  $('#fPick', root).classList.toggle('on', picking);
  root.querySelector('.page').classList.toggle('picking', picking);
  if (!picking) return;
  const n = picked.size;
  bar.innerHTML = `${icon('select', 14)}<span><b class="num">${n}</b> of ${shown.length} picked. Click tasks to pick them.</span>
    <button class="btn sm ghost" data-pick="all">Pick all shown</button>${n ? '<button class="btn sm ghost" data-pick="none">Clear</button>' : ''}
    <span class="sp"></span><button class="btn sm primary" data-pick="go" ${n ? '' : 'disabled'} data-busy="Queuing">${icon('spark', 13)} Reprocess ${n || ''}</button>
    <button class="btn sm danger" data-pick="del" ${n ? '' : 'disabled'}>${icon('trash', 13)} Delete ${n || ''}</button>
    <button class="btn sm ghost" data-pick="cancel">Cancel</button>`;
}
async function reprocessPicked(b) {
  const ids = [...picked];
  if (!ids.length) return;
  if (!await confirmBox('Reprocess tasks', `The AI reads the emails of <b>${ids.length} task${ids.length > 1 ? 's' : ''}</b> again carefully, in the background, looking for any task it missed. What you corrected by hand is kept.`, 'Reprocess')) return;
  b.disabled = true;
  try {
    const r = await api('POST', '/api/reprocess', { ids });
    toast(`Queued: ${plural(r.queued, 'thread')} to read again`);
    picking = false; picked.clear(); render();
  } catch (e) { b.disabled = false; toast(e.message, true); }
}

/** Send the picked tasks to the recycle bin. */
async function deletePicked(b) {
  const ids = [...picked];
  if (!ids.length) return;
  b.disabled = true;
  try {
    const r = await api('POST', '/api/tasks/delete', { ids });
    toast(`${plural(r.deleted, 'task')} moved to the recycle bin. Ctrl+Z to undo`);
    picking = false; picked.clear(); render();
  } catch (e) { b.disabled = false; toast(e.message, true); }
}
/** Archive, in one go, every open task between others: they are there for information only. */
async function archiveOthers(b) {
  const n = tasks.filter(t => t.status === 'open' && t.direction === 'others').length;
  if (!n || !await confirmBox('Archive tasks between others', `Archive the <b>${n} open task${n > 1 ? 's' : ''} between other people</b>: seen, nothing for you to do. Ctrl+Z brings them back.`, 'Archive all')) return;
  b.disabled = true;
  try { const r = await api('POST', '/api/tasks/archive-others'); toast(`${plural(r.archived, 'task')} between others archived. Ctrl+Z to undo`); }
  catch (e) { toast(e.message, true); }
  b.disabled = false;
}
/** The archive-them-all button shows only while some task between others is open, with how many. */
function paintArchOthers() {
  const b = root && $('#fArchOthers', root); if (!b) return;
  const n = tasks.filter(t => t.status === 'open' && t.direction === 'others').length;
  b.hidden = !n; $('em', b).textContent = n || '';
}
/** How many tasks wait in the recycle bin, on its button. */
function paintBin() {
  const n = S.status?.counts?.bin || 0, el = root && $('#fBinN', root);
  if (el) { el.textContent = n || ''; el.parentElement.classList.toggle('has', !!n); }
}

// What each dropdown choice asks of a task; a task passes a dropdown when it fits any of the choices ticked there.
const FITS = {
  dir: { _: (t, v) => t.direction === v },
  status: { _: (t, v) => statusGroup(t.status) === v },
  // When the email that opened the task arrived: today, yesterday, within the last 7 or 30 days (counting today), or before that.
  arr: { new: t => !t.seen && t.status === 'open', d0: t => arrived(t) >= startOfDay(), d1: t => arrived(t) >= startOfDay(1) && arrived(t) < startOfDay(),
    d7: t => arrived(t) >= startOfDay(6), d30: t => arrived(t) >= startOfDay(29), old: t => { const at = arrived(t); return !!at && at < startOfDay(29); } },
  due: { late: t => t.overdue, soon: t => t.due_soon, week: t => t.status === 'open' && t.days_left != null && t.days_left <= 7, none: t => t.status === 'open' && !t.deadline },
  mark: { unsure: t => !!t.unsure && t.status === 'open', ack: t => t.acknowledged_at && t.status === 'open', fwd: forwarded, fol: followed, park: t => t.status === 'parked', pin: t => !!t.pinned_at },
};
const arrived = t => Date.parse(t.opened_at || '') || 0;
const fits = (t, k) => !F[k].length || F[k].some(v => (FITS[k][v] || FITS[k]._)?.(t, v));

const matches = t => {
  if (t.status === 'dismissed') return false;
  for (const k in FITS) if (!fits(t, k)) return false;
  if (F.pri !== 'any' && t.priority !== F.pri) return false;
  if (F.from && (t.requester_email || t.requester_name) !== F.from) return false;
  if (F.to && (t.owner_email || t.owner_name) !== F.to) return false;
  if (F.q && ![t.title, t.detail, t.progress, t.owner_name, t.requester_name, t.subject, t.owner_email, t.requester_email, ...(t.secondary || []).flatMap(p => [p.name, p.email])].join(' ').toLowerCase().includes(F.q)) return false;
  return true;
};
const PRI_ORDER = { high: 0, normal: 1, low: 2 };
// Open first, then parked, then closed.
const STAGE = { open: 0, parked: 1 }, stage = t => STAGE[t.status] ?? 2;
const newsAt = t => t.last?.at || t.updated_at || t.opened_at || '';
const sorter = {
  deadline: (a, b) => stage(a) - stage(b) || String(a.deadline || '9').localeCompare(String(b.deadline || '9')) || PRI_ORDER[a.priority] - PRI_ORDER[b.priority],
  news: (a, b) => String(newsAt(b)).localeCompare(String(newsAt(a))),
  newest: (a, b) => String(b.opened_at || '').localeCompare(String(a.opened_at || '')),
  priority: (a, b) => PRI_ORDER[a.priority] - PRI_ORDER[b.priority] || String(a.deadline || '9').localeCompare(String(b.deadline || '9')),
};

// ---------- groups: by urgency when sorted by deadline, by day of the latest news or of the email's arrival otherwise ----------
const startOfDay = (n = 0) => { const d = new Date(); d.setHours(0, 0, 0, 0); d.setDate(d.getDate() - n); return d.getTime(); };
const GROUPS = {
  deadline: t => t.status === 'parked' ? ['parked', 'Parked', STATUS.parked.color]
    : t.status !== 'open' ? ['closed', 'Closed', '#0b7285']
    : t.days_left == null ? ['none', 'No deadline', '#0b7285']
    : t.days_left < 0 ? ['late', 'Overdue', '#c92a2a']
    : t.days_left <= 1 ? ['now', 'Today and tomorrow', '#c8822f']
    : t.days_left <= 7 ? ['week', 'Within a week', '#3b5bdb']
    : ['later', 'Later', '#1098ad'],
  news: t => { const at = Date.parse(newsAt(t)) || 0;
    return at >= startOfDay() ? ['d0', 'Today', '#2f9e44'] : at >= startOfDay(1) ? ['d1', 'Yesterday', '#3b5bdb']
      : at >= startOfDay(6) ? ['d7', 'Last 7 days', '#1098ad'] : ['old', 'Earlier', '#0b7285']; },
  // When the email that opened the task arrived.
  newest: t => { const at = Date.parse(t.opened_at || '');
    return !at ? ['none', 'Arrival unknown', '#0b7285'] : at >= startOfDay() ? ['d0', 'Today', '#2f9e44'] : at >= startOfDay(1) ? ['d1', 'Yesterday', '#3b5bdb']
      : at >= startOfDay(6) ? ['d7', 'Last week', '#1098ad'] : at >= startOfDay(29) ? ['d30', 'Last month', '#c8822f'] : ['old', 'Earlier', '#0b7285']; },
};
function grouped(list) {
  const key = GROUPS[F.sort];
  if (!key) return `<div class="cards">${list.map(card).join('')}</div>`;
  const g = new Map();
  for (const t of list) { const [k, l, c] = key(t); if (!g.has(k)) g.set(k, { l, c, items: [] }); g.get(k).items.push(t); }
  if (g.size < 2) return `<div class="cards">${list.map(card).join('')}</div>`;
  return [...g.values()].map(({ l, c, items }) => `<section class="tgroup" style="--c:${c}"><h3 class="tgroup-h"><i></i>${esc(l)}<span class="num">${items.length}</span></h3>
    <div class="cards">${items.map(card).join('')}</div></section>`).join('');
}
const card = t => taskCard(t, { news: true, quick: true, pin: true });

/** The Tasks tab's number: the tasks the filters show, kept up to date on every screen. */
function count() {
  const n = tasks.filter(matches).length;
  if (S.taskCount !== n) { S.taskCount = n; emit('taskCount'); }
}
const mounted = () => !!(root && $('#tList', root));
/** Called once at start: off the Tasks screen, its tasks still load as they change, for the tab's number. */
export function trackCount() {
  on('tasks', () => mounted() || load()); on('people', () => mounted() || load());
  load();
}

function render() {
  count();
  // root is #main, there for every page: the view is still on screen only while its own list is.
  if (!mounted()) return;
  setPref('taskFilters3', Object.fromEntries(Object.keys(blank()).map(k => [k, F[k]])));
  const base = tasks.filter(t => t.status !== 'dismissed');
  const facet = (k, v) => { const was = F[k], st = F.status; F[k] = withParked(k, v); const c = base.filter(matches).length; F[k] = was; F.status = st; return c; };
  paintDropdowns(facet);
  $$('#fLayout button', root).forEach(b => b.classList.toggle('on', b.dataset.v === F.layout));
  paintArchOthers();
  $('.fbar.one .search', root).classList.toggle('has', !!F.q);
  const list = base.filter(matches).sort(sorter[F.sort]);
  shown = list;
  // The filters in force, as badges: the count of what they show, and a click to remove each one.
  // A badge for each choice ticked in a dropdown: [key, choice, label, colour].
  const pick = (k, label = v => choice(k, v)?.[1] || v, color = v => choice(k, v)?.[2] || '#0b7285') => F[k].map(v => [k, v, label(v), color(v)]);
  // Under My open tasks, Status and Kind of task get no badges: the switch is what turns them off.
  const mine = mineOn();
  // Assigned to me, I assigned and Open never get a badge, whatever is ticked: the dropdowns show them.
  const quiet = { dir: ['to_me', 'by_me'], status: ['open'] };
  const loud = r => !quiet[r[0]]?.includes(r[1]);
  const on = [...(mine ? [] : [...pick('dir', v => dir(v).label, v => dir(v).color), ...pick('status', undefined, () => '#1c7ed6')].filter(loud)), ...pick('arr', v => v === 'new' ? 'New' : 'Arrived: ' + choice('arr', v)[1], () => '#3b5bdb'),
    ...pick('due', undefined, () => '#c8822f'), F.pri !== 'any' && ['pri', '', (PRI[F.pri]?.label || F.pri) + ' priority', PRI[F.pri]?.color || '#0b7285'],
    F.from && ['from', '', 'Asked by ' + nameOf(F.from, 'requester'), '#3b5bdb'], F.to && ['to', '', 'Done by ' + nameOf(F.to, 'owner'), '#c8822f'],
    ...pick('mark'), F.q && ['q', '', `“${F.q}”`, '#1098ad']].filter(Boolean);
  const late = list.filter(t => t.overdue).length;
  $('#tChips', root).innerHTML = `<label class="tog inline mine" title="Only the open tasks assigned to you or by you: Open, To me and By me on together"><input type="checkbox" id="fMine" ${mine ? 'checked' : ''}><span>My open tasks</span></label>` +
    `<span class="fcount"><b class="num">${list.length}</b> task${list.length === 1 ? '' : 's'}${late && F.due.join() !== 'late' ? ` · <a class="red" data-go="#/tasks/?due=late" title="Show only overdue">${late} overdue</a>` : ''}</span>` +
    on.map(([k, v, l, c]) => `<button class="fchip" data-clear="${k}" data-v="${esc(v)}" style="--c:${c}" title="Remove this filter"><i></i>${esc(l)}${icon('x', 11)}</button>`).join('') +
    (on.length ? '<button class="fchip clear" data-clear="all">Clear all</button>' : '');
  const box = $('#tList', root);
  if (!list.length) {
    paintPicks();
    box.innerHTML = `<div class="empty">${icon('tasks', 40)}<p>No tasks match.</p><p class="muted small">${on.length ? 'Remove a filter above to see more.' : mine ? 'Turn off My open tasks to see the rest.' : 'Tasks are found by the AI in your email threads; nobody adds them by hand.'}</p></div>`;
    return;
  }
  if (F.layout === 'table') box.innerHTML = table(list);
  else if (F.layout === 'board') box.innerHTML = `<div class="board">${Object.entries(DIR).map(([k, d]) => {
    const col = list.filter(t => t.direction === k);
    return `<div class="bcol" style="--c:${d.color};--s:${d.soft}"><h4 data-go="#/tasks/?dir=${k}&status=${F.status.join(',') || 'all'}" title="Show only these">${icon(d.icon, 14)} ${esc(d.label)}<span class="num">${col.length}</span></h4><div class="stack">${col.map(t => taskCard(t, { compact: true, pin: true })).join('') || '<div class="empty sm">None</div>'}</div></div>`;
  }).join('')}</div>`;
  else box.innerHTML = grouped(list);
  const sel = currentTask();
  if (sel) $$(`[data-task="${sel}"]`, box).forEach(x => x.classList.add('sel'));
  paintPicks();
}

const nameOf = (k, side) => { const t = tasks.find(x => (x[side + '_email'] || x[side + '_name']) === k); return t?.[side + '_name'] || k; };

function table(list) {
  return `<table class="tbl tasks-tbl fixed"><colgroup><col style="width:14px"><col style="width:22%"><col style="width:10%"><col style="width:10%"><col style="width:9%"><col style="width:7%"><col style="width:10%"><col style="width:8%"><col style="width:14%"><col></colgroup><thead><tr><th data-st-label="Kind colour" title="Sort by kind"></th><th>Task</th><th>Asked by</th><th>Done by</th><th>Kind</th><th>Opened</th><th>Deadline</th><th>Status</th><th>Latest news</th><th>Thread</th></tr></thead><tbody>
    ${list.map(t => `<tr data-task="${t.id}" class="${t.overdue ? 'late' : ''}"><td data-sort="${esc(dir(t.direction).short)}"><i class="bar" style="background:${dir(t.direction).color}"></i></td>
      <td class="tt-cell" data-sort="${esc(t.title)}"><b>${esc(t.title)}</b>${unsureMark(t) ? ' ' + unsureMark(t) : ''}${t.pinned_at ? ' ' + pinMark(t) : ''}${!t.seen && t.status === 'open' ? ' <span class="newdot">New</span>' : ''}<div class="muted small clamp1">${esc(t.progress || t.detail)}</div>${taskActs(t, { quick: true, pin: true })}</td>
      <td><a class="pcell" data-person="${esc(t.requester_email)}">${avatar(t.requester_name, t.requester_email, 'xs')}${esc(t.requester_name)}</a></td>
      <td><a class="pcell" data-person="${esc(t.owner_email)}">${avatar(t.owner_name, t.owner_email, 'xs')}${esc(t.owner_name)}</a>${t.secondary?.length ? ` <span class="more-n" title="Also asked: ${esc(t.secondary.map(p => p.name || p.email).join(', '))}">+${t.secondary.length}</span>` : ''}</td>
      <td>${dirChip(t.direction)}</td><td class="num muted" data-sort="${esc(t.opened_at || '')}">${esc(dateLabel(t.opened_at))}</td><td data-sort="${esc(dueKey(t))}">${dueBadge(t)}</td>
      <td>${statusChip(t)}</td>
      <td class="small" data-sort="${esc(t.last?.at || '')}">${t.last ? `<div class="clamp1" title="${esc(t.last.text)}">${esc(t.last.text)}</div><span class="muted">${esc(ago(t.last.at))}</span>` : ''}</td>
      <td class="small"><a class="muted clamp1" data-thread="${esc(t.conversation_id)}" title="Open the thread">${esc(t.subject)}</a></td></tr>`).join('')}</tbody></table>`;
}
