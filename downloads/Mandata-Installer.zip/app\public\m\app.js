// Mandata on a phone. Everything stays in Mandata on your computer: this page reads it and changes it there, over the
// Wi-Fi, through phone access (lib/phone.js). Home, Tasks (close, reopen, pin, deadline, follow-up emails you review
// and send), Ask Mandata, People, and every email of a thread. No build step, no libraries.

// ---------- small helpers ----------
const $ = (s, el = document) => el.querySelector(s);
const $$ = (s, el = document) => [...el.querySelectorAll(s)];
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const enc = encodeURIComponent;
const store = { get: (k, d) => { try { const v = localStorage.getItem('mandata.' + k); return v == null ? d : JSON.parse(v); } catch { return d; } },
  set: (k, v) => { try { localStorage.setItem('mandata.' + k, JSON.stringify(v)); } catch {} } };
const plural = (n, w) => `${n} ${w}${n === 1 ? '' : 's'}`;

const ICONS = {
  home: '<path d="M3 10.5 12 3l9 7.5V20a1 1 0 0 1-1 1h-5v-6h-6v6H4a1 1 0 0 1-1-1z"/>',
  tasks: '<path d="M9 11l3 3L22 4"/><path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11"/>',
  chat: '<path d="M21 12a8 8 0 0 1-11.6 7.1L4 20.5l1.4-4.6A8 8 0 1 1 21 12z"/>',
  people: '<path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.9M16 3.1a4 4 0 0 1 0 7.8"/>',
  more: '<circle cx="5" cy="12" r="1.4"/><circle cx="12" cy="12" r="1.4"/><circle cx="19" cy="12" r="1.4"/>',
  refresh: '<path d="M20 11a8 8 0 1 0-2.3 5.7M20 4v7h-7"/>',
  back: '<path d="M19 12H5M11 18l-6-6 6-6"/>',
  check: '<path d="M20 6 9 17l-5-5"/>',
  done: '<circle cx="12" cy="12" r="9"/><path d="m8 12 3 3 5-6"/>',
  archive: '<rect x="3" y="4" width="18" height="5" rx="1"/><path d="M5 9v10a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1V9M10 13h4"/>',
  reopen: '<path d="M3 12a9 9 0 1 0 3-6.7L3 8"/><path d="M3 3v5h5"/>',
  pin: '<path d="M12 17v5"/><path d="M9 10.8V4h6v6.8l3 3.2v3H6v-3z"/>',
  calendar: '<rect x="3" y="4" width="18" height="18" rx="2"/><path d="M16 2v4M8 2v4M3 10h18"/>',
  send: '<path d="M22 2 11 13M22 2l-7 20-4-9-9-4z"/>',
  mail: '<rect x="2" y="4" width="20" height="16" rx="2"/><path d="m22 7-10 6L2 7"/>',
  thread: '<path d="M6 3v12"/><circle cx="6" cy="18" r="3"/><circle cx="18" cy="6" r="3"/><path d="M18 9a9 9 0 0 1-9 9"/>',
  user: '<circle cx="12" cy="8" r="4"/><path d="M4 21v-1a6 6 0 0 1 6-6h4a6 6 0 0 1 6 6v1"/>',
  search: '<circle cx="11" cy="11" r="7"/><path d="m21 21-4.3-4.3"/>',
  sort: '<path d="M7 4v16M3 16l4 4 4-4M17 20V4M13 8l4-4 4 4"/>',
  alert: '<path d="M10.3 3.9 1.8 18a2 2 0 0 0 1.7 3h17a2 2 0 0 0 1.7-3L13.7 3.9a2 2 0 0 0-3.4 0z"/><path d="M12 9v4M12 17h.01"/>',
  clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
  stop: '<rect x="6" y="6" width="12" height="12" rx="2"/>',
  up: '<path d="M12 19V5M5 12l7-7 7 7"/>',
  draft: '<path d="M12 20h9"/><path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4z"/>',
  ban: '<circle cx="12" cy="12" r="9"/><path d="m5.7 5.7 12.6 12.6"/>',
  out: '<path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4M16 17l5-5-5-5M21 12H9"/>',
  phone: '<rect x="6" y="2" width="12" height="20" rx="2"/><path d="M11 18h2"/>',
  download: '<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><path d="m7 10 5 5 5-5M12 15V3"/>',
  share: '<path d="M12 3v12M8 7l4-4 4 4"/><path d="M5 11v8a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2v-8"/>',
  inbox: '<path d="M22 12h-6l-2 3h-4l-2-3H2"/><path d="M5.5 5.1 2 12v6a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-6l-3.5-6.9A2 2 0 0 0 16.8 4H7.2a2 2 0 0 0-1.7 1.1z"/>',
  layers: '<path d="m12 2 10 5-10 5L2 7z"/><path d="m2 17 10 5 10-5M2 12l10 5 10-5"/>',
  spark: '<path d="M12 3l1.9 5.1L19 10l-5.1 1.9L12 17l-1.9-5.1L5 10l5.1-1.9z"/>',
  trash: '<path d="M3 6h18M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2m3 0v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6"/>',
};
const icon = (n, s = 20) => `<svg width="${s}" height="${s}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${ICONS[n] || ''}</svg>`;

// The kinds of task, in the desktop app's colours (public/js/ui.js).
const DIR = {
  to_me: { label: 'Assigned to me', short: 'To me', color: '#c8822f', soft: '#fbf4ec', ink: '#8a5517', icon: 'inbox' },
  among: { label: 'Among others', short: 'Among others', color: '#5c940d', soft: '#f4fce3', ink: '#3f6a0a', icon: 'layers' },
  by_me: { label: 'I assigned', short: 'I asked', color: '#3b5bdb', soft: '#eef2fc', ink: '#2c449f', icon: 'send' },
  others: { label: 'Between others', short: 'Others', color: '#2f8f7f', soft: '#ecf6f4', ink: '#1f6a5d', icon: 'people' },
};
const dir = k => DIR[k] || DIR.others;
const kindChip = k => `<span class="chip kind" style="--kc:${dir(k).color};--ks:${dir(k).soft};--ki:${dir(k).ink}">${icon(dir(k).icon, 13)}${esc(dir(k).short)}</span>`;
// Avatar colours: blues, teals, greens, oranges, reds.
const AV = ['#1971c2', '#0c8599', '#2f9e44', '#e8590c', '#c92a2a', '#1864ab', '#087f5b', '#d9480f', '#5c940d', '#3b5bdb'];
const avatar = (name, key, cls = '') => {
  const h = [...String(key || name || '')].reduce((a, c) => (a * 31 + c.charCodeAt(0)) >>> 0, 7);
  const ini = String(name || key || '?').replace(/\(.*?\)/g, '').trim().split(/[\s.@_-]+/).filter(Boolean).slice(0, 2).map(w => w[0]).join('').toUpperCase();
  return `<span class="av ${cls}" style="--c:${AV[h % AV.length]}" aria-hidden="true">${esc(ini || '?')}</span>`;
};

// ---------- dates ----------
const LOCALE = 'en-GB';
const isoDay = d => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
const dayLabel = s => { if (!s) return ''; const d = new Date(s.length === 10 ? s + 'T12:00:00' : s); return d.toLocaleDateString(LOCALE, { weekday: 'short', day: 'numeric', month: 'short' }); };
const when = s => {
  if (!s) return '';
  const d = new Date(s), now = new Date(), mins = (now - d) / 60000;
  if (mins < 1) return 'just now';
  if (mins < 60) return `${Math.round(mins)} min ago`;
  if (isoDay(d) === isoDay(now)) return d.toLocaleTimeString(LOCALE, { hour: '2-digit', minute: '2-digit' });
  const y = new Date(now); y.setDate(y.getDate() - 1);
  if (isoDay(d) === isoDay(y)) return 'Yesterday';
  return d.toLocaleDateString(LOCALE, { day: 'numeric', month: 'short', ...(d.getFullYear() !== now.getFullYear() ? { year: 'numeric' } : {}) });
};
const fullDate = s => s ? new Date(s).toLocaleString(LOCALE, { weekday: 'short', day: 'numeric', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' }) : '';

// ---------- where it runs ----------
const UA = navigator.userAgent;
const IN_APP = /MandataApp/.test(UA);   // the Android app (installer/android) adds this to its browser's name
const IOS = /iPhone|iPad|iPod/.test(UA) || (/Macintosh/.test(UA) && navigator.maxTouchPoints > 1);
const ANDROID = /Android/.test(UA);
const STANDALONE = matchMedia('(display-mode: standalone)').matches || navigator.standalone === true;
const SITE = 'https://shamoug.github.io/mandata/phone.html';
const APK = 'https://shamoug.github.io/mandata/downloads/Mandata-Android.apk';

// ---------- the API, with a copy kept on the phone ----------
// Every answer read from the computer is kept on the phone (IndexedDB, by address). Without the computer, pages are
// drawn from that copy; changes are made to it at once and kept in order (the outbox), then sent once the computer
// answers again. What needs the computer itself (the AI, mail, sending email) waits: the [data-needs-pc] controls.
class Offline extends Error {}
const DB = (() => {
  let opened;
  const open = () => opened ||= new Promise((ok, bad) => {
    const r = indexedDB.open('mandata', 1);
    r.onupgradeneeded = () => { r.result.createObjectStore('copy'); r.result.createObjectStore('outbox', { autoIncrement: true }); };
    r.onsuccess = () => ok(r.result); r.onerror = () => bad(r.error);
  });
  const run = async (name, mode, fn) => {
    const db = await open();
    return new Promise((ok, bad) => { const tx = db.transaction(name, mode), req = fn(tx.objectStore(name)); tx.oncomplete = () => ok(req?.result); tx.onerror = () => bad(tx.error); });
  };
  const quiet = p => p.catch(() => undefined);
  return {
    get: k => quiet(run('copy', 'readonly', s => s.get(k))),
    put: (k, v) => quiet(run('copy', 'readwrite', s => s.put(v, k))),
    queue: v => run('outbox', 'readwrite', s => s.add(v)),
    drop: k => quiet(run('outbox', 'readwrite', s => s.delete(k))),
    waiting: async () => {
      try {
        const db = await open();
        return await new Promise(ok => {
          const out = [], tx = db.transaction('outbox', 'readonly');
          tx.objectStore('outbox').openCursor().onsuccess = e => { const c = e.target.result; if (c) { out.push({ key: c.key, v: c.value }); c.continue(); } };
          tx.oncomplete = () => ok(out); tx.onerror = () => ok(out);
        });
      } catch { return []; }
    },
  };
})();

/** One request to the computer, as it is. A GET gives up after 10 seconds (or wait): the phone is likely off its network. */
async function send(method, path, body, wait = 10000) {
  let r;
  try {
    r = await fetch(path, { method, credentials: 'same-origin', headers: method === 'GET' ? {} : { 'content-type': 'application/json' },
      body: method === 'GET' ? undefined : JSON.stringify(body || {}), signal: method === 'GET' ? AbortSignal.timeout(wait) : undefined });
  } catch { throw new Offline('Cannot reach Mandata on your computer'); }
  const d = await r.json().catch(() => ({}));
  if (r.status === 401 && d.pair) { showPair(); throw new Error('This phone is not paired'); }
  if (!r.ok) throw Object.assign(new Error(d.error || `Mandata answered ${r.status}`), { status: r.status });
  return d;
}
/**
 * A request, kept on the phone when it is a GET; without the computer, a GET is answered from that copy. Once the
 * computer is known to be away, a GET goes straight to the copy, without waiting for it again (the look every 15
 * seconds, in offlineNow, finds it when it is back): otherwise each page waited 10 seconds for nothing.
 */
async function api(method, path, body, wait) {
  if (offline && method === 'GET') {
    const c = await DB.get(path);
    if (c !== undefined) return c;
    throw new Offline('Cannot reach Mandata on your computer');
  }
  try {
    const d = await send(method, path, body, wait);
    online();
    if (method === 'GET') DB.put(path, d);
    return d;
  } catch (e) {
    if (!(e instanceof Offline)) throw e;
    offlineNow();
    if (method === 'GET') { const c = await DB.get(path); if (c !== undefined) return c; }
    throw e;
  }
}

// Off the computer's network: what waits to be sent, and a look every 15 seconds to see if it answers again.
let offline = false, waiting = 0, retry = null, flushing = false;
function offlineNow() {
  if (offline) return;
  offline = true; document.body.classList.add('offline'); drawStatus();
  clearInterval(retry);
  retry = setInterval(() => send('GET', '/api/phone/me').then(online, () => {}), 15000);
}
function online() {
  clearInterval(retry); retry = null;
  if (!offline) return;
  offline = false; document.body.classList.remove('offline');
  flush().then(() => { loadStatus(); listen(); S.tasksAt = 0; route({ quiet: true }); });
}
window.addEventListener('online', () => send('GET', '/api/phone/me').then(online, () => {}));
async function countWaiting() { waiting = (await DB.waiting()).length; drawStatus(); }

/**
 * A change: sent at once when the computer answers; otherwise kept in the outbox, made to the phone's copy with
 * local(), and sent in order once it is back. Returns true when it reached the computer.
 */
async function change(method, path, body, local) {
  if (!offline) {
    try { await api(method, path, body); return true; } catch (e) { if (!(e instanceof Offline)) throw e; }
  }
  // The same change already waiting (a second tap, from the list and the task) is kept once, not sent twice.
  const same = JSON.stringify([method, path, body || {}]);
  if (!(await DB.waiting()).some(({ v }) => JSON.stringify([v.method, v.path, v.body || {}]) === same))
    await DB.queue({ method, path, body, at: new Date().toISOString() });
  await local?.();
  await countWaiting();
  return false;
}
/** Send what waits, oldest first. A change the computer refuses (the task is gone) is dropped and said. */
async function flush() {
  if (flushing) return; flushing = true;
  let sent = 0; const refused = [];
  try {
    for (const { key, v } of await DB.waiting()) {
      try { await send(v.method, v.path, v.body); sent++; }
      catch (e) { if (e instanceof Offline) break; refused.push(e.message); }
      await DB.drop(key);
    }
  } finally { flushing = false; await countWaiting(); }
  if (sent) toast(`${plural(sent, 'change')} made offline sent to your computer`);
  if (refused.length) toast(`Your computer did not take ${plural(refused.length, 'change')}: ${refused[0]}`, true);
  if (sent || refused.length) { S.tasksAt = 0; prefetch(); }
}

// The phone's copy of a task changes as the computer would change it, marked as waiting to be sent.
const daysTo = d => Math.round((new Date(d + 'T12:00:00') - new Date(isoDay(new Date()) + 'T12:00:00')) / 864e5);
function asChanged(t, b) {
  const now = new Date().toISOString();
  if (b.action === 'close' || b.action === 'dismiss') {
    const r = (S.meta?.close_reasons || []).find(x => x.code === b.reason);
    Object.assign(t, { status: b.action === 'dismiss' ? 'dismissed' : r?.status || 'done', close_reason: b.reason || 'done', closed_at: now, closed_by: 'user' });
  }
  if (b.action === 'reopen') Object.assign(t, { status: 'open', close_reason: '', closed_at: null, closed_by: null, unpark_at: null });
  if (b.action === 'confirm') t.unsure = '';
  if (b.deadline) Object.assign(t, { deadline: b.deadline, deadline_source: 'user', deadline_note: '' });
  if ('pinned' in b) t.pinned_at = b.pinned ? now : null;
  const days = t.deadline ? daysTo(t.deadline) : null, open = t.status === 'open';
  Object.assign(t, { days_left: open ? days : null, overdue: open && days != null && days < 0,
    due_soon: open && days != null && days >= 0 && days <= (S.meta?.limits?.dueSoonDays ?? 3), seen: 1, pending: true });
  return t;
}
async function changeTaskCopy(id, b) {
  const one = t => String(t.id) === String(id) ? asChanged({ ...t }, b) : t;
  const list = await DB.get('/api/tasks');
  if (list) await DB.put('/api/tasks', list.map(one));
  const t = await DB.get(`/api/tasks/${id}`);
  if (t) await DB.put(`/api/tasks/${id}`, one(t));
  if (S.tasks) S.tasks = S.tasks.map(one);
}
/** A change to a task: at once, or on the phone until the computer is back. */
async function taskChange(id, method, path, body, msg, undo = null) {
  const sent = await change(method, path, body, () => changeTaskCopy(id, body));
  S.tasksAt = sent ? 0 : Date.now();
  toast(sent ? msg : `${msg} on this phone: sent to your computer when it is back`, false, undo);
  route({ quiet: true });
}

/** While connected, the open tasks, their details and the people are kept on the phone, for later without the computer. */
let prefetching = false;
async function prefetch() {
  if (prefetching || offline) return; prefetching = true;
  try {
    for (const p of ['/api/meta', '/api/people', '/api/ask', '/api/ask/starters']) await api('GET', p).catch(() => {});
    const list = await api('GET', '/api/tasks');
    for (const t of list.filter(t => t.status === 'open' || t.pinned_at).slice(0, 150)) {
      if (offline) break;
      await api('GET', `/api/tasks/${t.id}`).catch(() => {});
    }
  } catch {} finally { prefetching = false; }
}

// ---------- toast and sheet ----------
let toastTimer;
function toast(text, bad = false, undo = null) {
  const t = $('#toast'); t.textContent = text; t.className = 'show' + (bad ? ' bad' : '') + (undo ? ' act' : '');
  if (undo) {
    const b = document.createElement('button'); b.type = 'button'; b.textContent = 'Undo';
    b.onclick = () => { clearTimeout(toastTimer); t.className = ''; undo(); };
    t.append(b);
  }
  clearTimeout(toastTimer); toastTimer = setTimeout(() => t.className = '', bad ? 4500 : undo ? 5000 : 2600);
}
/** A dialog from the bottom of the screen. Resolves with what close() was given (undefined when dismissed). */
function sheet(html, onOpen) {
  const el = $('#sheet');
  el.innerHTML = `<div class="sh" role="dialog" aria-modal="true"><div class="grip"></div>${html}</div>`;
  el.hidden = false;
  return new Promise(resolve => {
    const close = v => { el.hidden = true; el.innerHTML = ''; el.onclick = null; resolve(v); afterSheet(); };
    el.onclick = e => { if (e.target === el || e.target.closest('[data-close]')) close(); };
    onOpen?.($('.sh', el), close);
  });
}
const confirmSheet = (title, text, yes, cls = 'primary') => sheet(`<h2>${esc(title)}</h2><p class="lead">${esc(text)}</p>
  <div class="btns"><button class="btn" data-close>Cancel</button><button class="btn ${cls}" id="yes">${esc(yes)}</button></div>`,
  (sh, close) => { $('#yes', sh).onclick = () => close(true); });
async function busy(btn, fn, label) {
  const was = btn.innerHTML; btn.disabled = true;
  if (label) btn.innerHTML = `<span class="spinner" style="width:16px;height:16px;border-width:2px"></span> ${esc(label)}`;
  try { return await fn(); } catch (e) { toast(e.message, true); } finally { if (btn.isConnected) { btn.disabled = false; btn.innerHTML = was; } }
}

// ---------- state ----------
const S = { status: null, meta: null, tasks: null, tasksAt: 0, people: null, me: null, view: '' };
const view = () => $('#view');
const loading = (text = 'Loading') => `<div class="load"><span class="spinner"></span>${esc(text)}</div>`;
const errorHtml = e => e instanceof Offline ? offlineHtml() : `<div class="err">${esc(e.message)}</div>`;
const offlineHtml = () => `<div class="card pad" style="margin-top:20px"><h2 style="font-size:18px;margin-bottom:6px">Not on this phone yet</h2>
  <p class="muted" style="margin:0 0 10px">Without your computer, Mandata shows what this phone has already opened. This page opens once the phone reaches the computer again: check that</p>
  <ul class="steps"><li>the computer is on and Mandata is running,</li><li>the phone is on the same Wi-Fi as the computer,</li><li>phone access is still on in Mandata, Settings &gt; Phone.</li></ul>
  <button class="btn primary wide" style="margin-top:8px" data-reload>${icon('refresh', 18)} Try again</button></div>`;

async function tasks(force = false) {
  if (!S.tasks || force || Date.now() - S.tasksAt > 15000) { S.tasks = await api('GET', '/api/tasks'); S.tasksAt = Date.now(); }
  return S.tasks;
}

// ---------- status ----------
async function loadStatus() {
  try { S.status = await api('GET', '/api/status'); } catch (e) { if (!(e instanceof Offline)) S.status = null; }
  drawStatus();
}
function drawStatus() {
  const st = S.status, dot = $('#st .dot'), txt = $('#stText');
  dot.className = 'dot';
  if (offline || !st) {
    dot.classList.add('bad'); txt.textContent = waiting ? `Offline · ${waiting} to send` : 'Offline';
    $('#sync').classList.remove('spin'); return;
  }
  const sy = st.sync || {};
  if (sy.running) { dot.classList.add('busy'); txt.textContent = sy.phase || 'Checking mail'; }
  else if (sy.aiBusy && sy.aiPhase) { dot.classList.add('busy'); txt.textContent = sy.aiPhase; }
  else if (st.ai?.focus) { dot.classList.add('busy'); txt.textContent = st.ai.focus; }
  else if (!st.outlook?.connected) { dot.classList.add('bad'); txt.textContent = 'Mail not connected'; }
  else if (!st.ai?.online) { dot.classList.add('bad'); txt.textContent = st.ai?.paused ? 'AI paused' : 'AI offline'; }
  else { dot.classList.add('on'); txt.textContent = sy.lastOk ? `Checked ${when(sy.lastOk)}` : 'Up to date'; }
  $('#sync').classList.toggle('spin', !!sy.running);
  const c = st.counts || {}, em = $('#tabs a[data-tab="tasks"] em') || (() => { const e = document.createElement('em'); $('#tabs a[data-tab="tasks"]').append(e); return e; })();
  em.textContent = c.overdue || ''; em.hidden = !c.overdue;
}
$('#st').onclick = () => {
  const st = S.status;
  if (offline || !st) return sheet(`<h2>Offline</h2><p class="lead">This phone cannot reach Mandata on your computer (${esc(location.host)}).</p>
    <p>You can keep using what is on the phone. ${waiting ? `<b>${plural(waiting, 'change')}</b> you made wait` : 'Changes you make wait'} on the phone and go to the computer once it answers again.</p>
    <p class="muted small" style="margin-top:8px">Until then: no new mail or tasks, no Ask Mandata, no follow-up drafts, no sending, no notifications.</p>
    <div class="btns" style="margin-top:16px"><button class="btn" data-close>Close</button><button class="btn primary" id="retryNow">${icon('refresh', 18)} Try now</button></div>`,
    (sh, close) => { $('#retryNow', sh).onclick = () => busy($('#retryNow', sh), async () => { await send('GET', '/api/phone/me'); online(); close(); toast('Connected to your computer'); }, 'Trying'); });
  const sy = st.sync || {};
  sheet(`<h2>Mandata on your computer</h2><p class="lead">${esc(location.host)} · version ${esc(st.version)}</p>
    <dl class="facts">
      <dt>Mail</dt><dd>${st.outlook?.connected ? `Connected${st.outlook.defaultStore ? `, ${esc(st.outlook.defaultStore)}` : ''}` : esc(st.outlook?.error || 'Not connected')}</dd>
      <dt>Last check</dt><dd>${sy.lastOk ? esc(fullDate(sy.lastOk)) : 'Not yet'}</dd>
      <dt>AI</dt><dd>${st.ai?.online ? `Online, ${esc(st.ai.model)}` : esc(st.ai?.error || 'Offline')}</dd>
      <dt>Reading</dt><dd>${sy.threadsQueued ? `${plural(sy.threadsQueued, 'thread')} waiting` : 'Nothing waiting'}${sy.threadsStuck ? `, ${sy.threadsStuck} stuck` : ''}</dd>
      <dt>Open tasks</dt><dd>${st.counts?.open ?? 0}, ${st.counts?.overdue ?? 0} overdue</dd>
    </dl><div class="btns" style="margin-top:16px"><button class="btn" data-close>Close</button></div>`);
};
$('#sync').innerHTML = icon('refresh', 19);
$('#sync').dataset.needsPc = '';
$('#sync').onclick = async () => { try { await api('POST', '/api/sync'); toast('Checking mail on your computer'); setTimeout(loadStatus, 800); } catch (e) { toast(e.message, true); } };

// ---------- live updates ----------
let events = null, dirty = new Set(), refreshTimer = null;
function listen() {
  if (events) events.close();
  events = new EventSource('/api/events');
  events.onmessage = e => {
    let m; try { m = JSON.parse(e.data); } catch { return; }
    if (m.type === 'status') { clearTimeout(listen.st); listen.st = setTimeout(loadStatus, 300); return; }
    if (['tasks', 'people', 'ask', 'drafts', 'threads'].includes(m.type)) {
      if (m.type === 'tasks') S.tasksAt = 0;
      if (m.type === 'people') S.people = null;
      dirty.add(m.type); clearTimeout(refreshTimer); refreshTimer = setTimeout(refresh, 700);
    }
  };
  // Gone quiet: the computer may be off its network, or only restarting. A look tells which.
  events.onerror = () => send('GET', '/api/phone/me').then(online, e => { if (e instanceof Offline) { events.close(); offlineNow(); } });
  events.onopen = () => { loadStatus(); checkBuild(); };
}
// A newer phone app on the computer (installed while this page stayed open): load it, once you are not typing.
let build = null;
async function checkBuild() {
  let b;
  try { b = (await send('GET', '/api/phone/build')).build; } catch { return; }
  if (!b) return;
  if (build == null) build = b;
  else if (b !== build) { if (typing()) setTimeout(checkBuild, 3000); else location.reload(); }
}
// What changed is drawn again, unless you are typing or a dialog is open: then once you are done.
const typing = () => !$('#sheet').hidden || ['INPUT', 'TEXTAREA', 'SELECT'].includes(document.activeElement?.tagName) || asking;
function refresh() {
  if (!dirty.size) return;
  if (typing()) { clearTimeout(refreshTimer); refreshTimer = setTimeout(refresh, 1500); return; }
  const want = { home: ['tasks'], tasks: ['tasks'], task: ['tasks', 'drafts'], people: ['people'], person: ['people', 'tasks'], ask: ['ask'], thread: ['tasks', 'threads'] }[S.view] || [];
  const hit = want.some(t => dirty.has(t));
  dirty.clear();
  if (hit) route({ quiet: true });
}
function afterSheet() { if (dirty.size) { clearTimeout(refreshTimer); refreshTimer = setTimeout(refresh, 300); } }
document.addEventListener('visibilitychange', () => { if (document.visibilityState === 'visible' && S.me) { checkBuild(); loadStatus(); S.tasksAt = 0; route({ quiet: true }); if (!offline && events?.readyState === 2) listen(); } });

// ---------- tasks: how one reads ----------
const CLOSED = { done: 'Done', cancelled: 'Cancelled', parked: 'Parked', dismissed: 'Not a task' };
const closeLabel = t => (S.meta?.close_reasons || []).find(r => r.code === t.close_reason)?.label || CLOSED[t.status] || t.status;
/** How long until a time: "in 3 days", "in 5 h", "in 20 min". */
const untilLabel = iso => { const ms = Date.parse(iso) - Date.now(); if (!(ms > 0)) return 'now';
  const m = Math.ceil(ms / 6e4), h = Math.round(ms / 36e5), d = Math.round(ms / 864e5);
  return m < 60 ? `in ${m} min` : h < 48 ? `in ${h} h` : `in ${d} days`; };
function dueChip(t) {
  // Parked: open again on its own once the park period (Settings > Tasks on the computer) is over.
  if (t.status === 'parked' && t.unpark_at) return `<span class="chip parked">${icon('clock', 13)}Parked, back ${esc(untilLabel(t.unpark_at))}</span>`;
  if (t.status !== 'open') return `<span class="chip ok">${icon('check', 13)}${esc(closeLabel(t))}</span>`;
  if (!t.deadline) return `<span class="chip">No deadline</span>`;
  if (t.overdue) return `<span class="chip late">${icon('alert', 13)}${-t.days_left}d late</span>`;
  if (t.days_left === 0) return `<span class="chip soon">${icon('clock', 13)}Due today</span>`;
  if (t.days_left === 1) return `<span class="chip soon">${icon('clock', 13)}Due tomorrow</span>`;
  return `<span class="chip${t.due_soon ? ' soon' : ''}">${icon('calendar', 13)}${esc(dayLabel(t.deadline))}</span>`;
}
const first = n => String(n || '').replace(/\(.*?\)/g, '').trim();
function whoLine(t) {
  const req = first(t.requester_name) || t.requester_email || 'Someone', own = first(t.owner_name) || t.owner_email || 'someone';
  const more = (t.secondary || []).length;
  return t.direction === 'to_me' ? `${req} asked you`
    : t.direction === 'among' ? `${req} asked you${more ? ` and ${plural(more, 'other')}` : ' among others'}`
    : t.direction === 'by_me' ? `You asked ${own}${more ? ` and ${plural(more, 'other')}` : ''}`
    : `${req} asked ${own}`;
}
// New to you (found and not opened yet): the card glows blue, as on the computer, until you open it.
// A card says only what tells tasks apart: no "No deadline" chip, no kind when the list shows one kind,
// and no latest news that only repeats the deadline.
const quietNews = x => !x || /^Deadline\b/i.test(x);
const taskCard = (t, news = true, kind = true) => `<a class="task${t.status !== 'open' ? ' closed' : ''}${!t.seen && t.status === 'open' ? ' isnew' : ''}" href="#/task/${t.id}">
  <div class="t1">${t.pinned_at ? `<span class="pin">${icon('pin', 15)}</span>` : ''}<h3 class="clamp2">${esc(t.title)}</h3>${!t.seen && t.status === 'open' ? '<i class="unseen" title="New"></i>' : ''}</div>
  <div class="row2">${kind ? `<span class="kind" style="--kc:${dir(t.direction).color}" title="${esc(dir(t.direction).label)}">${icon(dir(t.direction).icon, 13)}</span>` : ''}<span class="who clamp1">${esc(whoLine(t))}</span>${t.priority === 'high' && t.status === 'open' ? `<span class="chip late" title="High priority">${icon('alert', 12)}High</span>` : ''}${t.status !== 'open' || t.deadline ? dueChip(t) : ''}</div>
  ${(t.unsure && t.status === 'open') || t.pending ? `<div class="meta">${t.unsure && t.status === 'open' ? '<span class="chip unsure">Not sure</span>' : ''}${t.pending ? `<span class="chip">${icon('clock', 13)}Not sent yet</span>` : ''}</div>` : ''}
  ${news && !quietNews(t.last?.text) ? `<div class="news clamp1">${icon('spark', 13)}<span class="clamp1">${esc(t.last.text)}</span></div>` : ''}</a>`;
// An open task can be swiped: right closes it the default way (done; archived for a task asked of you among others or
// between others), left pins it to the top (or unpins it).
const archives = t => t.direction === 'others' || t.direction === 'among';
const swipeable = (t, html) => t.status !== 'open' ? html : `<div class="sw" data-id="${t.id}" data-others="${archives(t) ? 1 : ''}" data-pinned="${t.pinned_at ? 1 : ''}">
  <div class="sw-bg">${archives(t) ? `<span class="sw-done">${icon('archive', 20)}Archive</span>` : `<span class="sw-done">${icon('done', 20)}Done</span>`}<span class="sw-park">${t.pinned_at ? 'Unpin' : 'Pin'}${icon('pin', 20)}</span></div>${html}</div>`;
const cards = (list, news, kind) => list.length ? `<div class="list">${list.map(t => swipeable(t, taskCard(t, news, kind))).join('')}</div>` : '';

// ---------- swiping a task ----------
// Horizontal drags on a card are a swipe; vertical ones scroll as usual (touch-action: pan-y). Past a third of the
// card, or a quick flick, it closes the task (undo reopens it) or pins it; less springs back.
const swipe = { el: null };
async function closeBySwipe(sw, right) {
  const id = sw.dataset.id, others = !!sw.dataset.others;
  if (!right) { const pinned = !!sw.dataset.pinned; return taskChange(id, 'POST', `/api/tasks/${id}/pin`, { pinned: !pinned }, pinned ? 'Unpinned' : 'Pinned to the top'); }
  const reason = others ? 'archived' : 'done';
  const msg = reason === 'done' ? 'Closed as done' : 'Archived';
  sw.style.height = sw.offsetHeight + 'px'; void sw.offsetHeight; sw.classList.add('gone');
  await new Promise(r => setTimeout(r, 220));
  taskChange(id, 'PATCH', `/api/tasks/${id}`, { action: 'close', reason }, msg,
    () => taskChange(id, 'PATCH', `/api/tasks/${id}`, { action: 'reopen' }, 'Reopened'));
}
document.addEventListener('pointerdown', e => {
  const sw = e.target.closest('.sw'); if (!sw || e.button > 0) return;
  Object.assign(swipe, { el: sw, card: $('.task', sw), x: e.clientX, y: e.clientY, t: e.timeStamp, dx: 0, on: false, id: e.pointerId });
});
document.addEventListener('pointermove', e => {
  const s = swipe; if (!s.el || e.pointerId !== s.id) return;
  const dx = e.clientX - s.x, dy = e.clientY - s.y;
  if (!s.on) {
    if (Math.abs(dy) > 10 && Math.abs(dy) > Math.abs(dx)) { s.el = null; return; }   // scrolling
    if (Math.abs(dx) < 12) return;
    s.on = true; s.card.classList.add('dragging'); try { s.el.setPointerCapture(e.pointerId); } catch {}
  }
  s.dx = dx;
  s.card.style.transform = `translateX(${s.dx}px)`;
  s.el.classList.toggle('right', s.dx > 0); s.el.classList.toggle('left', s.dx < 0);
  s.el.classList.toggle('armed', Math.abs(s.dx) > s.el.offsetWidth / 3);
});
function endSwipe(e) {
  const s = swipe; if (!s.el || e.pointerId !== s.id) return;
  const sw = s.el, card = s.card; s.el = null;
  if (!s.on) return;
  card.classList.remove('dragging');
  const fast = Math.abs(s.dx) > 60 && Math.abs(s.dx) / Math.max(1, e.timeStamp - s.t) > 0.6;
  const ok = e.type === 'pointerup' && (Math.abs(s.dx) > sw.offsetWidth / 3 || fast);
  swipe.justSwiped = true; setTimeout(() => { swipe.justSwiped = false; }, 350);   // the click ending a drag opens nothing
  const back = () => { card.style.transform = ''; sw.classList.remove('armed'); setTimeout(() => sw.classList.remove('left', 'right'), 200); };
  if (!ok) return back();
  if (s.dx < 0) { back(); return closeBySwipe(sw, false); }   // pinning keeps the task in the list: it springs back
  card.style.transform = `translateX(${s.dx > 0 ? '' : '-'}110%)`;
  closeBySwipe(sw, s.dx > 0);
}
document.addEventListener('pointerup', endSwipe);
document.addEventListener('pointercancel', endSwipe);
document.addEventListener('click', e => { if (swipe.justSwiped && e.target.closest('.sw')) { e.preventDefault(); e.stopPropagation(); } }, true);

// ---------- Home ----------
async function home() {
  const all = await tasks();
  const open = all.filter(t => t.status === 'open');
  const name = first(S.status?.me?.name).split(' ')[0];
  const h = new Date().getHours(), hello = h < 12 ? 'Good morning' : h < 18 ? 'Good afternoon' : 'Good evening';
  const late = open.filter(t => t.overdue).sort((a, b) => a.days_left - b.days_left);
  const soon = open.filter(t => t.due_soon).sort((a, b) => a.days_left - b.days_left);
  const pinned = open.filter(t => t.pinned_at);
  const fresh = open.filter(t => t.mail_at).sort((a, b) => b.mail_at.localeCompare(a.mail_at)).slice(0, 5);
  return `<div class="hello"><h1>${esc(hello)}${name ? `, ${esc(name)}` : ''}</h1><p class="muted" style="margin:2px 0 0">${esc(new Date().toLocaleDateString(LOCALE, { weekday: 'long', day: 'numeric', month: 'long' }))}</p></div>
    <div class="tiles">
      <a class="tile late" href="#/tasks/late"><b>${late.length}</b><span>Overdue</span></a>
      <a class="tile soon" href="#/tasks/soon"><b>${soon.length}</b><span>Due soon</span></a>
      <a class="tile" href="#/tasks"><b>${open.length}</b><span>Open tasks</span></a>
      <a class="tile" href="#/tasks/new"><b>${open.filter(t => !t.seen).length}</b><span>New to you</span></a>
    </div>
    ${pinned.length ? `<div class="sec">${icon('pin', 15)} Pinned <em>${pinned.length}</em></div>${cards(pinned, false)}` : ''}
    <div class="sec">${icon('alert', 15)} Overdue <em>${late.length}</em></div>
    ${late.length ? cards(late.slice(0, 6), false) + (late.length > 6 ? `<a class="btn wide" style="margin-top:10px" href="#/tasks/late">See all ${late.length}</a>` : '') : '<div class="card empty">Nothing overdue. Well done.</div>'}
    ${soon.length ? `<div class="sec">${icon('clock', 15)} Due soon <em>${soon.length}</em></div>${cards(soon.slice(0, 6), false)}` : ''}
    ${fresh.length ? `<div class="sec">${icon('spark', 15)} Latest news</div>${cards(fresh, true)}` : ''}`;
}

// ---------- Tasks ----------
const TF = Object.assign({ dir: 'all', state: 'open', q: '', sort: 'arrival' }, store.get('tf', {}));
if (!['open', 'pinned', 'closed'].includes(TF.state)) TF.state = 'open';   // Parked was a filter once: parked tasks are under Closed
const QUICK = { late: 'Overdue', soon: 'Due soon', new: 'New to you' };
// The orders a list can take. Update (the latest email), newest on top, is the default; the one you choose is kept on this phone.
const SORTS = { arrival: 'Update', deadline: 'Due', priority: 'Priority', news: 'Process' };
// What each order means, as its tooltip.
const SORT_TIP = { arrival: 'By the latest email about the task, received or sent, latest first', deadline: 'By deadline, the nearest first',
  priority: 'High priority first, then normal, then low', news: 'By when Mandata found the task in your mail, latest first' };
// Arrival date: the latest email about the task, received or sent, else the one that opened it.
const arrived = t => String(t.mail_at || t.opened_at || '');
const PRI_RANK = { high: 0, normal: 1, low: 2 };
const ORDER = {
  arrival: (a, b) => arrived(b).localeCompare(arrived(a)),
  priority: (a, b) => (PRI_RANK[a.priority] ?? 1) - (PRI_RANK[b.priority] ?? 1) || arrived(b).localeCompare(arrived(a)),
  // When Mandata found the task: the one place processing counts.
  news: (a, b) => String(b.created_at || arrived(b)).localeCompare(String(a.created_at || arrived(a))),};
async function taskList(quick) {
  const all = await tasks();
  const q = TF.q.trim().toLowerCase();
  const match = t => !q || [t.title, t.detail, t.subject, t.requester_name, t.owner_name, t.requester_email, t.owner_email, ...(t.secondary || []).map(s => s.name)]
    .some(v => String(v || '').toLowerCase().includes(q));
  // Pinned: the open tasks pinned to the top. Closed holds parked tasks too, each with when it opens again.
  const byState = t => TF.state === 'open' ? t.status === 'open' : TF.state === 'pinned' ? t.status === 'open' && t.pinned_at : !['open', 'dismissed'].includes(t.status);
  const byQuick = t => !quick || (quick === 'late' ? t.overdue : quick === 'soon' ? t.due_soon : !t.seen && t.status === 'open');
  const pool = all.filter(t => (quick ? t.status === 'open' : byState(t)) && byQuick(t) && match(t));
  const count = k => pool.filter(t => k === 'all' || t.direction === k).length;
  const list = pool.filter(t => TF.dir === 'all' || t.direction === TF.dir);
  const kind = TF.dir === 'all';
  let body;
  if (!list.length) body = `<div class="card empty"><b>No tasks here</b>${q ? 'Nothing matches your search.' : quick ? '' : `Nothing ${TF.state} of this kind.`}</div>`;
  else if (TF.state === 'pinned' && !quick) body = cards(list.sort(ORDER[TF.sort] || ((a, b) => (a.deadline || '9').localeCompare(b.deadline || '9'))), true, kind);
  else if (TF.state === 'closed' && !quick) body = cards(list.sort((a, b) => String(b.closed_at || b.updated_at).localeCompare(String(a.closed_at || a.updated_at))).slice(0, 150), false, kind);
  // One list in the order chosen: pinned tasks keep their place (the Pinned filter lists them), marked by their pin.
  else if (ORDER[TF.sort]) body = cards(list.sort(ORDER[TF.sort]), true, kind);
  else {
    const groups = [['Overdue', t => t.overdue], ['Today and tomorrow', t => t.days_left != null && t.days_left <= 1],
      ['Within a week', t => t.days_left != null && t.days_left <= 7], ['Later', t => t.days_left != null], ['No deadline', () => true]];
    const seen = new Set(), out = [];
    for (const [label, test] of groups) {
      const g = list.filter(t => !seen.has(t.id) && test(t));
      g.forEach(t => seen.add(t.id));
      if (g.length) out.push(`<div class="sec">${esc(label)} <em>${g.length}</em></div>${cards(g.sort((a, b) => (a.deadline || '9').localeCompare(b.deadline || '9')), true, kind)}`);
    }
    body = out.join('');
  }
  return `<div class="h tasks-h"><h1>${quick ? esc(QUICK[quick]) : 'Tasks'}</h1><span class="sp"></span>${quick ? '<a class="btn sm" href="#/tasks">All tasks</a>'
      : `<div class="toggle" id="tfState" role="group" aria-label="Open or closed">${[['open', 'Open'], ['pinned', 'Pinned'], ['closed', 'Closed']].map(([k, l]) => `<button data-v="${k}" class="${TF.state === k ? 'on' : ''}" aria-pressed="${TF.state === k}">${l}</button>`).join('')}</div>`}</div>
    <div class="seg" id="tfDir">${[['all', 'All'], ...Object.entries(DIR).map(([k, d]) => [k, d.short])].map(([k, l]) => `<button data-v="${k}" class="${TF.dir === k ? 'on' : ''}">${esc(l)}<em>${count(k)}</em></button>`).join('')}</div>
    <div class="tools"><div class="search">${icon('search', 17)}<input type="search" id="tfQ" placeholder="Search tasks, people" value="${esc(TF.q)}" autocomplete="off" aria-label="Search tasks, people, subjects"></div>
    ${TF.state === 'closed' && !quick ? '' : `<label class="sortby" title="Order by">${icon('sort', 16)}<select id="tfSort" aria-label="Order by">${Object.entries(SORTS).map(([k, l]) => `<option value="${k}" title="${esc(SORT_TIP[k])}"${TF.sort === k ? ' selected' : ''}>${esc(l)}</option>`).join('')}</select></label>`}</div>
    <div id="tfList">${body}</div>`;
}
function wireTasks(el, quick) {
  $('#tfSort', el)?.addEventListener('change', e => set('sort', e.target.value));
  const set = (k, v) => { TF[k] = v; store.set('tf', { dir: TF.dir, state: TF.state, sort: TF.sort }); render(() => taskList(quick), w => wireTasks(w, quick), { quiet: true, keepScroll: k === 'q' }); };
  $('#tfState', el)?.addEventListener('click', e => { const b = e.target.closest('button'); if (b) set('state', b.dataset.v); });
  $('#tfDir', el)?.addEventListener('click', e => { const b = e.target.closest('button'); if (b) set('dir', b.dataset.v); });
  const qi = $('#tfQ', el); let t;
  qi.oninput = () => { clearTimeout(t); t = setTimeout(async () => { TF.q = qi.value; const html = await taskList(quick); const tmp = document.createElement('div'); tmp.innerHTML = html; $('#tfList', el).replaceWith($('#tfList', tmp)); $('#tfDir', el).replaceWith($('#tfDir', tmp)); wireTasks(el, quick); }, 200); };
}

// ---------- one task ----------
async function taskPage(id) {
  let t;
  try { t = await api('GET', `/api/tasks/${enc(id)}`); }
  catch (e) {
    // Not opened on this phone before: what the list knows of it, without its emails and history.
    const one = e instanceof Offline && (await tasks().catch(() => [])).find(x => String(x.id) === String(id));
    if (!one) throw e;
    t = { ...one, events: [], drafts: [], thread: null };
  }
  if (!t.seen && !offline) api('POST', `/api/tasks/${enc(id)}/seen`).catch(() => {});
  S.task = t;
  const msgs = [...(t.thread?.messages || [])].sort((a, b) => String(b.received_at).localeCompare(String(a.received_at)));
  const others = (t.secondary || []).map(s => s.name || s.email);
  const person = (name, email) => email ? `<a href="#/person/${enc(email)}">${esc(name || email)}</a>` : esc(name || '');
  const evs = t.events || [];
  return `<button class="back" data-back="#/tasks">${icon('back', 18)} Back</button>
  <article class="tp">
    <div class="btns" style="gap:6px;flex-wrap:wrap">${t.pending ? `<span class="chip">${icon('clock', 13)}Not sent yet</span>` : ''}${kindChip(t.direction)}${dueChip(t)}${t.priority === 'high' ? '<span class="chip late">High priority</span>' : ''}${t.pinned_at ? `<span class="chip">${icon('pin', 13)}Pinned</span>` : ''}</div>
    <h1>${esc(t.title)}</h1>
    <dl class="facts">
      <dt>Asked by</dt><dd>${person(t.requester_name, t.requester_email)}</dd>
      <dt>Asked of</dt><dd>${person(t.owner_name, t.owner_email)}${others.length ? `, ${(t.secondary || []).map(s => person(s.name, s.email)).join(', ')}` : ''}</dd>
      <dt>Deadline</dt><dd>${t.deadline ? `${esc(dayLabel(t.deadline))}${t.deadline_note ? `<br><span class="muted small">"${esc(t.deadline_note)}"</span>` : t.deadline_source === 'user' ? ' <span class="muted small">(set by you)</span>' : ''}` : 'None: no email sets one'}</dd>
      <dt>Asked on</dt><dd>${esc(fullDate(t.opened_at))}</dd>
      ${t.status === 'parked' && t.unpark_at ? `<dt>Back</dt><dd>Open again ${esc(untilLabel(t.unpark_at))}<br><span class="muted small">${esc(fullDate(t.unpark_at))}</span></dd>` : ''}
      ${t.status !== 'open' ? `<dt>Closed</dt><dd>${esc(closeLabel(t))}${t.closed_at ? `, ${esc(when(t.closed_at))}` : ''}${t.close_note ? `<br><span class="muted small">${esc(t.close_note)}</span>` : ''}</dd>` : ''}
      ${t.subject ? `<dt>Thread</dt><dd><a href="#/thread/${enc(t.conversation_id)}">${esc(t.subject)}</a></dd>` : ''}
    </dl>
    ${t.unsure && t.status === 'open' ? `<div class="block unsure"><h4>Not sure it is a task</h4><p>${esc(t.unsure)}</p><p class="muted small">Is it a task? Your answer teaches the AI.</p>
      <div class="btns" style="margin-top:10px"><button class="btn good" data-act="confirm">${icon('check', 18)} Yes, a task</button><button class="btn" data-act="notask">${icon('ban', 18)} Not a task</button></div></div>` : ''}
    ${t.detail ? `<div class="block"><h4>What is asked</h4><p>${esc(t.detail)}</p></div>` : ''}
    ${t.progress ? `<div class="block"><h4>Where it stands</h4><p>${esc(t.progress)}</p></div>` : ''}
    ${(t.drafts || []).length ? `<div class="block"><h4>Your emails about it</h4>${t.drafts.map(d => `<a class="mail" href="#" data-draft="${d.id}"><div class="mh"><b class="clamp1">${esc(d.subject || '(no subject)')}</b><small>${esc(d.status === 'sent' ? 'Sent' : d.status === 'sending' ? 'Sending' : 'Draft')} · ${esc(when(d.updated_at))}</small></div></a>`).join('')}</div>` : ''}
    ${evs.length ? `<div class="block"><h4>History</h4><ul class="tl">${evs.slice(-8).reverse().map(e => `<li><i></i><div>${esc(e.text)}<small>${esc(fullDate(e.at))}${e.email_id ? ` · <a href="#/email/${enc(e.email_id)}">Read the email</a>` : ''}</small></div></li>`).join('')}</ul>${evs.length > 8 ? `<p class="muted small" style="margin-top:8px">And ${evs.length - 8} earlier.</p>` : ''}</div>` : ''}
    ${msgs.length ? `<div class="sec">${icon('mail', 15)} Emails in the thread <em>${msgs.length}</em></div>${msgs.map(mailLine).join('')}` : ''}
    <div class="actions btns">${taskActions(t)}</div>
  </article>`;
}
const snippet = s => String(s || '').replace(/\s+/g, ' ').trim().slice(0, 160);
const mailLine = m => `<a class="mail${m.mine ? ' mine' : ''}" href="#/email/${enc(m.id)}"><div class="mh"><b class="clamp1">${esc(m.mine ? 'You' : m.from_name || m.from_email)}</b><small>${esc(when(m.received_at))}</small></div><p class="clamp2">${esc(snippet(m.body))}</p></a>`;
function taskActions(t) {
  if (t.status !== 'open') return `<button class="btn primary" data-act="reopen">${icon('reopen', 18)} ${t.status === 'parked' ? 'Resume' : 'Reopen'}</button>`;
  if (t.direction === 'others') return `<button class="btn" data-act="archive">${icon('check', 18)} Archive</button><button class="btn" data-act="more">${icon('more', 18)}</button>`;
  return `<button class="btn good" data-act="done">${icon('done', 18)} Done</button><button class="btn" data-act="followup" data-needs-pc>${icon('send', 18)} Follow up</button><button class="btn" data-act="more" aria-label="More">${icon('more', 18)}</button>`;
}
function wireTask(el) {
  const t = S.task;
  const patch = (body, msg) => taskChange(t.id, 'PATCH', `/api/tasks/${t.id}`, body, msg);
  el.addEventListener('click', async e => {
    const d = e.target.closest('[data-draft]');
    if (d) { e.preventDefault(); return openDraft(Number(d.dataset.draft)); }
    const b = e.target.closest('[data-act]'); if (!b) return;
    const act = b.dataset.act;
    if (act === 'done') return busy(b, () => patch({ action: 'close', reason: 'done' }, 'Closed as done'));
    if (act === 'archive') return busy(b, () => patch({ action: 'close', reason: 'archived' }, 'Archived'));
    if (act === 'reopen') return busy(b, () => patch({ action: 'reopen' }, t.status === 'parked' ? 'Resumed' : 'Reopened'));
    if (act === 'confirm') return busy(b, () => patch({ action: 'confirm' }, 'Confirmed as a task: the AI learns from it'));
    if (act === 'notask') { if (await confirmSheet('Not a task?', 'The AI misread the email: nobody asked for this. Mandata learns from it.', 'Not a task')) busy(b, () => patch({ action: 'dismiss' }, 'Not a task: the AI learns from it')); return; }
    if (act === 'followup') return followUp(t);
    if (act === 'more') return moreSheet(t, patch);
  });
}
async function moreSheet(t, patch) {
  const reasons = (S.meta?.close_reasons || []).filter(r => t.direction !== 'others' || r.code === 'archived');
  const v = await sheet(`<h2 class="clamp2">${esc(t.title)}</h2><p class="lead">What would you like to do?</p>
    <div class="opts">
      <button class="opt" data-v="deadline">${icon('calendar')}<div><b>Set the deadline</b><small>${t.deadline ? `Now ${esc(dayLabel(t.deadline))}` : 'No email sets one'}</small></div></button>
      <button class="opt" data-v="pin">${icon('pin')}<div><b>${t.pinned_at ? 'Unpin it' : 'Pin it to the top'}</b><small>${t.pinned_at ? 'Back among the others' : 'First in every list'}</small></div></button>
    </div>
    <div class="sec" style="margin-top:6px">Close it as</div>
    <div class="opts">${reasons.map(r => `<button class="opt" data-v="close:${esc(r.code)}">${icon(r.code === 'notask' ? 'ban' : r.code === 'parked' ? 'clock' : 'check')}<div><b>${esc(r.label)}</b><small>${esc(r.code === 'parked' && S.meta?.limits?.parkPeriod ? `Set aside for ${S.meta.limits.parkPeriod}, then open again` : r.hint || '')}</small></div></button>`).join('')}</div>
    <button class="btn wide" data-close>Cancel</button>`, (sh, close) => sh.addEventListener('click', e => { const o = e.target.closest('[data-v]'); if (o) close(o.dataset.v); }));
  if (!v) return;
  try {
    if (v === 'pin') return taskChange(t.id, 'POST', `/api/tasks/${t.id}/pin`, { pinned: !t.pinned_at }, t.pinned_at ? 'Unpinned' : 'Pinned to the top');
    if (v === 'deadline') return deadlineSheet(t, patch);
    const code = v.slice(6), r = reasons.find(x => x.code === code);
    if (code === 'notask' && !await confirmSheet('Not a task?', 'The AI misread the email: nobody asked for this. Mandata learns from it.', 'Not a task')) return;
    await patch({ action: code === 'notask' ? 'dismiss' : 'close', reason: code }, r?.event || 'Closed');
  } catch (e) { toast(e.message, true); }
}
async function deadlineSheet(t, patch) {
  const v = await sheet(`<h2>Deadline</h2><p class="lead">A deadline you set is kept: the AI does not change it.</p>
    <input type="date" id="dl" value="${esc(t.deadline || '')}" min="2000-01-01">
    <div class="presets">${[['Today', 0], ['Tomorrow', 1], ['In 3 days', 3], ['Next week', 7]].map(([l, n]) => `<button data-n="${n}">${l}</button>`).join('')}</div>
    <div class="btns" style="margin-top:12px"><button class="btn" data-close>Cancel</button><button class="btn primary" id="dlOk">Save</button></div>`, (sh, close) => {
    sh.addEventListener('click', e => { const p = e.target.closest('[data-n]'); if (!p) return; const d = new Date(); d.setDate(d.getDate() + Number(p.dataset.n)); $('#dl', sh).value = isoDay(d); });
    $('#dlOk', sh).onclick = () => close($('#dl', sh).value);
  });
  if (!v) return;
  try { await patch({ deadline: v }, `Deadline set to ${dayLabel(v)}`); } catch (e) { toast(e.message, true); }
}

// ---------- follow-ups: drafted on the computer, reviewed and sent here ----------
async function followUp(t) {
  const v = await sheet(`<h2>Follow up</h2><p class="lead">The AI on your computer drafts an email in the task's own thread. You review it before anything is sent.</p>
    <div class="presets">${['Gentle reminder', 'Ask for a date', 'Offer help', 'Send an update', 'Ask for an extension', 'Escalate politely'].map(p => `<button data-p="${esc(p)}">${esc(p)}</button>`).join('')}</div>
    <textarea id="fu" rows="3" placeholder="Anything to add? For example: mention the board meeting on Thursday" style="min-height:90px;margin-top:6px"></textarea>
    <div class="btns" style="margin-top:12px"><button class="btn" data-close>Cancel</button><button class="btn primary" id="fuGo">${icon('mail', 18)} Draft it</button></div>`, (sh, close) => {
    sh.addEventListener('click', e => { const p = e.target.closest('[data-p]'); if (p) { const ta = $('#fu', sh); ta.value = ta.value ? `${ta.value}. ${p.dataset.p}` : p.dataset.p; } });
    $('#fuGo', sh).onclick = () => busy($('#fuGo', sh), async () => close(await api('POST', `/api/tasks/${t.id}/followup`, { instruction: $('#fu', sh).value.trim() })), 'Drafting on your computer');
  });
  if (v?.id) draftSheet(v);
}
async function openDraft(id) { try { draftSheet(await api('GET', `/api/drafts/${id}`)); } catch (e) { toast(e.message, true); } }
async function draftSheet(d) {
  const done = ['sent', 'sending', 'discarded'].includes(d.status);
  const list = a => (a || []).map(x => typeof x === 'string' ? x : x.email || x.name).join(', ');
  await sheet(`<h2>${done ? 'Email' : 'Review the email'}</h2>
    <dl class="facts" style="margin:8px 0 4px;font-size:14px"><dt>To</dt><dd>${esc(list(d.to)) || '<span class="muted">nobody</span>'}</dd>${(d.cc || []).length ? `<dt>Cc</dt><dd>${esc(list(d.cc))}</dd>` : ''}</dl>
    <label class="f" for="dS">Subject</label><input type="text" id="dS" value="${esc(d.subject)}" ${done ? 'readonly' : ''}>
    <label class="f" for="dB">Message</label><textarea id="dB" rows="12" style="min-height:240px" ${done ? 'readonly' : ''}>${esc(d.body)}</textarea>
    ${done ? '<div class="btns" style="margin-top:12px"><button class="btn wide" data-close>Close</button></div>'
      : `<div class="btns" style="margin-top:12px"><button class="btn danger" id="dDel">${icon('trash', 18)} Discard</button><button class="btn" id="dSave">Save</button><button class="btn primary" id="dSend" data-needs-pc>${icon('send', 18)} Send</button></div>`}`,
  (sh, close) => {
    if (done) return;
    const edit = () => ({ subject: $('#dS', sh).value, body: $('#dB', sh).value });
    const save = () => change('PATCH', `/api/drafts/${d.id}`, edit(), async () => { const c = await DB.get(`/api/drafts/${d.id}`); await DB.put(`/api/drafts/${d.id}`, { ...(c || d), ...edit() }); });
    $('#dSave', sh).onclick = () => busy($('#dSave', sh), async () => { toast(await save() ? 'Draft saved' : 'Draft saved on this phone: sent to your computer when it is back'); close(); });
    $('#dDel', sh).onclick = () => busy($('#dDel', sh), async () => { toast(await change('DELETE', `/api/drafts/${d.id}`) ? 'Draft discarded' : 'Discarded on this phone: done on your computer when it is back'); close(); });
    $('#dSend', sh).onclick = async () => {
      const to = list(d.to);
      // Email goes only when you press Send and confirm.
      const ok = await new Promise(res => {
        const b = $('.btns', sh);
        b.innerHTML = `<p class="lead" style="width:100%;margin:0">Send it now${to ? ` to ${esc(to)}` : ''}? It goes from your mailbox.</p><button class="btn" id="dNo">Not yet</button><button class="btn primary" id="dYes">${icon('send', 18)} Send now</button>`;
        $('#dNo', sh).onclick = () => { res(false); close(); openDraft(d.id); };
        $('#dYes', sh).onclick = () => res(true);
      });
      if (!ok) return;
      busy($('#dYes', sh), async () => { await api('PATCH', `/api/drafts/${d.id}`, edit()); await api('POST', `/api/drafts/${d.id}/send`, { confirm: true }); toast('Sent'); close(); S.tasksAt = 0; route({ quiet: true }); }, 'Sending');
    };
  });
}

// ---------- threads and emails ----------
async function threadPage(id) {
  const th = await api('GET', `/api/threads/${enc(id)}`);
  const msgs = [...(th.messages || [])].sort((a, b) => String(b.received_at).localeCompare(String(a.received_at)));
  return `<button class="back" data-back="#/home">${icon('back', 18)} Back</button>
    <h1 style="font-size:20px;margin:4px 0 8px">${esc(th.subject || '(no subject)')}</h1>
    ${th.summary ? `<div class="block"><h4>Summary</h4><p>${esc(th.summary)}</p></div>` : ''}
    ${(th.tasks || []).length ? `<div class="sec">${icon('tasks', 15)} Tasks <em>${th.tasks.length}</em></div>${cards(th.tasks, false)}` : ''}
    <div class="sec">${icon('mail', 15)} Emails <em>${msgs.length}</em></div>${msgs.map(mailLine).join('')}`;
}
async function emailPage(id) {
  const m = await api('GET', `/api/emails/${enc(id)}`);
  const people = a => (a || []).map(x => x.email ? `<a href="#/person/${enc(x.email)}">${esc(x.name || x.email)}</a>` : esc(x.name || '')).join(', ');
  return `<button class="back" data-back="#/home">${icon('back', 18)} Back</button>
    <h1 style="font-size:20px;margin:4px 0 10px">${esc(m.subject || '(no subject)')}</h1>
    <div class="card pad">
      <dl class="facts" style="font-size:14px"><dt>From</dt><dd>${m.from_email ? `<a href="#/person/${enc(m.from_email)}">${esc(m.from_name || m.from_email)}</a>` : esc(m.from_name)}</dd>
        <dt>To</dt><dd>${people(m.to)}</dd>${(m.cc || []).length ? `<dt>Cc</dt><dd>${people(m.cc)}</dd>` : ''}
        <dt>Date</dt><dd>${esc(fullDate(m.received_at))}</dd>${(m.attachments || []).length ? `<dt>Files</dt><dd>${esc(m.attachments.join(', '))}</dd>` : ''}</dl>
    </div>
    <div class="card pad" style="margin-top:10px"><div class="email-body">${esc(String(m.body || '').replace(/\r/g, '').replace(/\n{3,}/g, '\n\n').trim())}</div></div>
    <p style="margin-top:12px"><a class="btn wide" href="#/thread/${enc(m.conversation_id)}">${icon('thread', 18)} The whole thread</a></p>`;
}

// ---------- People ----------
let PQ = '';
async function peoplePage() {
  S.people ||= await api('GET', '/api/people');
  const q = PQ.trim().toLowerCase();
  const list = S.people.filter(p => !q || [p.name, p.email, p.title, p.organization, p.unit].some(v => String(v || '').toLowerCase().includes(q)))
    .sort((a, b) => String(b.last_seen || '').localeCompare(String(a.last_seen || ''))).slice(0, 200);
  return `<div class="h"><h1>People</h1><span class="sp"></span><span class="muted small">${S.people.length}</span></div>
    <div class="search">${icon('search', 18)}<input type="search" id="pq" placeholder="Search people" value="${esc(PQ)}" autocomplete="off"></div>
    <div class="list" id="pl">${list.map(p => `<a class="person" href="#/person/${enc(p.email)}">${avatar(p.name, p.email)}<div class="clamp1" style="flex:1"><b class="clamp1">${esc(p.name || p.email)}</b><small class="clamp1">${esc([p.title, p.organization || p.unit].filter(Boolean).join(', ') || p.email)}</small></div>
      <div class="n">${p.owns_open ? `<b style="color:var(--ink)">${p.owns_open}</b> open<br>` : ''}${esc(when(p.last_seen))}</div></a>`).join('') || '<div class="card empty">Nobody matches.</div>'}</div>`;
}
function wirePeople(el) {
  const qi = $('#pq', el); let t;
  qi.oninput = () => { clearTimeout(t); t = setTimeout(async () => { PQ = qi.value; const tmp = document.createElement('div'); tmp.innerHTML = await peoplePage(); $('#pl', el).replaceWith($('#pl', tmp)); }, 150); };
}
async function personPage(id) {
  const p = await api('GET', `/api/people/${enc(id)}`);
  const open = (p.tasks || []).filter(t => t.status === 'open'), closed = (p.tasks || []).filter(t => t.status !== 'open' && t.status !== 'dismissed');
  return `<button class="back" data-back="#/home">${icon('back', 18)} Back</button>
    <div class="prof-h">${avatar(p.name, p.email, 'lg')}<div style="min-width:0"><h1>${esc(p.name || p.email)}</h1>
      <div class="muted">${esc([p.title, p.unit, p.organization].filter(Boolean).join(', '))}</div>
      <a class="small" href="mailto:${esc(p.email)}">${esc(p.email)}</a></div></div>
    ${p.bio ? `<div class="block"><h4>Profile</h4><p>${esc(p.bio)}</p></div>` : ''}
    ${p.tasking ? `<div class="block"><h4>What they ask and do</h4><p>${esc(p.tasking)}</p></div>` : ''}
    ${p.relationship ? `<div class="block"><h4>How you work together</h4><p>${esc(p.relationship)}</p></div>` : ''}
    ${open.length ? `<div class="sec">${icon('tasks', 15)} Open tasks <em>${open.length}</em></div>${cards(open, false)}` : ''}
    ${closed.length ? `<div class="sec">Closed <em>${closed.length}</em></div>${cards(closed.slice(0, 10), false)}` : ''}
    ${(p.threads || []).length ? `<div class="sec">${icon('thread', 15)} Threads <em>${p.threads.length}</em></div>${p.threads.slice(0, 15).map(th => `<a class="mail" href="#/thread/${enc(th.id)}"><div class="mh"><b class="clamp1">${esc(th.subject || '(no subject)')}</b><small>${esc(when(th.last_at))}</small></div><p>${plural(th.messages || 0, 'email')}</p></a>`).join('')}` : ''}`;
}

// ---------- Ask Mandata ----------
let asking = null;
function md(text, refs) {
  const idx = new Map((refs || []).filter(r => r.cited !== false).map((r, i) => [r.tag, [r, i + 1]]));
  const inline = s => esc(s).replace(/==(.+?)==/g, '<b>$1</b>').replace(/\*\*(.+?)\*\*/g, '<b>$1</b>').replace(/(^|[^*])\*([^*\s][^*]*?)\*(?!\*)/g, '$1<i>$2</i>').replace(/`([^`]+)`/g, '<code>$1</code>')
    .replace(/\[([TPHEU]\d+)\]/g, (m, tg) => { const x = idx.get(tg); if (!x) return ''; const [r, n] = x; return r.gone ? `<span class="cite">${n}</span>` : `<a class="cite" href="${refHref(r)}">${n}</a>`; });
  const out = []; let list = null;
  const close = () => { if (list) { out.push(`</${list}>`); list = null; } };
  for (const raw of String(text || '').replace(/\r/g, '').split('\n')) {
    const line = raw.trimEnd();
    const b = line.match(/^\s*[-*•]\s+(.*)$/), o = line.match(/^\s*\d+[.)]\s+(.*)$/), h = line.match(/^\s*#{1,4}\s+(.*)$/);
    if (b || o) { const kind = b ? 'ul' : 'ol'; if (list !== kind) { close(); out.push(`<${kind}>`); list = kind; } out.push(`<li>${inline((b || o)[1])}</li>`); continue; }
    close();
    if (!line.trim()) continue;
    out.push(h ? `<h4>${inline(h[1])}</h4>` : `<p>${inline(line)}</p>`);
  }
  close();
  return out.join('');
}
const refHref = r => r.type === 'task' ? `#/task/${enc(r.id)}` : r.type === 'person' ? `#/person/${enc(r.id)}` : r.type === 'thread' ? `#/thread/${enc(r.id)}` : r.type === 'email' ? `#/email/${enc(r.id)}` : '#';
const refIcon = { task: 'tasks', person: 'user', thread: 'thread', email: 'mail' };
const answerHtml = m => {
  const cited = (m.refs || []).filter(r => r.cited !== false && !r.gone);
  return `<div class="msg ai">${m.content ? md(m.content, m.refs || []) : '<p class="muted">No answer.</p>'}
    ${cited.length ? `<div class="refs">${cited.map((r, i) => `<a href="${refHref(r)}"><b>${i + 1}</b>${icon(refIcon[r.type] || 'spark', 14)}<span class="clamp1">${esc(r.label || r.tag)}</span></a>`).join('')}</div>` : ''}</div>`;
};
async function askPage(id) {
  if (id) {
    const c = await api('GET', `/api/ask/${enc(id)}`);
    return `<button class="back" data-back="#/ask">${icon('back', 18)} Conversations</button>
      <h1 style="font-size:19px;margin:2px 0 12px" class="clamp2">${esc(c.title || 'Conversation')}</h1>
      <div class="chat" id="chat" data-conv="${c.id}">${(c.list || []).map(m => m.role === 'user' ? `<div class="msg me">${esc(m.content)}</div>` : answerHtml(m)).join('')}</div>${composer()}`;
  }
  const [convs, st] = await Promise.all([api('GET', '/api/ask'), api('GET', '/api/ask/starters')]);
  return `<div class="h"><h1>Ask Mandata</h1></div>
    <p class="muted" style="margin:-4px 0 12px">Ask about your tasks, deadlines, threads and people. The AI on your computer answers from what Mandata holds, and cites it.</p>
    <div class="chat" id="chat" data-conv="" style="padding-bottom:0"></div>
    <div class="starters" id="starters">${(st.starters || []).slice(0, 5).map(s => `<button data-q="${esc(s.text)}">${icon('chat', 18)}<span>${esc(s.text)}</span></button>`).join('')}</div>
    ${convs.length ? `<div id="earlier"><div class="sec">Earlier <em>${convs.length}</em></div><div class="convs">${convs.slice(0, 30).map(c => `<a class="conv" href="#/ask/${c.id}">${icon(c.pinned ? 'pin' : 'chat', 18)}<span class="clamp1" style="flex:1">${esc(c.title || 'Conversation')}</span><small class="muted">${esc(when(c.updated_at))}</small></a>`).join('')}</div></div>` : ''}
    <div style="height:80px"></div>${composer()}`;
}
const composer = () => `<form class="composer" id="ask"><textarea id="askQ" rows="1" placeholder="Ask Mandata" enterkeyhint="send"></textarea><button class="btn primary" id="askGo" aria-label="Send" data-needs-pc>${icon('up', 20)}</button></form>`;
function wireAsk(el) {
  const form = $('#ask', el), ta = $('#askQ', el), chat = $('#chat', el);
  ta.oninput = () => { ta.style.height = '44px'; ta.style.height = Math.min(ta.scrollHeight, 140) + 'px'; };
  ta.onkeydown = e => { if (e.key === 'Enter' && !e.shiftKey && !e.isComposing) { e.preventDefault(); form.requestSubmit(); } };
  $('#starters', el)?.addEventListener('click', e => { const b = e.target.closest('[data-q]'); if (b) { ta.value = b.dataset.q; form.requestSubmit(); } });
  form.onsubmit = async e => {
    e.preventDefault();
    if (asking) { asking.abort(); return; }
    if (offline) return toast(NEEDS_PC, true);
    const question = ta.value.trim(); if (!question) return;
    ta.value = ''; ta.oninput();
    $('#starters', el)?.remove(); $('#earlier', el)?.remove();
    chat.style.paddingBottom = '90px';
    chat.insertAdjacentHTML('beforeend', `<div class="msg me">${esc(question)}</div><div class="msg ai live"><div class="ph"><span class="spinner" style="width:14px;height:14px;border-width:2px"></span><span>Asking your computer</span></div><div class="txt"></div></div>`);
    const live = $('.live', chat), go = $('#askGo', el);
    live.scrollIntoView({ block: 'end', behavior: 'smooth' });
    go.innerHTML = icon('stop', 20); go.setAttribute('aria-label', 'Stop');
    const ctrl = asking = new AbortController();
    let text = '', failed = '', conv = Number(chat.dataset.conv) || null, raf = 0;
    const paint = () => { raf = 0; $('.txt', live).innerHTML = md(text); live.scrollIntoView({ block: 'end' }); };
    try {
      const r = await fetch('/api/ask/answer', { method: 'POST', credentials: 'same-origin', headers: { 'content-type': 'application/json' }, signal: ctrl.signal,
        body: JSON.stringify({ conversation_id: conv, question }) });
      if (!r.ok) { const d = await r.json().catch(() => ({})); throw new Error(d.error || `Mandata answered ${r.status}`); }
      const reader = r.body.getReader(), dec = new TextDecoder(); let buf = '';
      for (;;) {
        const { value, done } = await reader.read(); if (done) break;
        buf += dec.decode(value, { stream: true });
        let nl; while ((nl = buf.indexOf('\n')) >= 0) {
          const line = buf.slice(0, nl); buf = buf.slice(nl + 1); if (!line.trim()) continue;
          let ev; try { ev = JSON.parse(line); } catch { continue; }
          if (ev.t === 'start') { conv = ev.conversation?.id || conv; chat.dataset.conv = conv || ''; }
          else if (ev.t === 'phase') $('.ph span:last-child', live).textContent = ev.text;
          else if (ev.t === 'token') { text += ev.text; if (!raf) raf = requestAnimationFrame(paint); }
          else if (ev.t === 'done') { live.outerHTML = answerHtml(ev.message); }
          else if (ev.t === 'error') failed = ev.error;
        }
      }
    } catch (err) { if (err.name !== 'AbortError') failed = err instanceof TypeError ? 'Cannot reach Mandata on your computer' : err.message; }
    asking = null;
    go.innerHTML = icon('up', 20); go.setAttribute('aria-label', 'Send');
    if (live.isConnected) live.outerHTML = `<div class="msg ai">${text ? md(text) : ''}${failed ? `<p style="color:var(--red)">${esc(failed)}</p>` : !text ? '<p class="muted">Stopped.</p>' : ''}</div>`;
    // The conversation now has its own address, without drawing the page again.
    if (conv && location.hash !== `#/ask/${conv}`) { history.replaceState(null, '', `#/ask/${conv}`); S.view = 'ask'; }
  };
}

// ---------- More ----------
async function morePage() {
  const st = S.status || {};
  const install = IN_APP ? '' : IOS && !STANDALONE ? `<div class="block"><h4>Install on this iPhone</h4><p>In Safari, tap Share ${icon('share', 16)} then <b>Add to Home Screen</b>. Mandata then opens full screen from its icon.</p></div>`
    : ANDROID ? `<div class="block"><h4>The Android app</h4><p style="margin-bottom:10px">Mandata as an app of its own: full screen, from its icon, and it remembers your computer.</p><a class="btn wide" href="${APK}">${icon('download', 18)} Get the Android app</a></div>` : '';
  return `<div class="h"><h1>More</h1></div>
    <div class="block"><h4>Your computer</h4><dl class="facts" style="font-size:14px"><dt>Address</dt><dd>${esc(location.host)}</dd><dt>Mandata</dt><dd>Version ${esc(st.version || '')}</dd>
      <dt>Mail</dt><dd>${st.outlook?.connected ? 'Connected' : 'Not connected'}</dd><dt>AI</dt><dd>${st.ai?.online ? esc(st.ai.model) : 'Offline'}</dd></dl></div>
    <div class="block"><h4>This phone</h4><p>${esc(S.me?.name || 'Paired')}, paired ${esc(when(S.me?.pairedAt))}.</p>
      ${window.MandataApp ? `<button class="btn wide" style="margin-top:10px" id="scanQr">${icon('phone', 18)} Pair with another computer</button>` : ''}
      <p class="muted small" style="margin-top:6px">Your mail and tasks stay on your computer. This phone shows them while it is on the same network.</p></div>
    ${install}
    <div class="block" id="upd"><h4>Updates</h4>${updBlock(S.update)}</div>
    <div class="block"><h4>Not here</h4><p class="muted">Settings, the AI and backups are in Mandata on your computer.</p></div>
    <div class="btns" style="margin-top:14px"><a class="btn" href="${SITE}" target="_blank" rel="noopener">${icon('phone', 18)} Help</a><button class="btn danger" id="unpair" data-needs-pc>${icon('out', 18)} Sign out this phone</button></div>`;
}
/**
 * Updates of Mandata on the computer, checked and installed from here when you want, without waiting for the check it
 * makes on its own. Installing restarts Mandata on the computer; this phone reconnects once it is back.
 */
function updBlock(u) {
  if (!u) return '<p class="muted">Looking at updates…</p>';
  const v = s => String(s || '').replace(/^v/, '');
  const newer = u.latest && ['available', 'downloading', 'ready'].includes(u.phase);
  const line = u.phase === 'checking' ? 'Checking for updates…'
    : u.phase === 'downloading' ? `Downloading Mandata ${esc(v(u.latest?.version))}: ${Math.round(u.progress?.percent || 0)}%`
    : u.phase === 'installing' ? 'Installing: Mandata restarts on your computer in a few seconds.'
    : newer ? `Mandata ${esc(v(u.latest.version))} is available (you have ${esc(v(u.current))}).`
    : u.phase === 'error' ? esc(u.error || 'Could not check for updates.')
    : `Mandata ${esc(v(u.current))} is up to date.${u.lastCheck ? ` Checked ${esc(when(u.lastCheck))}.` : ''}`;
  const btn = newer && u.can?.install ? `<button class="btn primary wide" data-upd="install" data-needs-pc>${icon('download', 18)} Install now</button>`
    : newer ? `<p class="muted small">${esc(u.can?.reason || 'Install it from Mandata on your computer.')}</p>`
    : ['checking', 'downloading', 'installing'].includes(u.phase) ? ''
    : `<button class="btn wide" data-upd="check" data-needs-pc>${icon('refresh', 18)} Check for updates</button>`;
  return `<p style="margin-bottom:10px">${line}</p>${btn}`;
}
async function loadUpdate(el) {
  try { S.update = await api('GET', '/api/update'); }
  catch { const box = $('#upd', el); if (box && !S.update) box.innerHTML = '<h4>Updates</h4><p class="muted">Updates are shown while this phone reaches your computer.</p>'; return; }
  const box = $('#upd', el); if (box) box.innerHTML = `<h4>Updates</h4>${updBlock(S.update)}`;
  // While it downloads or installs, followed every two seconds; the computer restarting ends it.
  clearTimeout(S.updTimer);
  if (['checking', 'downloading', 'installing'].includes(S.update.phase) && document.contains(el)) S.updTimer = setTimeout(() => loadUpdate(el), 2000);
}
function wireMore(el) {
  loadUpdate(el);
  $('#upd', el).addEventListener('click', async e => {
    const b = e.target.closest('[data-upd]'); if (!b) return;
    if (b.dataset.upd === 'install' && !await confirmSheet(`Install Mandata ${String(S.update?.latest?.version || '').replace(/^v/, '')}?`,
      'It is downloaded and checked on your computer, then Mandata restarts there. Your data is not affected.', 'Install now')) return;
    b.disabled = true;
    const req = b.dataset.upd === 'check' ? api('POST', '/api/update/check') : api('POST', '/api/update/download', { install: true, background: true });
    setTimeout(() => loadUpdate(el), 400);
    try { const r = await req; if (r?.phase) { S.update = r; loadUpdate(el); } if (b.dataset.upd === 'check' && r?.phase === 'current') toast('Mandata is up to date'); }
    catch (err) { toast(err.message, true); loadUpdate(el); }
  });
  $('#scanQr', el)?.addEventListener('click', () => window.MandataApp.scan());
  $('#unpair', el).onclick = async () => {
    if (!await confirmSheet('Sign out this phone?', 'To use Mandata here again, pair it again from Settings > Phone on your computer.', 'Sign out', 'danger')) return;
    try { await api('DELETE', '/api/phone/me'); } catch {}
    location.hash = ''; location.reload();
  };
}

// ---------- the router ----------
const ROUTES = {
  home: [() => home()],
  tasks: [q => taskList(QUICK[q] ? q : ''), (el, q) => wireTasks(el, QUICK[q] ? q : '')],
  task: [id => taskPage(id), el => wireTask(el)],
  thread: [id => threadPage(decodeURIComponent(id))],
  email: [id => emailPage(decodeURIComponent(id))],
  people: [() => peoplePage(), el => wirePeople(el)],
  person: [id => personPage(decodeURIComponent(id))],
  ask: [id => askPage(id), el => wireAsk(el)],
  more: [() => morePage(), el => wireMore(el)],
};
const TAB = { home: 'home', tasks: 'tasks', task: 'tasks', thread: 'tasks', email: 'tasks', people: 'people', person: 'people', ask: 'ask', more: 'more' };
let drawing = 0;
async function render(make, wire, { quiet = false, keepScroll = false } = {}) {
  const n = ++drawing, el = view(), y = scrollY;
  if (!quiet) { el.innerHTML = loading(); scrollTo(0, 0); }
  try {
    const html = await make();
    if (n !== drawing) return;
    el.innerHTML = html;
    wire?.(el);
    if (quiet || keepScroll) scrollTo(0, y);
  } catch (e) { if (n === drawing && e.message !== 'This phone is not paired') el.innerHTML = errorHtml(e); }
}
function route({ quiet = false } = {}) {
  if (!S.me) return;
  const [, name = 'home', arg = ''] = (location.hash || '#/home').split('/');
  const r = ROUTES[name] || ROUTES.home;
  const same = S.view === name && S.arg === arg;
  S.view = ROUTES[name] ? name : 'home'; S.arg = arg;
  for (const a of $$('#tabs a')) a.classList.toggle('on', a.dataset.tab === TAB[S.view]);
  $('#banner').hidden = S.view !== 'home';
  render(() => r[0](arg), r[1] ? el => r[1](el, arg) : null, { quiet: quiet && same });
}
const NEEDS_PC = 'This needs Mandata on your computer: it works again once the phone reaches it.';
document.addEventListener('click', e => {
  if (!offline || !e.target.closest('[data-needs-pc]')) return;
  e.preventDefault(); e.stopPropagation(); toast(NEEDS_PC, true);
}, true);
let navs = 0;
window.addEventListener('hashchange', () => { navs++; if (S.me) route(); else if (/pair=/.test(location.hash)) showPair(); });
// Back goes where you came from, or up a level when the page was opened directly.
document.addEventListener('click', e => {
  const b = e.target.closest('[data-back]');
  if (b) { if (navs > 0) { navs -= 2; history.back(); } else location.hash = b.dataset.back; }
  if (e.target.closest('[data-reload]')) location.reload();
});

// ---------- pairing ----------
function showPair(err = '') {
  S.me = null; events?.close();
  document.body.classList.add('paired-out');
  const code = (location.hash.match(/pair=([A-Za-z0-9]+)/) || [])[1] || '';
  view().innerHTML = `<div class="pair"><img src="icon-192.png" width="84" height="84" alt="">
    <h1>Mandata on your phone</h1>
    <p>Pair this phone with Mandata on your computer once. Your mail and tasks stay on the computer.</p>
    ${window.MandataApp ? `<button class="btn primary wide" type="button" id="scanQr">${icon('phone', 18)} Scan QR code</button><p class="small" style="margin:8px 0 14px">Point the phone at the QR code in Mandata, Settings &gt; Phone. Or type the code:</p>` : ''}
    
    <form class="card pad" id="pairForm">
      <ol class="steps"><li>On your computer, open Mandata, <b>Settings &gt; Phone</b>, and switch phone access on.</li><li>Scan its QR code with this phone's camera, or type the code it shows:</li></ol>
      <input type="text" id="code" class="code" maxlength="9" autocomplete="one-time-code" autocapitalize="characters" spellcheck="false" placeholder="ABCD2345" value="${esc(code)}" aria-label="Pairing code">
      ${err ? `<div class="err" style="margin-top:10px">${esc(err)}</div>` : ''}
      <button class="btn primary wide" style="margin-top:12px" id="pairGo">Pair this phone</button>
    </form></div>`;
  $('#scanQr')?.addEventListener('click', () => window.MandataApp.scan());
  $('#pairForm').onsubmit = async e => {
    e.preventDefault();
    const b = $('#pairGo');
    await busy(b, async () => {
      const r = await fetch('/api/pair', { method: 'POST', credentials: 'same-origin', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ code: $('#code').value, app: IN_APP }) }).catch(() => null);
      const d = r ? await r.json().catch(() => ({})) : { error: 'Cannot reach Mandata on your computer' };
      if (!r?.ok) return showPair(d.error || 'Could not pair');
      history.replaceState(null, '', '#/home');
      store.set('banner', 0);
      toast(`Paired: ${d.name}`);
      boot();
    }, 'Pairing');
  };
  // A code from the QR code pairs at once, here in the browser: with the app installed, the QR code opened the app
  // instead (an App Link). The app can be installed from Home or More once paired.
  if (code && !err) $('#pairForm').requestSubmit();
}

// ---------- install hint ----------
function banner() {
  const box = $('#banner');
  if (IN_APP || STANDALONE || store.get('banner', 0) > Date.now()) return box.innerHTML = '';
  const html = IOS ? `<b>Install Mandata</b><br>Tap Share ${icon('share', 16)} below, then <b>Add to Home Screen</b>.`
    : ANDROID ? `<b>Install the Mandata app</b><br>Then the QR code on your computer opens it straight away.<br><a class="btn primary sm" style="margin-top:8px" href="${APK}">${icon('download', 16)} Install the app</a>` : '';
  box.innerHTML = html ? `<div class="ban">${icon('phone', 20)}<div>${html}</div><button class="x" aria-label="Hide">×</button></div>` : '';
  $('.x', box)?.addEventListener('click', () => { store.set('banner', Date.now() + 30 * 864e5); box.innerHTML = ''; });
}

// ---------- start ----------
for (const i of $$('[data-ic]')) i.outerHTML = icon(i.dataset.ic, 23);
async function boot() {
  view().innerHTML = loading('Connecting to your computer');
  // A short first look: on the Wi-Fi the computer answers at once, and without it the phone's copy opens in 3 seconds.
  try { S.me = await api('GET', '/api/phone/me', undefined, 3000); }
  catch (e) { if (e instanceof Offline) { drawStatus(); view().innerHTML = offlineHtml(); } return; }
  document.body.classList.remove('paired-out');
  if (/pair=/.test(location.hash)) history.replaceState(null, '', '#/home');
  try { S.meta = await api('GET', '/api/meta'); } catch {}
  await loadStatus();
  checkBuild();
  await countWaiting();
  if (!offline) { listen(); flush().then(() => setTimeout(prefetch, 2000)); }
  banner(); route();
}
boot();
