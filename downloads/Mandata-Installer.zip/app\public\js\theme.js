// Light and dark mode. The dark palette's core is the :root[data-theme="dark"] block at the end of styles.css; the many colours
// written straight into rules are turned dark here, from the loaded stylesheet itself, so the dark mode follows every change
// to styles.css without a second copy to keep in step. Light tints become dark tints, dark text becomes light text, and strong
// colours (buttons, chips, the navy bar) stay as they are. Screen only: printed and exported pages keep the light look.
import { pref, setPref } from './ui.js';

const ROOT = document.documentElement;
// Every declaration that can carry a colour, plus the rest of the shorthands they belong to, so the cascade between rules stays
// the same in dark (each copied rule gains the same extra specificity).
const TOUCH = /^(color|fill|stroke|box-shadow|caret-color|accent-color|text-decoration(-color)?|column-rule(-color)?|background(-.+)?|border(-.+)?|outline(-.+)?)$/;
const role = p => p === 'color' || p === 'caret-color' ? 'text' : /^(background|fill|box-shadow)/.test(p) ? 'bg' : 'line';

// --- colour maths ---
const NAMED = { white: [255, 255, 255, 1], black: [0, 0, 0, 1] };
const COLOR = /#[0-9a-f]{3,8}\b|rgba?\([^)]*\)|\b(white|black)\b/gi;
function parse(s) {
  s = s.toLowerCase();
  if (NAMED[s]) return NAMED[s];
  if (s[0] === '#') {
    let h = s.slice(1);
    if (h.length <= 4) h = [...h].map(c => c + c).join('');
    if (h.length !== 6 && h.length !== 8) return null;
    return [0, 2, 4].map(i => parseInt(h.slice(i, i + 2), 16)).concat(h.length === 8 ? parseInt(h.slice(6), 16) / 255 : 1);
  }
  const n = s.match(/[\d.]+%?/g);
  if (!n || n.length < 3) return null;
  const a = n[3] == null ? 1 : n[3].endsWith('%') ? parseFloat(n[3]) / 100 : +n[3];
  return [+n[0], +n[1], +n[2], a];
}
function toHsl([r, g, b]) {
  r /= 255; g /= 255; b /= 255;
  const mx = Math.max(r, g, b), mn = Math.min(r, g, b), l = (mx + mn) / 2, d = mx - mn;
  if (!d) return [0, 0, l];
  const s = d / (1 - Math.abs(2 * l - 1));
  const h = mx === r ? ((g - b) / d) % 6 : mx === g ? (b - r) / d + 2 : (r - g) / d + 4;
  return [(h * 60 + 360) % 360, s, l];
}
function fromHsl(h, s, l, a) {
  const c = (1 - Math.abs(2 * l - 1)) * s, x = c * (1 - Math.abs((h / 60) % 2 - 1)), m = l - c / 2;
  const [r, g, b] = h < 60 ? [c, x, 0] : h < 120 ? [x, c, 0] : h < 180 ? [0, c, x] : h < 240 ? [0, x, c] : h < 300 ? [x, 0, c] : [c, 0, x];
  const v = [r, g, b].map(t => Math.round((t + m) * 255));
  return a < 1 ? `rgba(${v.join(',')},${+a.toFixed(3)})` : `rgb(${v.join(',')})`;
}
// One colour, by what it paints: a surface (bg), a border or rule (line) or text.
function darken(str, kind) {
  const c = parse(str); if (!c) return str;
  let [h, s, l] = toHsl(c);
  if (kind === 'text') return l >= 0.6 ? str : fromHsl(h, Math.min(s, 0.75), Math.min(0.92, 1 - l * 0.75), c[3]);
  if (l <= 0.55) return str;                       // strong colours keep their look
  if (s < 0.08) { h = 222; s = 0.45; }             // greys and white take the palette's cool tint
  return kind === 'bg' ? fromHsl(h, s * 0.45, 0.12 + (1 - l) * 0.75, c[3]) : fromHsl(h, s * 0.4, 0.2 + (1 - l) * 0.8, c[3]);
}
const mapValue = (v, kind) => v.replace(COLOR, m => darken(m, kind));

// --- the copied rules ---
// Split on a separator at the top level only (not inside brackets or quotes).
function split(s, sep) {
  const out = []; let depth = 0, q = null, cur = '';
  for (const ch of s) {
    if (q) { if (ch === q) q = null; }
    else if (ch === '"' || ch === "'") q = ch;
    else if (ch === '(' || ch === '[') depth++;
    else if (ch === ')' || ch === ']') depth--;
    else if (ch === sep && !depth) { out.push(cur); cur = ''; continue; }
    cur += ch;
  }
  if (cur.trim()) out.push(cur);
  return out;
}
const scope = sel => split(sel, ',').map(x => {
  x = x.trim();
  return /^(html|:root)\b/.test(x) ? x.replace(/^(html|:root)/, '$1[data-theme="dark"]') : ':root[data-theme="dark"] ' + x;
}).join(',');

function convert(rules) {
  let out = '';
  for (const r of rules) {
    if (r instanceof CSSStyleRule) {
      const decl = split(r.style.cssText, ';').map(d => {
        const i = d.indexOf(':'); if (i < 0) return '';
        const p = d.slice(0, i).trim().toLowerCase();
        return TOUCH.test(p) ? `${p}:${mapValue(d.slice(i + 1).trim(), role(p))}` : '';
      }).filter(Boolean);
      if (decl.length) out += `${scope(r.selectorText)}{${decl.join(';')}}\n`;
    } else if (r instanceof CSSMediaRule) {
      if (/\bprint\b/.test(r.conditionText) && !/\bscreen\b/.test(r.conditionText)) continue;
      const inner = convert(r.cssRules); if (inner) out += `@media ${r.conditionText}{${inner}}\n`;
    } else if (r instanceof CSSSupportsRule) {
      const inner = convert(r.cssRules); if (inner) out += `@supports ${r.conditionText}{${inner}}\n`;
    }
  }
  return out;
}

let built = false;
function build() {
  if (built) return; built = true;
  let css = '';
  for (const sh of document.styleSheets) {
    if (!sh.href || new URL(sh.href).origin !== location.origin) continue;   // only our own stylesheet (fonts are cross-origin)
    try { css += convert(sh.cssRules); } catch {}
  }
  const el = document.createElement('style');
  el.id = 'darkRules';
  el.textContent = `@media screen{\n${css}}`;
  document.head.append(el);
}

export const theme = () => ROOT.dataset.theme === 'dark' ? 'dark' : 'light';
function setTheme(t) {
  if (t === 'dark') { build(); ROOT.dataset.theme = 'dark'; } else delete ROOT.dataset.theme;
  setPref('theme', t);
}
export const toggleTheme = () => setTheme(theme() === 'dark' ? 'light' : 'dark');
// index.html sets data-theme before the page paints, so the dark page does not flash white; here the copied rules follow.
export function initTheme() { if (pref('theme', 'light') === 'dark') setTheme('dark'); else delete ROOT.dataset.theme; }
