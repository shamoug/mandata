// Reports: one row per week, the story of everything done in it. Each week has its figures (emails, tasks found by
// kind, tasks closed, follow-ups) and, once generated, a summary of about 100 words written by the local AI. Generate
// writes (or rewrites) the story. Export PDF prints the whole report to a PDF file in Documents\Mandata reports (no print
// dialog) and opens it in the PDF viewer, in a new tab: the report itself is never shown on this page.
import { GET, api, esc, icon, toast, busy, DIR, dateLabel, ago, $, LOCALE, latest, pdfSaved, errorBox } from '../ui.js';
import { S, onView } from '../store.js';

const KINDS = ['to_me', 'among', 'by_me', 'others'];
let root, weeks = [];

export function mount(el, arg) {
  root = el;
  el.innerHTML = `<div class="page rep">
    <div class="fbar"><h2 class="ptitle">${icon('report', 18)} Reports</h2>
      <span class="muted small">The story of each week: what came in, what you delivered, who you worked with. Generate it with the AI, then export it as a PDF.</span>
      <span class="sp"></span><span class="rep-ai" id="rAi"></span></div>
    <section class="rep-card"><div class="rep-tblwrap" id="rTbl"><div class="empty sm"><span class="spin"></span> Counting your weeks</div></div></section></div>`;
  const page = el.firstElementChild;
  page.addEventListener('click', onClick);
  load();
  onView('reports', load);
  onView('status', aiPill);
}

// Only the newest answer is drawn: a reload after Generate and one from a server event never land out of order.
// A first load that fails says so where the table would be, instead of counting the weeks for ever.
const load = latest(() => GET('/api/reports'), r => { weeks = r.weeks; draw(); aiPill(); },
  e => { const box = root && $('#rTbl', root); if (box && !$('table', box)) box.innerHTML = errorBox(e); else toast(e.message, true); });

function aiPill() {
  const ai = S.status?.ai, b = $('#rAi', root); if (!b || !ai) return;
  b.className = 'rep-ai ' + (ai.online && !ai.paused ? 'on' : 'off');
  b.innerHTML = `${icon('spark', 12)}${ai.online && !ai.paused ? `AI ready · ${esc(ai.model)}` : ai.paused ? 'AI paused: reports use the figures only' : 'AI offline: reports use the figures only'}`;
}

const range = w => `${dateLabel(w.from)} to ${dateLabel(w.to)}`;
const num = (n, cls = '') => n ? `<b class="num ${cls}">${n}</b>` : '<span class="subtle num">0</span>';
function summaryCell(w) {
  const r = w.report;
  if (!r) return `<span class="rep-none">${w.current ? 'The week is still running. Generate it any time.' : 'Not written yet'}</span>`;
  return `<div class="rep-sum"><b>${esc(r.headline)}</b><p>${esc(r.summary)}</p>
    <div class="rep-tags">${r.ai ? `<span class="rep-tag ai">${icon('spark', 10)}AI</span>` : '<span class="rep-tag">From the figures</span>'}
      ${r.stale ? '<span class="rep-tag warn" title="Mail or tasks of this week changed since it was written">Changed since: regenerate</span>' : ''}
      <span class="rep-when" title="${esc(new Date(r.generated_at).toLocaleString(LOCALE))}">${esc(ago(r.generated_at))}</span></div></div>`;
}

function draw() {
  const box = $('#rTbl', root); if (!box) return;
  if (!weeks.length) { box.innerHTML = `<div class="empty">${icon('report', 28)}<div>No weeks yet. They appear as Mandata reads your email.</div></div>`; return; }
  // One header row, so every column sorts. A group (Emails, Tasks, New tasks by kind) is named on a ruled line above its
  // columns. Each column is as wide as its name needs, so no name wraps or hides; the summary takes the rest.
  const K = { to_me: 'To me', among: 'Among', by_me: 'By me', others: 'Others' };
  const th = (label, tip, { cls = 'r', group = '', first = false, sort = true } = {}) =>
    `<th class="${cls}${group ? ' gc' : ''}${first ? ' g1' : ''}" title="${esc(tip)}"${sort ? '' : ' data-sort="off"'}><span class="th-g">${first ? esc(group) : '&nbsp;'}</span><span class="th-n">${label}</span></th>`;
  const DONE = ['Done', 'Delegated', 'Handled'];
  const outcomes = (w, keep = () => true) => Object.entries(w.outcomes || {}).filter(([o]) => keep(o)).map(([o, n]) => `${n} ${o.toLowerCase()}`).join(', ');
  box.innerHTML = `<table class="rep-tbl">
    <colgroup><col style="width:150px"><col><col style="width:60px"><col style="width:60px"><col style="width:70px"><col style="width:64px"><col style="width:80px">
      ${KINDS.map(k => `<col style="width:${k === 'others' ? 82 : 76}px">`).join('')}<col style="width:100px"><col style="width:218px"></colgroup>
    <thead><tr>${th('Week', 'The week, Monday to Sunday', { cls: '' })}${th('Summary&nbsp;<span class="subtle">(about 100 words)</span>', 'The story of the week, written by the AI', { cls: '' })}
      ${th('In', 'Emails received that week', { group: 'Emails', first: true })}${th('Out', 'Emails sent that week', { group: 'Emails' })}
      ${th('Found', 'My tasks (to me and by me) found in that week\'s email; tasks between others are not counted', { group: 'Tasks', first: true })}${th('Done', 'My tasks closed as done, delegated or handled that week', { group: 'Tasks' })}
      ${th('Cleared', 'My tasks taken off the list that week without work of yours: archived, duplicates, cancelled', { group: 'Tasks' })}
      ${KINDS.map((k, i) => th(`<i style="background:${DIR[k].color}"></i>${K[k]}`, `${DIR[k].label}: tasks of this kind found that week`, { cls: 'r k', group: 'New tasks by kind', first: !i })).join('')}
      ${th('Follow-ups', 'Follow-up, forward and acknowledgement emails sent from Mandata')}${th('Report', '', { sort: false })}</tr></thead>
    <tbody>${weeks.map(w => `<tr data-week="${esc(w.key)}">
      <td data-sort="${esc(w.key)}"><div class="rep-wkc"><b class="rep-wk">W${w.week}</b><small class="subtle">${w.year}</small>${w.current ? '<span class="rep-now">This week</span>' : ''}</div><div class="rep-range">${esc(range(w))}</div></td>
      <td>${summaryCell(w)}</td>
      <td class="r g1">${num(w.received)}</td><td class="r">${num(w.sent)}</td>
      <td class="r g1">${num(w.opened)}</td>
      <td class="r" title="${w.done} done${w.closed ? `. All closed that week: ${esc(outcomes(w))}` : ''}${w.earlier ? `. ${w.earlier} of the ${w.closed} closed were found in earlier weeks` : ''}">${num(w.done, 'green')}</td>
      <td class="r" title="${w.cleared ? `${w.cleared} cleared, not worked on: ${esc(outcomes(w, o => !DONE.includes(o)))}` : 'Nothing cleared'}">${w.cleared ? `<span class="rep-clr num">${w.cleared}</span>` : num(0)}</td>
      ${KINDS.map((k, i) => `<td class="r${i ? '' : ' g1'}" title="${esc(DIR[k].label)}: ${w.kinds[k]} found, ${w.closedKinds[k]} closed">${num(w.kinds[k])}</td>`).join('')}
      <td class="r">${num(w.followups)}</td>
      <td><div class="rep-acts">
        <button class="btn sm ${w.report ? '' : 'primary'}" data-gen="${esc(w.key)}" data-busy="Writing" title="${w.report ? 'Write this week\'s report again from the latest data' : 'Write the report of this week with the AI'}">${icon('spark', 12)}${w.report ? 'Regenerate' : 'Generate'}</button>
        <button class="btn sm good" data-pdf="${esc(w.key)}" data-busy="Exporting" title="Save the report of this week as a PDF file in Documents, Mandata reports, and open it">${icon('download', 12)}Export PDF</button></div></td></tr>`).join('')}</tbody></table>`;
}

async function onClick(e) {
  const g = e.target.closest('[data-gen]'), p = e.target.closest('[data-pdf]');
  if (g) return busy(g, () => generate(g.dataset.gen));
  if (p) return busy(p, () => exportPdf(p.dataset.pdf, p));
}

async function generate(key) {
  const r = await api('POST', `/api/reports/${key}/generate`);
  if (r.note) toast(`Written from the figures only: ${r.note}`, true); else toast(`Report for week ${r.facts.week.week} written`);
  await load();
}

/** Export is a file, never a print: the server prints the report to a PDF in Documents\Mandata reports and opens it in
 *  the PDF viewer (a new tab). A week never written is written first, by the AI. */
async function exportPdf(key, btn) {
  if (!weeks.find(x => x.key === key)?.report) btn.innerHTML = '<span class="spin"></span> Writing, then exporting';
  const r = await api('POST', `/api/reports/${key}/export`);
  pdfSaved(r);
}
