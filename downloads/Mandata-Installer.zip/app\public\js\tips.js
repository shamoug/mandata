// Tooltips: one floating card for the whole app in place of the window's plain ones.
// Any element with a title (or an SVG shape with a <title>) gets it: the title moves to data-tip the first time the mouse
// reaches it, so the window never shows its own. "Head: rest" reads as a heading and a line, each new line as a row of its
// own, and a shortcut in brackets at the end ("(Alt+Left)") as keys.
// data-tip-html carries a rich tip built with tipAttr() and its parts in ui.js: pills, people and links that can be clicked, since the card
// stays open while the mouse moves onto it. A click inside it goes through the app's one click router like any other.
import { esc, personTip } from './ui.js';

const SHOW = 380, SWITCH = 60, HIDE = 160;   // ms: wait before showing; moving between tipped things once one shows; grace to reach the card
let box, cur = null, showT = 0, hideT = 0, warm = false;

function ensure() {
  if (box) return box;
  box = document.createElement('div');
  box.className = 'tip';
  box.setAttribute('role', 'tooltip');
  box.hidden = true;
  box.addEventListener('mouseenter', () => clearTimeout(hideT));
  box.addEventListener('mouseleave', e => { if (!cur?.contains(e.relatedTarget)) later(); });
  // A click on a pill or link does what it says, then the card goes.
  box.addEventListener('click', e => { if (e.target.closest('a,button,[data-go],[data-person],[data-task],[data-thread],[data-msg],[data-draft]')) setTimeout(hide); });
  document.body.appendChild(box);
  return box;
}

/** The element under the mouse that carries a tip; a title found on the way becomes data-tip. */
function owner(t) {
  for (let e = t; e && e.nodeType === 1 && e !== document.body; e = e.parentElement) {
    if (e.closest?.('.tip')) return null;
    // A title set again since (a label that changes) wins over the tip taken from it before.
    if (e.hasAttribute('title')) {
      const s = e.getAttribute('title');
      e.removeAttribute('title');
      if (!s.trim()) continue;
      e.setAttribute('data-tip', s);
      // Something with no words of its own (an icon button) keeps its name for screen readers.
      if (!e.hasAttribute('aria-label') && !e.textContent.trim()) e.setAttribute('aria-label', s);
      return e;
    }
    if (e.hasAttribute('data-tip') || e.hasAttribute('data-tip-html') || e.hasAttribute('data-tip-name')) return e;
    if (e instanceof SVGElement) {
      const ti = [...e.children].find(c => c.tagName.toLowerCase() === 'title');
      if (ti) { const s = ti.textContent; ti.remove(); if (s.trim()) { e.setAttribute('data-tip', s); return e; } }
    }
  }
  return null;
}

const KEYS = /\s*\(((?:Alt|Ctrl|Shift|Cmd|Enter|Esc)\b[^)]*)\)\s*$/;
const keys = s => s.split(/\s*([+:])\s*/).map(k => k === '+' ? '<i>+</i>' : k === ':' ? '<i>:</i>' : `<kbd>${esc(k)}</kbd>`).join('');
/** Plain text, laid out: a heading, lines, and keys. */
function plain(s) {
  let k = '';
  s = s.replace(KEYS, (_, x) => { k = x; return ''; });
  const lines = s.split('\n').map(x => x.trim()).filter(Boolean);
  let head = '', rest = lines;
  if (lines.length > 1) [head, ...rest] = lines;
  else if (lines.length === 1) {
    const m = lines[0].match(/^([^:“"]{2,42}):\s+(.+)$/s);
    if (m) { head = m[1]; rest = [m[2]]; }
  }
  return (head ? `<div class="tp-h">${esc(head)}</div>` : '')
    + rest.map(x => `<div class="tp-b">${esc(x)}</div>`).join('')
    + (k ? `<div class="tp-keys">${keys(k)}</div>` : '');
}

function place(el) {
  const r = el.getBoundingClientRect(), b = box.getBoundingClientRect(), vw = innerWidth, vh = innerHeight, gap = 9;
  let top = r.top - b.height - gap, up = true;
  if (top < 6) { top = r.bottom + gap; up = false; }
  if (!up && top + b.height > vh - 6) top = Math.max(6, vh - b.height - 6);
  const cx = r.left + r.width / 2;
  const left = Math.min(Math.max(6, cx - b.width / 2), vw - b.width - 6);
  box.style.left = left + 'px'; box.style.top = top + 'px';
  box.classList.toggle('below', !up);
  box.style.setProperty('--ax', Math.min(Math.max(14, cx - left), b.width - 14) + 'px');
}

function show(el) {
  ensure();
  cur = el;
  // A person (an avatar, a name): their card, with links when they can be opened.
  const pl = el.hasAttribute('data-tip-name') && el.closest('[data-person]');
  const rich = el.getAttribute('data-tip-html') || (el.hasAttribute('data-tip-name')
    ? personTip(el.getAttribute('data-tip-name'), pl?.getAttribute('data-person') || el.getAttribute('data-tip-email'), !!pl?.getAttribute('data-person')) : '');
  box.innerHTML = rich || plain(el.getAttribute('data-tip') || '');
  box.classList.toggle('rich', !!rich);
  // Each tip takes the colour of what it explains, when that has one.
  const c = getComputedStyle(el).getPropertyValue('--c').trim();
  box.style.setProperty('--tc', /^#|^rgb|^hsl/.test(c) ? c : '#4263eb');
  box.hidden = false;
  box.classList.remove('in'); void box.offsetWidth;
  place(el);
  box.classList.add('in');
  warm = true;
}
function hide() {
  clearTimeout(showT); clearTimeout(hideT);
  cur = null;
  if (box) { box.hidden = true; box.classList.remove('in'); }
  setTimeout(() => { if (!cur) warm = false; }, 300);
}
const later = () => { clearTimeout(hideT); hideT = setTimeout(hide, HIDE); };

export function initTips() {
  document.addEventListener('mouseover', e => {
    if (box && box.contains(e.target)) return;
    const el = owner(e.target);
    if (el === cur) { clearTimeout(hideT); return; }
    clearTimeout(showT);
    if (!el) { if (cur) later(); return; }
    // Moving from one tipped thing to the next: the card follows straight away.
    showT = setTimeout(() => { if (el.isConnected && el.matches(':hover')) { clearTimeout(hideT); show(el); } }, warm ? SWITCH : SHOW);
  });
  document.addEventListener('mouseout', e => {
    if (!cur) return;
    const to = e.relatedTarget;
    if (to && (cur.contains(to) || box.contains(to))) return;
    if (cur.contains(e.target)) box.classList.contains('rich') ? later() : hide();
  });
  // A click, a key, a scroll or the window losing focus puts it away; so does its element leaving the page.
  document.addEventListener('mousedown', e => { if (!box?.contains(e.target)) hide(); }, true);
  document.addEventListener('keydown', e => { if (e.key === 'Escape' || !box?.contains(e.target)) hide(); }, true);
  document.addEventListener('scroll', e => { if (cur && !box.contains(e.target)) hide(); }, true);
  addEventListener('blur', hide);
  addEventListener('resize', hide);
  new MutationObserver(() => { if (cur && !cur.isConnected) hide(); }).observe(document.body, { childList: true, subtree: true });
}
