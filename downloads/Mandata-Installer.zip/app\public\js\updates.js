// Updates: the button in the status bar, the dialog that says what is new and installs it (with its progress bar), the
// Updates tab in Settings, and "What's new" once an update is in. The work itself is in lib/updater.js.
import { api, esc, $, $$, modal, toast, icon, ago, busy, LOCALE } from './ui.js';
import { S, on, emit } from './store.js';

const STEPS = ['Download', 'Check', 'Prepare', 'Restart'];
let U = null;                 // the latest state from the server
let dlg = null;               // the open update dialog
let askedFor = '', readyTold = '';

const ver = v => String(v || '').replace(/^v/i, '');
const day = iso => iso ? new Date(iso).toLocaleDateString(LOCALE, { day: 'numeric', month: 'long', year: 'numeric' }) : '';
const size = b => b >= 1 << 20 ? (b / (1 << 20)).toFixed(1) + ' MB' : Math.max(1, Math.round(b / 1024)) + ' KB';
const inHours = iso => { const h = (Date.parse(iso) - Date.now()) / 3600e3; return !iso ? '' : h < 1 ? `in ${Math.max(1, Math.round(h * 60))} min` : `in ${Math.round(h)} h`; };

/** Release notes (GitHub Markdown) as safe HTML: headings, lists, bold, italics, code and https links; nothing else. */
export function md(src) {
  const inline = s => s
    .replace(/`([^`]+)`/g, '<code>$1</code>')
    .replace(/\*\*([^*]+)\*\*/g, '<b>$1</b>')
    .replace(/(^|[\s(])[*_]([^*_\s][^*_]*?)[*_](?=[\s).,;:!?]|$)/g, '$1<i>$2</i>')
    .replace(/\[([^\]]+)\]\((https:\/\/[^)\s]+)\)/g, '<a href="$2" target="_blank" rel="noopener">$1</a>');
  const out = []; let list = null, para = [], code = null;
  const flush = () => { if (para.length) out.push(`<p>${inline(para.join(' '))}</p>`); para = []; if (list) { out.push(`</${list}>`); list = null; } };
  for (const raw of esc(src).split('\n')) {
    if (code !== null) { if (/^\s*```/.test(raw)) { out.push(`<pre><code>${code.join('\n')}</code></pre>`); code = null; } else code.push(raw); continue; }
    if (/^\s*```/.test(raw)) { flush(); code = []; continue; }
    const line = raw.trimEnd();
    let m;
    if (!line.trim()) { flush(); continue; }
    if ((m = line.match(/^#{1,6}\s+(.*)$/))) { flush(); out.push(`<h5>${inline(m[1])}</h5>`); continue; }
    if ((m = line.match(/^\s*[-*+]\s+(.*)$/)) || (m = line.match(/^\s*\d+[.)]\s+(.*)$/))) {
      const kind = /^\s*\d/.test(line) ? 'ol' : 'ul';
      if (para.length) { out.push(`<p>${inline(para.join(' '))}</p>`); para = []; }
      if (list !== kind) { if (list) out.push(`</${list}>`); out.push(`<${kind}>`); list = kind; }
      out.push(`<li>${inline(m[1])}</li>`); continue;
    }
    if (list && /^\s{2,}\S/.test(raw)) { out[out.length - 1] = out.at(-1).replace(/<\/li>$/, ' ' + inline(line.trim()) + '</li>'); continue; }
    if (list) { out.push(`</${list}>`); list = null; }
    para.push(line.trim());
  }
  if (code !== null) out.push(`<pre><code>${code.join('\n')}</code></pre>`);
  flush();
  return out.join('');
}
const notesHtml = notes => (notes || []).length
  ? notes.map(n => `<section class="upd-rel"><div class="upd-relh"><b>Version ${esc(ver(n.version))}</b><span class="muted">${esc(day(n.date))}</span></div>
      <div class="upd-md">${md(n.body) || '<p class="muted">No notes for this version.</p>'}</div></section>`).join('')
  : '<p class="muted">No release notes were published.</p>';

// ---------- the panel: in the dialog and in Settings > Updates ----------
const newerOf = u => u.latest && ['available', 'downloading', 'ready', 'installing'].includes(u.phase);
function progressHtml(u) {
  const p = u.progress || { percent: 0, step: 1, label: 'Starting' };
  const ready = u.phase === 'ready', pct = ready ? 100 : p.percent || 0, step = ready ? 4 : p.step || 1;
  const label = ready ? 'Ready to install' : u.phase === 'installing' ? 'Restarting Mandata' : p.label || 'Working';
  const detail = ready ? 'Downloaded and verified. Mandata restarts to finish.'
    : u.phase === 'installing' ? 'The new version is put in place; Mandata opens again in a few seconds.'
    : [p.text, p.rate && p.total && p.done < p.total ? size(p.rate) + '/s' : ''].filter(Boolean).join(' · ');
  return `<div class="upd-prog" role="group" aria-label="Update progress">
    <div class="upd-progh"><span>${esc(label)}</span><span class="upd-pct">${pct}%</span></div>
    <div class="upd-bar ${u.phase === 'installing' ? 'busy' : ''}" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="${pct}"><i style="width:${pct}%"></i></div>
    <div class="upd-progf"><span>${esc(detail)}</span><span>Step ${step} of ${STEPS.length} · ${esc(STEPS[step - 1])}</span></div>
  </div>`;
}

/** The app, its version and where it stands, with the one action that fits. */
function cardHtml(u) {
  const l = u.latest, newer = newerOf(u);
  const [dot, title, sub] = newer ? ['new', `Version ${ver(l.version)} is available`, `Released ${esc(day(l.date))} · <a href="${esc(l.url)}" target="_blank" rel="noopener">View release on GitHub</a>`]
    : u.phase === 'checking' ? ['busy', 'Checking for updates…', 'Contacting GitHub']
    : u.phase === 'error' ? ['bad', 'Could not check for updates', u.lastCheck ? `Last attempt ${esc(ago(u.lastCheck))}` : '']
    : ['ok', 'Mandata is up to date', [u.lastCheck ? `Last checked ${esc(ago(u.lastCheck))}` : '', u.nextCheck ? `next check ${esc(inHours(u.nextCheck))}` : ''].filter(Boolean).join(' · ')];
  const cta = u.phase === 'downloading' ? `<button class="btn" data-u="cancel">Cancel</button>`
    : u.phase === 'ready' ? `<button class="btn primary" data-u="install">Restart to update</button>`
    : u.phase === 'installing' ? ''
    : newer ? `<button class="btn primary" data-u="download" ${u.can.install ? '' : 'disabled'}>Update now</button>`
    : `<button class="btn" data-u="check" data-busy="Checking" ${u.phase === 'checking' ? 'disabled' : ''}>Check for updates</button>`;
  return `<div class="upd-card">
    <div class="upd-top"><img class="upd-logo" src="icon.png" alt="">
      <div class="upd-id"><div class="upd-name">Mandata <span>${esc(ver(u.current))}</span></div>
        <div class="upd-state"><i class="upd-dot ${dot}"></i>${esc(title)}</div>${sub ? `<div class="upd-sub">${sub}</div>` : ''}</div>
      <div class="upd-cta">${cta}</div></div>
    ${alerts(u)}${['downloading', 'ready', 'installing'].includes(u.phase) ? progressHtml(u) : ''}
  </div>`;
}
const alerts = u => (u.error ? `<div class="upd-alert bad">${icon('alert', 14)}<span>${esc(u.error)}</span></div>` : '')
  + (newerOf(u) && !u.can.install ? `<div class="upd-alert">${icon('alert', 14)}<span>${esc(u.can.reason)}</span>${u.can.kind === 'manual' ? `<a class="btn sm" href="${esc(u.page)}" target="_blank" rel="noopener">Open download page</a>` : ''}</div>` : '');

function panelHtml(u, { inSettings = false } = {}) {
  const l = u.latest, newer = newerOf(u);
  const notes = newer ? `<section class="upd-sec"><h4>Release notes</h4><div class="upd-notes">${notesHtml(l.notes)}</div></section>` : '';
  if (!inSettings && newer) return `<div class="upd-ask"><img class="upd-logo lg" src="icon.png" alt="">
      <div><h3>A new version of Mandata is available</h3><p>Mandata ${esc(ver(l.version))} is available. You have version ${esc(ver(u.current))}.${u.phase === 'available' ? ' Would you like to update now?' : ''}</p></div></div>
    ${alerts(u)}${['downloading', 'ready', 'installing'].includes(u.phase) ? progressHtml(u) : ''}${notes}
    <label class="upd-check"><input type="checkbox" data-auto ${u.mode === 'auto' ? 'checked' : ''}><span>Install future updates automatically</span></label>`;
  const opt = (v, t, d) => `<label class="upd-radio"><input type="radio" name="updMode" value="${v}" ${u.mode === v ? 'checked' : ''}><span><b>${t}</b><small>${d}</small></span></label>`;
  return `${cardHtml(u)}
    <section class="upd-sec"><h4>Installation</h4><div class="upd-radios" role="radiogroup" aria-label="How updates are installed">
      ${opt('auto', 'Install updates automatically', 'New versions are downloaded and installed in the background, and used the next time Mandata starts. You are told when one is ready and can restart at once.')}
      ${opt('ask', 'Ask before installing', 'You are notified when a new version is available and choose when to install it.')}
    </div></section>
    ${notes}
    <p class="upd-fine">Mandata checks for updates every ${esc(String(u.checkHours))} hours. Downloads are verified against the release's published SHA-256 checksums before anything is installed. Your data is not affected.</p>`;
}

function footerHtml(u, inSettings = false) {
  if (inSettings) return '';
  const l = u.latest;
  if (u.phase === 'downloading') return `<div class="btnrow"><button class="btn push" data-u="cancel">Cancel</button></div>`;
  if (u.phase === 'installing') return `<div class="btnrow"><span class="muted push"><span class="spin"></span> Restarting Mandata…</span></div>`;
  if (u.phase === 'ready') return `<div class="btnrow"><button class="btn push" data-u="later">Later</button><button class="btn primary" data-u="install">Restart to update</button></div>`;
  if (l && u.phase === 'available') return `<div class="btnrow">${u.skipped === l.version ? '' : '<button class="btn ghost" data-u="skip">Skip this version</button>'}
    <button class="btn push" data-u="later">Remind me later</button><button class="btn primary" data-u="download" ${u.can.install ? '' : 'disabled'}>Update now</button></div>`;
  return `<div class="btnrow"><button class="btn push" data-u="close">Close</button></div>`;
}

/** Buttons and the choice of mode, in either place. */
function wire(root, close) {
  root.addEventListener('click', async e => {
    const b = e.target.closest('[data-u]'); if (!b) return;
    const a = b.dataset.u;
    if (a === 'close') return close?.();
    if (a === 'later') { await api('POST', '/api/update/later').catch(() => {}); return close ? close() : null; }
    if (a === 'skip') { await api('POST', '/api/update/skip').catch(() => {}); toast(`Mandata ${ver(U.latest?.version)} skipped. It stays in Settings > Updates.`); return close ? close() : null; }
    const path = { check: '/api/update/check', download: '/api/update/download', cancel: '/api/update/cancel', install: '/api/update/install' }[a];
    if (!path) return;
    if (a === 'download') { set({ ...U, phase: 'downloading', progress: { percent: 0, step: 1, label: 'Starting the download' } }); }
    await busy(b, async () => {
      // Update now installs it as soon as it is downloaded and checked: Mandata restarts on the new version.
      const r = await api('POST', path, a === 'download' ? { install: true } : undefined);
      if (r?.phase) set(r);
      if (a === 'check' && r?.phase === 'current') toast('Mandata is up to date');
    });
  });
  root.addEventListener('change', async e => {
    const auto = e.target.matches('[data-auto]');
    if (e.target.name !== 'updMode' && !auto) return;
    const mode = auto ? (e.target.checked ? 'auto' : 'ask') : e.target.value;
    try { set(await api('PUT', '/api/update/settings', { mode })); toast(mode === 'auto' ? 'Updates will be installed automatically' : 'Mandata will ask before installing an update'); }
    catch (err) { toast(err.message, true); }
  });
}

/** Drawn again on every change; the bar alone moves while a download runs, so it slides and nothing jumps. */
function paint(el, foot, opts) {
  if (!el?.isConnected || !U) return;
  const bar = $('.upd-bar i', el);
  if (bar && U.phase === 'downloading' && el.dataset.phase === 'downloading' && el.dataset.ver === U.latest?.version) {
    const t = document.createElement('div'); t.innerHTML = progressHtml(U);
    $('.upd-prog', el).replaceWith($('.upd-prog', t));
    if (foot) foot.innerHTML = footerHtml(U); else { const a = $('.upd-acts', el); if (a && !a.innerHTML.includes('data-u="cancel"')) a.innerHTML = footerHtml(U, true); }
    requestAnimationFrame(() => { const i = $('.upd-bar i', el); if (i) { i.style.width = bar.style.width; requestAnimationFrame(() => { i.style.width = (U.progress?.percent || 0) + '%'; }); } });
    return;
  }
  const scroll = $('.upd-notes', el)?.scrollTop;
  el.innerHTML = panelHtml(U, opts) + (foot ? '' : `<div class="upd-acts">${footerHtml(U, true)}</div>`);
  el.dataset.phase = U.phase; el.dataset.ver = U.latest?.version || '';
  if (scroll) { const n = $('.upd-notes', el); if (n) n.scrollTop = scroll; }
  if (foot) foot.innerHTML = footerHtml(U);
  else { const a = $('.upd-acts', el); if (a) a.innerHTML = footerHtml(U, true); }
}

// ---------- the dialog ----------
export function openUpdates() {
  if (dlg) return;
  if (!U) return toast('Update information is still loading');
  const m = modal({ title: 'Software update', size: 'updm', body: '<div class="upd"></div>', footer: '<div class="updfoot"></div>',
    onClose: () => { dlg = null; if (U?.ask) api('POST', '/api/update/later').catch(() => {}); } });
  const el = $('.upd', m.el), foot = $('.updfoot', m.el);
  dlg = { m, paint: () => paint(el, foot) };
  wire(m.el, () => { m.close(true); dlg = null; });
  dlg.paint();
  const off = on('update', () => { if (!m.el.isConnected) return off(); dlg?.paint(); });
}

/** The Updates tab in Settings. */
export function updatesTab(box) {
  if (!box) return;
  if (!box.dataset.wired) { box.dataset.wired = '1'; wire(box); const off = on('update', () => { if (!box.isConnected) return off(); paint(box, null, { inSettings: true }); }); }
  if (!U) { box.innerHTML = '<div class="aim-load"><span class="spin"></span> Reading…</div>'; return; }
  paint(box, null, { inSettings: true });
}

// ---------- the status bar button, the questions, What's new ----------
function renderButton() {
  const b = $('#updBtn'); if (!b || !U) return;
  const l = U.latest, shown = l && (U.phase === 'downloading' || U.phase === 'ready' || U.phase === 'installing' || (U.phase === 'available' && U.skipped !== l.version));
  b.hidden = !shown;
  if (!shown) return;
  const pct = U.progress?.percent || 0;
  const [cls, html, tip] = U.phase === 'downloading' ? ['busy', `${icon('download', 14)}<em>${pct}%</em>`, `Downloading Mandata ${ver(l.version)}: ${pct}%`]
    : U.phase === 'installing' ? ['busy', '<span class="spin"></span>', 'Restarting to install the update']
    : U.phase === 'ready' ? ['ready', `${icon('power', 14)}<em>Restart</em>`, `Mandata ${ver(l.version)} is ready: restart to install it`]
    : ['new', `${icon('download', 14)}<i class="upd-dot"></i>`, `Mandata ${ver(l.version)} is available: see what is new`];
  b.className = 'updbtn ' + cls; b.title = tip; b.setAttribute('aria-label', tip);
  if (b.dataset.h !== html) { b.dataset.h = html; b.innerHTML = html; }
}

function whatsNew(j) {
  const m = modal({ title: 'Software update', size: 'updm', onClose: () => api('POST', '/api/update/seen').catch(() => {}), body: `<div class="upd">
    <div class="upd-ask"><img class="upd-logo lg" src="icon.png" alt=""><div><h3>Mandata was updated to version ${esc(ver(j.version))}</h3><p>The update was installed successfully. Your data was not affected.</p></div></div>
    <section class="upd-sec"><h4>What's new</h4><div class="upd-notes">${notesHtml(j.notes)}</div></section></div>`,
    footer: `<div class="btnrow"><button class="btn primary push" data-ok>Done</button></div>` });
  $('[data-ok]', m.el).onclick = () => m.close();
}

/** Auto mode: the update is in place for the next start; restart now to use it at once, or carry on. */
function readyNotice(u) {
  const v = ver(u.latest.version);
  const m = modal({ title: 'Update installed', size: 'updm', body: `<div class="upd">
    <div class="upd-ask"><img class="upd-logo lg" src="icon.png" alt=""><div><h3>Mandata ${esc(v)} is installed</h3>
      <p>The update was downloaded and verified in the background. It will be used the next time Mandata starts. You can restart now to use it straight away; your work is kept.</p></div></div></div>`,
    footer: `<div class="btnrow"><button class="btn ghost" data-new>What's new</button><button class="btn push" data-later>Later</button><button class="btn primary" data-now>Restart now</button></div>` });
  $('[data-later]', m.el).onclick = () => m.close();
  $('[data-new]', m.el).onclick = () => { m.close(); openUpdates(); };
  $('[data-now]', m.el).onclick = e => busy(e.currentTarget, async () => { const r = await api('POST', '/api/update/install'); m.close(); set(r); });
}

function set(u) {
  if (!u) return;
  U = u;
  if (S.status) S.status.update = u;
  renderButton();
  emit('update', u);
  if (u.ask && askedFor !== u.latest?.version && !dlg && !document.querySelector('.overlay')) { askedFor = u.latest.version; openUpdates(); }
  if (u.phase === 'ready' && u.mode === 'auto' && readyTold !== u.latest?.version && !dlg && !document.querySelector('.overlay')) { readyTold = u.latest.version; readyNotice(u); }
  if (u.justUpdated && !document.querySelector('.overlay')) { const j = u.justUpdated; U.justUpdated = null; whatsNew(j); }
}

export function initUpdates() {
  $('#updBtn').onclick = openUpdates;
  // The status carries it too (on load, and after a lost connection): taken when it differs from what is shown.
  on('status', () => { const u = S.status?.update; if (u && JSON.stringify(u) !== JSON.stringify(U)) set(u); });
}
export const onUpdateEvent = u => set(u);
