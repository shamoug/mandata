<#
.SYNOPSIS
  Installs or updates Mandata for the current user, without a setup program. Run by install.bat.

.DESCRIPTION
  1. Checks this computer: 64-bit Windows, PowerShell allowed to run scripts, classic Outlook.
  2. The app runtime (Electron): downloaded from its official GitHub release and checked against its SHA-256, only when
     it is missing or a different version. Its program file is renamed Mandata.exe; nothing is built or signed.
  3. The app's files are copied into %LOCALAPPDATA%\Programs\Mandata\resources\app (the runtime there is kept).
  4. Start Menu and Desktop shortcuts, and an entry in Settings > Apps to uninstall it.
  5. The local AI (Ollama and a model, 3 to 20 GB): installed by ai-setup.ps1 when missing, after asking.
  6. Starts Mandata.

  No admin rights. Files downloaded by this script carry no "downloaded from the internet" mark, so Windows SmartScreen
  does not ask about them. Your data (%USERPROFILE%\.mandata) is never touched.

.EXAMPLE
  powershell -ExecutionPolicy Bypass -File install.ps1
  powershell -ExecutionPolicy Bypass -File install.ps1 -AI no -NoLaunch
  powershell -ExecutionPolicy Bypass -File install.ps1 -AI yes -Model qwen3:8b
#>
[CmdletBinding()]
param(
  [ValidateSet('ask', 'yes', 'no')] [string]$AI = 'ask',   # install the local AI when it is missing
  [string]$Model,                                         # default: the best model for this computer
  [switch]$NoDesktopIcon,
  [switch]$NoLaunch
)

. (Join-Path $PSScriptRoot 'common.ps1')
$dest = Join-Path $env:LOCALAPPDATA 'Programs\Mandata'
$appDir = Join-Path $dest 'resources\app'
$downloads = Join-Path $script:StateDir 'downloads'
$uninstallKey = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\Mandata'
$innoKey = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\{6E2B6E0C-5A3B-4E0F-9C43-2D0B9B7A8F14}_is1'
$port = 4318

# The app's files: next to this folder when it was packed to share (pack.bat), or the project this folder is in.
function Find-AppSource {
  foreach ($p in (Join-Path $PSScriptRoot '..\app'), (Join-Path $PSScriptRoot '..\..')) {
    if (Test-Path (Join-Path $p 'server.js')) { return (Resolve-Path $p).Path }
  }
  Stop-Setup "The app's files were not found next to the installer (no server.js in ..\app or ..\..)."
}

# Without a byte order mark: the app reads these files with JSON.parse, which rejects one (Set-Content -Encoding UTF8
# in Windows PowerShell writes it).
function Write-Utf8([string]$Path, [string]$Text) { [IO.File]::WriteAllText($Path, $Text.Trim(), (New-Object Text.UTF8Encoding($false))) }

function Ask([string]$Question, [bool]$Default) {
  $hint = if ($Default) { '[Y/n]' } else { '[y/N]' }
  $a = Read-Host "        $Question $hint"
  if (-not $a.Trim()) { return $Default }
  return $a.Trim() -match '^(y|yes|o|oui)$'
}

function Stop-Mandata {
  # Asked to stop first, so it closes its data file cleanly; whatever is left is then stopped.
  if (Request-AppShutdown $port) { Write-Info 'Asked the running Mandata to close' }
  $ours = { Get-Process -ErrorAction SilentlyContinue | Where-Object { try { $_.Path -and $_.Path.StartsWith($dest, [StringComparison]::OrdinalIgnoreCase) } catch { $false } } }
  for ($i = 0; $i -lt 10 -and (& $ours); $i++) { Start-Sleep -Milliseconds 500 }
  for ($i = 0; $i -lt 10 -and (& $ours); $i++) { & $ours | Stop-Process -Force -ErrorAction SilentlyContinue; Start-Sleep -Seconds 1 }
  # A copy started from the project ("node server.js") holds the same port and data file.
  try {
    Get-NetTCPConnection -LocalPort $port -State Listen -ErrorAction Stop | ForEach-Object {
      $p = Get-Process -Id $_.OwningProcess -ErrorAction SilentlyContinue
      if ($p -and $p.ProcessName -match '^(node|electron|Mandata)$') { Stop-Process -Id $p.Id -Force -ErrorAction SilentlyContinue; Write-Info "Stopped $($p.ProcessName) on port $port" }
    }
  } catch {}
}

function New-Shortcut([string]$Path, [string]$Target, [string]$Icon) {
  New-Item -ItemType Directory -Force (Split-Path -Parent $Path) | Out-Null
  $sh = New-Object -ComObject WScript.Shell
  $l = $sh.CreateShortcut($Path)
  $l.TargetPath = $Target
  $l.WorkingDirectory = Split-Path -Parent $Target
  $l.IconLocation = "$Icon,0"
  $l.Description = 'Tasks found in your email'
  $l.Save()
}

# The models in the AI server's model folder, as Ollama names them ("qwen3:4b", "someone/model:tag").
function Get-InstalledModels {
  $man = Join-Path (Get-OllamaModelsDir) 'manifests'
  if (-not (Test-Path $man)) { return @() }
  @(Get-ChildItem -Recurse -File $man -ErrorAction SilentlyContinue | ForEach-Object {
    $p = $_.FullName.Substring($man.Length + 1).Split('\')   # host\namespace\repo\tag
    if ($p.Count -eq 4) { if ($p[1] -eq 'library') { "$($p[2]):$($p[3])" } else { "$($p[1])/$($p[2]):$($p[3])" } }
  })
}

function Assert-FreeSpace([string]$Path, [double]$NeedGb, [string]$What) {
  $free = Get-FreeBytes $Path
  if ($free -lt $NeedGb * 1GB) {
    Stop-Setup ("Not enough disk space for $What on drive $([IO.Path]::GetPathRoot($Path)): {0:N1} GB needed, {1:N1} GB free. Free some space and run install.bat again." -f $NeedGb, ($free / 1GB))
  }
}

try {
  $src = Find-AppSource
  $version = [string](Get-Content -Raw (Join-Path $src 'package.json') | ConvertFrom-Json).version
  Write-Host ''
  Write-Host "  Mandata $version  -  installing for $env:USERNAME" -ForegroundColor White
  Write-Info "From: $src"
  Write-Info "To:   $dest"

  # ------------------------------------------------------------------------------------------------ checks
  Write-Step 'Checking this computer'
  if ($ExecutionContext.SessionState.LanguageMode -ne 'FullLanguage') {
    Stop-Setup "PowerShell runs in $($ExecutionContext.SessionState.LanguageMode) mode on this computer (an IT policy), so it cannot install the app. Ask IT to allow it."
  }
  $arch = Get-NativeArch
  if ($arch -eq 'x86') { Stop-Setup 'Mandata needs 64-bit Windows (x64 or ARM64).' }
  Write-Ok "Windows $([Environment]::OSVersion.Version), $arch"
  if (Test-ClassicOutlook) { Write-Ok 'Classic Outlook is installed' }
  else { Write-Note 'Classic Outlook was not found. Mandata reads mail only through classic Outlook (not the new Outlook); install it before using the app.' }
  Initialize-Network

  # ------------------------------------------------------------------------------------------------ runtime
  Write-Step "App runtime (Electron $($script:ElectronVersion), $arch)"
  $exe = Join-Path $dest 'Mandata.exe'
  $runtimeFile = Join-Path $dest 'runtime.txt'   # "<electron version> <arch>", written by this script
  $have = if (Test-Path $runtimeFile) { (Get-Content -Raw $runtimeFile).Trim() }
          elseif ((Test-Path (Join-Path $dest 'version')) -and $arch -eq 'x64') { (Get-Content -Raw (Join-Path $dest 'version')).Trim() + ' x64' }   # an earlier install
  $needRuntime = -not (Test-Path $exe) -or $have -ne "$($script:ElectronVersion) $arch"

  # Kept across the update: the AI model chosen at install.
  $keepDefaults = $null
  $defaultsFile = Join-Path $appDir 'install-defaults.json'
  if (Test-Path $defaultsFile) { $keepDefaults = Get-Content -Raw $defaultsFile }

  if ($needRuntime) {
    $base = "https://github.com/electron/electron/releases/download/v$($script:ElectronVersion)"
    $zip = "electron-v$($script:ElectronVersion)-win32-$arch.zip"
    $zipPath = Join-Path $downloads $zip
    Assert-FreeSpace $env:LOCALAPPDATA 0.8 'the app'
    try { $sums = Get-WebText "$base/SHASUMS256.txt" }
    catch { Stop-Setup "Could not reach github.com to download the app runtime ($($_.Exception.Message)). Check the internet connection (or VPN/proxy) and run install.bat again." }
    $sha = Find-Sha256 $sums $zip
    if (-not $sha) { Stop-Setup "No checksum for $zip in the Electron release." }
    Get-Download "$base/$zip" $zipPath $sha 'Electron'
    Write-Host ''
    Write-Ok 'Downloaded and checked (SHA-256)'
  } else { Write-Ok 'Already installed' }

  # ------------------------------------------------------------------------------------------------ install
  Write-Step 'Installing the app'
  Stop-Mandata
  if ($needRuntime) {
    for ($i = 0; $i -lt 10; $i++) {
      try { Expand-ZipTo $zipPath $dest -Label 'Unpacking'; break }
      catch { if ($i -eq 9) { Stop-Setup "Could not replace $dest ($($_.Exception.Message)). Quit Mandata from the tray and run this again." }; Start-Sleep -Seconds 1 }
    }
    # Antivirus often holds a new program file for a moment while it scans it.
    for ($i = 0; $i -lt 10; $i++) {
      try { Rename-Item (Join-Path $dest 'electron.exe') 'Mandata.exe' -ErrorAction Stop; break }
      catch { if ($i -eq 9) { Stop-Setup "Could not rename electron.exe ($($_.Exception.Message)). Run install.bat again." }; Start-Sleep -Seconds 2 }
    }
    Remove-Item -Force (Join-Path $dest 'resources\default_app.asar') -ErrorAction SilentlyContinue
    Set-Content -Encoding ASCII $runtimeFile "$($script:ElectronVersion) $arch"
  }
  # Mandata's icon and name in place of Electron's, which Windows shows on the taskbar. On every install, as the icon
  # may change.
  $names = @{ ProductName = 'Mandata'; FileDescription = 'Mandata'; CompanyName = 'United Nations'; InternalName = 'Mandata.exe'; OriginalFilename = 'Mandata.exe' }
  for ($i = 0; $i -lt 10; $i++) {
    try { Set-ExeIdentity $exe (Join-Path $src 'desktop\icon.ico') $names; break }
    catch { if ($i -eq 9) { Write-Note "Mandata.exe keeps Electron's icon and name ($($_.Exception.Message))." }; Start-Sleep -Seconds 2 }
  }
  # The app's own files, into a new folder first and then swapped in, so a failure never leaves half an app.
  $new = "$appDir.new"
  if (Test-Path $new) { Remove-Item -Recurse -Force $new }
  New-Item -ItemType Directory -Force $new | Out-Null
  Copy-AppFiles $src $new
  if ($keepDefaults) { Write-Utf8 (Join-Path $new 'install-defaults.json') $keepDefaults }
  for ($i = 0; $i -lt 10 -and (Test-Path $appDir); $i++) { try { Remove-Item -Recurse -Force $appDir -ErrorAction Stop } catch { Start-Sleep -Seconds 1 } }
  if (Test-Path $appDir) { Stop-Setup "Could not replace $appDir. Quit Mandata from the tray and run this again." }
  Move-Item $new $appDir
  # The uninstaller and the AI setup, kept with the app.
  $setupDir = Join-Path $dest 'setup'
  New-Item -ItemType Directory -Force $setupDir | Out-Null
  foreach ($f in Get-ChildItem (Join-Path $PSScriptRoot '*.ps1')) { Copy-Plain $f.FullName (Join-Path $setupDir $f.Name) }
  Copy-Plain (Join-Path $PSScriptRoot '..\uninstall.bat') (Join-Path $setupDir 'uninstall.bat')
  Get-ChildItem -Recurse -File $dest | Unblock-File -ErrorAction SilentlyContinue
  Write-Ok "Mandata $version installed"

  # ------------------------------------------------------------------------------------------------ shortcuts
  Write-Step 'Shortcuts'
  $icon = Join-Path $appDir 'desktop\icon.ico'
  $startMenu = Join-Path ([Environment]::GetFolderPath('Programs', 'Create')) 'Mandata.lnk'
  $desktopLnk = Join-Path ([Environment]::GetFolderPath('Desktop', 'Create')) 'Mandata.lnk'
  New-Shortcut $startMenu $exe $icon
  Write-Ok 'Start Menu'
  # Made by Electron for notifications while Mandata.exe still called itself Electron: it has the app's id but no icon,
  # and the taskbar would show Electron's icon from it.
  $stray = Join-Path (Split-Path $startMenu) 'Electron.lnk'
  if ((Test-Path $stray) -and (New-Object -ComObject WScript.Shell).CreateShortcut($stray).TargetPath -eq $exe) { Remove-Item -Force $stray }
  if ($NoDesktopIcon) { Remove-Item -Force $desktopLnk -ErrorAction SilentlyContinue }
  else { New-Shortcut $desktopLnk $exe $icon; Write-Ok 'Desktop' }
  # The app adds its id to these shortcuts when it starts (Windows needs it for notifications and the taskbar), and
  # registers itself to start with Windows (untick "Start with Windows" in its tray menu to stop that).
  try { & "$env:SystemRoot\System32\ie4uinit.exe" -show } catch {}   # refreshes Windows' icon cache

  # Settings > Apps
  if (Test-Path $innoKey) { Remove-Item -Recurse -Force $innoKey }   # left by the earlier setup program
  New-Item -Force $uninstallKey | Out-Null
  $size = [int]((Get-ChildItem -Recurse -File $dest | Measure-Object Length -Sum).Sum / 1KB)
  $values = @{
    DisplayName = 'Mandata'; DisplayVersion = $version; Publisher = 'United Nations'; DisplayIcon = $icon
    InstallLocation = $dest; UninstallString = "`"$env:SystemRoot\System32\cmd.exe`" /c `"`"$setupDir\uninstall.bat`"`""
    InstallDate = (Get-Date -Format 'yyyyMMdd')
  }
  foreach ($k in $values.Keys) { New-ItemProperty -Force -Path $uninstallKey -Name $k -Value $values[$k] -PropertyType String | Out-Null }
  foreach ($k in 'NoModify', 'NoRepair') { New-ItemProperty -Force -Path $uninstallKey -Name $k -Value 1 -PropertyType DWord | Out-Null }
  New-ItemProperty -Force -Path $uninstallKey -Name EstimatedSize -Value $size -PropertyType DWord | Out-Null
  Write-Ok 'Listed in Settings > Apps (uninstall from there)'

  # ------------------------------------------------------------------------------------------------ AI
  Write-Step 'Local AI (Ollama and a model)'
  # The model the app will use: the one asked for, else the one chosen at an earlier install, else the best for this
  # computer. Names are compared with their tag ("phi4-mini" is "phi4-mini:latest").
  $full = { param($n) if ($n -match ':') { $n } else { "${n}:latest" } }
  $ollama = Find-Ollama
  $server = [bool]($ollama -or (Test-OllamaApi))
  $models = @(Get-InstalledModels)
  $earlier = $null
  if ($keepDefaults) { try { $earlier = [string]($keepDefaults | ConvertFrom-Json).model } catch {} }
  $pc = Get-Capacity
  if (-not $Model) { $Model = if ($earlier) { $earlier } else { Select-BestModel $pc } }
  $haveModel = [bool]($models | Where-Object { $_ -eq (& $full $Model) })
  if ($server -and $haveModel) { Write-Ok "AI server and $Model already installed" }
  elseif ($server -and $models -and -not $earlier -and -not $PSBoundParameters.ContainsKey('Model') -and $AI -ne 'yes') {
    # Set up before, by hand: the model is chosen in the app (Settings > AI), so nothing more is downloaded.
    Write-Ok "AI server and models already installed: $($models -join ', ') (choose one in the app's Settings > AI)"
  } else {
    Write-Info ("Memory {0} GB, graphics memory {1} GB: the best model for this computer is $Model." -f $pc.RamGb, $pc.VramGb)
    $missing = @($(if (-not $server) { 'the AI server (Ollama)' }), $(if (-not $haveModel) { "the model $Model" })) | Where-Object { $_ }
    Write-Info "Missing: $($missing -join ' and ')."
    $go = switch ($AI) { 'yes' { $true } 'no' { $false } default { Ask 'Download and install it now? This can take a while.' $true } }
    if ($go) {
      $gb = @(@((Get-ModelCatalog).models | Where-Object { (& $full $_.name) -eq (& $full $Model) } | ForEach-Object { [double]$_.gb }) + 5)[0]
      Assert-FreeSpace (Get-OllamaModelsDir) ($gb * 1.1 + $(if ($server) { 0 } else { 2 })) 'the AI'
      & powershell -NoProfile -ExecutionPolicy Bypass -File (Join-Path $PSScriptRoot 'ai-setup.ps1') -Model $Model
      if ($LASTEXITCODE) { Write-Note "The AI did not finish installing (log: $(Join-Path $script:StateDir 'ai-setup.log')). Run install.bat again to retry; the app works without it, but finds no tasks." }
      else { $haveModel = $true; Write-Ok "AI ready: $Model" }
    } else { Write-Note 'Skipped. Run install.bat again to install it; the app finds no tasks without it.' }
  }
  # The app starts with this model until another is chosen in Settings.
  if ($haveModel) {
    Write-Utf8 (Join-Path $appDir 'install-defaults.json') (@{ model = $Model } | ConvertTo-Json -Compress)
    Set-SetupState @{ model = $Model }
  }
  # ------------------------------------------------------------------------------------------------ done
  Write-Host ''
  Write-Host '  Mandata is installed.' -ForegroundColor Green
  Write-Info 'To pin it to the taskbar: while it runs, right-click its icon on the taskbar and choose "Pin to taskbar".'
  Write-Info '(Windows does not let an installer pin apps itself.)'
  if (-not $NoLaunch) { Start-Process $exe; Write-Info 'Starting Mandata.' }
  exit 0
} catch {
  Write-Host ''
  Write-Host "  INSTALL FAILED: $($_.Exception.Message)" -ForegroundColor Red
  exit 1
}
