<#
.SYNOPSIS
  Installs (or removes) Mandata's local AI: the Ollama runtime and the AI model. Run by the setup wizard, hidden,
  which shows the progress this script writes to -ProgressFile. Can also be run by hand.

.DESCRIPTION
  Install (default):
  1. Ollama: an Ollama already installed or running is used as it is. Otherwise only the runtime is installed
     (ollama.exe and its libraries from the official standalone zip, not the Ollama desktop app) to
     %LOCALAPPDATA%\Programs\Ollama. Without an NVIDIA GPU the CUDA libraries (about 1.3 GB) are left out and only the
     needed files are downloaded. AMD Radeon cards get the ROCm libraries. With only built-in graphics,
     OLLAMA_IGPU_ENABLE=1 lets Ollama use them.
  2. The model: without -Model, the best one for this computer's memory and graphics (Select-BestModel, rules in
     lib/models.json). Pulled through Ollama, or straight from the Ollama registry when Ollama cannot reach it (for example
     behind an office proxy that needs a Windows sign-in).
  3. A short test question checks that the model answers.

  -Remove: removes the Ollama runtime only if this script installed it, and with -RemoveModel the model.

.EXAMPLE
  powershell -ExecutionPolicy Bypass -File ai-setup.ps1            (the best model for this computer)
  powershell -ExecutionPolicy Bypass -File ai-setup.ps1 -Model qwen3:8b
#>
[CmdletBinding()]
param(
  [string]$Model,             # default: the best model for this computer
  [string]$ProgressFile,
  [string]$OllamaVersion,     # for example v0.35.0; default: the latest release
  [switch]$NoIGpu,
  [switch]$SkipTest,
  [switch]$Remove,
  [switch]$RemoveModel
)

. (Join-Path $PSScriptRoot 'common.ps1')
$script:ProgressPath = $ProgressFile
New-Item -ItemType Directory -Force $script:StateDir | Out-Null
$log = Join-Path $script:StateDir $(if ($Remove) { 'ai-remove.log' } else { 'ai-setup.log' })
try { Start-Transcript -Path $log -Force | Out-Null } catch {}

function Invoke-OllamaPull([string]$Name) {
  # Ollama's own download, read line by line for its progress.
  $req = New-Request "$script:OllamaApi/api/pull"
  $req.Proxy = $null; $req.Method = 'POST'; $req.ContentType = 'application/json'; $req.ReadWriteTimeout = 600000
  $bytes = [Text.Encoding]::UTF8.GetBytes((@{ model = $Name; stream = $true } | ConvertTo-Json -Compress))
  $req.ContentLength = $bytes.Length
  $rs = $req.GetRequestStream(); $rs.Write($bytes, 0, $bytes.Length); $rs.Close()
  $resp = $req.GetResponse()
  try {
    $sr = New-Object IO.StreamReader($resp.GetResponseStream())
    while ($null -ne ($line = $sr.ReadLine())) {
      if (-not $line.Trim()) { continue }
      $j = $line | ConvertFrom-Json
      if ($j.error) { throw [string]$j.error }
      if ($j.total -and $j.total -gt 50MB) {
        Send-Progress ($j.completed / $j.total) ("Downloading: " + (Format-Size ([double]$j.completed)) + ' of ' + (Format-Size ([double]$j.total)))
      } else { Send-Progress 0 ([string]$j.status) }
      if ($j.status -eq 'success') { return }
    }
  } finally { $resp.Close() }
  throw 'The AI server stopped before the download finished'
}

$pct = 0
try {
  if ($ExecutionContext.SessionState.LanguageMode -ne 'FullLanguage') {
    throw "PowerShell runs in $($ExecutionContext.SessionState.LanguageMode) mode on this computer (an IT policy). Ask IT to install the AI server and the model $Model."
  }
  $state = Get-SetupState

  # ---------------------------------------------------------------------------------------------- remove
  if ($Remove) {
    Set-Stage 0 50 'Removing the AI model'
    $ollama = Find-Ollama
    if ($RemoveModel -and $ollama) {
      if (Start-OllamaServe $ollama 20) {
        # A failure here leaves the model, never the AI server: removing it below still runs.
        try {
          $req = New-Request "$script:OllamaApi/api/delete"; $req.Proxy = $null; $req.Method = 'DELETE'; $req.ContentType = 'application/json'
          $b = [Text.Encoding]::UTF8.GetBytes((@{ model = $Model } | ConvertTo-Json -Compress)); $req.ContentLength = $b.Length
          $s = $req.GetRequestStream(); $s.Write($b, 0, $b.Length); $s.Close()
          $req.GetResponse().Close(); Write-Ok "Removed $Model"
        } catch { Write-Note "Model $Model not removed: $($_.Exception.Message)" }
      }
    }
    Set-Stage 50 100 'Removing the AI server'
    $ours = [bool]$state.ollamaInstalled -and (Test-Path (Join-Path $script:OllamaDir 'installed-by-task-manager.txt'))
    if ($ours) {
      Get-Process -ErrorAction SilentlyContinue | Where-Object { try { $_.Path -and $_.Path.StartsWith($script:OllamaDir, [StringComparison]::OrdinalIgnoreCase) } catch { $false } } |
        Stop-Process -Force -ErrorAction SilentlyContinue
      Start-Sleep -Seconds 1
      Remove-Item -Recurse -Force $script:OllamaDir -ErrorAction SilentlyContinue
      if ($state.pathAdded) { Remove-UserPath ([string]$state.pathAdded) }
      if ($state.igpuEnvSet) { [Environment]::SetEnvironmentVariable('OLLAMA_IGPU_ENABLE', $null, 'User') }
      Write-Ok "Removed $($script:OllamaDir)"
      Remove-Item -Recurse -Force $script:StateDir -ErrorAction SilentlyContinue
    } else { Write-Info 'The AI server was not installed by Mandata setup; it stays.' }
    # The AI server settings setup added, whoever installed the server.
    foreach ($k in @($state.serverEnvSet | Where-Object { $_ })) { [Environment]::SetEnvironmentVariable([string]$k, $null, 'User') }
    Write-ProgressFile 'done|100|Removed'
    exit 0
  }

  # ---------------------------------------------------------------------------------------------- install
  Set-Stage 0 3 'Checking this computer'
  Initialize-Network
  $arch = Get-NativeArch
  if ($arch -eq 'x86') { throw 'The local AI needs 64-bit Windows on an x64 or ARM64 processor.' }
  $gpu = Get-Gpus
  Write-Info ("Processor $arch; graphics: " + $(if ($gpu.Names) { $gpu.Names -join ', ' } else { 'none found' }))
  if (-not $Model) {
    $pc = Get-Capacity
    $Model = Select-BestModel $pc
    Write-Ok ("Memory {0} GB, graphics memory {1} GB: the best AI model for this computer is $Model" -f $pc.RamGb, $pc.VramGb)
  }

  # Ollama
  Set-Stage 3 40 'Installing the AI server'
  $pct = 3
  $ollama = Find-Ollama
  $apiVersion = Test-OllamaApi
  if ($ollama -or $apiVersion) { Write-Ok "The AI server is already here$(if ($ollama) { ": $ollama" })$(if ($apiVersion) { " (running $apiVersion)" })" }
  else {
    $tag = $OllamaVersion
    if (-not $tag) { $tag = Get-OllamaLatestTag }
    $rel = if ($tag) { "https://github.com/ollama/ollama/releases/download/$tag" } else { 'https://github.com/ollama/ollama/releases/latest/download' }
    $ozip = "ollama-windows-$(if ($arch -eq 'arm64') { 'arm64' } else { 'amd64' }).zip"
    $skip = if ($gpu.Nvidia) { @() } else { @('lib/ollama/cuda_') }
    $done = $false
    if ($skip -and (Initialize-RangeStream)) {
      try {
        $rs = New-Object TaskManagerSetup.HttpRangeStream("$rel/$ozip")
        Expand-ZipTo $rs $script:OllamaDir -SkipPrefixes $skip -Label 'Downloading the AI server' -Merge
        Write-Info ("Downloaded " + (Format-Size $rs.Downloaded) + " of the " + (Format-Size $rs.Length) + " package")
        $done = $true
      } catch { Write-Note "Partial download did not work ($($_.Exception.Message)); downloading the whole package." }
    }
    if (-not $done) {
      $sums = try { Get-WebText "$rel/sha256sum.txt" } catch { '' }
      $zipPath = Join-Path $script:StateDir $ozip
      Get-Download "$rel/$ozip" $zipPath $(if ($sums) { Find-Sha256 $sums $ozip }) 'Downloading the AI server'
      Expand-ZipTo $zipPath $script:OllamaDir -SkipPrefixes $skip -Label 'Unpacking the AI server' -Merge
      Remove-Item -Force $zipPath -ErrorAction SilentlyContinue
    }
    if ($gpu.AmdDiscrete -and $arch -eq 'x64') {
      try {
        $rz = 'ollama-windows-amd64-rocm.zip'; $rp = Join-Path $script:StateDir $rz
        Get-Download "$rel/$rz" $rp $null 'Downloading AMD graphics support'
        Expand-ZipTo $rp $script:OllamaDir -Label 'Unpacking AMD graphics support' -Merge
        Remove-Item -Force $rp -ErrorAction SilentlyContinue
      } catch { Write-Note "AMD ROCm libraries not installed ($($_.Exception.Message)); the AI server uses Vulkan or the processor." }
    }
    $ollama = Join-Path $script:OllamaDir 'ollama.exe'
    if (-not (Test-Path $ollama)) { throw 'The AI server did not install: its program file is missing.' }
    Get-ChildItem -Recurse -File $script:OllamaDir | Unblock-File -ErrorAction SilentlyContinue
    Set-Content -Encoding ASCII (Join-Path $script:OllamaDir 'installed-by-task-manager.txt') "Installed by Mandata setup on $(Get-Date -Format s). Removed when Mandata is uninstalled with its AI."
    Set-SetupState @{ ollamaInstalled = $true; ollamaDir = $script:OllamaDir }
    Write-Ok "AI server installed to $($script:OllamaDir)"
  }
  if ($ollama -and (Split-Path -Parent $ollama) -eq $script:OllamaDir -and (Add-UserPath $script:OllamaDir)) {
    Set-SetupState @{ pathAdded = $script:OllamaDir }
  }
  if (-not $NoIGpu -and -not $gpu.Nvidia -and -not $gpu.AmdDiscrete -and $gpu.Integrated) {
    if ([Environment]::GetEnvironmentVariable('OLLAMA_IGPU_ENABLE', 'User') -ne '1') {
      [Environment]::SetEnvironmentVariable('OLLAMA_IGPU_ENABLE', '1', 'User')
      Set-SetupState @{ igpuEnvSet = $true }
      Write-Ok 'The AI server will use the built-in graphics'
    }
    $env:OLLAMA_IGPU_ENABLE = '1'
  }
  # How the AI server runs best (lib/models.json, server): a smaller context cache, and with a separate graphics card a
  # smaller margin kept free on it, so the model fits the card whole. A value already set on this computer is kept.
  $srv = (Get-ModelCatalog).server
  if ($srv) {
    $want = [ordered]@{}
    foreach ($o in @($srv.env) + @($(if ($gpu.Nvidia -or $gpu.AmdDiscrete) { $srv.gpuEnv }))) { if ($o) { $o.PSObject.Properties | ForEach-Object { $want[$_.Name] = [string]$_.Value } } }
    $set = @($state.serverEnvSet | Where-Object { $_ })
    foreach ($k in $want.Keys) {
      if (-not [Environment]::GetEnvironmentVariable($k, 'User') -and -not [Environment]::GetEnvironmentVariable($k, 'Machine')) {
        [Environment]::SetEnvironmentVariable($k, $want[$k], 'User'); $set += $k
      }
      if (-not (Test-Path "Env:$k")) { Set-Item "Env:$k" $want[$k] }
    }
    if ($set.Count) { Set-SetupState @{ serverEnvSet = @($set | Select-Object -Unique) }; Write-Ok 'The AI server is set to fit the model in less memory' }
  }

  # Start it
  Set-Stage 40 44 'Starting the AI server'
  $pct = 40
  $proxy = Get-ProxyFor 'https://registry.ollama.ai/v2/'
  if ($proxy -and -not $env:HTTPS_PROXY) { $env:HTTPS_PROXY = $proxy; Write-Info "The AI server uses the proxy $proxy" }
  $up = if ($ollama) { Start-OllamaServe $ollama } else { [bool](Test-OllamaApi) }
  if (-not $up) { throw 'The AI server did not start. Restart the computer and run setup again (choose Repair).' }

  # The model
  Set-Stage 44 95 "Downloading the AI model $Model"
  $pct = 44
  $modelsDir = Get-OllamaModelsDir
  $have = @()
  try { $have = @((Invoke-Local '/api/tags' $null 10).models | ForEach-Object { $_.name }) } catch {}
  if ($have -contains $Model -or (Test-ModelFiles $modelsDir $Model)) { Write-Ok "$Model is already installed" }
  else {
    try {
      # The internet can drop during a download of several GB: try again every 5 seconds (Ollama carries on from where
      # it stopped), and give up only after 15 minutes without progress or on an error trying again cannot fix.
      $since = [DateTime]::UtcNow; $attempt = 0
      while ($true) {
        try { Invoke-OllamaPull $Model; break }
        catch {
          $msg = $_.Exception.Message
          if ($msg -match 'file does not exist|not found|manifest unknown|invalid model|no space left' -or ([DateTime]::UtcNow - $since).TotalMinutes -gt 15) { throw }
          $attempt++
          Write-Note "The connection was lost ($msg); trying again in 5 s (attempt $attempt)"
          Send-Progress 0 "Connection lost; trying again (attempt $attempt)"
          Start-Sleep -Seconds 5
        }
      }
      Write-Ok "Pulled $Model"
    }
    catch {
      Write-Note "The AI server could not download the model ($($_.Exception.Message)); downloading it directly."
      Save-ModelFromRegistry $modelsDir $Model
      Write-Ok "Downloaded $Model"
    }
  }

  # A short test
  $summary = "The AI server and $Model are ready"
  if (-not $SkipTest) {
    Set-Stage 95 100 'Checking that the AI model answers (the first start can take a minute)'
    $pct = 95
    try {
      $t = Measure-Command { $null = Invoke-Local '/api/generate' @{ model = $Model; prompt = 'Reply with the single word OK.'; stream = $false; think = $false; options = @{ num_predict = 8 } } 600 }
      $where = 'the processor'
      try {
        $m = (Invoke-Local '/api/ps' $null 10).models | Where-Object { $_.name -eq $Model -or $_.model -eq $Model } | Select-Object -First 1
        if ($m -and $m.size_vram) { $where = if ($m.size_vram -ge 0.9 * $m.size) { 'the graphics processor' } else { 'the graphics and the processor' } }
      } catch {}
      $summary = "The AI model answered in {0:N0} seconds, running on $where." -f $t.TotalSeconds
      Write-Ok $summary
    } catch { $summary = "$Model is installed; the test question did not finish ($($_.Exception.Message))."; Write-Note $summary }
  }
  Write-ProgressFile "done|100|$summary|$Model"
  $code = 0
} catch {
  $msg = $_.Exception.Message -replace '[\r\n|]+', ' '
  Write-Host "FAILED: $msg"
  Write-ProgressFile "error|$pct|$msg|$Model"
  $code = 1
} finally {
  try { Stop-Transcript | Out-Null } catch {}
}
exit $code
