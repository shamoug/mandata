// Shared helpers: API, escaping, time, avatars, icons, modals, toasts, and the colours every screen shares.
export async function api(method, url, body) {
  // Every change is sent as JSON: the server refuses anything else, so other websites cannot drive the app.
  const write = method !== 'GET';
  const r = await fetch(url, { method, headers: write ? { 'content-type': 'application/json' } : {}, body: write ? JSON.stringify(body || {}) : undefined });
  const j = await r.json().catch(() => ({}));
  if (!r.ok || j?.error) throw new Error(j?.error || r.statusText);
  return j;
}
export const GET = u => api('GET', u);
export const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
export const $ = (s, el = document) => el.querySelector(s);
export const $$ = (s, el = document) => [...el.querySelectorAll(s)];
export const splitList = s => String(s || '').split(/[;,\s]+/).map(x => x.trim()).filter(Boolean);
export const enc = encodeURIComponent;

// ---------- what the server's codes mean (GET /api/meta): labels, the locale and limits, applied once at start ----------
export const META = {};
/** The locale dates are written in; set from the server (undefined, the browser's own, until then). */
export let LOCALE;
/** One reference list as a map from code to its row: ref('priorities').get('high').label. */
// Built once per list (labelOf runs in loops over every row), and again only when the server sends the list anew.
const refs = new WeakMap();
const NONE = [];
const ref = list => { const a = META[list] || NONE; let m = refs.get(a); if (!m) refs.set(a, m = new Map(a.map(r => [r.code, r]))); return m; };
export const labelOf = (list, code) => ref(list).get(code)?.label || code;
export function applyMeta(m) {
  Object.assign(META, m);
  LOCALE = m.locale;
  // The colours and icons below are how each code looks; its name comes from the server.
  for (const [map, list] of [[DIR, 'task_directions'], [STATUS, 'task_statuses'], [CLOSE, 'close_reasons'], [PRI, 'priorities']])
    for (const r of m[list] || []) map[r.code] = { ...(map[r.code] || {}), label: r.label, ...(r.hint ? { hint: r.hint } : {}) };
}

// ---------- the kinds of task, the same colour everywhere ----------
export const DIR = {
  to_me: { label: 'Assigned to me', short: 'To me', color: '#c8822f', soft: '#fbf4ec', ink: '#8a5517', icon: 'inbox' },
  among: { label: 'Among others', short: 'Among others', color: '#5c940d', soft: '#f4fce3', ink: '#3f6a0a', icon: 'layers',
    hint: 'Asked of you as one of many: of a group ("Dear colleagues", a list), or of you after someone else, who answers for it' },
  by_me: { label: 'I assigned', short: 'By me', color: '#3b5bdb', soft: '#eef2fc', ink: '#2c449f', icon: 'send' },
  others: { label: 'Between others', short: 'Others', color: '#2f8f7f', soft: '#ecf6f4', ink: '#1f6a5d', icon: 'people' },
};
export const dir = k => DIR[k] || DIR.others;
export const STATUS = {
  open: { label: 'Open', color: '#3b5bdb' }, parked: { label: 'Parked', color: '#b08900' }, done: { label: 'Done', color: '#2f8a4f' },
  cancelled: { label: 'Cancelled', color: '#b0715a' }, dismissed: { label: 'Not a task', color: '#a0522d' },
};
/** Ways you can close a task. Done, delegated and handled count as done; archived (seen, nothing for you to do) and the rest count as cancelled. A task between others is not yours to close, only to archive: its emails close it; parked sets it aside until you resume it; not a
 *  task (the AI misread the email) leaves every list and is never raised again. */
export const CLOSE = {
  done: { label: 'Done', icon: 'check', color: '#2f8a4f', hint: 'The work was delivered' },
  archived: { label: 'Archived', icon: 'archive', color: '#5f7d95', hint: 'Seen, nothing for you to do' },
  delegated: { label: 'Delegated', icon: 'send', color: '#3b5bdb', hint: 'You handed it to someone else to carry' },
  outofscope: { label: 'Handled', icon: 'out', color: '#5c7c8a', hint: 'Taken care of elsewhere: someone else did it, without you handing it over' },
  cancelled: { label: 'Cancelled', icon: 'x', color: '#b0715a', hint: 'No longer needed: dropped, stopped part-way or replaced by another request' },
  duplicate: { label: 'Duplicate', icon: 'tasks', color: '#0b7285', hint: 'The same work is already another task' },
  superseded: { label: 'Superseded', icon: 'x', color: '#8a6d5a', hint: 'A later reply in the thread asked for other work instead', auto: true },
  notask: { label: 'Not a task', icon: 'ban', color: '#a0522d', hint: 'The AI misread the email: nobody asked for this' },
  parked: { label: 'Parked', icon: 'pause', color: '#b08900', hint: 'On hold: set aside until you resume it' },
};
/** The task-list filter a status belongs to: open, parked, or closed (done, cancelled). */
export const statusGroup = s => s === 'open' || s === 'parked' ? s : 'closed';
export const PRI = { high: { label: 'High', color: '#c92a2a' }, normal: { label: 'Normal', color: '#1c7ed6' }, low: { label: 'Low', color: '#74c0fc' } };

export function ago(iso) {
  if (!iso) return '';
  const s = (Date.now() - Date.parse(iso)) / 1000;
  if (s < 45) return 'just now';
  if (s < 3600) return Math.round(s / 60) + ' min ago';
  if (s < 86400) return Math.round(s / 3600) + ' h ago';
  if (s < 86400 * 7) return Math.round(s / 86400) + ' d ago';
  return new Date(iso).toLocaleDateString(LOCALE, { day: 'numeric', month: 'short' });
}
export function when(iso) {
  if (!iso) return '';
  const d = new Date(iso), n = new Date(), time = d.toLocaleTimeString(LOCALE, { hour: '2-digit', minute: '2-digit' });
  if (d.toDateString() === n.toDateString()) return time;
  if (n - d < 6 * 864e5) return d.toLocaleDateString(LOCALE, { weekday: 'short' }) + ' ' + time;
  return d.toLocaleDateString(LOCALE, { day: 'numeric', month: 'short', year: d.getFullYear() === n.getFullYear() ? undefined : '2-digit' });
}
export const fullDate = iso => iso ? new Date(iso).toLocaleString(LOCALE, { dateStyle: 'medium', timeStyle: 'short' }) : '';
// A moment ("2026-10-01T23:30:00Z") shows on your own day; a plain date (a deadline) shows as written.
export const dateLabel = d => d ? (/T/.test(d) ? new Date(d) : new Date(String(d).slice(0, 10) + 'T12:00:00')).toLocaleDateString(LOCALE, { day: 'numeric', month: 'short' }) : '';
export const firstName = n => String(n || '').trim().split(/\s+/)[0] || '';
/** A month ("2026-10") by name: "Oct", or as opts say. */
export const monthLabel = (k, opts = { month: 'short' }) => new Date(k + '-15T12:00:00').toLocaleDateString(LOCALE, opts);
/** "1 task", "3 tasks". */
export const plural = (n, word) => `${n} ${word}${n === 1 ? '' : 's'}`;

/** How a deadline sorts: open tasks by date (no deadline after dated ones), then parked, then closed tasks by when they closed. */
export const dueKey = t => t.status !== 'open' ? (t.status === 'parked' ? '}' : '~') + (t.closed_at || '') : t.deadline || '9999';
/** "3 days left", "Due today", "2 days late", coloured. */
export function dueBadge(t) {
  if (t.status !== 'open') {
    const s = CLOSE[t.close_reason] || STATUS[t.status] || STATUS.done;
    const g = statusGroup(t.status);
    // Closed by the app reading the email: the robot takes the status icon's place, so the pill stays the same size.
    const auto = t.closed_by === 'email' && t.status !== 'parked';
    const tip = tipHead(s.label + (t.closed_at ? ' on ' + dateLabel(t.closed_at) : ''), auto ? 'robot' : s.icon || 'check') + (s.hint ? tipLine(esc(s.hint)) : '')
      + (auto ? tipLine('Automatically classified as closed') : '')
      + tipActs(tipPill(`See ${g} tasks`, `data-go="#/tasks/?status=${g}"`, 'tasks'));
    return `<span class="due" data-go="#/tasks/?status=${g}" ${tipAttr(tip)} style="--c:${s.color}">${icon(auto ? 'robot' : s.icon || (t.status === 'done' ? 'check' : 'x'), 11)}${esc(s.label)}${t.closed_at ? ' ' + dateLabel(t.closed_at) : ''}</span>`;
  }
  const d = t.days_left;
  // No email sets a deadline and none can be told from the thread: it is left open, never guessed.
  if (d == null) return `<span class="due" style="--c:#0b7285" ${tipAttr(tipHead('Deadline: None', 'clock') + tipLine('No email sets a deadline: set one yourself if it needs one.'))} aria-label="Deadline: None">${icon('clock', 11)}Deadline: None</span>`;
  const [txt, c] = d < 0 ? [`${-d} day${d < -1 ? 's' : ''} late`, '#c92a2a'] : d === 0 ? ['Due today', '#c8822f'] : d === 1 ? ['Due tomorrow', '#c8822f']
    : d <= 7 ? [`${d} days left`, '#3b5bdb'] : [`Due ${dateLabel(t.deadline)}`, '#1098ad'];
  const f = d < 0 ? 'late' : d <= (META.limits?.dueSoonDays ?? 0) ? 'soon' : d <= 7 ? 'week' : '';
  const src = t.deadline_source === 'user' ? ['Set by you', '#3b5bdb'] : ['From the email', '#2f8a4f'];
  const tip = tipHead(txt, 'clock')
    + `<div class="tp-kv"><span>Deadline</span><b>${esc(dueDay(t.deadline))}</b>${tipTag(src[0], src[1])}</div>`
    + (t.deadline_note ? `<div class="tp-q">${esc(t.deadline_note)}</div>` : '')
    + (f ? tipActs(tipPill(DUE_SEE[f], `data-go="#/tasks/?due=${f}"`, 'tasks')) : '');
  return `<span class="due" ${f ? `data-go="#/tasks/?due=${f}"` : ''} style="--c:${c}" ${tipAttr(tip)} aria-label="${esc(txt + '. ' + deadlineSays(t))}">${icon('clock', 11)}${txt}</span>`;
}
const DUE_SEE = { late: 'See all late tasks', soon: 'See all due soon', week: 'See all due this week' };
const dueDay = d => new Date(String(d).slice(0, 10) + 'T12:00:00').toLocaleDateString(LOCALE, { weekday: 'short', day: 'numeric', month: 'long', year: 'numeric' });
/** Where a deadline comes from, in a sentence. */
function deadlineSays(t) {
  if (!t.deadline) return 'Deadline: None. No email sets one';
  const on = dateLabel(t.deadline);
  if (t.deadline_source === 'user') return `Deadline ${on}, set by you`;
  return `Deadline ${on}, from the email${t.deadline_note ? `: “${t.deadline_note}”` : ''}`;
}

const AV = ['#5b7bd5', '#4f9d8f', '#c0843d', '#e8590c', '#0b7285', '#4a93b8', '#7d9b4f', '#b0715a', '#6c7fa8', '#f08c00', '#3f8f6b', '#b8862f'];
export function initials(name) {
  const p = String(name || '?').replace(/[^A-Za-zÀ-ɏ ]/g, ' ').trim().split(/\s+/);
  return ((p[0]?.[0] || '?') + (p.length > 1 ? p[p.length - 1][0] : '')).toUpperCase();
}
export function colorOf(key) { let h = 0; for (const c of String(key || '')) h = (h * 31 + c.charCodeAt(0)) >>> 0; return AV[h % AV.length]; }
/** Every person gets a stable colour from their address. */
// Its tooltip is the person's card (tips.js builds it from data-tip-name and data-tip-email); tip false leaves it out,
// for an avatar inside something that shows that card already.
export function avatar(name, email, size = '', tip = true) {
  return `<span class="av ${size}" style="--c:${colorOf(email || name)}"${tip ? ` data-tip-name="${esc(name || email)}" data-tip-email="${esc(email || '')}"` : ''}><span>${esc(initials(name || email))}</span></span>`;
}

// ---------- rich tooltips (tips.js shows them) ----------
// A rich tip is HTML in data-tip-html: a heading, lines, tags, and pills that can be clicked (any data-go, data-person,
// data-task... works in it, as everywhere). Build it from these parts, then put tipAttr(html) on the element.
export const tipAttr = html => `data-tip-html="${esc(html)}"`;
export const tipHead = (text, ic = '') => `<div class="tp-h">${ic ? icon(ic, 12) : ''}<span>${esc(text)}</span></div>`;
export const tipLine = html => `<div class="tp-b">${html}</div>`;
const tipTag = (text, color = '') => `<span class="tp-tag"${color ? ` style="--k:${color}"` : ''}>${esc(text)}</span>`;
export const tipPill = (label, attrs = '', ic = '') => `<span class="tp-pill" ${attrs}>${ic ? icon(ic, 11) : ''}${esc(label)}</span>`;
export const tipActs = (...pills) => `<div class="tp-acts">${pills.filter(Boolean).join('')}</div>`;
/** A person: avatar, name and address; with link, pills to their profile and their open tasks. */
export function personTip(name, email, link = false) {
  const q = k => `data-go="${esc(`#/tasks/?${k}=${enc(email)}&status=open`)}"`;
  return `<div class="tp-person">${avatar(name, email, '', false)}<div><b>${esc(name || email)}</b>${email && email !== name ? `<small>${esc(email)}</small>` : ''}</div></div>`
    + (link && email ? tipActs(tipPill('Profile', `data-person="${esc(email)}"`, 'user'), tipPill('Asked by them', q('from'), 'inbox'), tipPill('Done by them', q('to'), 'send')) : '');
}
/** Several people as pills that open their profiles. */
export const peopleTip = (head, list) => tipHead(head, 'people')
  + `<div class="tp-acts">${list.map(p => `<span class="tp-pill tp-who" ${p.email ? `data-person="${esc(p.email)}"` : ''}>${avatar(p.name, p.email, 'xs', false)}${esc(p.name || p.email)}</span>`).join('')}</div>`;
/** Badges that open the task list filtered to what they say. */
// A task's status shows how you closed it (Handled, Delegated…) when you did.
export const statusChip = t => {
  const c = t.status !== 'open' && CLOSE[t.close_reason] || STATUS[t.status] || {}, g = statusGroup(t.status);
  return `<span class="chip" data-go="#/tasks/?status=${g}" title="See ${g} tasks" style="--c:${c.color}"><i></i>${esc(c.label || t.status)}</span>`;
};
export const priChip = p => `<span class="chip" data-go="#/tasks/?pri=${esc(p)}" title="See ${esc((PRI[p]?.label || p).toLowerCase())} priority tasks" style="--c:${PRI[p]?.color}"><i></i>${esc(PRI[p]?.label || p)} priority</span>`;
const dirTip = k => tipHead(dir(k).label, dir(k).icon) + (dir(k).hint ? tipLine(esc(dir(k).hint)) : '')
  + tipActs(tipPill(`See all: ${dir(k).label}`, `data-go="#/tasks/?dir=${esc(DIR[k] ? k : 'others')}"`, 'tasks'));
export const dirChip = k => `<span class="dchip" data-go="#/tasks/?dir=${esc(DIR[k] ? k : 'others')}" ${tipAttr(dirTip(k))} style="--c:${dir(k).color};--s:${dir(k).soft};--i:${dir(k).ink}">${icon(dir(k).icon, 11)}${esc(dir(k).label)}</span>`;

const P = {
  refresh: '<path d="M20 11a8 8 0 1 0-2.3 5.7M20 4v7h-7"/>',
  sun: '<circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/>',
  moon: '<path d="M21 12.8A9 9 0 1 1 11.2 3a7 7 0 0 0 9.8 9.8z"/>',
  gear: '<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.8l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-1.8-.3 1.7 1.7 0 0 0-1 1.5V21a2 2 0 1 1-4 0v-.1a1.7 1.7 0 0 0-1.1-1.5 1.7 1.7 0 0 0-1.8.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.7 1.7 0 0 0 .3-1.8 1.7 1.7 0 0 0-1.5-1H3a2 2 0 1 1 0-4h.1a1.7 1.7 0 0 0 1.5-1.1 1.7 1.7 0 0 0-.3-1.8l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.7 1.7 0 0 0 1.8.3H9a1.7 1.7 0 0 0 1-1.5V3a2 2 0 1 1 4 0v.1a1.7 1.7 0 0 0 1 1.5 1.7 1.7 0 0 0 1.8-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.7 1.7 0 0 0-.3 1.8V9a1.7 1.7 0 0 0 1.5 1H21a2 2 0 1 1 0 4h-.1a1.7 1.7 0 0 0-1.5 1z"/>',
  x: '<path d="M18 6 6 18M6 6l12 12"/>',
  pin: '<path d="M12 17v5"/><path d="M9 10.8V4h6v6.8l3 3.2v3H6v-3z"/><path d="M8 4h8"/>',
  plus: '<path d="M12 5v14M5 12h14"/>',
  minus: '<path d="M5 12h14"/>',
  archive: '<rect x="2" y="3" width="20" height="5" rx="1"/><path d="M4 8v11a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8"/><path d="M10 12h4"/>',
  inbox: '<path d="M22 12h-6l-2 3h-4l-2-3H2"/><path d="M5.5 5.1 2 12v6a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-6l-3.5-6.9A2 2 0 0 0 16.8 4H7.2a2 2 0 0 0-1.7 1.1z"/>',
  tasks: '<path d="M9 11l3 3L22 4"/><path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11"/>',
  people: '<path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.9M16 3.1a4 4 0 0 1 0 7.8"/>',
  draft: '<path d="M12 20h9"/><path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4z"/>',
  pulse: '<path d="M22 12h-4l-3 9L9 3l-3 9H2"/>',
  send: '<path d="M22 2 11 13M22 2l-7 20-4-9-9-4z"/>',
  forward: '<path d="m15 5 6 6-6 6"/><path d="M21 11H10a7 7 0 0 0-7 7v2"/>',
  mail: '<rect x="2" y="4" width="20" height="16" rx="2"/><path d="m22 7-10 6L2 7"/>',
  spark: '<path d="M12 3l1.9 5.1L19 10l-5.1 1.9L12 17l-1.9-5.1L5 10l5.1-1.9z"/><path d="M19 3v4M17 5h4"/>',
  check: '<path d="M20 6 9 17l-5-5"/>',
  user: '<circle cx="12" cy="8" r="4"/><path d="M4 21v-1a6 6 0 0 1 6-6h4a6 6 0 0 1 6 6v1"/>',
  clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
  flag: '<path d="M4 15s1-1 4-1 5 2 8 2 4-1 4-1V3s-1 1-4 1-5-2-8-2-4 1-4 1zM4 22v-7"/>',
  trash: '<path d="M3 6h18M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2m3 0v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6"/>',
  undo: '<path d="M3 7v6h6"/><path d="M21 17a9 9 0 0 0-15-6.7L3 13"/>',
  arrow: '<path d="M5 12h14M13 6l6 6-6 6"/>',
  back: '<path d="M19 12H5M11 18l-6-6 6-6"/>',
  edit: '<path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.1 2.1 0 0 1 3 3L12 15l-4 1 1-4z"/>',
  home: '<path d="M3 10.5 12 3l9 7.5V20a1 1 0 0 1-1 1h-5v-6h-6v6H4a1 1 0 0 1-1-1z"/>',
  thread: '<path d="M6 3v12"/><circle cx="6" cy="18" r="3"/><circle cx="18" cy="6" r="3"/><path d="M18 9a9 9 0 0 1-9 9"/>',
  grid: '<rect x="3" y="3" width="7" height="7" rx="1.5"/><rect x="14" y="3" width="7" height="7" rx="1.5"/><rect x="3" y="14" width="7" height="7" rx="1.5"/><rect x="14" y="14" width="7" height="7" rx="1.5"/>',
  list: '<path d="M8 6h13M8 12h13M8 18h13M3 6h.01M3 12h.01M3 18h.01"/>',
  search: '<circle cx="11" cy="11" r="7"/><path d="m21 21-4.3-4.3"/>',
  out: '<path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6M15 3h6v6M10 14 21 3"/>',
  alert: '<path d="M10.3 3.9 1.8 18a2 2 0 0 0 1.7 3h17a2 2 0 0 0 1.7-3L13.7 3.9a2 2 0 0 0-3.4 0zM12 9v4M12 17h.01"/>',
  down: '<path d="m6 9 6 6 6-6"/>',
  eye: '<path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8S1 12 1 12z"/><circle cx="12" cy="12" r="3"/>',
  play: '<path d="M7 4v16l13-8z"/>',
  pause: '<path d="M8 5v14M16 5v14"/>',
  target: '<path d="M12 2 21.5 9 18 20H6L2.5 9z"/><path d="M12 8l4 3.5-1.5 4.5h-5L8 11.5z"/>',
  expand: '<path d="m7 15 5 5 5-5M7 9l5-5 5 5"/>',
  collapse: '<path d="m7 20 5-5 5 5M7 4l5 5 5-5"/>',
  newest: '<path d="M3 6h10M3 12h7M3 18h4M18 5v14M14.5 15.5 18 19l3.5-3.5"/>',
  oldest: '<path d="M3 6h4M3 12h7M3 18h10M18 19V5M14.5 8.5 18 5l3.5 3.5"/>',
  select: '<rect x="3" y="3" width="18" height="18" rx="3"/><path d="m8 12 3 3 5-6"/>',
  chat: '<path d="M21 12a8 8 0 0 1-11.6 7.1L4 20.5l1.4-4.6A8 8 0 1 1 21 12z"/><path d="M8.5 12h.01M12 12h.01M15.5 12h.01"/>',
  copy: '<rect x="9" y="9" width="12" height="12" rx="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/>',
  stop: '<rect x="6" y="6" width="12" height="12" rx="2"/>',
  up: '<path d="M12 19V5M5 12l7-7 7 7"/>',
  report: '<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><path d="M14 2v6h6"/><path d="M8 18v-3M12 18v-6M16 18v-4"/>',
  download: '<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><path d="m7 10 5 5 5-5M12 15V3"/>',
  upload: '<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><path d="m17 8-5-5-5 5M12 3v12"/>',
  database: '<ellipse cx="12" cy="5" rx="8" ry="3"/><path d="M4 5v14c0 1.7 3.6 3 8 3s8-1.3 8-3V5"/><path d="M4 12c0 1.7 3.6 3 8 3s8-1.3 8-3"/>',
  more: '<circle cx="5" cy="12" r="1.2"/><circle cx="12" cy="12" r="1.2"/><circle cx="19" cy="12" r="1.2"/>',
  // The actions of the activity log, one picture each.
  newTask: '<rect x="3" y="3" width="18" height="18" rx="3"/><path d="M12 8v8M8 12h8"/>',
  done: '<circle cx="12" cy="12" r="9"/><path d="m8 12 3 3 5-6"/>',
  doneAll: '<path d="M18 6 7 17l-5-5"/><path d="m22 10-7.5 7.5L13 16"/>',
  reopen: '<path d="M3 12a9 9 0 1 0 3-6.7L3 8"/><path d="M3 3v5h5"/>',
  history: '<path d="M3 12a9 9 0 1 0 3-6.7L3 8"/><path d="M3 3v5h5M12 7v5l3 2"/>',
  thumb: '<path d="M7 10v11"/><path d="M15 5.9 14 10h5.8a2 2 0 0 1 1.9 2.6l-2.3 7A2 2 0 0 1 17.5 21H4a1 1 0 0 1-1-1v-9a1 1 0 0 1 1-1h2.8a2 2 0 0 0 1.8-1.1L12 2a3.1 3.1 0 0 1 3 3.9z"/>',
  ban: '<circle cx="12" cy="12" r="9"/><path d="m5.7 5.7 12.6 12.6"/>',
  noTask: '<rect x="5" y="4" width="14" height="18" rx="2"/><path d="M9 2h6v4H9zM10 12l4 4M14 12l-4 4"/>',
  restore: '<path d="M3 6h18M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2m3 0v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6"/><path d="M12 18v-7M9 14l3-3 3 3"/>',
  flame: '<path d="M12 22c4 0 7-2.7 7-7 0-3.5-2.5-6.5-4-8-.3 2-1.3 3.5-3 4.5C12 8 10.5 4.5 8 2c0 4-3 6.5-3 13 0 4.3 3 7 7 7z"/>',
  merge: '<circle cx="18" cy="18" r="3"/><circle cx="6" cy="6" r="3"/><path d="M6 21V9a9 9 0 0 0 9 9"/>',
  review: '<circle cx="11" cy="11" r="7"/><path d="m21 21-4.3-4.3M8 11l2 2 4-4"/>',
  repeat: '<path d="m17 2 4 4-4 4"/><path d="M3 11v-1a4 4 0 0 1 4-4h14"/><path d="m7 22-4-4 4-4"/><path d="M21 13v1a4 4 0 0 1-4 4H3"/>',
  book: '<path d="M2 4h6a4 4 0 0 1 4 4v13a3 3 0 0 0-3-3H2z"/><path d="M22 4h-6a4 4 0 0 0-4 4v13a3 3 0 0 1 3-3h7z"/>',
  mailIn: '<path d="M22 13h-6l-2 3h-4l-2-3H2"/><path d="M5.5 6.1 2 13v5a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-5l-3.5-6.9"/><path d="M12 2v8M9 7l3 3 3-3"/>',
  skip: '<path d="m5 4 10 8-10 8z"/><path d="M19 5v14"/>',
  bulb: '<path d="M9 18h6M10 22h4"/><path d="M12 2a7 7 0 0 0-4 12.7c.6.5 1 1.3 1 2.1V18h6v-1.2c0-.8.4-1.6 1-2.1A7 7 0 0 0 12 2z"/>',
  trendUp: '<path d="m22 7-8.5 8.5-5-5L2 17"/><path d="M16 7h6v6"/>',
  phone: '<rect x="6" y="2" width="12" height="20" rx="2"/><path d="M11 18h2"/>',
  power: '<path d="M12 2v10"/><path d="M18.4 6.6a9 9 0 1 1-12.8 0"/>',
  sliders: '<path d="M4 21v-7M4 10V3M12 21v-9M12 8V3M20 21v-5M20 12V3M1 14h6M9 8h6M17 16h6"/>',
  calendar: '<rect x="3" y="4" width="18" height="18" rx="2"/><path d="M16 2v4M8 2v4M3 10h18"/>',
  calendarCheck: '<rect x="3" y="4" width="18" height="18" rx="2"/><path d="M16 2v4M8 2v4M3 10h18M9 16l2 2 4-4"/>',
  eraser: '<path d="m7 21-4.3-4.3a1 1 0 0 1 0-1.4l10-10a1 1 0 0 1 1.4 0l5.6 5.6a1 1 0 0 1 0 1.4L11 21z"/><path d="M22 21H7M5 11l9 9"/>',
  save: '<path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z"/><path d="M17 21v-8H7v8M7 3v5h8"/>',
  cpu: '<rect x="5" y="5" width="14" height="14" rx="2"/><rect x="9" y="9" width="6" height="6"/><path d="M9 2v3M15 2v3M9 19v3M15 19v3M2 9h3M2 15h3M19 9h3M19 15h3"/>',
  gauge: '<path d="m12 14 4-4"/><path d="M3.3 19a10 10 0 1 1 17.4 0"/>',
  idcard: '<rect x="2" y="5" width="20" height="14" rx="2"/><circle cx="8" cy="11" r="2"/><path d="M5 16a3 3 0 0 1 6 0M14 10h5M14 14h3"/>',
  profile: '<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><path d="M14 2v6h6"/><circle cx="12" cy="13" r="2"/><path d="M8 19a4 4 0 0 1 8 0"/>',
  building: '<rect x="4" y="2" width="16" height="20" rx="2"/><path d="M9 22v-4h6v4M8 6h.01M12 6h.01M16 6h.01M8 10h.01M12 10h.01M16 10h.01M8 14h.01M12 14h.01M16 14h.01"/>',
  userEdit: '<circle cx="9" cy="8" r="4"/><path d="M2 21v-1a6 6 0 0 1 6-6h3"/><path d="M19.5 13.5a1.6 1.6 0 0 1 2.3 2.3L17 20.6l-3 .7.7-3z"/>',
  eyeOff: '<path d="M9.9 4.2A10.9 10.9 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.2 3.2M6.6 6.6A18.5 18.5 0 0 0 1 12s4 8 11 8a10.9 10.9 0 0 0 5.4-1.4"/><path d="M14.1 14.1a3 3 0 1 1-4.2-4.2M1 1l22 22"/>',
  layers: '<path d="m12 2 10 5-10 5L2 7z"/><path d="m2 17 10 5 10-5M2 12l10 5 10-5"/>',
  robot: '<rect x="4" y="8" width="16" height="12" rx="2"/><path d="M12 8V5M9 13h.01M15 13h.01M9 17h6"/><circle cx="12" cy="4" r="1"/>',
};
export const icon = (n, s = 16) => `<svg width="${s}" height="${s}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${P[n] || ''}</svg>`;

export function toast(msg, err = false) {
  const t = document.createElement('div');
  t.className = 'toast' + (err ? ' err' : '');
  t.textContent = msg;
  $('#toasts').append(t);
  setTimeout(() => t.remove(), err ? 7000 : 3500);
}

// Modals close only via the X button or Esc (never on backdrop click), so typed input is never lost.
const stack = [];
// Esc closes the top dialog only (not the task drawer behind it).
document.addEventListener('keydown', e => { if (e.key === 'Escape' && stack.length) { e.stopImmediatePropagation(); stack.at(-1).close(); } });
export function modal({ title, body, footer = '', size = '', onClose }) {
  const o = document.createElement('div');
  o.className = 'overlay';
  o.innerHTML = `<div class="modal ${size}" role="dialog" aria-modal="true"><header><h2>${esc(title)}</h2>
    <button class="iconbtn x" aria-label="Close">${icon('x')}</button></header><div class="mb">${body}</div>${footer ? `<footer>${footer}</footer>` : ''}</div>`;
  document.body.append(o);
  let closed = false;
  const m = { el: o, close(silent) { if (closed) return; closed = true; o.remove(); stack.splice(stack.indexOf(m), 1); if (!silent) onClose?.(); } };
  stack.push(m);
  $('.x', o).onclick = () => m.close();
  return m;
}
/** Close the dialog holding this element, when a click in it navigates elsewhere. */
export function closeModalOf(el) { const m = stack.find(x => x.el.contains(el)); m?.close(true); }
export function confirmBox(title, html, okLabel = 'Confirm') {
  return new Promise(res => {
    const m = modal({ title, size: 'small', body: `<p style="margin:12px 0">${html}</p>`,
      footer: `<div class="btnrow"><button class="btn primary ok">${esc(okLabel)}</button><button class="btn ghost no">Cancel</button></div>`,
      onClose: () => res(false) });
    $('.ok', m.el).onclick = () => { m.close(true); res(true); };
    $('.no', m.el).onclick = () => m.close();
  });
}
export function promptBox(title, label, { value = '', okLabel = 'Save', type = 'text', placeholder = '' } = {}) {
  return new Promise(res => {
    const field = type === 'textarea' ? `<textarea rows="3" class="pv" placeholder="${esc(placeholder)}">${esc(value)}</textarea>` : `<input type="${type}" class="pv" value="${esc(value)}" placeholder="${esc(placeholder)}">`;
    const m = modal({ title, size: 'small', body: `<label class="f">${esc(label)}</label>${field}`,
      footer: `<div class="btnrow"><button class="btn primary ok">${esc(okLabel)}</button><button class="btn ghost no">Cancel</button></div>`, onClose: () => res(null) });
    const inp = $('.pv', m.el); inp.focus();
    $('.ok', m.el).onclick = () => { m.close(true); res(inp.value); };
    $('.no', m.el).onclick = () => m.close();
  });
}

// ---------- loading and drawing ----------
/** Only the newest of overlapping loads is drawn: an older answer landing late is dropped. A failure of the newest goes to fail.
 *  draw and fail get the call's own arguments after the answer or the error. */
export function latest(load, draw, fail = e => console.error(e)) {
  let n = 0;
  return async (...a) => {
    const k = ++n;
    try { const r = await load(...a); if (k === n) draw(r, ...a); } catch (e) { if (k === n) fail(e, ...a); }
  };
}
/** Runs fn once the calls have stopped for ms. */
export const debounce = (fn, ms = 150) => { let t; return (...a) => { clearTimeout(t); t = setTimeout(() => fn(...a), ms); }; };
/** What could not be loaded, where it would have been: an empty-state box, or a red line. */
export const errorBox = (e, line = false) => line ? `<p class="red">${esc(e?.message || e)}</p>` : `<div class="empty">${esc(e?.message || e)}</div>`;
/** A colour from data, only as a plain hex colour: anything else could break out of its style attribute. */
export const safeColor = (c, dflt = '#0b7285') => /^#[0-9a-f]{3,8}$/i.test(String(c || '')) ? c : dflt;
/** The buttons of a .seg filter, from [key, label, colour, count] rows; the current one is on. */
export const segButtons = (items, current) => items.map(([k, l, c, n]) => `<button data-v="${esc(k)}" style="--c:${safeColor(c)}" class="${current === k ? 'on' : ''}"><i></i>${esc(l)} <span class="num">${n}</span></button>`).join('');

// ---------- your preferences: the app opens as you left it ----------
// Dark mode, the screen you were on, filters, sorts, tabs. Kept three ways, so closing the app, a crash or an update never
// loses them: with your data (the server hands them to the page, see index.html), in a cookie, and in local storage.
// Each copy carries the time it was written (_at); the newest wins and the others fill in what it lacks.
const COOKIE = 'mandata_prefs';
const PREFS = (() => {
  const legacy = {};
  try { for (let i = 0; i < localStorage.length; i++) { const k = localStorage.key(i); if (k?.startsWith('tm_') && k !== 'tm_prefs') try { legacy[k.slice(3)] = JSON.parse(localStorage.getItem(k)); } catch {} } } catch {}
  let local = {}, cookie = {};
  try { local = JSON.parse(localStorage.getItem('tm_prefs')) || {}; } catch {}
  try { const c = document.cookie.split('; ').find(s => s.startsWith(COOKIE + '=')); if (c) cookie = JSON.parse(decodeURIComponent(c.slice(COOKIE.length + 1))) || {}; } catch {}
  const all = [legacy, local, cookie, window.MANDATA_PREFS || {}].filter(o => o && typeof o === 'object' && !Array.isArray(o));
  return Object.assign({}, ...all.sort((a, b) => (a._at || 0) - (b._at || 0)));
})();
let saving = null, keeping = null;
function savePrefs() {
  PREFS._at = Date.now();
  // A burst of changes (typing in a search box) writes the browser's copies once, when it pauses.
  clearTimeout(keeping); keeping = setTimeout(() => { keeping = null; keepLocal(); }, 150);
  clearTimeout(saving);
  saving = setTimeout(sendPrefs, 300);
}
/** The two copies in the browser, written again as the page opens so all three agree. */
function keepLocal() {
  const json = JSON.stringify(PREFS);
  try { localStorage.setItem('tm_prefs', json); } catch {}
  // A cookie holds about 4 KB: a bigger set lives in the other two copies only.
  const enc = encodeURIComponent(json);
  try { document.cookie = enc.length < 3800 ? `${COOKIE}=${enc}; max-age=315360000; path=/; samesite=strict` : `${COOKIE}=; max-age=0; path=/`; } catch {}
}
keepLocal();
// The server's copy is the one that survives everything: one older than the browser's (the app closed before it was sent) catches up.
if ((PREFS._at || 0) > ((window.MANDATA_PREFS || {})._at || 0)) saving = setTimeout(sendPrefs, 300);
function sendPrefs() {
  clearTimeout(saving); saving = null;
  fetch('/api/prefs', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ prefs: PREFS }), keepalive: true }).catch(() => {});
}
// Leaving or reloading the page sends what is still waiting.
addEventListener('pagehide', () => { if (keeping) { clearTimeout(keeping); keeping = null; keepLocal(); } if (saving) sendPrefs(); });
export function pref(key, dflt) { const v = PREFS[key]; return v === undefined ? dflt : v; }
export function setPref(key, value) {
  if (JSON.stringify(PREFS[key]) === JSON.stringify(value)) return;
  if (value === undefined) delete PREFS[key]; else PREFS[key] = value;
  savePrefs();
}

/** An exported PDF: the server saved it in Documents\Mandata reports and opened it. */
export const pdfSaved = r => toast(`Saved to Documents, Mandata reports, and opened in a new tab: ${r.file.split(/[\\/]/).pop()}`);

/** Show a spinner on the button while `fn` runs; errors become a red toast. */
export async function busy(btn, fn) {
  const html = btn.innerHTML; btn.disabled = true; btn.innerHTML = `<span class="spin"></span> ${esc(btn.dataset.busy || 'Working')}`;
  try { return await fn(); } catch (e) { toast(e.message, true); } finally { if (btn.isConnected) { btn.disabled = false; btn.innerHTML = html; } }
}
